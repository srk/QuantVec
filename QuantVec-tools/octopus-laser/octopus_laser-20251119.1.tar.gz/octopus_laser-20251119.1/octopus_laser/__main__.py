# -*- coding: utf-8 -*-


"""octopus_laser.__main__: executed when octopus_laser directory is called as script."""


from .octopus_laser import main
main()
# -*- coding: utf-8 -*-
"""
Steven R Kirk and Samantha Jenkins 2025
@author: stevenrkirk@gmail.com
Octopus_laser
=============
Generate files of Electric field vs. time for multiple direction components, for input into OCTOPUS
time-dependent propagation runs.
"""
import argparse,configparser,os,sys,math
import numpy as np
from math import *

__version__ = "20251119.0001"

def checkconfig(configfile):  # check if a config file exists, build a template in current directory if needed
    """
    Check that a config file exists.
    If not, build an example 'octopus_laser.cfg', direct the user to customise that, then exit
    """
    if (os.path.isfile(configfile)):
        print('Found a octopus_laser configuration file: {0}'.format(configfile))
    else:
        with open('octopus_laser.cfg','w') as f:
            f.write('[Timespan]\n')
            f.write('# Specify the complete span of time for generating field values\n')
            f.write('# The user is responsible for units! (Octopus by default uses atomic units)\n')            
            f.write('# Time start\n')
            f.write('time_start = 0.0\n')
            f.write('# Time end\n')
            f.write('time_end = 100.0\n')
            f.write('# Time step\n')
            f.write('time_step = 0.1\n')
            f.write('\n')
            f.write('# You can have multiple field block definitions after here with different names\n')
            f.write('# Field expressions can use time \'t\' , Python math module functions, Numpy functions [as np.name() ] and named parameters\n')
            f.write('# Separate the field definitions by a blank line, comment characters (#) are allowed\n')
            f.write('# e.g.\n')
            f.write('\n')            
            f.write('[Field_1]\n')
            f.write('# A descriptive name for this field\n')            
            f.write('name = Test field\n')
            f.write('# Start time of the field\n')            
            f.write('t_start = 0.0\n')
            f.write('# Time when this field ends\n')            
            f.write('t_end = 10.0\n')
            f.write('# List of named parameters (variable=value), comma-separated, quote-delimited. Can be an empty string.\n')            
            f.write('params = "w=0.205,cep=30,p=1,peakamp=0.01"\n')
            f.write('# Expression for amplitude vs. time t . Can use Python math module functions and named parameters\n')            
            f.write('amp = peakamp*(sin(0.2*w*t)**2)\n')
            f.write('# Expressions for the x-,y- and z- components of the field\n')            
            f.write('fx = cos((w*t)+(cep*pi/180.0))\n')
            f.write('fy = p*sin((w*t)+(cep*pi/180.0))\n')
            f.write('fz = 0.0\n')
            f.write('# Specification of the user-chosen x-, y-, z- axes for the field in simulation (lab) coordinates\n')
            f.write('xdir = [1.0,0.0,0.0]\n')
            f.write('ydir = [0.0,1.0,0.0]\n')
            f.write('zdir = [0.0,0.0,1.0]\n')
            f.write('# End of this field block\n')
            f.write('\n')
            f.write('# more field definition blocks here if needed\n')                        
           
        print('ERROR: No octopus_laser.cfg file was found in this directory!')
        print('       An example octopus_laser.cfg file has been created for you.')
        print('       Edit this and customize it before running octopus_laser again')
        sys.exit()

class field:
    '''
    Field object class
    '''
    def __init__(self,name,ampexprstring,fx_exprstring,fy_exprstring,fz_exprstring,
                 tstart, tstop, xdir,ydir,zdir,paramstring):
        '''
        Initialize the properties of the field object
       '''
        self.name = name
        self.ampexprstring = ampexprstring.strip('\"\' ')
        if self.ampexprstring == '':
            print('Error: Amplitude expression is empty')
            sys,exit()
        self.fx_exprstring = fx_exprstring.strip('\"\' ')
        if self.fx_exprstring == '':
            print('Error: F(x) expression is empty') 
            sys.exit()       
        self.fy_exprstring = fy_exprstring.strip('\"\' ')
        if self.fy_exprstring == '':
            print('Error: F(y) expression is empty')
            sys.exit()        
        self.fz_exprstring = fz_exprstring.strip('\"\' ')
        if self.fz_exprstring == '':
            print('Error: F(z) expression is empty') 
            sys.exit()       
        self.tstart = float(tstart)
        self.tstop = float(tstop)
        self.xdir = np.array(xdir)
        self.ydir = np.array(ydir)
        self.zdir = np.array(zdir)
        self.constants = {}
        # build a dictionary of user-defined constants
        for pair in paramstring.strip('\"\'').split(','):
            #print('pair = {0}'.format(pair))
            if len(pair.strip()) > 0:
                #print(pair)
                key, value = pair.split('=')
                self.constants[key.strip()] = float(value.strip())

    def show(self):
        '''
        Print the specification of the field object
        '''
        print('FIELD: {0}'.format(self.name))
        print('Amplitude expression: {0}'.format(self.ampexprstring))
        print('Field x-component   : {0}'.format(self.fx_exprstring)) 
        print('Field y-component   : {0}'.format(self.fy_exprstring))
        print('Field z-component   : {0}'.format(self.fz_exprstring))                
        print('         Start time : {0}'.format(self.tstart))
        print('          Stop time : {0}'.format(self.tstop))
        print(' Global x-direction : {0}'.format(self.xdir))
        print(' Global y-direction : {0}'.format(self.ydir)) 
        print(' Global z-direction : {0}'.format(self.zdir)) 
        print('         Parameters : {0}'.format(self.constants))                             

    def fieldeval(self,t):
        '''
        Evaluate field components field_x, field_y, field_z as a function of time
        '''
        fx = 0.0
        fy = 0.0
        fz = 0.0
        funcfield = np.array([0.0,0.0,0.0],dtype=np.float64)              
        xfunc = self.string_to_function(self.fx_exprstring)
        yfunc = self.string_to_function(self.fy_exprstring)
        zfunc = self.string_to_function(self.fz_exprstring)

        ampfunc = self.string_to_function(self.ampexprstring)
        amp = ampfunc(t)
        #print('=======')
        #print('t = {0}'.format(t))
        #print('xfunc expression = {0} = {1}'.format(self.fx_exprstring,xfunc(t)))
        #print('yfunc expression = {0} = {1}'.format(self.fy_exprstring,yfunc(t)))
        #print('zfunc expression = {0} = {1}'.format(self.fz_exprstring,zfunc(t)))
        #print('ampfunc expression = {0} = {1}'.format(self.ampexprstring,ampfunc(t)))
        if t >= self.tstart and t <= self.tstop:        
            funcfield =   (amp*xfunc(t)*self.xdir) \
                        + (amp*yfunc(t)*self.ydir) \
                        + (amp*zfunc(t)*self.zdir)
        #print('funcfield = {0}'.format(funcfield))            
        return funcfield
    
    def string_to_function(self,expression):
        def function(t):
            '''
            Return value of the function
            '''
            dict_t = {"t": t}
            #print('Expression = {0}'.format(expression))
            #print(self.constants)
            try:
                result = eval(expression,globals(),self.constants | dict_t)
            except:
                print('An exception occurred in eval() evaluating expression \'{0}\''.format(expression))
                sys.exit()
            return result
            
        # 1 input, 1 output ufunc
        return np.frompyfunc(function, 1, 1)

# MAIN

def main():
    print('-------------')
    print('octopus_laser')
    print('-------------')
    print('octopus_laser version = {0}'.format(__version__))
    print(' ')    
    # parse command-line arguments
    parser = argparse.ArgumentParser(description='Generate field vs time tabulated data for OCTOPUS')
    parser.add_argument("configfile",help="File containing configuration data",default="octopus_laser.cfg")
    parser.add_argument("prefix", help="Filename prefix for field vs. t data",default='laser')
    parser.add_argument("--verbose",help="Show more verbose screen output",action='store_true')
    parser.add_argument("--onefile",help="Write all field values in one file",action='store_true')
    args = parser.parse_args()
    verbose = args.verbose
    onefile = args.onefile
    #
    configfile = os.path.abspath(args.configfile)
    checkconfig(configfile)
    prefix = args.prefix
    #fs = 41.34137378956

    # parse config file
    config = configparser.ConfigParser()
    config.read(configfile)
    t_start = float(config['Timespan']['time_start'])
    t_end = float(config['Timespan']['time_end'])    
    t_step = float(config['Timespan']['time_step'])
    fieldlist = []
    for s in config.sections():
        if s != 'Timespan':  # then it is a Field section
            thisf = field(config[s]['name'], config[s]['amp'],config[s]['fx'],config[s]['fy'],config[s]['fz'],
                          config[s]['t_start'],config[s]['t_end'],
                          [float(a) for a in config[s]['xdir'].strip('[]').split(',')],
                          [float(b) for b in config[s]['ydir'].strip('[]').split(',')],
                          [float(c) for c in config[s]['zdir'].strip('[]').split(',')],
                          config[s]['params'])
            fieldlist.append(thisf)
    # show
    if verbose:
        print('Loaded the field objects\n')
        for fobj in fieldlist:
            fobj.show()
            print()
        print('End of field object list')
    print()
#
    print('Start time: {0}'.format(t_start))
    print('  End time: {0}'.format(t_end))
    print(' Time step: {0}'.format(t_step))
    numsteps = int((t_end-t_start)/t_step) + 1
    print('Writing {} values'.format(numsteps))
    # create files called <prefix>_x, <prefix>_y, <prefix>_z
    if (onefile): # all columns in a single file
        with open(prefix,'w') as f:
            t = t_start
            while t <= t_end :
                efx = 0.0 
                efy = 0.0
                efz = 0.0
                for i in fieldlist:  # add contributions to the total field 
                    fi = i.fieldeval(t)
                    efx = efx + fi[0]
                    efy = efy + fi[1]
                    efz = efz + fi[2]
                # format is: time, E_x, E_y, E_z    
                f.write('{0:14.10f}  {1:14.10f} {2:14.10f} {3:14.10f} \n'.format(t,efx,efy,efz))
                t = t + t_step
    else: # separate files
        with open(prefix+'_x','w') as fx, open(prefix+'_y','w') as fy, open(prefix+'_z','w') as fz:
            t = t_start
            while t <= t_end :
                efx = 0.0 
                efy = 0.0
                efz = 0.0
                for i in fieldlist:  # add contributions to the total field 
                    fi = i.fieldeval(t)
                    efx = efx + fi[0]
                    efy = efy + fi[1]
                    efz = efz + fi[2]
                # format is: time, real part, imaginary part    
                fx.write('{0:14.10f} {1:14.10f} {2:14.10f}\n'.format(t,efx,0.0))
                fy.write('{0:14.10f} {1:14.10f} {2:14.10f}\n'.format(t,efy,0.0))
                fz.write('{0:14.10f} {1:14.10f} {2:14.10f}\n'.format(t,efz,0.0))
                t = t + t_step        
    print('Done')     
    
if __name__ == '__main__':
    main()
    
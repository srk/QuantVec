# -*- coding: utf-8 -*-
"""setup.py: setuptools control."""

import re
from setuptools import setup

version = re.search(
    '^__version__\s*=\s*"(.*)"',
    open('octopus_laser/octopus_laser.py').read(),
    re.M
    ).group(1)

setup(
    name = "octopus_laser",
    packages = ["octopus_laser"],
    entry_points = {
        "console_scripts": ['octopus_laser=octopus_laser.octopus_laser:main',]
        },
    version = version,
    author='Prof. Steven R. Kirk',
    author_email='stevenrkirk@gmail.com',
    description = "octopus_laser",
    url = 'https://www.beaconresearch.org',
    )

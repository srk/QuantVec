octopus_laser (will rename this as 'multilaser' later)
Steven R. Kirk, Samantha Jenkins 2025
======================================================

Main code is in octopus_laser/octopus_laser.py

Can be directly installed from the base directory using: 'pip install . '

Usage: octopus_laser <cfg file with duration and field definitions> <prefix>
Example: octopus_laser test.cfg laser

generates 3 files, laser_x, laser_y, laser_z

with columns for time, real part of field, imaginary part of field (the latter is not used at the moment, just set to 0.0)

If the code is run without specifying a .cfg file, an example .cfg file will be generated. This can be renamed/modified to
match the user's needs.

Time and field definitions in the '.cfg' file, written according to the standard for
the built-in Python module 'configparser'. The code uses Python's expression parser
to evaluate expressions defined at *run-time* in the user-generated .cfg file.

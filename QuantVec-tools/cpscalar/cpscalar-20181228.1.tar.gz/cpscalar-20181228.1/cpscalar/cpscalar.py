#!/usr/bin/python
# -*- coding: utf-8 -*-
"""
cpscalar
========
Show the scalar values associated with a specific critical point, 
for one (or a list of) input .sumviz/.sum file(s).
Parameters for --vals:
            'rho'=Charge density, 'lap'=Laplacian, 'ellip'=ellipticity, 'metal'=metallicity
            'stiff' and 'stress_stiff' are the conventional and stress tensor stiffnesses
            'pol' and 'stress_pol' are the conventional and stress tensor polarizabilities
            'stress_ellip' and 'stress_ellip_hessrho' are the conventional and hessrho stress tensor ellipticities
            'H','V','G','K' and 'L' are the correspondingly named energy densities
            'bpl' and 'gbl' are the bond path length and the distance between nuclei (GBL_II)
            'curv' is bpl-gbl
            'stress_ellip' is stress tensor ellipticity = | lambda2/lambda1 |- 1
            
Multiple parameters may appear, in any order, separated by spaces
Output columns are in the same order as the parameters.

Examples:
python cpscalar.py myfile.sumviz C1 C2 --vals rho lap metal H
python cpscalar.py filelist.txt C1 C2 --vals H stiff pol

Authors: Steven Kirk (stevenrkirk@gmail.com)
         Samantha Jenkins (samanthajsuman@gmail.com)
         Xu Tianlv (xutl@hunnu.edu.cn)
Bug fixes: 20171029 (discovered by Jiahui)
           20180518 (discovered by Alireza)
           20180706 (SRK)
           20181228 (Tianlv - stress tensor ellipticity added)
"""

# Python 2 compatibility shims
from __future__ import print_function, division
__version__ = "20181228.0001"

from builtins import input
import sys,os,math,copy,argparse
import numpy as np

import molgraph as mg
import beacon_utils as bu

def sortlabel(instring):
    """
    Generate a CP label with the atom order sorted alphabetically, separated by '-'
    """
    tokens=instring.split("-")
    tokens.sort()
    return("-".join(tokens))

def main():
    print(__doc__)
    parser = argparse.ArgumentParser(description='Show critical point scalar values')
    parser.add_argument("infile", help="Name of input file, or file containing list of input filenames")
    parser.add_argument("atom_1_name", help="First atom specifying BCP of interest")
    parser.add_argument("atom_2_name", help="Second atom specifying BCP of interest")
    parser.add_argument("--vals", help="Scalar values to display",
                                  nargs="+",
                                  choices=['rho','lap','ellip','H','V','G','K','L',
                                           'metal','stiff','stress_stiff',
                                           'stress_ellip','stress_ellip_hessrho',
                                           'pol','stress_pol',
                                           'bpl','gbl','curv','stress_ellip'],
                                  default=['ellip'])
    args = parser.parse_args()
    fname = args.infile
    atom1 = args.atom_1_name
    atom2 = args.atom_2_name
    vals = args.vals

    # main program starts here
    for line in bu.repheader():
        print(line)
    print("Found molgraph module version {}".format(mg.__version__))
    print("Found beacon_utils module version {}".format(bu.__version__))
    print("VERSION "+__version__)
    print("")

    # construct the list of files to be examined
    index = fname.rfind('.')
    extension = fname[index:]
    print('Input file extension is {0}'.format(extension))
    if (fname.endswith('.sumviz') or fname.endswith('.sum')): # single .sumviz/.sum file
        print('Input file {0} is a .sumviz/.sum file, calculating for this file only'.format(fname))
        filelist = []
        filelist.append(fname)
    else:                                                     # list of .sumviz/.sum file names
        print('Assuming input file contains a list of .sumviz/.sum file names')
        f = open(fname)
        filelist = f.readlines()
        f.close()

    # read selected atoms
    searched_bcplabel = sortlabel(atom1+'-'+atom2)
    print('Searching for BCP {0}'.format(searched_bcplabel))
    print('=================')
    headings = 'Filename : CP_name: '+':'.join(vals)
    print(headings)
    filecount = 0

    # remove any blank lines or comment lines from filelist
    newfilelist = []
    for line in filelist:
        if ( not (line.strip() == '' or line.startswith('#')) ):
            newfilelist.append(line)
    for infile in newfilelist:  # loop over files named in sequence, load each MG
        filecount = filecount + 1
        infile = infile.strip()
        thismg = mg.Molgraph()
        thismg.read(infile)
        # Sort the CP labels
        for cp in thismg.cplist:
            cp.connected = sortlabel(cp.connected)
        # find the quantity for this input file and the requested BCP
        cpfound = False
        for cp in thismg.cplist:
            if (cp.type == 'BCP' and searched_bcplabel == cp.connected):  # found the BCP of interest
                cpfound = True
                props=[]
                for chosenval in vals:
                    if chosenval == 'rho':      # total charge density
                        props.append(': {0}'.format(cp.Rho))
                    elif chosenval == 'lap':    # Laplacian
                        props.append(': {0}'.format(cp.DelSqRho))
                    elif chosenval == 'ellip':  # Ellipticity
                        props.append(': {0}'.format(cp.Ellipticity))
                    elif chosenval == 'H':      # H
                        props.append(': {0}'.format(-1.0*cp.K))
                    elif chosenval == 'V':      # V
                        props.append(': {0}'.format(cp.V))
                    elif chosenval == 'G':      # G
                        props.append(': {0}'.format(cp.G))
                    elif chosenval == 'K':      # K (=-H)
                        props.append(': {0}'.format(cp.K))
                    elif chosenval == 'L':      # L
                        props.append(': {0}'.format(cp.L))
                    elif chosenval == 'bpl':    # Bond path length
                        props.append(': {0}'.format(cp.BPL))
                    elif chosenval == 'metal':  # metallicity
                        number = cp.Rho/cp.DelSqRho
                        props.append(': {0}'.format(number))
                    elif chosenval == 'stiff':  # Rho stiffness
                        number = math.fabs(cp.HessRho_EigVals[1])/cp.HessRho_EigVals[2]
                        props.append(': {0}'.format(number))
                    elif chosenval == 'stress_stiff':  # Stress tensor stiffness
                        number = math.fabs(cp.Stress_EigVals[0]/cp.Stress_EigVals[2])
                        props.append(': {0}'.format(number))
                    elif chosenval == 'pol':    # Polarizability
                        number = cp.HessRho_EigVals[2]/math.fabs(cp.HessRho_EigVals[1])
                        props.append(': {0}'.format(number))
                    elif chosenval == 'stress_pol':  # Stress polarizability
                        number = math.fabs(cp.Stress_EigVals[2]/cp.Stress_EigVals[0])
                        props.append(': {0}'.format(number))
                    elif chosenval == 'stress_ellip':  # Stress ellipticity
                        number = math.fabs(cp.Stress_EigVals[1]/cp.Stress_EigVals[0])- 1.0
                        props.append(': {0}'.format(number))
                    elif chosenval == 'stress_ellip_hessrho':  # Stress ellipticity
                        number = math.fabs(cp.Stress_EigVals[0]/cp.Stress_EigVals[1])- 1.0
                        props.append(': {0}'.format(number))
                    elif chosenval == 'gbl':  # Geometric bond length (distance between nuclei = GBL_II)
                        number = cp.GBL_II
                        props.append(': {0}'.format(number))
                    elif chosenval == 'curv':  # Bond curvature = BPL - GBL_II
                        number = cp.BPL - cp.GBL_II
                        props.append(': {0}'.format(number))
                    elif chosenval == 'stress_ellip':  # stress ellipticity
                        number = math.fabs(cp.Stress_EigVals[1]/cp.Stress_EigVals[0]) - 1.0
                        props.append(': {0}'.format(number))
                dataline = ''.join(props)
                print('{0}'.format(infile+' :'+searched_bcplabel+' '+dataline))
        if (not cpfound):  # BCP not found
            print('BCP {0} not found in {1}'.format(searched_bcplabel,infile)) 
    #
    print('Program exiting')

if __name__ == "__main__":
    main()

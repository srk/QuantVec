# -*- coding: utf-8 -*-
"""setup.py: setuptools control."""

import re
from setuptools import setup

version = re.search(
    r'^__version__\s*=\s*"(.*)"',
    open('cpscalar/cpscalar.py').read(),
    re.M
    ).group(1)

setup(
    name = "cpscalar",
    packages = ["cpscalar"],
    entry_points = {
        "console_scripts": ['cpscalar=cpscalar.cpscalar:main',]
        },
    version = version,
    author='Prof. Steven R. Kirk',
    author_email='stevenrkirk@gmail.com',
    description = "cpscalar",
    url = 'https://www.beaconresearch.org',
    )

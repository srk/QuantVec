#!/usr/bin/python
# -*- coding: utf-8 -*-
"""
cpscalar
========
Show the scalar values associated with a specific critical point, 
for one (or a list of) input .sumviz/.sum file(s).
Parameters for --vals:
            'rho'=Charge density, 'lap'=Laplacian, 'ellip'=ellipticity, 'metal'=metallicity
            'stiff' and 'stress_stiff' are the conventional and stress tensor stiffnesses
            'pol' and 'stress_pol' are the conventional and stress tensor polarizabilities
            'stress_ellip' and 'stress_ellip_hessrho' are the conventional and hessrho stress tensor ellipticities
            'H','V','G','K' and 'L' are the correspondingly named energy densities
            'bpl' and 'gbl' are the bond path length and the distance between nuclei (GBL_II)
            'curv' is bpl-gbl
            'stress_ellip' is stress tensor ellipticity = | lambda2/lambda1 |- 1
            'L1','L2','L3' and 'L1s','L2s','L3s' are raw eigenvalues of Hess(Rho) and the stress tensor
            
Multiple parameters may appear, in any order, separated by spaces
Output columns are in the same order as the parameters.

Examples:
cpscalar myfile.sumviz C1 C2 --vals rho lap metal H
cpscalar filelist.txt C1 C2 --vals H stiff pol L3s

Authors: Steven Kirk (stevenrkirk@gmail.com)
         Samantha Jenkins (samanthajsuman@gmail.com)
         Xu Tianlv (xutl@hunnu.edu.cn)
Bug fixes: 20171029 (discovered by Jiahui)
           20180518 (discovered by Alireza)
           20180706 (SRK)
           20181228 (Tianlv - stress tensor ellipticity added)
           20200511 (Added explicit L1,L2,L3,L1s,L2s,L3s eigenvalues)
"""

# Python 2 compatibility shims
from __future__ import print_function, division
from builtins import input
import sys,os,math,copy,argparse,csv
import numpy as np

import molgraph as mg
import beacon_utils as bu

__version__ = "20251106.0001"

def csvdump(csvfile,header,data):
    """
    Dump a CSV file to specified filename 'csvfile'
    Start file with list of header line strings
    Continue with 'data' lines (list of lists)
    Close file after creation
    Uses builtin 'csv' module
    """
    if not csvfile == 'none':
        with open(csvfile,'w',newline='') as csvf:
            csvwriter = csv.writer(csvf, dialect='excel',delimiter=',',quotechar='"', quoting=csv.QUOTE_NONNUMERIC)
            for line in header:
                csvwriter.writerow(['#'+line])
            for row in data:               
                csvwriter.writerow(row)

def sortlabel(instring):
    """
    Generate a CP label with the atom order sorted alphabetically, separated by '-'
    """
    if "-" in instring:
        tokens=instring.split("-")
        tokens.sort()
        return("-".join(tokens))
    elif " " in instring:
        tokens=instring.split()
        tokens.sort()
        return(" ".join(tokens))
    else:
        return(instring)        


def cpcrystdist(fr1,o,a,b,c,fr2list):
    """
    Given a (fx,fy,fz) fractional crystal coordinate point fr1 in a crystal cell specified by origin vector o and
    crystal basis vectors a,b,c, return :
    * the index of the best(closest) periodic copy (CPC) to fr1 from a list of other points 'fr2list'
    * CPC cell index (-1,0,1) in a-direction
    * CPC cell index (-1,0,1) in b-direction
    * CPC cell index (-1,0,1) in c-direction
    * The distance 'mindist' between fr1 and the best point  
    """
    mindist = 1.0E6
    r1 = o + (fr1[0]*a)+(fr1[1]*b)+(fr1[2]*c)
    closestfr2 = np.array([0.0,0.0,0.0],dtype=np.float64)
    closesti = 0
    closestj = 0
    closestk = 0
    closest_index = -1
    #print('fr1=',fr1)
    #print('fr2list=',fr2list)
    count = -1
    for fr2 in fr2list:
        count = count+1
        dist = 0.0
        #print('considering periodic copies of ',fr2)
        for i in range(-1,2,1):
            for j in range(-1,2,1):
                for k in range(-1,2,1):
                    testfx = fr2[0]+float(i)
                    testfy = fr2[1]+float(j)
                    testfz = fr2[2]+float(k)
                    r2 = o + (testfx*a)+(testfy*b)+(testfz*c)

                    dr = r2-r1
                    dist = np.sqrt(dr.dot(dr))
                    #print(count,i,j,k,testfx,testfx,testfz,dist)                    
                    if dist < mindist:
                        closestfr2 = fr2
                        closesti = i
                        closestj = j
                        closestk = k
                        mindist = dist
                        closest_index = count
    #print('==')
    #print('Closest point to fractional coordinates ({3},{4},{5}) with Cartesian coordinates ({0},{1},{2}) is'.format(r1[0],r1[1],r1[2],fr1[0],fr1[1],fr1[2]))
    #print('Point number {0} with fractional coordinates ({1},{2},{3})'.format(closest_index,closestfr2[0],closestfr2[1],closestfr2[2]))
    #print('with cell shifts ({0}*a, {1}*b, {2}*c) and absolute distance {3}'.format(closesti,closestj,closestk,mindist) )
    #
    return closest_index, closesti, closestj, closestk, mindist


def getfrac(r,box_o,box_a,box_b,box_c):
    """
    Return an np.array with the fractional coordinates of a Cartesian point
    """
    ox = r[0] - box_o[0]
    oy = r[1] - box_o[1]
    oz = r[2] - box_o[2]
    mod2_a = (box_a[0]*box_a[0])+(box_a[1]*box_a[1])+(box_a[2]*box_a[2])
    mod2_b = (box_b[0]*box_b[0])+(box_b[1]*box_b[1])+(box_b[2]*box_b[2])
    mod2_c = (box_c[0]*box_c[0])+(box_c[1]*box_c[1])+(box_c[2]*box_c[2])
    frac_x = ((box_a[0]*ox)+(box_a[1]*oy)+(box_a[2]*oz))/mod2_a
    frac_y = ((box_b[0]*ox)+(box_b[1]*oy)+(box_b[2]*oz))/mod2_b
    frac_z = ((box_c[0]*ox)+(box_c[1]*oy)+(box_c[2]*oz))/mod2_c
    return np.array([frac_x,frac_y,frac_z],dtype=np.float64)

def getcart(fr,box_o,box_a,box_b,box_c):
    """
    Return an np.array with the Cartesian coordinates of a fractional point fr with
    box_o: np.array containing origin position
    box_a: np.array containing box a-vector
    box_b: np.array containing box b-vector
    box_c: np.array containing box c-vector
    """
    return (box_o + (fr[0]*box_a)+(fr[1]*box_b)+(fr[2]*box_c))

def pathlength(r):
    """
    Returns the cumulative length list of a path r (provided as a list of [x,y,z] triples)
    """
    length = 0.0
    c_length = []
    oldp = r[0]
    for p in r:  # accumulate path length over position list
        dx = p[0] - oldp[0]
        dy = p[1] - oldp[1]
        dz = p[2] - oldp[2]
        length = length + math.sqrt((dx*dx)+(dy*dy)+(dz*dz))
        c_length.append(length)
        oldp = p
    return(length)  # returns array of cumulative lengths for input path r


def main():
    print(__doc__)
    parser = argparse.ArgumentParser(description='Show critical point scalar values')
    parser.add_argument("infile", help="Name of input file, or file containing list of input filenames")
    parser.add_argument("atom_1_name", help="First atom specifying BCP of interest",default='all')
    parser.add_argument("atom_2_name", help="Second atom specifying BCP of interest",default='bcp')
    parser.add_argument("--vals", help="Scalar values to display",
                                  nargs="+",
                                  choices=['rho','lap','ellip','H','V','G','K','L',
                                           'metal','stiff','stress_stiff',
                                           'stress_ellip','stress_ellip_hessrho',
                                           'pol','stress_pol',
                                           'bpl','gbl','curv','stress_ellip','bcpcheck',
                                           'L1','L2','L3','L1s','L2s','L3s'],
                                  default=['ellip'])
    parser.add_argument("--filter",help="Filter mode (default=off)", action='store_true') 
    parser.add_argument("--filteredprefix",help="Prefix for filtered .sumviz files (default='filtered')", default='filtered')
    parser.add_argument("--minrho",help='Minimum value of charge density rho for filtered CPs (default=1e-10)',default='1.0E-10')
    parser.add_argument("--trackthresh",help="CP tracking jump distance threshold (default=0.0)", default=0.0)
    parser.add_argument("--outfile",help="Output filename",default='')
    parser.add_argument("--pbc",help="Periodic boundary conditions should be applied (default=off)", action='store_true',default=False) 
    parser.add_argument("--verbose",help="Verbose output", action='store_true')                               
    args = parser.parse_args()
    fname = args.infile
    atom1 = args.atom_1_name
    atom2 = args.atom_2_name
    searched_bcplabel='-'.join([atom1,atom2])
    original_bcplabel=searched_bcplabel
    vals = args.vals
    isfiltered = args.filter
    pbc = args.pbc
    minrho = float(args.minrho)
    iscrystal = False
    ignoremissing=False
    verbose=args.verbose
    #
    trackthresh=float(args.trackthresh)
    if trackthresh > 0.0: # flag for tracking
        tracker_on = True
    else:
        tracker_on = False
    if isfiltered:
        filteredprefix = args.filteredprefix        
    #
    outfile = args.outfile
    if outfile == '':
        fout = None
    else:
        fout = open(outfile,'w')
        fout.write('# Generated by cpscalar\n')
        fout.write('# Input file is: {0}'.format(os.path.abspath(fname))+'\n')
        fout.write('# Searched CP AS TYPED is {0}'.format(searched_bcplabel)+'\n')
        fout.write('# Output variables:'+'\n')
        fout.write('# {0}'.format('Filename: CP name: CP position: '+': '.join(vals))+'\n')
    listmode = False  

    print('Input file = {0}'.format(fname))
    print('Output file ={0}'.format(outfile))
    print('Specified CP = {0}-{1}'.format(atom1,atom2))
    print('Periodic boundary : {0}'.format(pbc))
    print('Tracking: {0}, tracking threshold = {1}'.format(tracker_on,trackthresh))
    print('Minimum Rho for filtering: {0}'.format(minrho))
    # define a NaN
    nan = float('nan')   

    # main program starts here
    for line in bu.repheader():
        print(line)
    print("Found molgraph module version {}".format(mg.__version__))
    print("Found beacon_utils module version {}".format(bu.__version__))
    print("VERSION "+__version__)
    print("")
    if pbc:
        print("\n*** PERIODIC BOUNDARY CONDITIONS MODE SPECIFIED ***\n")
    if isfiltered:
        print('*** FILTER MODE SPECIFIED ***')
    if tracker_on:
        print("\n*** CP TRACKING MODE SPECIFIED BY CHOOSING trackthresh = {} (>0) ***\n".format(trackthresh))        

    if (atom1 == 'all'):
        searchedtype = atom2.upper()
        print('---- {0} list mode requested with \' all {1} \''.format(searchedtype,atom2))
        listmode = True
        atom1 = ''  
        atom2 = ''

    # construct the list of files to be examined (only one item in single input file case)
    index = fname.rfind('.')
    extension = fname[index:]
    print('Input file extension is {0}'.format(extension))
    if (fname.endswith('.sumviz') or fname.endswith('.sum')): # single .sumviz/.sum file
        print('Input file {0} is a .sumviz/.sum file, calculating for this file only'.format(fname))
        filelist = []
        filelist.append(fname)
    else:                                                     # list of .sumviz/.sum file names
        print('Assuming input file contains a list of .sumviz/.sum file names')
        filelist = []
        with open(fname) as f:
            for line in f:
                if not line.startswith('#'):
                    filelist.append(line)
        print('Input file contains {0} relevant lines'.format(len(filelist)))


    # read selected atoms
    searched_bcplabel = sortlabel(atom1+'-'+atom2)
    original_bcplabel = searched_bcplabel # make a copy of the original BCP label
    print('Searching for BCP {0}'.format(searched_bcplabel))
    if pbc and not listmode:
        symbol1 = atom1.partition('_')[0]  # if atom1 name has a cell code, remove it and store the symbol
        symbol2 = atom2.partition('_')[0]  #  " atom2    "       "
        print('In PBC mode, so will watch all BCPs with names {0}_???-{1}_???'.format(symbol1,symbol2))
        symbol1list = []
        symbol2list = []
        bcpfracs = []
    print('=================')
    headings = 'Filename : CP_name: Coords (X,Y,Z): '+': '.join(vals)
    print(headings)
    filecount = 0


    # remove any blank lines or comment lines from filelist
    newfilelist = []
    for line in filelist:
        if ( not (line.strip() == '' or line.startswith('#')) ):
            newfilelist.append(line)
    # ===========
    # MAIN LOOP OVER MGs, ONE PER FILE
    # ===========
    trackedfr = None
    filecount = 0
    for infile in newfilelist:  # loop over files named in sequence, load each MG
        filecount = filecount + 1
        if filecount == 1:
            isfirstfile = True
        else:
            isfirstfile = False
        infile = infile.strip()
        thismg = mg.Molgraph()
        thismg.read(infile,debug=verbose)
        try:
            thistitle = thismg.title
        except:
            print('ERROR: no title field found in {0}'.format(infile))
            sys.exit()
        #
        if 'CRYSTAL' in thismg.title: # is this a crystal? If so, get o,a,b,c and write to output file header
            iscrystal = True
            tokens = thismg.title.split()
            box_o = np.fromstring(tokens[-4].strip('{}'),sep=',')
            box_a = np.fromstring(tokens[-3].strip('{}'),sep=',')
            box_b = np.fromstring(tokens[-2].strip('{}'),sep=',')
            box_c = np.fromstring(tokens[-1].strip('{}'),sep=',')
            mod_a = math.sqrt((box_a[0]*box_a[0])+(box_a[1]*box_a[1])+(box_a[2]*box_a[2]))
            mod_b = math.sqrt((box_b[0]*box_b[0])+(box_b[1]*box_b[1])+(box_b[2]*box_b[2]))
            mod_c = math.sqrt((box_c[0]*box_c[0])+(box_c[1]*box_c[1])+(box_c[2]*box_c[2]))
            if isfirstfile and fout is not None:
                fout.write('# CRYSTAL DATA from {0}'.format(infile))
                fout.write('# Cell origin: ({0},{1},{2})'.format(box_o[0],box_o[1],box_o[2])+'\n')
                fout.write('# Cell a-vector: ({0},{1},{2}) |a|={3}'.format(box_a[0],box_a[1],box_a[2],mod_a)+'\n')
                fout.write('# Cell b-vector: ({0},{1},{2}) |b|={3}'.format(box_b[0],box_b[1],box_b[2],mod_b)+'\n')
                fout.write('# Cell c-vector: ({0},{1},{2}) |c|={3}'.format(box_c[0],box_c[1],box_c[2],mod_c)+'\n')                           
        else:
            iscrystal = False
            thismg.calculate_gbl()
        #
        # Sort the CP labels in the input file
        for cp in thismg.cplist:          
            cp.connected = sortlabel(cp.connected)

        #
        if pbc and isfirstfile and not listmode:
            # Initialize a trackedcp from first CP exactly matching name
            for eachcp in thismg.cplist:
                if eachcp.connected == searched_bcplabel:
                    trackedcp = copy.deepcopy(eachcp)
                    cart = np.array([eachcp.pos_x,eachcp.pos_y,eachcp.pos_z],dtype=np.float64)
                    trackedfr = getfrac(cart,box_o,box_a,box_b,box_c)
                    break
            if trackedfr is None:  # it doesn't exist even in the first file, exit with error
                print('The specified CP is not found in the first file - exiting')
                sys.exit()

        # find the CP - start assuming it isn't found
        cpfound = False
        cpfilteredmatches = []
        cpmatches = []
        tempcpmatches = []
        #
        # Do we need an frlist? Build one if we do.
        if pbc:
            bcpfrlist = []
            for eachcp in [ cp for cp in thismg.cplist if cp.type == 'BCP']:
                eachcart = np.array([cp.pos_x,cp.pos_y,cp.pos_z],dtype=np.float64)
                eachfrac = getfrac(eachcart,box_o,box_a,box_b,box_c)
                bcpfrlist.append(eachfrac)
            mindist = 1.0E6
            print('Built bcpfrlist with {0} entries'.format(len(bcpfrlist)))
        if listmode:
            print('Currently in list mode')
            
        # -----------------
        for cp in thismg.cplist: # LOOP OVER ALL CPs in this file
            if listmode:
                # If this is listmode just add all matching CPs of type 'searchedtype' to the match list
                if (cp.type == searchedtype and cp.Rho > minrho):
                    cpmatches.append(cp)
                # and then drop through to printing the details
            else: # not listmode, search more specifically
                # CASE 1: not in PBC
                if not pbc:
                    # search first on specified BCP name
                    if (cp.type == 'BCP' and searched_bcplabel == cp.connected and cp.Rho > minrho):
                        cpmatches.append(cp)  # found the CP of interest
                else: # search for a wildcard BCP name 
                    tokens = cp.connected.split('-')
                    if cp.type == 'BCP':
                        if tokens[0].startswith(symbol1) and tokens[1].startswith(symbol2) and cp.Rho > minrho:  # found a possible wildcard match for searched_bcplabel
                            cpmatches.append(cp)                    
        # Finished looping over the CPs, built the match list
        # How many matches were found?
        if not listmode:                    
            ncpmatches = len(cpmatches)
            print('Found {0} matches'.format(ncpmatches))
            #if (ncpmatches > 1) or (ncpmatches < 1): # multiple CP name matches found or none
            if (ncpmatches > 1) : # multiple CP name matches found or none
                if not pbc and ignoremissing == False: # zero or more than 1 match found in a non-periodic system, ask user
                    print('** Multiple CPs (or none) found matching the requested name. If this is a crystal, use the --pbc option ')
                    multlist = []
                    nearestidx = 0
                    thisidx=0
                    nearestdist = 1.0E10
                    for cp in cpmatches:
                        # closest to central axis fix
                        dist=math.sqrt(((cp.pos_x)*(cp.pos_x))+((cp.pos_y)*(cp.pos_y)))
                        if dist < nearestdist:
                            nearestdist = dist
                            nearestidx = thisidx
                        thisidx = thisidx+1
                        multlist.append("{0} {1} {2} {3} {4}".format(cp.connected,cp.pos_x,cp.pos_y,cp.pos_z,cp.Rho))
                    #chosenidx=bu.numbered_menu("Name, Position, Rho: choose a BCP - enter list number",multlist)
                    #print("CHOSEN CP {0} {1}".format(chosenidx,multlist[chosenidx-1]))
                    #chosencp = cpmatches[chosenidx-1]
                    chosencp = cpmatches[nearestidx]
                    cpmatches = [chosencp]
                    ncpmatches = 1
                    
                else:   # so we must be in a periodic system
                    print('trackedfr = {0}'.format(trackedfr))
                    # pick out the BCP to be tracked
                    print('=== {0} Matching BCPs ==='.format(ncpmatches))
                    #print('Possible matches are')
                    bcpfrlist = []
                    for thiscp in cpmatches:
                        eachcart = np.array([thiscp.pos_x,thiscp.pos_y,thiscp.pos_z],dtype=np.float64)
                        eachfrac = getfrac(eachcart,box_o,box_a,box_b,box_c)
                        bcpfrlist.append(eachfrac)
                        #print('{0} Cart {1} Frac {2}'.format(thiscp.connected,str(eachcart),str(eachfrac)))
                        #print('bcpfrlist now has {0} entries'.format(len(bcpfrlist)))
                    # So show all the options
                    #    frlist = []
                    #    othernameslist = []
                    #    cpmatches = []  # rebuild the cpmatches list from scratch
                    #    for cp in thismg.cplist:
                    #        if cp.type == 'BCP':
                    #            tokens = cp.connected.split('-')
                    #            if tokens[0].startswith(symbol1) and tokens[1].startswith(symbol2):
                    #                cpmatches.append(cp)
                    #                cart = np.array([cp.pos_x,cp.pos_y,cp.pos_z],dtype=np.float64)
                    #                if pbc:
                    #                    frac = getfrac(cart,box_o,box_a,box_b,box_c)
                    #                props = []
                    #                props.append(cp.connected)
                    #                props.append(': Cart. ( {0:13.10f} {1:13.10f} {2:13.10f} )'.format(cp.pos_x,cp.pos_y,cp.pos_z))
                    #                if pbc:
                    #                    props.append(': Frac. ( {0:13.10f} {1:13.10f} {2:13.10f} )'.format(frac[0],frac[1],frac[2]))
                    #                    frlist.append(frac)  # build up a list of fracs for all BCPs
                    #                    othernameslist.append(cp.connected)

                    # now find the closest to trackedfr on the full list frlist 
                    print('trackedfr = ',trackedfr)
                    #print('bcpfrlist = ')
                    #for fr in bcpfrlist:
                    #    print(fr)
                    #print('Entering PBC scanner')
                    closest_index, closesti, closestj, closestk, mindist = cpcrystdist(trackedfr,box_o,box_a,box_b,box_c,bcpfrlist)
                    #print('Found something {0} away, index is {1}'.format(mindist,closest_index))
                    trackedcp = cpmatches[closest_index]
                    print('Closest searched equivalent CP is {0}'.format(trackedcp.connected))
                    print('Point number {0} with fractional coordinates ({1},{2},{3})'.format(closest_index,
                                                                                                bcpfrlist[closest_index][0],
                                                                                                bcpfrlist[closest_index][1],
                                                                                                bcpfrlist[closest_index][2]))
                    print('with cell shifts ({0}*a, {1}*b, {2}*c) and absolute distance {3:13.10f}'.format(closesti,
                                                                                                            closestj,
                                                                                                            closestk,
                                                                                                            mindist) )
                    # check if nearest BCP is too far away
                    if mindist > trackthresh:  # closest BCP is too far away
                        print('** WARNING **')
                        print('Original BCP may have disappeared !')
                        print('Distance moved by chosen BCP name between input files = {0} > {1}'.format(mindist,trackthresh))
                        print('Tracked CP fractional coordinates = ',trackedfr)
                        print('was compared with the comparison list')
                        for frac in frlist:
                            print(frac)
                        print ('and the closest in the list was')
                        print('i=',closest_index,'cell numbers = ',closesti,closestj,closestk)
                        print('this one is ',bcpfrlist[closest_index])
                        print('Check your input data and/or set --trackthresh > {0}'.format(mindist))
                        cpfound = False
                        sys.exit()
                    # now we have a replacement, one single match in cpmatches
                    # update the tracked CP name
                    print('So now its {0}'.format(trackedcp.connected))
                    searched_bcplabel = trackedcp.connected                    
                    cpmatches = [trackedcp]
                    print('Tracked CP name updated to {0}'.format(searched_bcplabel))
                    # now update trackedcp with
                    bestfrac = np.array([ float(closesti)+bcpfrlist[closest_index][0],
                                          float(closestj)+bcpfrlist[closest_index][1],
                                          float(closestk)+bcpfrlist[closest_index][2] ],dtype=np.float64) 
                    #cart = np.array([trackedcp.pos_x,trackedcp.pos_y,trackedcp.pos_z],dtype=np.float64)
                    # update the cartesian position of trackedcp
                    newcart = box_o+(bestfrac[0]*box_a)+(bestfrac[1]*box_b)+(bestfrac[2]*box_c)
                    trackedcp.pos_x = newcart[0]
                    trackedcp.pos_y = newcart[1]
                    trackedcp.pos_z = newcart[2]



            else:  # case of a single matching existing CP, ncpmatches = 1
                cpfound = True
                print("Found the matching CP {0}".format(searched_bcplabel))

        #  Copy the CP matches to cpfilteredmatches
        cpfilteredmatches = cpmatches
        if len(cpfilteredmatches) == 0:  # case of no matches
            cpfound = False
            #print(len(vals))
            print('{0}'.format(infile+' : CP not found '+': '*len(vals)))
            if fout is not None:
                fout.write('{0}'.format(infile+' : CP not found '+': '*len(vals)+'\n'))
        # 
        print('=============')
        print(headings)
        # Now print the necessary quantities
        for cp in cpfilteredmatches: # falls through if no cpfilteredmatches?
            cpfound = False
            if (cp.type == 'BCP'):  # found the BCP of interest
                cpfound = True
                props=[]
                props.append(cp.connected)
                props.append(': Cart. ({0:13.10f}, {1:13.10f}, {2:13.10f})'.format(cp.pos_x,cp.pos_y,cp.pos_z))                
                # If a crystal, calculate and print the fractional coordinate
                if (pbc):
                    ox = cp.pos_x - box_o[0]
                    oy = cp.pos_y - box_o[1]
                    oz = cp.pos_z - box_o[2]
                    mod_or = math.sqrt((ox*ox)+(oy*oy)+(oz*oz))
                    frac_x = ((box_a[0]*ox)+(box_a[1]*oy)+(box_a[2]*oz))/(mod_a*mod_a)
                    frac_y = ((box_b[0]*ox)+(box_b[1]*oy)+(box_b[2]*oz))/(mod_b*mod_b)
                    frac_z = ((box_c[0]*ox)+(box_c[1]*oy)+(box_c[2]*oz))/(mod_c*mod_c)
                    props.append(': Frac. ({0:13.10f}, {1:13.10f}, {2:13.10f})'.format(frac_x,frac_y,frac_z))
                    trackedfr = np.array([frac_x,frac_y,frac_z],dtype=np.float64)
                # BPL check
                # check both GBL and BPL
                if 'bcpcheck' in vals:   # recalculate the BPL
                    print('GBL_II and BPL checking ACTIVATED')
                    # Get BCP position
                    bcppos = [cp.pos_x, cp.pos_y, cp.pos_z]
                    print('BCP position: {0}'.format(bcppos))
                    # Get names of NACPs at the ends of the bond
                    tokens = cp.connected.split('-')
                    end1name = tokens[0]  # NACP 1
                    end2name = tokens[1]  # NACP 2
                    # Find which nuclei the NACPs are associated with, regenerate GBL_II if both are associated with nuclei
                    # Also get coordinates of nuclei
                    nucpos1 = []
                    nucpos2 = []
                    print
                    for j in range(0,len(thismg.atom_label)):
                        if thismg.atom_label[j] == end1name: # Atom j matches the end1
                            nucpos1 = [thismg.atom_x[j],thismg.atom_y[j],thismg.atom_z[j]]
                        if thismg.atom_label[j] == end2name:
                            nucpos2 = [thismg.atom_x[j],thismg.atom_y[j],thismg.atom_z[j]]
                    if len(nucpos1) !=0 and len(nucpos2) != 0:  # update GBL_II
                        print('Nucleus 1 position: {0}'.format(nucpos1))
                        print('Nucleus 2 position: {0}'.format(nucpos2))
                        print('Original GBL_II = {0}'.format(cp.GBL_II))
                        cp.GBL_II = pathlength([nucpos1,nucpos2])
                        print(' Updated GBL_II = {0}'.format(cp.GBL_II))
                    #  Get locations of NACPs
                    end1cp = [endcp for endcp in thismg.cplist if endcp.connected==end1name]
                    end2cp = [endcp for endcp in thismg.cplist if endcp.connected==end2name]
                    end1pos = [end1cp[0].pos_x, end1cp[0].pos_y, end1cp[0].pos_z]
                    end2pos = [end2cp[0].pos_x, end2cp[0].pos_y, end2cp[0].pos_z]
                    print('NACP 1 position: {0}'.format(end1pos))
                    print('NACP 2 position: {0}'.format(end2pos))
                    #
                    bond1 = cp.pathlist[0]  # list of bondpath points with coords in .path_x, .path_y, .path_z
                    bond2 = cp.pathlist[1]  #   "   "
                    # measure path part 1
                    pathpart1 = []
                    pathpart1.append(bcppos)
                    for i in range(0,len(bond1.path_x)):
                        pathpart1.append([bond1.path_x[i], bond1.path_y[i], bond1.path_z[i]])
                    pathlen1 = pathlength(pathpart1)
                    lastp1 = pathpart1[-1]
                    print('Last point on path 1: {0}'.format(lastp1))   
                    # measure path part 2
                    pathpart2 = []
                    pathpart2.append(bcppos)
                    for i in range(0,len(bond2.path_x)):
                        pathpart2.append([bond2.path_x[i], bond2.path_y[i], bond2.path_z[i]])
                    pathlen2 = pathlength(pathpart2)
                    lastp2 = pathpart2[-1]
                    print('Last point on path 2: {0}'.format(lastp2))                     
                    # now compute the end distance of the path to the nearest NACP
                    dr11 = [lastp1[0]-end1pos[0],lastp1[1]-end1pos[1],lastp1[2]-end1pos[2]]
                    dr12 = [lastp1[0]-end2pos[0],lastp1[1]-end2pos[1],lastp1[2]-end2pos[2]]
                    dr21 = [lastp2[0]-end1pos[0],lastp2[1]-end1pos[1],lastp2[2]-end1pos[2]]
                    dr22 = [lastp2[0]-end2pos[0],lastp2[1]-end2pos[1],lastp2[2]-end2pos[2]]                    
                    end1dist = min(math.sqrt((dr11[0]**2)+(dr11[1]**2)+(dr11[2]**2)),
                                   math.sqrt((dr12[0]**2)+(dr12[1]**2)+(dr12[2]**2)))
                    end2dist = min(math.sqrt((dr21[0]**2)+(dr21[1]**2)+(dr21[2]**2)),
                                   math.sqrt((dr22[0]**2)+(dr22[1]**2)+(dr22[2]**2)))
                    print('BPL = {0} + {1} + {2} + {3}'.format(pathlen1,pathlen2,end1dist,end2dist))                    
                    newbpl = pathlen1 + pathlen2 + end1dist + end2dist
                    print('Old BPL = {0} New BPL = {1}'.format(cp.BPL,newbpl))
                    cp.BPL = newbpl

                # Append props list with chosen variables
                for chosenval in vals:
                    if chosenval == 'rho':      # total charge density
                        if cpfound:
                            props.append(': {0}'.format(cp.Rho))
                        else:
                            props.append(': {0}'.format(nan))
                    elif chosenval == 'lap':    # Laplacian
                        if cpfound:
                            props.append(': {0}'.format(cp.DelSqRho))
                        else:
                            props.append(': {0}'.format(nan))
                    elif chosenval == 'ellip':  # Ellipticity
                        if cpfound:
                            props.append(': {0}'.format(cp.Ellipticity))
                        else:
                            props.append(': {0}'.format(nan))
                    elif chosenval == 'H':      # H
                        if cpfound:
                            props.append(': {0}'.format(-1.0*cp.K))
                        else:
                            props.append(': {0}'.format(nan))                        
                    elif chosenval == 'V':      # V
                        if cpfound:
                            props.append(': {0}'.format(cp.V))
                        else:
                            props.append(': {0}'.format(nan))                            
                    elif chosenval == 'G':      # G
                        if cpfound:
                            props.append(': {0}'.format(cp.G))
                        else:
                            props.append(': {0}'.format(nan))                            
                    elif chosenval == 'K':      # K (=-H)
                        if cpfound:
                            props.append(': {0}'.format(cp.K))
                        else:
                            props.append(': {0}'.format(nan))                            
                    elif chosenval == 'L':      # L
                        if cpfound:
                            props.append(': {0}'.format(cp.L))
                        else:
                            props.append(': {0}'.format(nan))                            
                    elif chosenval == 'bpl':    # Bond path length
                        if cpfound:
                            props.append(': {0}'.format(cp.BPL))
                        else:
                            props.append(': {0}'.format(nan))                            
                    elif chosenval == 'metal':  # metallicity
                        if cpfound:
                            number = cp.Rho/cp.DelSqRho
                        else:
                            number = nan
                        props.append(': {0}'.format(number))
                    elif chosenval == 'stiff':  # Rho stiffness
                        if cpfound:
                            number = math.fabs(cp.HessRho_EigVals[1])/cp.HessRho_EigVals[2]
                        else:
                            number = nan
                        props.append(': {0}'.format(number))
                    elif chosenval == 'stress_stiff':  # Stress tensor stiffness
                        if cpfound:
                            number = math.fabs(cp.Stress_EigVals[0]/cp.Stress_EigVals[2])
                        else:
                            number = nan
                        props.append(': {0}'.format(number))
                    elif chosenval == 'pol':    # Polarizability
                        if cpfound:
                            number = cp.HessRho_EigVals[2]/math.fabs(cp.HessRho_EigVals[1])
                        else:
                            number = nan
                        props.append(': {0}'.format(number))
                    elif chosenval == 'stress_pol':  # Stress polarizability
                        if cpfound:
                            number = math.fabs(cp.Stress_EigVals[2]/cp.Stress_EigVals[0])
                        else:
                            number = nan
                        props.append(': {0}'.format(number))
                    elif chosenval == 'stress_ellip':  # Stress ellipticity |l2s/l1s|-1
                        if cpfound:
                            number = math.fabs(cp.Stress_EigVals[1]/cp.Stress_EigVals[0])- 1.0
                        else:
                            number = nan
                        props.append(': {0}'.format(number))
                    elif chosenval == 'stress_ellip_hessrho':  # Stress ellipticity (Hessian order) |l1s/l2s|-1
                        if cpfound:
                            number = math.fabs(cp.Stress_EigVals[0]/cp.Stress_EigVals[1])- 1.0
                        else:
                            number = nan
                        props.append(': {0}'.format(number))
                    elif chosenval == 'gbl':  # Geometric bond length (distance between nuclei = GBL_II)
                        if cpfound:
                            number = cp.GBL_II
                        else:
                            number = nan
                        props.append(': {0}'.format(number))
                    elif chosenval == 'curv':  # Bond curvature = BPL - GBL_II
                        if cpfound:
                            number = cp.BPL - cp.GBL_II
                        else:
                            number = nan
                        props.append(': {0}'.format(number))
                    elif chosenval == 'L1':  # L1 eigenvalue HessRho
                        if cpfound:
                            number = cp.HessRho_EigVals[0]
                        else:
                            number = nan
                        props.append(': {0}'.format(number))
                    elif chosenval == 'L2':  # L2 eigenvalue HessRho
                        if cpfound:
                            number = cp.HessRho_EigVals[1]
                        else:
                            number = nan
                        props.append(': {0}'.format(number))
                    elif chosenval == 'L3':  # L3 eigenvalue HessRho
                        if cpfound:
                            number = cp.HessRho_EigVals[2]
                        else:
                            number = nan
                        props.append(': {0}'.format(number))
                    elif chosenval == 'L1s':  # L1 eigenvalue Stress
                        if cpfound:
                            number = cp.Stress_EigVals[0]
                        else:
                            number = nan
                        props.append(': {0}'.format(number))
                    elif chosenval == 'L2s':  # L2 eigenvalue Stress
                        if cpfound:
                            number = cp.Stress_EigVals[1]
                        else:
                            number = nan
                        props.append(': {0}'.format(number))
                    elif chosenval == 'L3s':  # L3 eigenvalue Stress
                        if cpfound:
                            number = cp.Stress_EigVals[2]
                        else:
                            number = nan
                        props.append(': {0}'.format(number))

                dataline = ''.join(props)
                print('{0}'.format(infile+' :'+searched_bcplabel+' '+dataline))
                if fout is not None:
                    fout.write('{0}'.format(infile+' :'+searched_bcplabel+' '+dataline+'\n'))
                # create a filtered sumviz file if requested
                if isfiltered:  # make a filtered sumviz file
                    # copy the existing MG to a new MG
                    newmg = copy.deepcopy(thismg)
                    # remove all existing BCPs,RCPs,CCPs
                    newcplist = [newcp for newcp in thismg.cplist if not (newcp.type == 'BCP' or newcp.type=='RCP' or newcp.type=='CCP') ]

                    newmg.cplist = newcplist
                    # add back the single selected BCP if Rho > minrho
                    if cp.Rho > minrho:
                        singlecp = copy.deepcopy(cp)
                        singlecp.connected = original_bcplabel
                        newmg.cplist.append(singlecp)
                        for i in newmg.cplist:
                            i.ESP = 0.0
                            i.ESPNuc = 0.0
                            i.ESPe = 0.0
                            i.ESPeNuc = 0.0
                            i.ESPn = 0.0
                            i.ESPnNuc = 0.0
                        # create infile_filtered.sumviz from infile.sumviz
                        newsumvizfile = filteredprefix+infile
                        with open(newsumvizfile,'w') as newf:
                            newmg.write_aimall(newf,'sumviz')

        #dummy = input('Press return')            
        #if (not cpfound):  # BCP not found
        #    print('{0}'.format(infile+' :'+searched_bcplabel+' :'))
        #    if fout is not None:
        #        fout.write('{0}'.format(infile+' :'+searched_bcplabel+' :\n'))
    
    #
    if (iscrystal):
        print(' === Crystal data: origin and crystal vectors ====')
        print('Origin: {0} {1} {2}'.format(box_o[0],box_o[1],box_o[2]))
        print('     a: {0} {1} {2} |a|={3}'.format(box_a[0],box_a[1],box_a[2],mod_a))
        print('     b: {0} {1} {2} |b|={3}'.format(box_b[0],box_b[1],box_b[2],mod_b))
        print('     c: {0} {1} {2} |c|={3}'.format(box_c[0],box_c[1],box_c[2],mod_c))
    if fout is not None:
        fout.close()
    print('Program exiting')

if __name__ == "__main__":
    main()

# -*- coding: utf-8 -*-


"""cpscalar.__main__: executed when cpscalar directory is called as script."""


from .cpscalar import main
main()
# -*- coding: utf-8 -*-
"""
drproject3
=======
Evaluate projections of AIM eigenvectors and position shifts,
evaluated along an IRC path (or general sequence of structures), onto CP position shifts.
A subset of the critical points in each molecular graph are selected for analysis.

Usage: python drproject3.py <file containing list of files in desired sequence>

Written in Python 3.4
NOTE: All displayed CP labels will be alphabetically sorted for ease of comparison

Modified 20160225: Option to select specific atom as origin, position coordinates changed
Modified 20170203: Can now selecte specified file from list as source of projection axes
Modified 20170402: Aligned output .xyz file now named using selected atom names
Modified 20170409: Now strips path information from CPs to save memory

"""
from __future__ import print_function
import sys, math, copy, os, argparse
from builtins import input
import numpy as np

import molgraph as mg
import beacon_utils as bu


__version__ = "20170409.0002"


class CPFilter:
    def __init__(self, FilterFunction):
        self.FilterFunction = FilterFunction

    def filter(self, inlist):
        return self.FilterFunction(inlist)

    def changeFilter(self, newFilterFunction):
        self.FilterFunction = newFilterFunction
        
def ClosedShellBCPFilter(inlist):
    outlist = []
    for cp in inlist:
        if ((cp.type == "BCP") and (cp.DelSqRho > 0.0)): # SELECTION CRITERIA - closed shell BCPs
             outlist.append(cp)
    return(outlist)
#   return( [cp for cp in inlist if ((cp.type == "BCP") and (cp.DelSqRho > 0.0))] )    
        
def SharedShellBCPFilter(inlist):
    outlist = []
    for cp in inlist:
        if ((cp.type == "BCP") and (cp.DelSqRho < 0.0)): # SELECTION CRITERIA - shared shell BCPs
             outlist.append(cp)
    return(outlist)
#   return( [cp for cp in inlist if ((cp.type == "BCP") and (cp.DelSqRho < 0.0))] ) 

def BCPFilter(inlist):
    outlist = []
    for cp in inlist:
        if ((cp.type == "BCP")): # SELECTION CRITERIA - BCPs
             outlist.append(cp)
    return(outlist)
    
def NACPFilter(inlist):
    outlist = []
    for cp in inlist:
        if ((cp.type == "NACP")): # SELECTION CRITERIA - NACPs
             outlist.append(cp)
    return(outlist)  
    
def RCPFilter(inlist):
    outlist = []
    for cp in inlist:
        if ((cp.type == "RCP")): # SELECTION CRITERIA - RCPs
             outlist.append(cp)
    return(outlist)      
    
def CCPFilter(inlist):
    outlist = []
    for cp in inlist:
        if ((cp.type == "CCP")): # SELECTION CRITERIA - CCPs
             outlist.append(cp)
    return(outlist)                      

def AllCPFilter(inlist):
    outlist = []
    for cp in inlist:
        outlist.append(cp)
    return(outlist)     
 
def sortlabel(instring):
    """
    Generate a CP label with the atom order sorted alphabetically, separated by '-'
    """
    tokens=instring.split("-")
    tokens.sort()
    return("-".join(tokens))

def main():    
    # main program starts here
    print("Running {0} on {1} using Python {2}".format(sys.argv[0],sys.platform,sys.version))
    print("Current working directory: {0}".format(os.path.abspath(os.getcwd())))
    print("Found molgraph module version {0}".format(mg.__version__))
    print("Found beacon_utils module version {0}".format(bu.__version__))
    print(__doc__)
    print("VERSION "+__version__)
    print("")
    print("***** NOTE! ***** ")
    print("This code ONLY tracks CPs whose connection information is the same")
    print("between successive IRC steps!")
    print("")
    print()
    
    parser = argparse.ArgumentParser(description="Projection of CP eigenvectors onto CP shifts\n"+
                                                 "===========================================")
    parser.add_argument("filelist", help="File containing list of data files to plot")
    
    args = parser.parse_args()
    filelistname=args.filelist
    
    fl = open(filelistname,"r")
    filelist = fl.readlines()
    fl.close()
    print("Read file list from: {0}".format(filelistname))
    first_file = True
    
    filecount = 0
    graphlist = []
    for infile in filelist: # loop over files named in sequence, load each MG, sort all CP labels and add to graphlist
        filecount = filecount + 1
        infile = infile.strip()
        print("Reading molecular graph data from input file: {0}".format(infile))
        thismg = mg.Molgraph()
        thismg.read(infile)
        # new - strip paths from molecular graphs - not needed here, saves memory
        thismg.trimpaths()
        # Sort the CP labels
        for cp in thismg.cplist:
            cp.connected = sortlabel(cp.connected)
        graphlist.append(copy.deepcopy(thismg))
    print("Read molecular graph data from {0} files in input list".format(filecount))
    print("")
        
    vector_names = ['e1h = Eigenvector e1 of Hessian(Rho)',
                    'e2h = Eigenvector e2 of Hessian(Rho)',
                    'e3h = Eigenvector e3 of Hessian(Rho)',
                    'e1s = Eigenvector e1 of Bader Stress Tensor',
                    'e2s = Eigenvector e2 of Bader Stress Tensor',
                    'e3s = Eigenvector e3 of Bader Stress Tensor',
                    'mds = - Divergence of Bader Stress Tensor',
                    'e1h+e2h',
                    'e1h+e2h+e3h',
                    '(l1*e1h)+(l2*e2h)+(l3*e3h)',
                    '(l2*l3)e1h + (l1*l3)e2h + (l1*l2)e3h',
                    'dr = shift vector from previous step to current step']
    vector_attrs = ['HessRho_EigVec1',
                    'HessRho_EigVec2',
                    'HessRho_EigVec3',
                    'Stress_EigVec1',
                    'Stress_EigVec2',
                    'Stress_EigVec3',
                    'MinusDivStress',
                    'e1h+e2h',
                    'e1h+e2h+e3h',
                    '(l1*e1h)+(l2*e2h)+(l3*e3h)',
                    '(l2*l3)e1h + (l1*l3)e2h + (l1*l2)e3h',
                    'dr']
    
    # Ask user if they want to define a specific atom as the origin
    origin_mode = 0
    origin = [0.0,0.0,0.0]
    n = bu.numbered_menu('Do you want to define a new origin of coordinates?', [
                         'No - use existing origin',
                         'Yes - use an atomic position as new origin, extra atomic positions to define frame'])
    if (n == 2):    # designate an atom as new origin
        origin_mode = 2
        numatoms = len(thismg.atom_x)
        selected_atoms = input('Enter name of one atom to use as the origin ,or three atoms to define frame: ').split()
        ftest = open('_'.join(selected_atoms)+'_aligned.xyz','w')
        selected_atom = selected_atoms[0]
        #
        # Loop over all MGs
        #
        for thismg in graphlist:
            # redefine origin    
            for i in range(0,numatoms):
                if (selected_atom == thismg.atom_label[i]):
                    origin[0] = thismg.atom_x[i]
                    origin[1] = thismg.atom_y[i]
                    origin[2] = thismg.atom_z[i]
                    #print('New origin: atom {0} at {1} {2} {3}'.format(selected_atom,origin[0],origin[1],origin[2]))
                    #dummy = input('Wait')
                    thismg.change_origin(origin)
                    break
            # now reorientate if necessary
            if (len(selected_atoms) > 1): # Calculate new axes and reorientate
                # first selected atom is now at origin
                # second atom defines x-direction
                # third atom defines y-direction
                # z direction defined by bu.vectorproduct(x,y)
                for i in range(0,numatoms):
                    if (selected_atoms[1] == thismg.atom_label[i]): # found the second orientation atom
                        newx = [thismg.atom_x[i],thismg.atom_y[i],thismg.atom_z[i]]
                    elif (selected_atoms[2] == thismg.atom_label[i]): # found the third orientation atom
                        tmpy = [thismg.atom_x[i],thismg.atom_y[i],thismg.atom_z[i]]
                # Now construct orthogonal set
                modx = math.sqrt(bu.dotprod(newx,newx))
                unitx = [0.0,0.0,0.0]
                unitx[0] = newx[0]/modx
                unitx[1] = newx[1]/modx
                unitx[2] = newx[2]/modx
                mody_x = bu.dotprod(unitx,tmpy)
                y_x = [0.0,0.0,0.0] # component of tmpy vector along unitx
                y_x[0] = mody_x*unitx[0]
                y_x[1] = mody_x*unitx[1]
                y_x[2] = mody_x*unitx[2]
                newy = [0.0,0.0,0.0]
                newy[0] = tmpy[0] - y_x[0]
                newy[1] = tmpy[1] - y_x[1]
                newy[2] = tmpy[2] - y_x[2]
                mody = math.sqrt(bu.dotprod(newy,newy))
                unity = [0.0,0.0,0.0]
                unity[0] = newy[0]/mody
                unity[1] = newy[1]/mody
                unity[2] = newy[2]/mody
                # Now with unitx and unity we can compute unitz as a vector cross product
                unitz = bu.vectorproduct(unitx,unity)
                print('Computed new axes')
                print('New x : {0} {1} {2}'.format(unitx[0],unitx[1],unitx[2]))
                print('New y : {0} {1} {2}'.format(unity[0],unity[1],unity[2]))
                print('New z : {0} {1} {2}'.format(unitz[0],unitz[1],unitz[2]))
                #
                # Project everything
                #
                thismg.change_axes(unitx,unity,unitz)
            # Now dump this MG as xyz
            thismg.nuctoxyz(ftest)
        ftest.close()
        print ('=== ALIGNMENT CHANGE ===')
        print ('Analyzed molecular graphs are now aligned:')
        print ('Origin: {0}'.format(selected_atoms[0]))
        if len(selected_atoms) > 1:
            print('{0}-{1} defines x-axis, {2}-{3}-{4} defines the x-y plane'.format(selected_atoms[0],selected_atoms[1],
                                                                                     selected_atoms[0],selected_atoms[1],selected_atoms[2]))
    else:
        origin_mode = 1
        print('Using conventional origin and axes - no additional aligment')
    
    #print('Origin shift check')
    #for thismg in graphlist:
    #    print(thismg.filename)
    #    for i in range(0,len(thismg.atom_x)): 
    #        if (selected_atom == thismg.atom_label[i]):
    #            print('New origin: atom {0} at {1} {2} {3}'.format(selected_atom,thismg.atom_x[i],thismg.atom_y[i],thismg.atom_z[i]))
    #            break
        
            #for i in range(0,len(self.atom_x)):
            #    print('{0} {1} {2} {3}'.format(self.atom_label[i],self.atom_x[i],self.atom_y[i],self.atom_z[i]))
    
    # Ask user to select CP subset
    n = bu.numbered_menu('Select a subset of CPs for analysis',['Closed shell BCPs','Shared shell BCPs',
                                                                'All BCPs', 'All NACPs', 'All RCPs', 'All CCPs', 'All CPs' ])
    if (n==1): # closed shell BCPs
        cpf = CPFilter(ClosedShellBCPFilter)
        print("Selected closed shell BCPs")
    elif (n==2): # shared shell BCPs
        cpf = CPFilter(SharedShellBCPFilter)
        print("Selected shared shell BCPs")
    elif (n==3): # All BCPs
        cpf = CPFilter(BCPFilter)
        print("Selected all BCPs")
    elif (n==4): # NACPs
        cpf = CPFilter(NACPFilter)
        print("Selected NACPs")
    elif (n==5): # RCPs
        cpf = CPFilter(RCPFilter)
        print("Selected RCPs")
    elif (n==6): # CCPs
        cpf = CPFilter(CCPFilter)
        print("Selected CCPs") 
    elif (n==7): # All CPs
        cpf = CPFilter(AllCPFilter)
        print("All CPs")     
    else:        # error message and exit
        print("Exiting ..")
        sys.exit()
    
    print("")
    
    ignore_list=[]
    proj_tracking = False    
    firstfile = filelist[0].rstrip()
    lastfile = filelist[-1].rstrip()
    print("First file in input list: {0}".format(firstfile))
    print("Last file in input list : {0}".format(lastfile))
    nref = bu.numbered_menu('Which file from the input list should be used for projection axes?',['First file in the input list -  '+firstfile, 'Last file in the input list - '+lastfile,'File from specific numbered position in the list (0=first file)','Previous file in the input list (tracking)'])
    if (nref == 1):   # Use projection axes from first file
        projection_mg = 0
        print('Using projection axes from first file')
    elif (nref == 2): # Use projection axes from last file
        projection_mg = len(graphlist)-1
        print('Using projection axes from last file')
    elif (nref == 3): # Use projection axes from specific list item
        sel_listnum = int(input('Input file list item number (0=first file,1=second file etc.):'))
        projection_mg = sel_listnum
        chosenfile = filelist[sel_listnum].rstrip()
        print('Using projection axes from file list item {0} - {1}'.format(sel_listnum,chosenfile)) 
    elif (nref == 4): # Use projection axes from previous file
        proj_tracking = True
        print('TRACKING - using projection axes from previous step')    
    else:             # error message and exit
        print("Invalid option - exiting ..")
        sys.exit
    
    # get all the necessary details of the projection MG, if statically defined
    if (proj_tracking == False): # get all the necessary details of the projection MG, if statically defined
        projmg = graphlist[projection_mg]
        print("Using projection vectors from molecular graph in file: {0}".format(projmg.filename))
        proj_cplist = cpf.filter(projmg.cplist)
        print("Filtered CP list coordinates in selected projection axes step") 
        #for cp in proj_cplist: # print the CP labels and positions
        #    print("{0} {1:12s} {2:12.8} {3:12.8} {4:12.8}".format(infile,cp.connected,cp.pos_x,cp.pos_y,cp.pos_z))
        proj_cp_names = [cp.connected for cp in proj_cplist]     # record projection MG CP names
    
    mgcount = -1
    for thismg in graphlist: # main loop over sequence of molecular graphs
        print("============================================================")
        mgcount = mgcount + 1   
        
        if (mgcount == 0): # FIRST FILE (MG) ONLY 
            #
            refmg = thismg
            ref_cplist = cpf.filter(thismg.cplist) # construct reference CP list for dr calculation
            ref_cp_names = [cp.connected for cp in ref_cplist] # record reference CP names
            # record CP list at first step
            first_ref_cplist = copy.deepcopy(ref_cplist)      
            #        
        else:              # GENERAL CASE - ALL SUCCEEDING FILES IN THE SEQUENCE
            #
            #
            thiscplist = cpf.filter(thismg.cplist) # get the filtered list of CPs
            if (proj_tracking) == True:  # Make the reference molecular graph the projection molecular graph
                projmg = refmg
                proj_cplist = ref_cplist
                proj_cp_names = [cp.connected for cp in proj_cplist]
    
            for cp in thiscplist:  #  Check each CP in this MG exists in reference and projection list
                # first check in the reference list
                ref_found = False
                for ref_cp in ref_cplist:  # check if CP found in ref CP list, fix or ignore if not found
                    if ref_cp.connected == cp.connected:
                        ref_found = True
    
                # if this cp isn't in the reference step or already ignored 
                if ((not(ref_found)) and (ignore_list.count(cp.connected) < 1) ):  # This BCP does not appear in reference step, not on ignore list (fix or ignore)
                    print("Found a CP named [{0}] which does not exist in the reference step".format(cp.connected))
                    n=bu.numbered_menu('Enter the list number of a matching reference step CP, or 99 to ignore this CP in future',ref_cp_names)
                    #
                    if (not(n==99)): # add a new clone CP to the ref list
                        newcp = copy.deepcopy(ref_cplist[n-1])
                        newcp.connected = cp.connected
                        print("")
                        print("Selected a reference step CP at {0:12.8} {1:12.8} {2:12.8}".format(newcp.pos_x,newcp.pos_y,newcp.pos_z))
                        ref_cplist.append(newcp)        # add this new CP to the reference list
                        first_ref_cplist.append(newcp)  # also add it to the reference list from the first frame
                    else:            # mark this CP to be ignored in future
                        ignore_list.append(cp.connected)
    
                # then check in the projection list
                proj_found = False
                for proj_cp in proj_cplist: # check if CP found in proj CP list, fix or ignore if not found
                    if proj_cp.connected == cp.connected:
                        proj_found = True
                if ((not(proj_found)) and (ignore_list.count(cp.connected) < 1) ): # This BCP does not appear in reference step, not on ignore list
                    print("Found a CP named {0} which does not exist in the projection step".format(cp.connected))
                    n=bu.numbered_menu('Enter the list number of a matching projection step CP, or 99 to ignore this CP in future',proj_cp_names)
                    #
                    if (not(n==99)): # add a new clone CP to the ref list
                        newcp = copy.deepcopy(proj_cplist[n-1])
                        newcp.connected = cp.connected
                        print("")
                        print("Selected a projection step CP at {0:12.8} {1:12.8} {2:12.8}".format(newcp.pos_x,newcp.pos_y,newcp.pos_z))
                        proj_cplist.append(newcp)        # add this new CP to the projection list
                    else:            # mark this CP to be ignored in future
                        ignore_list.append(cp.connected)
    
            #    
            # DONE CHECKS, now loop over CPs in this molecular graph and print projections
            print("Position shift dr constructed from: {0} and {1}".format(thismg.filename, refmg.filename))
            print("Projection axes from              : {0}".format(projmg.filename))        
            print("Filename,         Connectivity,     dr.e1h, dr.e2h, dr.e3h, dr.e1s, dr.e2s, dr.e3s, moddr")
            for cp in thiscplist: # for each cp calculate the dr and projections
                if (ignore_list.count(cp.connected) > 0): # skip this CP if it is on the ignore list
                    continue
                #
                found_cp = False          
                for refcp in ref_cplist: # If this CP exists in the previous (i.e. reference) step, get the dr
                    if cp.connected == refcp.connected: # found the corresponding CP in the reference step
                       found_cp = True
                       # calculate dr
                       dr = [cp.pos_x - refcp.pos_x, cp.pos_y - refcp.pos_y, cp.pos_z - refcp.pos_z]
                       moddr =  math.sqrt(bu.dotprod(dr,dr))
                       # Normalize dr
                       dr = [dr[0]/moddr, dr[1]/moddr, dr[2]/moddr]
                if (not found_cp): # CP not found in reference step, exit with error message and CP name
                    print("ERROR: {0} {1:12s} not found in reference step".format(infile, cp.connected))
                    sys.exit()
                # 
                # If this CP exists in the projection axes step, get the corresponding eigenvectors
                #
                found_proj_cp = False
                for proj_cp in proj_cplist: # calculate and print dot products 
                    if cp.connected == proj_cp.connected: # found the corresponding CP in the reference step
                       # get projection eigenvectors
                       e1h = proj_cp.HessRho_EigVec1
                       e2h = proj_cp.HessRho_EigVec2 
                       e3h = proj_cp.HessRho_EigVec3
                       e1s = proj_cp.Stress_EigVec1
                       e2s = proj_cp.Stress_EigVec2
                       e3s = proj_cp.Stress_EigVec3
                       dpe1h = bu.dotprod(dr,e1h)
                       dpe2h = bu.dotprod(dr,e2h)
                       dpe3h = bu.dotprod(dr,e3h)
                       dpe1s = bu.dotprod(dr,e1s)
                       dpe2s = bu.dotprod(dr,e2s)
                       dpe3s = bu.dotprod(dr,e3s)                  
                       print("{0} {1:12s} {2:12.8} {3:12.8} {4:12.8} {5:12.8} {6:12.8} {7:12.8} {8:12.8}".format(thismg.filename,cp.connected,dpe1h,dpe2h,dpe3h,dpe1s,dpe2s,dpe3s,moddr))
                       found_proj_cp = True
                       continue
                # Checks to catch cases where CPs not found
                if (not found_proj_cp): # CP not found in projection step list, exit with error message and list of projection step CPs
                    print("WARNING - did not find a matching CP called {0} in projection vector MG".format(cp.connected))
                    print([proj_cp.connected for proj_cp in proj_cplist])  
                    sys.exit()                   
                if (not found_cp): # CP not found in reference step list, exit with error message and lists of reference and projection step CPs
                    print("ERROR: {0} {1:12s} not found in reference step".format(infile, cp.connected))
                    print("Names of CPs in reference step")
                    print([refcp.connected for refcp in ref_cplist])
                    print("Names of CPs in projection step")
                    print([proj_cp.connected for proj_cp in proj_cplist])
                    sys.exit()
            # We are tracking dr, current step becomes the new reference step
            ref_cplist = copy.deepcopy(thiscplist)
            refmg = thismg        
            print("")                     
            #
    print("============================================================")
    
    # end of main program
    print("Ignored CPs:")
    for name in ignore_list:
        print(name)
    #print("Sum of |dp| = {0}".format(sum_moddp))
    #print("Sum of  dp  = {0}".format(sum_dp))
    print("Program exiting")

if __name__ == '__main__':
    main()

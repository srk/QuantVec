# -*- coding: utf-8 -*-
"""
drproject3
==========
Evaluate projections of nuclear and CP positions shifts, and general vectors evaluated
either analytically or by interpolation into VTK-format gridded data
for a general sequence of structures(time sequence, IRC path etc.), onto QTAIM critical point eigenvectors.
A subset of the critical points in each molecular graph are selected for analysis. 

Usage: drproject3 <file containing list of files in desired sequence>

Written in Python 3
NOTE: All displayed CP labels will be alphabetically sorted for ease of comparison
NOTE: Support for Vector fields from VTK files currently incomplete - under development

Modified 20160225: Option to select specific atom as origin, position coordinates changed
Modified 20170203: Can now selecte specified file from list as source of projection axes
Modified 20170402: Aligned output .xyz file now named using selected atom names
Modified 20170409: Now strips path information from CPs to save memory
Modified 20240624: Allow for wider CP names to accomodate annotated BCP names in crystals
Modified 20250601: Allow projection axes and dr shifts to come from different CPs (hybrids)
Modified 20250915: Trap a possible ZeroDivisionError

"""
from __future__ import print_function
import sys, math, copy, os, argparse
from builtins import input
import numpy as np
import vtk as vtk

import molgraph as mg
import beacon_utils as bu


__version__ = "202501205.001"

class CPFilter:
    def __init__(self, FilterFunction,**kwargs):
        self.FilterFunction = FilterFunction

    def filter(self, inlist,**kwargs):
        return self.FilterFunction(inlist,**kwargs)

    def changeFilter(self, newFilterFunction):
        self.FilterFunction = newFilterFunction

def ClosedShellBCPFilter(inlist,**kwargs):
    outlist = []
    for cp in inlist:
        if ((cp.type == "BCP") and (cp.DelSqRho > 0.0)): # SELECTION CRITERIA - closed shell BCPs
             outlist.append(cp)
    return(outlist)
#   return( [cp for cp in inlist if ((cp.type == "BCP") and (cp.DelSqRho > 0.0))] )    
        
def SharedShellBCPFilter(inlist,**kwargs):
    outlist = []
    for cp in inlist:
        if ((cp.type == "BCP") and (cp.DelSqRho < 0.0)): # SELECTION CRITERIA - shared shell BCPs
             outlist.append(cp)
    return(outlist)
#   return( [cp for cp in inlist if ((cp.type == "BCP") and (cp.DelSqRho < 0.0))] ) 

def BCPFilter(inlist,**kwargs):
    outlist = []
    for cp in inlist:
        if ((cp.type == "BCP")): # SELECTION CRITERIA - BCPs
             outlist.append(cp)
    return(outlist)
    
def NACPFilter(inlist,**kwargs):
    outlist = []
    for cp in inlist:
        if ((cp.type == "NACP")): # SELECTION CRITERIA - NACPs
             outlist.append(cp)
    return(outlist)  
    
def RCPFilter(inlist,**kwargs):
    outlist = []
    for cp in inlist:
        if ((cp.type == "RCP")): # SELECTION CRITERIA - RCPs
             outlist.append(cp)
    return(outlist)      
    
def CCPFilter(inlist,**kwargs):
    outlist = []
    for cp in inlist:
        if ((cp.type == "CCP")): # SELECTION CRITERIA - CCPs
             outlist.append(cp)
    return(outlist)                      

def AllCPFilter(inlist,**kwargs):
    outlist = []
    for cp in inlist:
        outlist.append(cp)
    return(outlist) 

def SpecificCPFilter(inlist,**kwargs):
    #print(kwargs)
    sortedname = sortlabel(kwargs['cpname'])
    outlist = [cp for cp in inlist if cp.connected == sortedname ]
    #print('Filter returns the names {0}'.format([cp.connected for cp in outlist]))
    if len(outlist) == 0:
        print('Did not recognise that CP name : {0}'.format(sortedname))
    return(outlist)        
 
def sortlabel(instring):
    """
    Generate a CP label with the atom order sorted alphabetically, separated by '-'
    """
    tokens=instring.split("-")
    tokens.sort()
    return("-".join(tokens))

def vtk_to_nparray(filename: str, arraynum: int):
    """
    Read a Fortran-ordered VTK StructuredPoints object from a .vtk file.
    Convert the VTK point_data object array number 'arraynum' to a 3-D numpy array of the vector quantity (3-component tuples}
    Return Numpy arrays: x-values, y-values, z-values, mesh data
    """
    reader = vtk.vtkStructuredPointsReader()
    reader.SetFileName(filename)
    reader.Update()
    dataset = reader.GetOutput()
    point_data = dataset.GetPointData()
    nx,ny,nz = dataset.GetDimensions()
    bounds = dataset.GetBounds()
    xarray = np.linspace(bounds[0],bounds[1],nx)
    yarray = np.linspace(bounds[2],bounds[3],ny)
    zarray = np.linspace(bounds[4],bounds[5],nz)
    array = point_data.GetArray(0)
    flat_nparray = numpy_support.vtk_to_numpy(array)
    full_nparray = flat_nparray.reshape(nx,ny,nz,-1,order='F')
    return xarray, yarray, zarray, full_nparray

def shiftcom(thismg):
    '''
    Adjust all position coordinates in a molecular graph to put the centre of mass
    on the origin of the coordinate system
    '''
    # Calculate the centre of mass coordinates
    com = [0.0, 0.0, 0.0]
    mtot = 0.0
    elements_dict = {'H' : 1.00784,'HE' : 4.003, 'LI' : 6.941, 'BE' : 9.012,\
                 'B' : 10.811, 'C' : 12.011, 'N' : 14.007, 'O' : 15.999,\
                 'F' : 18.998, 'NE' : 20.180, 'NA' : 22.990, 'MG' : 24.305,\
                 'AL' : 26.982, 'SI' : 28.086, 'P' : 30.974, 'S' : 32.066,\
                 'CL' : 35.453, 'AR' : 39.948, 'K' : 39.098, 'CA' : 40.078,\
                 'SC' : 44.956, 'TI' : 47.867, 'V' : 50.942, 'CR' : 51.996,\
                 'MN' : 54.938, 'FE' : 55.845, 'CO' : 58.933, 'NI' : 58.693,\
                 'CU' : 63.546, 'ZN' : 65.38, 'GA' : 69.723, 'GE' : 72.631,\
                 'AS' : 74.922, 'SE' : 78.971, 'BR' : 79.904, 'KR' : 84.798,\
                 'RB' : 84.468, 'SR' : 87.62, 'Y' : 88.906, 'ZR' : 91.224,\
                 'NB' : 92.906, 'MO' : 95.95, 'TC' : 98.907, 'RU' : 101.07,\
                 'RH' : 102.906, 'PD' : 106.42, 'AG' : 107.868, 'CD' : 112.414,\
                 'IN' : 114.818, 'SN' : 118.711, 'SB' : 121.760, 'TE' : 126.7,\
                 'I' : 126.90447, 'XE' : 131.294, 'CS' : 132.905, 'BA' : 137.328,\
                 'LA' : 138.905, 'CE' : 140.116, 'PR' : 140.908, 'ND' : 144.243,\
                 'PM' : 144.913, 'SM' : 150.36, 'EU' : 151.964, 'GD' : 157.25,\
                 'TB' : 158.925, 'DY': 162.500, 'HO' : 164.930, 'ER' : 167.259,\
                 'TM' : 168.934, 'YB' : 173.055, 'LU' : 174.967, 'HF' : 178.49,\
                 'TA' : 180.948, 'W' : 183.84, 'RE' : 186.207, 'OS' : 190.23,\
                 'IR' : 192.217, 'PT' : 195.085, 'AU' : 196.967, 'HG' : 200.592,\
                 'TL' : 204.383, 'PB' : 207.2, 'BI' : 208.980, 'PO' : 208.982,\
                 'AT' : 209.987, 'RN' : 222.081, 'FR' : 223.020, 'RA' : 226.025,\
                 'AC' : 227.028, 'TH' : 232.038, 'PA' : 231.036, 'U' : 238.029,\
                 'NP' : 237, 'PU' : 244, 'AM' : 243, 'CM' : 247, 'BK' : 247,\
                 'CT' : 251, 'ES' : 252, 'FM' : 257, 'MD' : 258, 'NO' : 259,\
                 'LR' : 262, 'RF' : 261, 'DB' : 262, 'SG' : 266, 'BH' : 264,\
                 'HS' : 269, 'MT' : 268, 'DS' : 271, 'RG' : 272, 'CN' : 285,\
                 'NH' : 284, 'FL' : 289, 'MC' : 288, 'LV' : 292, 'TS' : 294,\
                 'OG' : 294}
    count = 0
    for label in thismg.atom_label:
        sym = label.strip('0123456789').upper()
        if sym in elements_dict:
            atmass = elements_dict[sym]
        else:
            atmass = 0.0
        #print('{0} Label: {1} Mass {2}'.format(count,label,atmass))
        com[0] = com[0] + (atmass*thismg.atom_x[count])
        com[1] = com[1] + (atmass*thismg.atom_y[count])
        com[2] = com[2] + (atmass*thismg.atom_y[count])
        count = count+1
        mtot = mtot + atmass
    # compute final COM
    com[0] = com[0]/mtot
    com[1] = com[1]/mtot
    com[2] = com[2]/mtot
    #print('Molecular mass: {0}'.format(mtot))
    #print('COM: {0} {1} {2}'.format(com[0],com[1],com[2]) )
    #print('Adjusting nuclear and CP coordinates')
    # Adjust nuclear positions
    for i in range(len(thismg.atom_x)):
        thismg.atom_x[i] = thismg.atom_x[i] - com[0]
        thismg.atom_y[i] = thismg.atom_y[i] - com[1]
        thismg.atom_z[i] = thismg.atom_z[i] - com[2]
    # Adjust critical point positions
    for thiscp in thismg.cplist:
        thiscp.pos_x = thiscp.pos_x - com[0]
        thiscp.pos_y = thiscp.pos_y - com[1]
        thiscp.pos_z = thiscp.pos_z - com[2]
    #  Later adjust paths data if needed

def main():
    #    
    # MAIN PROGRAM STARTS HERE
    #
    print("Running {0} on {1} using Python {2}".format(sys.argv[0],sys.platform,sys.version))
    print("Current working directory: {0}".format(os.path.abspath(os.getcwd())))
    print("Found molgraph module version {0}".format(mg.__version__))
    print("Found beacon_utils module version {0}".format(bu.__version__))
    print(__doc__)
    print("VERSION "+__version__)
    print("")
    print("***** NOTE! ***** ")
    print("This code ONLY tracks CPs whose connection information is the same")
    print("between successive IRC steps!")
    print("")
    print()
    
    parser = argparse.ArgumentParser(description="Projection of CP eigenvectors onto CP shifts\n"+
                                                 "===========================================")
    parser.add_argument("filelist", help="File containing list of data files to plot")
    parser.add_argument("--ignorenew",help="Ignore BCPs that don't exist in the reference",action='store_true')
    parser.add_argument("--verbose",help="Be verbose in standard output",action='store_true')
    parser.add_argument('--fieldprefix',help="Field vector VTK dataset filename prefix for projection")

    # Parse args
    args = parser.parse_args()
    filelistname=args.filelist
    ignorenew = args.ignorenew
    verbose = args.verbose
    if (args.fieldprefix):
        fieldfileprefix = args.fieldprefix
        fieldmode = True
    else:
        fieldmode = False
    specificcp =''
    hybrid_mode = False      # assume not hybrid
    tracking_mode = False    # new variable named for consistency
    proj_tracking = False    # assume non-tracking mode
    proj_live = False        # assume non-live mode

    #    
    vector_names = ['e1h = Eigenvector e1 of Hessian(Rho)',
                    'e2h = Eigenvector e2 of Hessian(Rho)',
                    'e3h = Eigenvector e3 of Hessian(Rho)',
                    'e1s = Eigenvector e1 of Bader Stress Tensor',
                    'e2s = Eigenvector e2 of Bader Stress Tensor',
                    'e3s = Eigenvector e3 of Bader Stress Tensor',
                    'mds = - Divergence of Bader Stress Tensor',
                    'e1h+e2h',
                    'e1h+e2h+e3h',
                    '(l1*e1h)+(l2*e2h)+(l3*e3h)',
                    '(l2*l3)e1h + (l1*l3)e2h + (l1*l2)e3h',
                    'dr = shift vector from previous step to current step']
    vector_attrs = ['HessRho_EigVec1',
                    'HessRho_EigVec2',
                    'HessRho_EigVec3',
                    'Stress_EigVec1',
                    'Stress_EigVec2',
                    'Stress_EigVec3',
                    'MinusDivStress',
                    'e1h+e2h',
                    'e1h+e2h+e3h',
                    '(l1*e1h)+(l2*e2h)+(l3*e3h)',
                    '(l2*l3)e1h + (l1*l3)e2h + (l1*l2)e3h',
                    'dr']    

    # GET FILE LIST
    fl = open(filelistname,"r")
    filelist = []
    with open(filelistname,'r') as fl: # read input file list
        for line in fl:
            if not line.startswith("#"):
                filelist.append(line.strip())
    print("Read {0} items as file list from: {1}".format(len(filelist),filelistname))
    print("Starting file sequence")
    first_file = True
    filecount = 0
    graphlist = []
    for infile in filelist: # loop over files named in sequence, load each MG, sort all CP labels and add MG to graphlist
        filecount = filecount + 1
        infile = infile.strip()
        print("Reading molecular graph data from input file: {0}".format(infile))
        thismg = mg.Molgraph()
        thismg.read(infile,debug=False)
        # new - strip paths from molecular graphs - not needed here, saves memory
        thismg.trimpaths()
        # Sort the CP labels
        for cp in thismg.cplist:
            cp.connected = sortlabel(cp.connected)
        graphlist.append(copy.deepcopy(thismg))
    print("Read molecular graph data from {0} files in input list".format(filecount))
    print('List contains {0} molecular graphs'.format(len(graphlist)))
    print("")
    if fieldmode: # generate a list 'fieldfilelist' of field vector .vtk files from the current sumviz filelist filenames
        print("Field prefix specified - constructing field filename list")
        fieldfilelist = [ fieldfileprefix+i.strip().removesuffix('.sumviz')+'.vtk' for i in filelist ]

    # ASK USER IF THEY WANT TO DEFINE A SPECIFIC ATOM AS THE ORIGIN
    origin = [0.0,0.0,0.0]
    n = bu.numbered_menu('Do you want to define a new origin of coordinates?', [
                         'No - use existing origin',
                         'Yes - use an atomic position as new origin, extra atomic positions to define frame',
                         'Yes - shift origin to Centre of Mass'])
    
    if (n == 2):    # designate an atom as new origin
        origin_mode = 2
        numatoms = len(thismg.atom_x)
        selected_atoms = input('Enter name of one atom to use as the origin ,or three atoms to define frame: ').split()
        ftest = open('_'.join(selected_atoms)+'_aligned.xyz','w')
        selected_atom = selected_atoms[0]
        #
        # Loop over all MGs
        #
        for thismg in graphlist:
            # redefine origin    
            for i in range(0,numatoms):
                if (selected_atom == thismg.atom_label[i]):
                    origin[0] = thismg.atom_x[i]
                    origin[1] = thismg.atom_y[i]
                    origin[2] = thismg.atom_z[i]
                    #print('New origin: atom {0} at {1} {2} {3}'.format(selected_atom,origin[0],origin[1],origin[2]))
                    #dummy = input('Wait')
                    thismg.change_origin(origin)
                    break
            # now reorientate if necessary
            if (len(selected_atoms) > 1): # Calculate new axes and reorientate
                # first selected atom is now at origin
                # second atom defines x-direction
                # third atom defines y-direction
                # z direction defined by bu.vectorproduct(x,y)
                for i in range(0,numatoms):
                    if (selected_atoms[1] == thismg.atom_label[i]): # found the second orientation atom
                        newx = [thismg.atom_x[i],thismg.atom_y[i],thismg.atom_z[i]]
                    elif (selected_atoms[2] == thismg.atom_label[i]): # found the third orientation atom
                        tmpy = [thismg.atom_x[i],thismg.atom_y[i],thismg.atom_z[i]]
                # Now construct orthogonal set
                modx = math.sqrt(bu.dotprod(newx,newx))
                unitx = [0.0,0.0,0.0]
                unitx[0] = newx[0]/modx
                unitx[1] = newx[1]/modx
                unitx[2] = newx[2]/modx
                mody_x = bu.dotprod(unitx,tmpy)
                y_x = [0.0,0.0,0.0] # component of tmpy vector along unitx
                y_x[0] = mody_x*unitx[0]
                y_x[1] = mody_x*unitx[1]
                y_x[2] = mody_x*unitx[2]
                newy = [0.0,0.0,0.0]
                newy[0] = tmpy[0] - y_x[0]
                newy[1] = tmpy[1] - y_x[1]
                newy[2] = tmpy[2] - y_x[2]
                mody = math.sqrt(bu.dotprod(newy,newy))
                unity = [0.0,0.0,0.0]
                unity[0] = newy[0]/mody
                unity[1] = newy[1]/mody
                unity[2] = newy[2]/mody
                # Now with unitx and unity we can compute unitz as a vector cross product
                unitz = bu.vectorproduct(unitx,unity)
                print('Computed new axes')
                print('New x : {0} {1} {2}'.format(unitx[0],unitx[1],unitx[2]))
                print('New y : {0} {1} {2}'.format(unity[0],unity[1],unity[2]))
                print('New z : {0} {1} {2}'.format(unitz[0],unitz[1],unitz[2]))
                #
                # Project everything
                #
                thismg.change_axes(unitx,unity,unitz)
            # Now dump this MG as xyz
            thismg.nuctoxyz(ftest)
        ftest.close()
        print ('=== ALIGNMENT CHANGE ===')
        print ('Analyzed molecular graphs are now aligned:')
        print ('Origin: {0}'.format(selected_atoms[0]))
        if len(selected_atoms) > 1:
            print('{0}-{1} defines x-axis, {2}-{3}-{4} defines the x-y plane'.format(selected_atoms[0],selected_atoms[1],
                                                                                     selected_atoms[0],selected_atoms[1],selected_atoms[2]))
    elif (n == 1):  # conventional origin, no additional alignment
        origin_mode = 1
        print('Using conventional origin and axes - no additional alignment performed')
    else:           # set origin of position to the centre of mass
        print('OPTION 3: Setting Centre of Mass as origin in all input molecular graphs')
        for thismg in graphlist:
            shiftcom(thismg)
        print('COM shifts applied on all molecular graphs')

    #print('Origin shift check')
    #for thismg in graphlist:
    #    print(thismg.filename)
    #    for i in range(0,len(thismg.atom_x)): 
    #        if (selected_atom == thismg.atom_label[i]):
    #            print('New origin: atom {0} at {1} {2} {3}'.format(selected_atom,thismg.atom_x[i],thismg.atom_y[i],thismg.atom_z[i]))
    #            break    
            #for i in range(0,len(self.atom_x)):
            #    print('{0} {1} {2} {3}'.format(self.atom_label[i],self.atom_x[i],self.atom_y[i],self.atom_z[i]))
    
    # ASK USER TO SELECT CP SUBSET
    n = bu.numbered_menu('Select a subset of CPs for analysis',
                         ['Closed shell BCPs','Shared shell BCPs','All BCPs', 'All NACPs', 'All RCPs', 'All CCPs',
                           'All CPs','Specific CP','Specific CPs (HYBRID)','Specific CP (LIVE)' ])
    if (n==1): # closed shell BCPs
        cpf = CPFilter(ClosedShellBCPFilter)
        print("Selected closed shell BCPs")
    elif (n==2): # shared shell BCPs
        cpf = CPFilter(SharedShellBCPFilter)
        print("Selected shared shell BCPs")
    elif (n==3): # All BCPs
        cpf = CPFilter(BCPFilter)
        print("Selected all BCPs")
    elif (n==4): # NACPs
        cpf = CPFilter(NACPFilter)
        print("Selected NACPs")
    elif (n==5): # RCPs
        cpf = CPFilter(RCPFilter)
        print("Selected RCPs")
    elif (n==6): # CCPs
        cpf = CPFilter(CCPFilter)
        print("Selected CCPs") 
    elif (n==7): # All CPs
        cpf = CPFilter(AllCPFilter)
        print("All CPs") 
    elif (n==8): # Specific named CP
        print('Specific named CP')
        tempname = input('Enter name of CP (separate endpoint names with a space): ')
        tokens = tempname.split()
        if len(tokens) == 2:
            specificcpname = sortlabel('-'.join(tokens))
        elif len(tokens) == 1:
            specificcpname = tempname
            print('You chose to track a specific BCP: {0}'.format(specificcpname))

        cpf = CPFilter(SpecificCPFilter,cpname=specificcpname)
        if verbose:
            print('Opening output file {0}'.format(specificcpname+".traj"))
        ftraj = open(specificcpname+'.traj','w')
        # set projcpname AND drcpname to both be equal to 'specificcp'
        projcpname = specificcpname
        drcpname = specificcpname
    elif (n==9): # HYBRID: specify one CP for projection axes, and another for dr shifts
        if verbose:
            print('**** HYBRID MODE ****')
            print('Shifts dr and projection directions will come from different CPs')
        hybrid_mode = True
        # First get projection axes CP
        tempname = input('Enter name of CP providing projection axes (separate endpoint names with a space if a BCP): ')
        tokens = tempname.split()
        if len(tokens) == 2:       # Projection data from a BCP  -> projcpname , specificcpname
            specificcpname = sortlabel('-'.join(tokens))
            projcpname = specificcpname
            print('You chose to get projection axes from a BCP: {0}'.format(specificcpname)) 
            #cpf = CPFilter(SpecificCPFilter,cpname=specificcpname)
        elif len(tokens) == 1:    # Projection data from a NACP  -> projcpname , specificcpname
            specificcpname = tokens[0]
            projcpname = specificcpname
            print('You chose to get projection axes from a CP: {0}'.format(specificcpname))
            print('WARNING: eigenvector projection axes from an NACP may be unreliable if pseudos+core_density have been used!')
            print('Stopping here for now')
            sys.exit()
        else: # exit
            print('Only BCPs and NACPs can be used for projection axes!')
            sys.exit()

        # Then get dr shifts CP           
        tempname = input('Enter name of CP providing the dr shifts (separate endpoint names with a space if a BCP): ')
        tokens = tempname.split()
        if len(tokens) == 2:  # tracked CP is a BCP  -> specificcpname, drcpname, cpf
            specificcpname = sortlabel('-'.join(tokens))
            drcpname = specificcpname
            print('You chose to get dr shifts from a BCP: {0}'.format(specificcpname)) 
            cpf = CPFilter(SpecificCPFilter,cpname=specificcpname)
        elif len(tokens) == 1:  # tracked is an NACP -> specificcpname, drcpname,cpf
            specificcpname = tokens[0]
            drcpname = specificcpname
            print('You chose to get dr shifts from a CP: {0}'.format(specificcpname))
            cpf = CPFilter(SpecificCPFilter,cpname=specificcpname)
        else: #exit
            print('Only BCPs and NACPs can be used for dr shifts!')
            sys.exit()
        # construct and open output trajectory filename for hybrid case
        ftrajname = drcpname+"_hybrid_"+projcpname+".traj"
        ftraj = open(ftrajname, 'w')
        if verbose:
            print('Will write an output file named {0}'.format(ftrajname))
    elif (n==10): # Vector from field
        print('*** FIELD MODE ***')
        print('Field vectors will be projected')
        fieldmode = True

    else:        # error message and exit
        print("Unrecognised option, exiting ..")
        sys.exit()
    
    ignore_list=[]
    firstfile = filelist[0].rstrip()
    lastfile = filelist[-1].rstrip()
    print("First file in input list: {0}".format(firstfile))
    print("Last file in input list : {0}".format(lastfile))
    nproj = bu.numbered_menu('Which file from the input list should be used for projection axes?',
                             [  'First file in the input list -  '+firstfile, 
                                'Last file in the input list - '+lastfile,
                                'File from specific numbered position in the list (0=first file)',
                                'Previous file in the input list (TRACKING)',
                                'Current file in the input list (LIVE)'])
    if (nproj == 1):   # Use projection axes from first file
        projection_mg = 0
        print('Using projection axes from first file')
    elif (nproj == 2): # Use projection axes from last file
        projection_mg = len(graphlist)-1
        print('Using projection axes from last file')
    elif (nproj== 3): # Use projection axes from specific list item
        sel_listnum = int(input('Input file list item number (0=first file,1=second file etc.):'))
        projection_mg = sel_listnum
        chosenfile = filelist[sel_listnum].rstrip()
        print('Using projection axes from file list item {0} - {1}'.format(sel_listnum,chosenfile)) 
    elif (nproj == 4): # Use projection axes from previous file (tracking mode)
        proj_tracking = True
        print('TRACKING - using projection axes from previous step')
    elif (nproj == 5): # Use projection axes from current file (live mode) e.g. for field projection
        proj_live = True
        print('LIVE MODE - using projection axes from current step')    
    else:             # error message and exit
        print("Invalid option - exiting ..")
        sys.exit()
    
    print("")
    print('== MODE SETTINGS ==')
    # drcpname, projcpname, cpf all set by now
    if hybrid_mode:
        print('* Shifts dr and projection directions will come from DIFFERENT CPs')
    else:
        print('* Shifts dr and projection directions will come from the same CP')
    print('             dr shifts from CP: {0}'.format(drcpname))
    print ('Projection directions from CP: {0}'.format(projcpname))
    if proj_tracking:
        print('* Tracking mode ON')
    else:
        print('* Tracking mode OFF')
    if proj_live:
        print('* Live mode ON')
    else:
        print('* Live mode OFF')
    print("===================")

    # If tracking mode not enabled, get all the necessary details of the projection MG
    if (proj_tracking == False): 
        projmg = graphlist[projection_mg]
        print("Using projection vectors from molecular graph in file: {0}".format(projmg.filename))
        if verbose:
            print("using CP named {0}".format(projcpname))
        proj_cplist = cpf.filter(projmg.cplist,cpname=projcpname)
        if len(proj_cplist) == 0:
            print('Could not find the mentioned CP - available CPs are')
            for cp in projmg.cplist:
                print(cp.connected)
            sys.exit()
        print('Specific projection CP is {0}'.format(proj_cplist[0].connected))
        #print("Filtered CP list coordinates in selected projection axes step") 
        #for cp in proj_cplist: # print the CP labels and positions
        #    print("{0} {1:18s} {2:12.8} {3:12.8} {4:12.8}".format(infile,cp.connected,cp.pos_x,cp.pos_y,cp.pos_z))
        proj_cp_names = [cp.connected for cp in proj_cplist]     # record projection MG CP names
    #
    # MAIN LOOP over sequence of molecular graphs
    mgcount = -1
    for thismg in graphlist: 
        print("============================================================")
        mgcount = mgcount + 1
        if (mgcount == 0): # FIRST FILE (MG) ONLY: set refmg, ref_cplist, ref_cp_names, first_ref_cplist
            #
            refmg = thismg
            # get the filtered list of CPs, set refmg, ref_cplist, ref_cp_names, first_ref_cplist
            ref_cplist = cpf.filter(thismg.cplist,cpname=specificcpname) # construct reference CP list for dr calculation from cpf object
            ref_cp_names = [cp.connected for cp in ref_cplist]           # record reference CP names
            if verbose:
                print("refmg contains {0}".format(ref_cp_names))
            first_ref_cplist = copy.deepcopy(ref_cplist)      # record CP list at first step
            #        
        else:              # GENERAL CASE - ALL SUCCEEDING MGs IN THE SEQUENCE
            # Get the filtered list of CPs in the current step in thiscplist
            if n == 8 or n == 9:  # specific CP or hybrid
                print('Looking for specific CP {0} in {1}'.format(drcpname,thismg.filename))
                thiscplist = cpf.filter(thismg.cplist,cpname=drcpname)
                print('Looked for {0}, matches={1}'.format(drcpname,len(thiscplist)))
            elif n == 10:      # Current density J from this CP
                print('Current density J not fully implemented yet!"')
                sys.exit()
            else:                 # multiple CPs defined by type
                thiscplist = cpf.filter(thismg.cplist)
                print('Found {0} matching CPs in {1}'.format(len(thiscplist,thismg.filename)))
            if len(thiscplist) == 0:
                print('No matching CPs found - exiting')
                sys.exit()
            thiscplist_names = [cp.connected for cp in thiscplist]    
            if (proj_tracking) == True:  # For tracking, make the projection molecular graph be the most recently-defined reference molecular graph 
                projmg = refmg
                #proj_cplist = ref_cplist
                proj_cplist = cpf.filter(projmg.cplist,cpname=projcpname)
                proj_cp_names = [cp.connected for cp in proj_cplist]
                print('proj_cp_names = {0} from {1}'.format(proj_cp_names,projmg.filename))
            # check if at least one matching CP was found in this step, set change_reference flag if not
            change_reference = False
            if len(thiscplist) > 0:
                change_reference = True
            
            # LOOP OVER selected CPs in this MG
            # Check each CP in current MG exists in reference and projection list            

            for cp in thiscplist:  
                #  STEP 1. first check for specified CP in the reference list
                #
                ref_found = False
                for ref_cp in ref_cplist:  # check if CP found in ref CP list, fix or ignore if not found
                    if ref_cp.connected == cp.connected:
                        ref_found = True
                # if this cp isn't in the reference step or already ignored 
                if ((not(ref_found)) and (ignore_list.count(cp.connected) < 1) ):  # This BCP does not appear in reference step, not on ignore list (fix or ignore)       
                    ref_cp_names = [i.connected for i in ref_cplist]
                    print("Found a CP named [{0}] which does not exist in the reference step".format(cp.connected))
                    n=bu.numbered_menu('Enter the list number of a matching reference step CP, or 99 to ignore this CP in future',ref_cp_names)
                    if ignorenew or n==99:
                        print('Ignoring this new CP')
                        n = 99
                    #
                    if (not(n==99)):                    # add a new clone CP to the ref list
                        newcp = copy.deepcopy(ref_cplist[n-1])
                        newcp.connected = cp.connected
                        print("")
                        print("Selected a reference step CP at {0:12.8} {1:12.8} {2:12.8}".format(newcp.pos_x,newcp.pos_y,newcp.pos_z))
                        ref_cplist.append(newcp)        # add this new CP to the reference list
                        first_ref_cplist.append(newcp)  # also add it to the reference list from the first frame
                    else:                               # mark this CP to be ignored in future
                        ignore_list.append(cp.connected)

                # STEP 2: then check in the projection CP list
                #
                proj_found = False
                #print('Searching for projcpname {0}'.format(projcpname))
                for proj_cp in projmg.cplist: # check if CP found in proj CP list, fix or ignore if not found
                    #print(proj_cp.connected)
                    if proj_cp.connected == projcpname:
                        proj_found = True
                        print('Found {0}'.format(projcpname))
                if ((not(proj_found)) and (ignore_list.count(cp.connected) < 1) ): # This BCP does not appear in reference step, not on ignore list
                    print("Found a CP named {0} which does not exist in the projection step".format(projcp.connected))
                    n=bu.numbered_menu('Enter the list number of a matching projection step CP, or 99 to ignore this CP in future',proj_cp_names)
                    #
                    if (not(n==99)): # add a new clone CP to the ref list
                        newcp = copy.deepcopy(proj_cplist[n-1])
                        newcp.connected = cp.connected
                        print("")
                        print("Selected a projection step CP at {0:12.8} {1:12.8} {2:12.8}".format(newcp.pos_x,newcp.pos_y,newcp.pos_z))
                        proj_cplist.append(newcp)        # add this new CP to the projection list
                    else:            # mark this CP to be ignored in future
                        ignore_list.append(cp.connected) 
                #print('CP check in projection list')
            #    
            # DONE CHECKS, now loop over CPs in thismg and print projections
            if verbose:
                if fieldmode:
                    print("Current density J constructed from: {0}".format(refmg.filename))
                    print("                           CP name: {0}".format(refmg.filename)) 
                else:
                    print("Position shift dr constructed from: {0}".format(refmg.filename))
                    print("                                to: {0}".format(thismg.filename))
                    print("                           CP name: {0}".format(drcpname))
                print("Projection axes from              : {0}".format(projmg.filename))
                print("                           CP name: {0}".format(projcpname))        
            print("Filename,         Connectivity,     dr.e1h, dr.e2h, dr.e3h, dr.e1s, dr.e2s, dr.e3s, moddr")

            for cp in thiscplist: # for each selected CP in this MG, calculate the dr and projections
                if (ignore_list.count(cp.connected) > 0): # skip this CP if it is on the ignore list
                    continue
                #
                if fieldmode:
                    # Field should always be available at this CP
                    refcplist = [ cp ]   # rewrite the reference CP list as just this CP
                #
                found_cp = False          
                for refcp in ref_cplist: # If this CP exists in the reference step, get the dr
                    if cp.connected == refcp.connected: # found the corresponding CP in the reference step
                        found_cp = True
                        if fieldmode:  # current density J vector -> dr
                            print('Constructing dr = J vector for CP {0}'.format(cp.connected))
                            # load field for this timestep
                            # get field vector at                             
                        else:
                            print('Constructing dr shift for CP {0}'.format(refcp.connected))
                            print('Constructing dr as {0} -> {1}'.format(cp.connected, refcp.connected))
                            print('From: {0},{1},{2}'.format(refcp.pos_x,refcp.pos_y, refcp.pos_z))
                            print('  To: {0},{1},{2}'.format(cp.pos_x,cp.pos_y, cp.pos_z))
                            # calculate dr
                            dr = [cp.pos_x - refcp.pos_x, cp.pos_y - refcp.pos_y, cp.pos_z - refcp.pos_z]
                            moddr =  math.sqrt(bu.dotprod(dr,dr))
                        # NORMALIZE DR (trap ZeroDivisionError)
                        try:
                            dr = [dr[0]/moddr, dr[1]/moddr, dr[2]/moddr]
                        except ZeroDivisionError:
                            moddr = 0.0
                            dr = [0.0,0.0,0.0]
                        #
                if (not found_cp): # CP not found in reference step, exit with error message and CP name
                    print("ERROR: {0} {1:12s} not found in reference step".format(infile, cp.connected))
                    sys.exit()
                # 
                # If this CP exists in the projection axes step, get the corresponding eigenvectors
                # 
                found_proj_cp = False
                for proj_cp in proj_cplist: # calculate and print dot products 
                    if proj_cp.connected == projcpname: # found the corresponding CP in the reference step matching current CP and project dr
                        # get projection eigenvectors
                        e1h = proj_cp.HessRho_EigVec1
                        e2h = proj_cp.HessRho_EigVec2 
                        e3h = proj_cp.HessRho_EigVec3
                        print('TrajCP {0}  dr: {1}'.format(drcpname,dr))
                        print('ProjCP {0} e1h: {1}'.format(projcpname,e1h))
                        print('ProjCP {0} e2h: {1}'.format(projcpname,e2h))
                        print('ProjCP {0} e3h: {1}'.format(projcpname,e3h))
                        e1s = proj_cp.Stress_EigVec1
                        e2s = proj_cp.Stress_EigVec2
                        e3s = proj_cp.Stress_EigVec3
                        # perform projections
                        dpe1h = bu.dotprod(dr,e1h)
                        dpe2h = bu.dotprod(dr,e2h)
                        dpe3h = bu.dotprod(dr,e3h)
                        dpe1s = bu.dotprod(dr,e1s)
                        dpe2s = bu.dotprod(dr,e2s)
                        dpe3s = bu.dotprod(dr,e3s)
                        # GENERATE OUTPUT
                        # filename, CP, dr.e1h, dr.e2h, dr.e3h, dr.e1s, dr.e2s, dr.e3s, moddr                        
                        #print("{0} {1:12s} {2:12.8} {3:12.8} {4:12.8} {5:12.8} {6:12.8} {7:12.8} {8:12.8}".format(thismg.filename,cp.connected,
                        # dpe1h,dpe2h,dpe3h,dpe1s,dpe2s,dpe3s,moddr))
                        output_line="{0} {1:18s} {2:14.10} {3:14.10} {4:14.10} {5:14.10} {6:14.10} {7:14.10} {8:14.10}".format(thismg.filename,cp.connected,
                                                                                                                               dpe1h,dpe2h,dpe3h,dpe1s,dpe2s,dpe3s,moddr)
                        if change_reference == False:
                            output_line="# CP is missing"
                        print(output_line)
                        if specificcpname != '':
                            ftraj.write(output_line+'\n')
                        found_proj_cp = True
                        continue
                       
                # Checks to catch cases where CPs not found
                if (not found_proj_cp): # CP not found in projection step list, exit with error message and list of projection step CPs
                    print("WARNING - did not find a matching CP called {0} in projection vector MG".format(cp.connected))
                    print([proj_cp.connected for proj_cp in proj_cplist])  
                    sys.exit()                   
                if (not found_cp): # CP not found in reference step list, exit with error message and lists of reference and projection step CPs
                    print("ERROR: {0} {1:12s} not found in reference step".format(infile, cp.connected))
                    print("Names of CPs in reference step")
                    print([refcp.connected for refcp in ref_cplist])
                    print("Names of CPs in projection step")
                    print([proj_cp.connected for proj_cp in proj_cplist])
                    sys.exit()
            # Current MG becomes the new dr reference MG
            if change_reference:
                print('This MG now becomes the new dr reference MG')
                ref_cplist = copy.deepcopy(thiscplist)
                refmg = thismg        
                print("Current step becomes the new reference step") 
            #dummy= input('Press return')                    
            #
    print("============================================================")    
    # end of main program
    print("Ignored CPs:")
    for name in ignore_list:
        print(name)
    # close output .traj file
    if ftraj is not None:
        ftraj.close()
    if proj_tracking:
        endstring = "Tracking "
    else:
        endstring = ""
    if hybrid_mode:
        endstring = endstring+"Hybrid "
    else:
        endstring = endstring+"Standard "
    print('Finished producing this {0} trajectory'.format(endstring))
    print("Program exiting")

# call main
if __name__ == '__main__':
    main()

# -*- coding: utf-8 -*-


"""drproject3.__main__: executed when drproject3 directory is called as script."""


from .drproject3 import main
main()
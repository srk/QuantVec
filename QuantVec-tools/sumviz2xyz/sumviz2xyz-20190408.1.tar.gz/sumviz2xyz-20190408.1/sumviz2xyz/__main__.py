# -*- coding: utf-8 -*-


"""sumviz2xyz .__main__: executed when sumviz2xyz  directory is called as script."""


from .sumviz2xyz  import main
main()
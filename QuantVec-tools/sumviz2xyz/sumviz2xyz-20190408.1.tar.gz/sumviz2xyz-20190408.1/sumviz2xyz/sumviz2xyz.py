# -*- coding: utf-8 -*-
"""
sumviz2xyz
---------------------------------
Loops over all .sumviz (atomic units) files in the current directory and recreates 
a multi-step.xyz file (Angstrom units)

Usage: python sumviz2xyz.py <inputfile/filelist> <output XYZ file name>


"""
from __future__ import print_function
import argparse, glob
import molgraph as mg

__version__ = "20190408.0001"

def main():
    parser = argparse.ArgumentParser(description="Convert all molecular graph data files to simple XYZ format\n"+
                                                 "===========================================================")
    parser.add_argument("inputfile",help="Input file or filelist(.txt)")
    parser.add_argument("outputfile", help="XYZ file name for output")
    parser.add_argument("--verbose",help="Show more verbose screen output",action='store_true')
    args = parser.parse_args()
                    
    arglist = []
    verbose = args.verbose
    inputfile = args.inputfile
    
    print("sumviz2xyz")
    print("==========")
    print("Version {0}".format(__version__))
    if inputfile.endswith(".txt"):  # filelist case
        with open(inputfile,'r') as f:
            for line in f.readlines():
                if not (line.startswith('#') or line.strip() == ''):
                    arglist.append(line)
    else:
        arglist.append(inputfile)

    xyzfilename = args.outputfile
    with open(xyzfilename,'w') as xyzfile:
        for filename in arglist:
# open the specified file
            print('Reading file: {0}'.format(filename.strip()))
            t = mg.Molgraph()        # make a new Molgraph object called 't'
            t.read(filename.strip())
            if verbose:
                print("Using molgraph version {0}".format(mg.__version__))
                print("Input file type = {0}".format(t.filetype))
                print("Codeversion = {0}".format(t.codeversion))
                print("Wavefunction file = {0}".format(t.wf_file))
                print("Title = {0}".format(t.title))
                print("Model = {0}".format(t.model))
                print("ATOMIC DATA")
                print('Label Charge X Y Z')
                for i in range (0,len(t.atom_label)): # loop over all atomic nuclei in the molecular graph
                    print("{0} {1} {2} {3} {4}".format(t.atom_label[i],t.atom_charge[i],
                          t.atom_x[i],t.atom_y[i],t.atom_z[i]))
                print("Molecular charge: {0} Molecular Energy: {1}".format(t.mol_charge,t.mol_energy))
                print("Molecular virial ratio: {0}".format(t.mol_virial_ratio))
                print("Critical points")
                for cp in t.cplist: # loop over all CPs in the molecular graph
                    print ("")
                    print ("{0} : {1} {2} {3}".format(cp.type,cp.pos_x,cp.pos_y,cp.pos_z))
                    print ("Rho = {0:17.10E}\nGradRho = {1:17.10E} {2:17.10E} {3:17.10E}".format(
                            cp.Rho,cp.GradRho[0],cp.GradRho[1],cp.GradRho[2]))
                    if cp.type == "BCP":
                        print("BPL     = {0:17.10E}".format(cp.BPL))
                        print("GBL_I   = {0:17.10E}".format(cp.GBL_I))
                        print("GBL_II  = {0:17.10E}".format(cp.GBL_II))
                        print("GBL_III = {0:17.10E}".format(cp.GBL_III))
                        print("GBL_IV  = {0:17.10E}".format(cp.GBL_IV))
                        if (len(cp.pathlist) > 0):
                            print("This BCP has {0} associated paths with lengths:".format(len(cp.pathlist)))
                            for thispath in cp.pathlist:
                                print(len(thispath.path_x))            
                print("Critical point counts: NCP={0} NNA={1} BCP={2} RCP={3} CCP={4}".format(
                                        t.num_ncp,t.num_nna,t.num_bcp,t.num_rcp,t.num_ccp))
                print("Writing nuclear coordinates to .xyz format")
            t.nuctoxyz(xyzfile)
# finished looping over files

if __name__ == '__main__':
    main()



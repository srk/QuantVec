# -*- coding: utf-8 -*-
"""setup.py: setuptools control."""

import re
from setuptools import setup,find_packages

version = re.search(
    '^__version__\s*=\s*"(.*)"',
    open('sumviz2xyz/sumviz2xyz.py').read(),
    re.M
    ).group(1)

setup(
    name = "sumviz2xyz",
    py_modules=['sumviz2xyz'],
    packages=find_packages(),
    version = version,
    entry_points = {
        "console_scripts": [' sumviz2xyz = sumviz2xyz.sumviz2xyz:main',]
        },    
    author='Prof. Steven R. Kirk',
    author_email='stevenrkirk@gmail.com',
    description = "sumviz2xyz",
    url = 'https://www.beaconresearch.org',
    )

# -*- coding: utf-8 -*-
"""setup.py: setuptools control."""

import re
from setuptools import setup

version = re.search(
    '^__version__\s*=\s*"(.*)"',
    open('trajplot/trajplot.py').read(),
    re.M
    ).group(1)

setup(
    name = "trajplot",
    packages = ["trajplot"],
    entry_points = {
        "console_scripts": ['trajplot=trajplot.trajplot:main',]
        },
    version = version,
    author='Prof. Steven R. Kirk',
    author_email='stevenrkirk@gmail.com',
    description = "trajplot",
    url = 'https://www.beaconresearch.org',
    install_requires=['numpy','matplotlib'],
    )

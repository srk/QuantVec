# -*- coding: utf-8 -*-


"""trajplot.__main__: executed when trajplot directory is called as script."""


from .trajplot import main
main()
# -*- coding: utf-8 -*-
"""
trajplot
========
Usage: trajplot <file containing list of files in desired sequence>
Input file format: each line has the format
              datafilename linecolour linestyle markersymbol markerfill markersize filterstring
              e.g. data.txt red - o full 5 avg+avg+avg
              Blank lines or lines starting with # are ignored. filterstring = 'none' or sequences of filter operations e.g. 'avg','turn'
              If a header line of the form '# curvelabelstring' is found in the input data header, it is used to set the curve label
"""
from __future__ import print_function

__version__ = "20211231.0001"
import sys, math, os, copy, argparse, csv, os.path
import matplotlib as mpl
import numpy as np
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.pyplot as plt
import beacon_utils as bu

def csvdump(csvfile,header,data):
    """
    Dump a CSV file to specified filename 'csvfile'
    Start file with list of header line strings
    Continue with data lines (list of lists)
    Close file after creation
    """
    if not csvfile == 'none':
        with open(csvfile,'w',newline='') as csvf:
            csvwriter = csv.writer(csvf, dialect='excel',delimiter=',',quotechar='"', quoting=csv.QUOTE_NONNUMERIC)
            for line in header:
                csvwriter.writerow(['#'+line])
            for row in data:               
                csvwriter.writerow(row)

def running_mean(x, N):
    cumsum = numpy.cumsum(numpy.insert(x, 0, 0)) 
    return (cumsum[N:] - cumsum[:-N]) / N                
                
def traj_filter(alg,x,y,z,dr,valid,maxturn,avgflag):
    """
    From a 3D trajectory with coordinates held in lists x,y,z and step size information in dr,
    modify a list of logical point validity flags 'valid' using algorithm 'alg', the same length as 
    the input trajectory, with True = valid point, False = possible transient. Maximum allowed turn allowed
    in filtered path given by 'maxturn' (degrees).
    """
    traj_len = len(x)
    transient_count = 0
    # convert maxturn from degrees to radians
    maxturn = maxturn*math.pi/180.0
    print('Filtering a trajectory of length {0}'.format(traj_len))
    if alg == 'turn':  # filter by comparison of 1-2 and 1-3 turning angles
        # prescreen by short dr between two longer dr's
        for i in range(2,traj_len-1):
            dri = dr[i]
            drj = dr[i-1]
            drk = dr[i+1]
            if (dri < 0.25*(drj+drk)):
                valid[i] = False
        print('Prescreened {0} points as transients'.format(valid.count(False)))
        print('Using turn angle algorithm')
        #initialize algorithm
        prevstep = [x[1]-x[0], y[1]-y[0], z[1]-z[0]]
        # loop through points, starting from the second one
        for i in range(2,traj_len-1):  # i is the reference point, first and last points must be valid
            # skip this point if already marked as a transient
            if not valid[i]:
                #print('Skipped {0}'.format(i))
                continue
            # find the most recent valid point
            prevfound = False
            j=i
            while not prevfound:
               j = j-1
               if valid[j]:
                   prevfound = True
            assert(j > -1)  # there must be previous valid point somewhere behind us
            # previous valid point is now 'j'
            # find the next valid point
            nextfound = False
            k = i
            while not nextfound:
                k = k + 1
                if valid[k]:
                    nextfound = True
            assert(k < traj_len)  # there must be a valid point ahead
            # next valid point is now 'k'
            #
            #print('Point {0}: previous = {1},next = {2}'.format(i,j,k))            
            dji = [ x[i]-x[j], y[i]-y[j], z[i]-z[j] ]
            djk = [ x[k]-x[j], y[k]-y[j], z[k]-z[j] ]
            dri = dr[i]    # moddr for this point
            drj = dr[j]    # moddr for previous valid point
            drk = dr[k]    # moddr for next valid point
            modprevstep = math.sqrt(bu.dotprod(prevstep,prevstep))
            modji = math.sqrt(bu.dotprod(dji,dji))
            modjk = math.sqrt(bu.dotprod(djk,djk))
            #print('modprevstep={0}, modd1={1}, modd2={2}'.format(modprevstep,modd1,modd2))
            angle1 = math.acos(bu.dotprod(dji,prevstep)/(modprevstep*modji))  # ji angle with previous step
            angle2 = math.acos(bu.dotprod(djk,prevstep)/(modprevstep*modjk))  # jk angle with previous step
            # test if point 'i' is a one-point transient
            bool_straighter = (angle2 < angle1)      # true if j-k step is 'straighter ahead'
            bool_bigturn = (angle1 > maxturn)            # true if j-i step turns by > maxturn from previous
            bool_modchange = (dri < 0.25*(drj+drk))  # true if dr[i] less than half the mean of dr[j] and dr[k] 
            if ( (bool_straighter and bool_bigturn) ):  #  found a transient
                #print('{0} NO: straighter={0} bigturn={1} tooshort={2}'.format(bool_straighter,bool_bigturn,bool_modchange))           
                valid[i] = False   
                transient_count = transient_count + 1
            else:
                #print('{0} YES'.format(i))
                valid[i] = True
                prevstep = dji
    elif alg == 'avg':  # averaging filter
        # prescreen by short dr between two longer dr's
        for i in range(2,traj_len-1):
            dri = dr[i]
            drj = dr[i-1]
            drk = dr[i+1]
            if (dri < 0.25*(drj+drk)):
                valid[i] = False
        print('Prescreened {0} points as transients'.format(valid.count(False)))
        print('Using 2-point averaging algorithm')
        avgflag = True
        # make new arrays of only currently valid points
        new_x = np.array( [ix for (ix, flag) in zip(x, valid) if flag] )
        new_y = np.array( [iy for (iy, flag) in zip(y, valid) if flag] )
        new_z = np.array( [iz for (iz, flag) in zip(z, valid) if flag] )
        # start
        x[:] = []
        y[:] = []
        z[:] = []
        valid[:] = []
        x.append(new_x[0])
        y.append(new_y[0])
        z.append(new_z[0])
        valid.append(True)
        # middle
        for i in range (1, len(new_x)-1):
            #x.append( (new_x[i-1] + new_x[i] )/2.0 )
            #y.append( (new_y[i-1] + new_y[i] )/2.0 )
            #z.append( (new_z[i-1] + new_z[i] )/2.0 )
            x.append( (new_x[i-1] + new_x[i] + new_x[i+1])/3.0 )
            y.append( (new_y[i-1] + new_y[i] + new_y[i+1])/3.0 )
            z.append( (new_z[i-1] + new_z[i] + new_z[i+1])/3.0 )
            valid.append(True)
        #end
        x.append(new_x[-1])
        y.append(new_y[-1])
        z.append(new_z[-1])   
        valid.append(True)
        print ('Created averaged trajectory of length {0}'.format(len(x)))
        
        
    print('Filter detected {0} transients'.format(transient_count))
    num_transients = valid.count(False)
    print('{0}/{1} points are now flagged as possible transients'.format(num_transients,traj_len))
    return 

def set_axes_equal(ax: plt.Axes):
    """Set 3D plot axes to equal scale.

    Make axes of 3D plot have equal scale so that spheres appear as
    spheres and cubes as cubes.  Required since `ax.axis('equal')`
    and `ax.set_aspect('equal')` don't work on 3D.
    """
    limits = np.array([
        ax.get_xlim3d(),
        ax.get_ylim3d(),
        ax.get_zlim3d(),
    ])
    origin = np.mean(limits, axis=1)
    radius = 0.5 * np.max(np.abs(limits[:, 1] - limits[:, 0]))
    _set_axes_radius(ax, origin, radius)

def _set_axes_radius(ax, origin, radius):
    x, y, z = origin
    ax.set_xlim3d([x - radius, x + radius])
    ax.set_ylim3d([y - radius, y + radius])
    ax.set_zlim3d([z - radius, z + radius])

def trajplot(filelist, axislabels,matrix,modulus,zerothresh,csvfile,maxturn,plot_title):
    """
    Routine to plot a set of 3-D trajectories using the coordinates held in the
    3rd, 4th, and 5th columns [Hessian of Rho] (after skipping the first line)
    or 6th, 7th and 8th columns [Bader stress tensor] of a set of data files 
    which are listed in the text file whose name is given by the variable 'filelist'.
   'axislabels' is a simple list of 3 strings giving the 'x', 'y' and 'z' axis labels. 
 
    The legend for each trajectory is taken from the second non-whitespace string 
    on the first line of each numerical data file.
 
    In the 'filelist' file, if the name of a numerical data file is followed by a 
    space and a Matplotlib colour code (e.g. 'g' for green), that colour is used 
    for the trajectory. If no colour code is present, the default colour is blue.
    
    The lines look like:
    data_file {line_colour line_style line_marker marrker_fill marker_size filter
    
    20160131 Added choice to apply modulus operator or not
    20170104 Added per-dataset filter option to plot file
    20170412 Added 'maxturn' for filter algorithm - max. allowed turn angle in filter algorithm
    20200604 caught blank line in plotfile corner case
    20211231 replaced deprecated matplotlib 'gca()' call
    
    """
    # matplotlib parameters
    mpl.rcParams['legend.fontsize'] = 10 # change font sizes etc. here
    mpl.rcParams['lines.linestyle'] = '-'
    mpl.rcParams['lines.marker'] = '.'
    fig = plt.figure()
    ax = fig.add_subplot(projection='3d')
    xlabel = axislabels[0]
    ylabel = axislabels[1]
    zlabel = axislabels[2]
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    ax.set_zlabel(zlabel)
    
    # select eigenvectors and modulus/no-modulus mode
    print("")
    if (matrix == 'ask'):
        n = bu.numbered_menu('Select a matrix for eigenvector projections',['Hessian of charge density','Bader stress tensor'])
        if (n == 1): # Hessian of Rho projections                                                        
            matrix = 'hessian'
        elif (n == 2): # Bader Stress tensor projections
            matrix = 'stress'
        else:
            print("Error: exiting ..")
            sys.exit()
    # report projection eigenvectors used
    if (matrix =='stress'):
        print('Projecting onto stress tensor eigenvectors')
    elif (matrix =='hessian'):
        print('Projecting onto Hessian(rho) eigenvectors')    
    # choose plot titles
    if plot_title == 'auto':  # automatically generated title
        if (matrix =='stress'):
            subtitle = 'Stress tensor eigenvector projections'
        elif (matrix =='hessian'):
            subtitle = 'Hessian eigenvector projections'
    elif plot_title == 'none':  # no plot title
        subtitle = ''
    else:    # arbitrary title string
        subtitle = plot_title.strip('\'"')   
    print("")
    if (modulus == 'ask'):
        n_mod = bu.numbered_menu('Do you want to use the modulus of the coordinates?',['No','Yes'])
        if (n_mod == 1): # don't use modulus
            modulus = 'no' 
        elif (n_mod == 2): # Use modulus
            modulus = 'yes'
        else:
            print("Error: exiting ..")
            sys.exit()
    if (modulus == 'no'):  # usual case
        print("Modulus operator NOT applied to plot coordinates")
    elif (modulus == 'yes'):
        print("Modulus operator applied to plot coordinates")
        xlabel = '|'+axislabels[0]+'|'
        ylabel = '|'+axislabels[1]+'|'
        zlabel = '|'+axislabels[2]+'|'
        ax.set_xlabel(xlabel)
        ax.set_ylabel(ylabel)
        ax.set_zlabel(zlabel)
    # Print selected zero threshhold and max. turning angle
    print('Rounding projected coordinates < {0} to exactly zero'.format(zerothresh))
    print('Turn filter max. turning angle = {0} degrees'.format(maxturn))
    
    # extra subtitle if needed
    extratitle = input("Enter additional title text, or just press Return: ")
    if (len(extratitle) == 0):
       ax.set_title(subtitle)
    else:
       ax.set_title(extratitle+'\n'+subtitle)
    pathfileslist = []
    sumdslist = []
    totaldrlist = []
    trajlist = []
    allboxlist = []
    trajcount = 0
    maxfilenamelen = 0
    
    # loop over input files
    for infiledesc in filelist:
        if (not (infiledesc.startswith('#') or len(infiledesc.strip()) == 0)): # lines starting with '#' are skipped
            print(infiledesc)
            pathfileslist.append(infiledesc)
            listtokens = infiledesc.split()
            
            # parse optional line and marker style parameters
            # line colour
            if (len(listtokens) > 1):       # set line colour
                linecolour = listtokens[1]
            else:
                linecolour = 'b'
            if (len(listtokens) > 2):       # set line style
                linestyle = listtokens[2]
            else:
                linestyle = '-'    
            if (len(listtokens) > 3):       # set line marker
                linemarker = listtokens[3]
            else:
                linemarker = '.'    
            if (len(listtokens) > 4):       # set line marker fill style
                linemarkerfillstyle = listtokens[4]
            else:
                linemarkerfillstyle = 'full'
            if (len(listtokens) > 5):       # set line marker size
                linemarkersize = listtokens[5]
            else:
                linemarkersize = '10'
            if (len(listtokens) > 6):       # set optional filter name
                filternames = listtokens[6]
            else:
                filternames = 'none'
                
            # open the data file
            trajcount = trajcount + 1
            infilename = listtokens[0].strip()
            namelen = len(infilename)
            if namelen > maxfilenamelen:
                maxfilenamelen = namelen
            infile = open(infilename)
            line = "#"
            curvelabel = ''
            while (line.startswith('#') or len(line.strip()) == 0):  # look for first non-blank line that does not start with '#'
                tokens = line.split()
                if (len(tokens) == 2):         # This could be a header line of the form '# curvelabel'
                   if tokens[0] == '#':        # the second field is the intended curve label
                       curvelabel = tokens[1]  # set the curve label                   
                line = infile.readline()
            
            if curvelabel == '':
                print('Fetching curve label from second field on data line:')
                print('{0}'.format(line))            
                curvelabel = line.split()[1] # get label from first actual data line of file if not already set
            
            x = []
            y = []
            z = []
            point_moddr=[]
            dataname = []
#            sumds = 0.0         # length of CP trajectory in U-space
            totaldrlength = 0.0 # total real-space length of CP trajectory in au
            old_drpx = 0.0
            old_drpy = 0.0
            old_drpz = 0.0
            firstpoint = True
            
            # LOOP OVER DATA FILE LINES
            while (len(line.strip()) > 0):  # loop over data lines
                tokens = line.split()
                if (not(tokens[0].startswith("#"))):  #  if line doesn't start with '#'
                    if (matrix == 'hessian'): # Hessian of Rho eigenvector frame e1h,e2h,e3h [columns 3,4,5]
                        frame_coords = [ float(tokens[2]), float(tokens[3]), float(tokens[4]) ]
                    else:                      # Stress Tensor eigenvector frame e1s,e2s,e3s [columns 6,7,8]
                        frame_coords = [ float(tokens[5]), float(tokens[6]), float(tokens[7]) ]
                        
                    # multiply projections by moddr = length of CP shift in atomic units [column 9]
                    moddr = float(tokens[8])
                    
                    # construct trajectory path coordinates (drpx,drpy,drpz) using moddr
                    if (modulus == 'no'): # no modulus
                        drpx = frame_coords[0]*moddr
                        drpy = frame_coords[1]*moddr
                        drpz = frame_coords[2]*moddr
                    else: # modulus  - absolute values                      
                        drpx = math.fabs(frame_coords[0])*moddr
                        drpy = math.fabs(frame_coords[1])*moddr
                        drpz = math.fabs(frame_coords[2])*moddr
                    if (math.fabs(drpx) < zerothresh ):
                        drpx = 0.0                    
                    x.append(drpx)
                    if (math.fabs(drpy) < zerothresh ):
                        drpy = 0.0
                    y.append(drpy)
                    if (math.fabs(drpz) < zerothresh ):
                        drpz = 0.0
                    z.append(drpz)
                    point_moddr.append(moddr)
                    dataname.append(tokens[0])
                    totaldrlength = totaldrlength + moddr
                # read next line
                line = infile.readline()
                
            # done reading this trajectory, close file
            infile.close()
           
            # filter the trajectory if requested
            lentraj = len(x)
            print('TRAJECTORY ANALYSIS:')
            print('Trajectory has {0} points'.format(lentraj))            
            valid = [True]*lentraj  # first, assume all trajectory points are valid
            thisfilterlist = filternames.split('+')
            # set the averaging flag to False by default
            avgflag = False
            for thisfilter in thisfilterlist:
                if (thisfilter == 'turn' or thisfilter == 'avg'):  # apply turning angle filter
                    traj_filter(thisfilter,x,y,z,point_moddr,valid,maxturn,avgflag)
                    
            # show filtered points
            blocklist = [name for name,x in zip(dataname,valid) if not x] 
            if len(blocklist) > 0:
                print('Transient points are:')
                print('{0}'.format(','.join(blocklist)))
                
            # make new lists of points for plotting based on validity
            plotx = [ix for (ix, flag) in zip(x, valid) if flag]
            ploty = [iy for (iy, flag) in zip(y, valid) if flag]
            plotz = [iz for (iz, flag) in zip(z, valid) if flag]
            plotname = [name for (name, flag) in zip(dataname,valid) if flag]
            newmoddr = [idr for (idr, flag) in zip(point_moddr, valid) if flag]
            # calculate and record box sizes
            newbox = [max(plotx)-min(plotx), max(ploty)-min(ploty), max(plotz)-min(plotz) ]
            allboxlist.append(newbox)
            
            # dump plot points as .csv
            #trajcsvname = csvfile+'_'+"{0}".format(trajcount)+'.csv'
            if csvfile == '':
                print('infilename = {0}'.format(infilename))
                trajcsvname = infilename[:-4]+'_'+"{0}".format(trajcount)+'_trj.csv'
            else:
                trajcsvname = csvfile+'_'+"{0}".format(trajcount)+'.csv'

            if not avgflag:  # not averaged
                dumpdata = [[ xlabel,ylabel,zlabel,'moddr' ]]
                numberlist = [ [dumpx,dumpy,dumpz,nmdr] for (dumpx,dumpy,dumpz,nmdr) in zip(plotx,ploty,plotz,newmoddr)]
            else:            # averaged
                dumpdata = [[ xlabel,ylabel,zlabel ]]
                numberlist = [ [dumpx,dumpy,dumpz] for (dumpx,dumpy,dumpz) in zip(plotx,ploty,plotz)]
            dumpdata.extend(numberlist)
            csvdump(trajcsvname,[ infilename ],dumpdata)
            
            # now calculate u-space length from plottable points
            sumds = 0.0         # length of CP trajectory in U-space
            for i in range(1,len(plotx)):  # from second point onwards
                ushift_x = plotx[i] - plotx[i-1]
                ushift_y = ploty[i] - ploty[i-1]
                ushift_z = plotz[i] - plotz[i-1]
                ushift = math.sqrt((ushift_x*ushift_x)+(ushift_y*ushift_y)+(ushift_z*ushift_z))
                sumds = sumds + ushift
                
            # record the u-space length and real-space length of this filtered path
            sumdslist.append(sumds)
            if avgflag:  # averaged data 
                totaldrlist.append(-0.0)
            else:
                totaldrlist.append(totaldrlength)
            
            # plot the line itself
            ax.plot(plotx,ploty,plotz, label=curvelabel,
                                       color=linecolour,
                                       linestyle=linestyle,
                                       marker=linemarker,
                                       fillstyle=linemarkerfillstyle,
                                       markersize=linemarkersize,
                                       picker=5)
            
            # plot symbols at the beginning and end of each curve
            start_x = []
            start_x.append(plotx[0])
            start_y = []
            start_y.append(ploty[0])
            start_z = []
            start_z.append(plotz[0])
            end_x = []
            end_x.append(plotx[-1])
            end_y = []
            end_y.append(ploty[-1])
            end_z = []
            end_z.append(plotz[-1])
            
            # now plot the end markers - 's'=square at the start, 'x' at the end
            endmarkersize = float(linemarkersize)*1.5
            ax.plot(start_x,start_y,start_z, marker='s',color=linecolour,markersize=endmarkersize)
            ax.plot(end_x,end_y,end_z, marker='x',color=linecolour,markersize=endmarkersize)
            print('Plotting trajectory {0} with {1} points'.format(trajcount,len(plotx)))
            
            # add plotted trajectory to trajectory list
            trajlist.append(copy.deepcopy([plotname, plotx, ploty, plotz]))
            
    ax.legend()


    ax.set_box_aspect([1,1,1]) # IMPORTANT - this is the new, key line
    ax.set_proj_type('ortho') # OPTIONAL - default is perspective (shown in image above)
    set_axes_equal(ax) # IMPORTANT - this is also required
    
    # enable picker
    fig.canvas.mpl_connect('pick_event', lambda event: onpick(event, trajlist))
    print('** Click on curve points for more information or close figure for summary **')
    #
    
    plt.tight_layout()
    plt.show()
    print('\nSums of plotted trajectory lengths')
    
    # Get filename lengths
    namelengths=[]
    for i in range(0,len(pathfileslist)):
        namelengths.append(len(pathfileslist[i].split()[0]))
    maxnamelen = max(namelengths)
    print("{:<{width}}".format("Name", width=maxnamelen)+' U-space path length  Real-space path length(au)')
    for i in range(0,len(pathfileslist)): # show sums of filtered dr's
        print("{0} {1}  {2}".format(pathfileslist[i].split()[0],sumdslist[i],totaldrlist[i]))  
    print('== Bounding Box lengths [ (e1.dr)_max, .. ] for output trajectories ==')
    j=0
    for limits in allboxlist:
        print('{0: >{1}}:  {2}, {3}, {4} '.format(pathfileslist[j].split()[0],maxfilenamelen,limits[0],limits[1],limits[2]))
        j=j+1
    print('======================================================================')     
    return

def onpick(event, trajlist):
    ind = event.ind[0]
    x, y, z = event.artist._verts3d
    pickedx = x[ind]
    pickedy = y[ind]
    pickedz = z[ind]
    # 
    for i in range(0,len(trajlist)):
        namelist = trajlist[i][0]
        xlist = trajlist[i][1]
        ylist = trajlist[i][2]
        zlist = trajlist[i][3]
        distlist = []
        for j in range(0,len(namelist)):
            distlist.append(distance3D([pickedx,pickedy,pickedz],[xlist[j],ylist[j],zlist[j]]))
        dr = min(distlist)
        idx = distlist.index(dr)
        print('Closest point {0} in curve {1}: {2},distance {3}'.format(idx+1,i+1,namelist[idx],dr))
    print(' ')
    
def distance3D(a,b):
   """
   Straight line distance between 3D points with coordinates in lists a and b
   """
   dx = a[0] - b[0]
   dy = a[1] - b[1]
   dz = a[2] - b[2]
   return math.sqrt((dx*dx)+(dy*dy)+(dz*dz))
    
# main program starts here
# argument parser
def main():
    parser = argparse.ArgumentParser(description="Trajectory plotter for drproject3 results\n"+
                                                 "==========================================\n",
                                                 formatter_class=argparse.RawTextHelpFormatter,
                                                 epilog="VERSION: "+__version__+"\n"+__doc__+"\n")
    parser.add_argument("filelist", help="File containing list of data files to plot")
    parser.add_argument("--matrix", help="Matrix used to provide projection eigenvectors",
                                    choices=['hessian','stress','ask=default'],
                                    default='ask')
    parser.add_argument("--modulus", help="Whether or not to use the modulus of the projected coordinates to plot: yes,no,ask(default)",
                                    choices=['no','yes','ask'],default='ask')
    parser.add_argument("--zerothresh", help="Integer N, where projection coordinates smaller than 10^(-N) are forced to zero: (default N=14)",
                                    default=14)
    parser.add_argument("--maxturn", help="Maximum turn angle to allow in filtered path, degrees: (default 60.0)",
                                    default=60.0)    
    parser.add_argument("--csvfile", help="Name of .csv file to dump trajectories, multiple sets will have suffix _1,_2 etc.: (default=datafile_n_trj.csv)",
                                     default='')
    parser.add_argument("--title", help="Title for plot (auto, none, 'requested title string') ",
                                    default="auto")                                   
    
    args = parser.parse_args()
    filelistname=args.filelist
    matrix=args.matrix
    modulus=args.modulus
    zthresh=10.0**(-1*int(args.zerothresh))
    csvfile=args.csvfile
    maxturn=float(args.maxturn)
    plot_title=args.title
    
    header=bu.repheader()
    print(__doc__)
    print('\n'.join(header))    
    print("VERSION "+__version__)
    print("")
    print("Input file: {0}".format(filelistname))
    cwd = os.getcwd()
    mpl.rcParams['savefig.dpi'] = 300
    mpl.rcParams['savefig.directory'] = cwd
    fl = open(filelistname,"r")
    flist = fl.readlines()
    trajplot(flist,['dr.e1','dr.e2','dr.e3'],matrix,modulus,zthresh,csvfile,maxturn,plot_title)
    fl.close()

if __name__ == '__main__':
    main()


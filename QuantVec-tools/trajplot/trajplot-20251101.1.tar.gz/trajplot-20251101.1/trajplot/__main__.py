# -*- coding: utf-8 -*-


"""trajcurve.__main__: executed when trajcurve directory is called as script."""


from .trajcurve import main
main()
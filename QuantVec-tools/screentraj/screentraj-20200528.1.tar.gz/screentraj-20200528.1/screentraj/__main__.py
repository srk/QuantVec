# -*- coding: utf-8 -*-


"""screentraj.__main__: executed when screentraj directory is called as script."""


from .screentraj import main
main()
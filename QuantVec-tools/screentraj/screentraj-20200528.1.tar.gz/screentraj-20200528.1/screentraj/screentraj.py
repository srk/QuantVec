# -*- coding: utf-8 -*-
"""
screentraj
=======

Usage: screentraj <file containing trajectory data>

"""

__version__ = "20200528.0001"
import sys, math, os, copy, argparse, csv, os.path
import matplotlib as mpl
import numpy as np
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.pyplot as plt
import beacon_utils as bu

def main():
    parser = argparse.ArgumentParser(description="Trajectory data prescreener for drproject3 results\n"+
                                                 "==================================================")
    parser.add_argument("inputfile", help="File containing list of data files to plot")
                                     
    args = parser.parse_args()
    inputfile=args.inputfile
    
    header=bu.repheader()
    print('\n'.join(header))
    print(__doc__)
    print("VERSION "+__version__)
    #print("Using beacon_utils module version {0}".format(bu.__version__))
    print("")

    x = []
    point_moddr=[]

    # prepare matplotlib 2-D graph
    fig, ax = plt.subplots()
    ax.set(xlabel='Sequence number', ylabel='Step Length moddr',
           title='Step length distribution')

    with open(inputfile) as infile:
        line = infile.readline()
        # LOOP OVER DATA FILE LINES
        while (len(line.strip()) > 0):  # loop over data lines
            tokens = line.split()
            if (not(tokens[0].startswith("#"))):  #  if line doesn't start with '#'
                datafilename =  tokens[0]
                datafilename = datafilename[:-7] # strip off .sumviz
                # remove file prefix and .sumviz from datafilename to leave the sequence number
                seqnum = float(datafilename[-4:])
                moddr = float(tokens[-1]) # this is the last value on each line, the moddr
                # add data point to arrays
                x.append(seqnum)
                point_moddr.append(moddr)
            line = infile.readline()

    # plot the line itself
    ax.plot(x,point_moddr,marker='.')
    plt.tight_layout()
    plt.show()

if __name__ == '__main__':
    main()

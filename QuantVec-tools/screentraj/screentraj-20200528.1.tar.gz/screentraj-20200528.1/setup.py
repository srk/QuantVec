# -*- coding: utf-8 -*-
"""setup.py: setuptools control."""

import re
from setuptools import setup

version = re.search(
    '^__version__\s*=\s*"(.*)"',
    open('screentraj/screentraj.py').read(),
    re.M
    ).group(1)

setup(
    name = "screentraj",
    packages = ["screentraj"],
    entry_points = {
        "console_scripts": ['screentraj=screentraj.screentraj:main',]
        },
    version = version,
    author='Prof. Steven R. Kirk',
    author_email='stevenrkirk@gmail.com',
    description = "screentraj",
    url = 'https://www.beaconresearch.org',
    install_requires=['numpy','matplotlib'],
    )

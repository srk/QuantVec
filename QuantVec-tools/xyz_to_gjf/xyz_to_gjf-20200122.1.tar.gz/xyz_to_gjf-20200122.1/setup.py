# -*- coding: utf-8 -*-
"""setup.py: setuptools control."""

import re
from setuptools import setup

version = re.search(
    '^__version__\s*=\s*"(.*)"',
    open('xyz_to_gjf/xyz_to_gjf.py').read(),
    re.M
    ).group(1)

setup(
    name = "xyz_to_gjf",
    packages = ["xyz_to_gjf"],
    entry_points = {
        "console_scripts": ['xyz_to_gjf=xyz_to_gjf.xyz_to_gjf:main',]
        },
    version = version,
    author='Prof. Steven R. Kirk',
    author_email='stevenrkirk@gmail.com',
    description = "xyz_to_gjf",
    url = 'https://www.beaconresearch.org'
    )
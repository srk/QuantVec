# -*- coding: utf-8 -*-


"""xyz_to_gjf.__main__: executed when xyz_to_gjf directory is called as script."""


from .xyz_to_gjf import main
main()
# -*- coding: utf-8 -*-
"""
xyz_to_gjf
==========
Split an xyz-format coordinate file, containing 1 or more structures
into multiple G09 input files using a template input file specified on
the command line. The template file looks like a standard G09 input file,
except it will contain no geometric information and will also contain different
text 'tags' of the form <tag>, i.e.

<xyz> : Should occur once in the template, and will be replaced in the
        output file by the atomic geometrical information.

<name>: Can occur in multiple locations in the template, and will be replaced
        by the name (without the .xyz extension) of the .xyz input file.
        
<frametitle>: Holds the comment line from each frame in the input .xyz file

Usage: xyz_to_gjf xyzname templatename

"""

__version__ = "20200122.0001"
import sys, argparse
import os.path


def main():
    print(__doc__)    
    print('VERSION: '+__version__)
    parser = argparse.ArgumentParser(description='Convert all structures in an input .xyz file to G09 input files using a template')
    parser.add_argument("xyzname", help="Name of input .xyz file")
    parser.add_argument("templatename", help="Name of G09 template input file with tags (see help)")

    # parse arguments and check files exist    
    args = parser.parse_args()
    xyzname = args.xyzname
    routename = args.templatename
    if not os.path.exists(xyzname):
        print('Cannot find input .xyz file: {0}'.format(xyzname))
        sys.exit(1)  # non-zero return code 
    if not os.path.exists(routename):
        print('Cannot find input template file: {0}'.format(routename))
        sys.exit(1)  # non-zero return code
        
    # Read template file
    routefile = open(routename,'r')
    route = routefile.readlines()
    routefile.close()
    
    # open the input xyz file
    print ('Opening input file : {0}'.format(xyzname))
    xyzfile = open(xyzname, 'r')
    
    # Count the number of 'frames' in the input file
    count = 0
    with open(xyzname,'r') as xyzfile:
        line = xyzfile.readline().strip()
        while line:
            if line.isdigit():  # count this frame, skip the contents (i.e. comment line plus atom records)
                numatoms = int(line)
                count = count+1
                for i in range(0,numatoms+1):
                    line = xyzfile.readline()
            line = xyzfile.readline().strip()
                
    print('Input file has {0} frame(s)'.format(count))                
    n = 0
    with open(xyzname,'r') as xyzfile:
        # read the first line of the file
        line = xyzfile.readline().strip()
        # keep doing this part until there are no more lines in the input file
        while line:
            natoms = int(line)                 # get the number of atoms in this frame (must convert from string to integer using 'int') 
            n = n + 1                          # increase the current frame number
            # print a message for the user
            print('Frame {} has {} atoms'.format(n, natoms))
            frametitle = xyzfile.readline()    # read the frame title
            atsym = []                         # make a new empty lists of atom symbols, x, y, z coordinates
            atx = []
            aty = []
            atz = []
            for i in range(0,natoms):
                line = xyzfile.readline()
                linedata = line.split()        # split up the line into columns, store in 'linedata'
                symbol = linedata[0]           # first string of non-space characters is the atomic symbol
                # Now read the coordinates (must convert from string to floating point number using 'float')
                x      = float(linedata[1])    # second column of data is the x-coordinate
                y      = float(linedata[2])    # third column of data is the y-coordinate
                z      = float(linedata[3])    # fourth column of data is the z-coordinate
                atsym.append(symbol)
                atx.append(x)
                aty.append(y)
                atz.append(z)
            # Finished reading in data for this frame, now make the G09 input file
            if count == 1:
                gjfname = xyzname.replace('.xyz', '.gjf')
            else:
                gjfname = xyzname.replace('.xyz', '_'+'{:04d}'.format(n)+'.gjf')
                
            fname = gjfname[:-4]
            print('Preparing file {0}'.format(gjfname))
            template = route
            with open(gjfname,'w') as gjffile:
                for templine in template:
                    if '<xyz>' in templine: # write the structure data
                        for i in range (0, natoms):
                            gjffile.write('{} {: f} {: f} {: f}\n'.format(atsym[i],atx[i],aty[i],atz[i]))
                    elif '<frametitle>' in templine:
                        gjffile.write('{}'.format(frametitle))
                    else:
                        templine = templine.replace('<name>',fname)
                        gjffile.write('{}\n'.format(templine.rstrip())) 
            
            # read in the number of atoms in the next frame
            line = xyzfile.readline()

if __name__ == '__main__':
    main()
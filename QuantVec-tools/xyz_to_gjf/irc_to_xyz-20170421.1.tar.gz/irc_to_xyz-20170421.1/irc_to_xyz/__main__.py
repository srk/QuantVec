# -*- coding: utf-8 -*-


"""irc_to_xyz.__main__: executed when irc_to_xyz directory is called as script."""


from .irc_to_xyz import main
main()
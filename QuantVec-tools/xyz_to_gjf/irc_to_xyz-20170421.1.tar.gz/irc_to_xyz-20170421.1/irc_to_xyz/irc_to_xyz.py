# -*- coding: utf-8 -*-
"""
irc_to_xyz
==========
Parse a g09 log file from an IRC/Opt job and extract a .xyz file.
If the job is an IRC or a relaxed PES scan the output file will contain multiple steps

@author: steve
Enhancement: 20150224 - Added printing of program version information
                        Captures G09-calculated net reaction coordinate for each step (in XYZ data headers)
"""
# Python 2 compatibility shims
from __future__ import print_function, division
__version__ = "20170421.0001"

import sys, argparse

def dumpframe(logfile,infoline,xyzfile):
    """
    Read atomic coordinate lines from logfile, then dump a .xyz-format frame to xyzfile
    using 'infoline' as a comment line
    """
    atom_syms = ['X ','H ','He','Li','Be','B ','C ','N ','O ', 'F ','Ne','Na','Mg','Al','Si','P ','S ',
                 'Cl','Ar','K ','Ca','Sc','Ti','V ','Cr','Mn','Fe','Co','Ni','Cu','Zn','Ga','Ge','As',
                 'Se','Br','Kr','Rb','Sr','Y ','Zr','Nb','Mo','Tc','Ru','Rh','Pd','Ag','Cd','In','Sn',
                 'Sb','Te','I ','Xe','Cs','Ba','La','Ce','Pr','Nd','Pm','Sm','Eu','Gd','Tb','Dy','Ho',
                 'Er','Tm','Yb','Lu','Hf','Ta','W ','Re','Os','Ir','Pt','Au','Hg','Tl','Pb','Bi','Po',
                 'At','Rn','Fr','Ra','Ac','Th','Pa','U ','Np','Pu','Am','Cm','Bk','Cf','Es','Fm']
    # start the atom counter, the symbol list and the coordinate lists
    natoms = 0
    atomlist = []
    x = []
    y = []
    z = []
    line = logfile.readline().strip()  # this should be the first line of coordinate data
    # now read the atom numbers and coordinates
    while (not '---' in line) and (line != ''):
        strings = line.split()
        atomicnum = int(strings[1])
        if atomicnum > 100:
            print('Atomic numbers up to 100 supported - {0} out of range'.format(atomicnum))
            sys.exit()
        atomlist.append(atom_syms[atomicnum])
        x.append(strings[-3])
        y.append(strings[-2])
        z.append(strings[-1])
        # read the next line
        line = logfile.readline().strip()
        
    natoms = len(atomlist)
    # Now write out the current block of XYZ coordinates
    xyzfile.write('{}\n'.format(natoms))
    xyzfile.write(infoline)
    for i in range (0,natoms):
        xyzfile.write('{} {} {} {}\n'.format(atomlist[i],x[i],y[i],z[i]))


def main():
    print('Version: {0}'.format(__version__))
    parser = argparse.ArgumentParser(description='Extract intermediate structures from a G09 log file (IRC/Opt or relaxed PES scan)')
    parser.add_argument("logname", help="Name of input G09 .log file")
    parser.add_argument("xyzname", help="Name of output multi-step .xyz file")                             
    args = parser.parse_args()
    logname = args.logname
    xyzname = args.xyzname

    direction = ''
    #print program header
    print(__doc__)
    print("VERSION: "+__version__)
    
    # open the input log file
    print ('Opening input file : {0}'.format(logname))
    logfile = open(logname, 'r')
    xyzfile = open(xyzname, 'w')
    
    #
    # First find the route line (located after the third line of dashes)
    for i in range(0,3):
        line = logfile.readline().strip()
        while (not line.startswith('-------')):  # find first line of dashes
            line = logfile.readline().strip()
    #
    # next line should be the route line, but could be split over multiple lines in the file,
    # so make a list of valid lines with route information until you hit another line of dashes,
    # then stick the parts together
    linelist = []
    line = logfile.readline().strip()
    while not line.startswith('-----'):   
        linelist.append(line)
        line = logfile.readline().strip()
    routeline = ''.join(linelist)
    print(routeline)
    lrouteline = routeline.lower()  # convert to lowercase for easier pattern matching
    jobtype ='unknown'
    if 'irc' in lrouteline:  # this is an IRC job
        jobtype = 'IRC'
    elif ('opt' in lrouteline) and ('modredundant' in lrouteline):  # this is a relaxed PES scan
        jobtype = 'Opt_scan'
    elif ('opt' in lrouteline):  # probably just a geometry optimization
        jobtype = 'Opt'
    print('Detected job type = {0}'.format(jobtype))

    scan_point_info = ''
    #
    # loop over input lines
    line = logfile.readline()
    while (line != ''):
        if jobtype == 'IRC':
            # Find a point and path number
            if (line.count('Delta-x Convergence Met') > 0):
                line = logfile.readline()
                comment = line
                strings = line.split()
                pointnum = int(strings[2])
                pathnum = int(strings[5])
                if (pathnum == 1):
                    direction = 'f'
                else:
                    direction = 'r'
                # next line should be the change in the reaction coordinate - ignore
                line = logfile.readline()
                # next line should be the net reaction coordinate up to this point
                line = logfile.readline().strip()
                netrc = 0
                if (line.startswith('NET REACTION COORDINATE UP TO THIS POINT')):
                    netrc = float(line.split()[-1])
                print ("Path number: {0} Point number: {1} NetRC = {2}".format(pathnum, pointnum,netrc))
    
                # find ' Z-Matrix orientation:'
                while (not line.strip().endswith('orientation:')):
                    line = logfile.readline()
                # skip past first line of dashes
                line = logfile.readline()
                line = logfile.readline()
                # find second line of dashes
                while (not line.startswith(' --')):
                    line = logfile.readline()
                infoline = '{0} NetRC = {1}\n'.format(comment.rstrip(),netrc)
                dumpframe(logfile,infoline,xyzfile)
        
        elif jobtype == 'Opt_scan':
            if 'scan point' in line:
                scan_point_info = ' '.join(line.split()[10:])
            # Find an converged optimization marker
            if 'Stationary point found' in line:
                while (not((line.count('Input orientation') > 0) or (line.count('Standard orientation') > 0))): 
                    line = logfile.readline()
                    if (line == ''):
                        break
                for i in range(0,4):
                    line = logfile.readline()
                    if line == '':
                       break
                infoline = 'Local minimum: '+scan_point_info
                print(infoline)
                dumpframe(logfile,infoline+'\n',xyzfile)
        
        elif jobtype == 'Opt':
            # Find an converged optimization marker
            if 'Stationary point found' in line:
                while (not((line.count('Input orientation') > 0) or (line.count('Standard orientation') > 0))): 
                    line = logfile.readline()
                for i in range(0,4):
                    line = logfile.readline()
                infoline = 'Local minimum\n'
                dumpframe(logfile,infoline,xyzfile)         
    
    # read the next line

        line = logfile.readline()
       
    
    # close all files and exit
    xyzfile.close()
    logfile.close()

if __name__ == '__main__':
    main()

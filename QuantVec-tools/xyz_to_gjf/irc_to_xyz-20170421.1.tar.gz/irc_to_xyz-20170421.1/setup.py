# -*- coding: utf-8 -*-
"""setup.py: setuptools control."""

import re
from setuptools import setup

version = re.search(
    '^__version__\s*=\s*"(.*)"',
    open('irc_to_xyz/irc_to_xyz.py').read(),
    re.M
    ).group(1)

setup(
    name = "irc_to_xyz",
    packages = ["irc_to_xyz"],
    entry_points = {
        "console_scripts": ['irc_to_xyz=irc_to_xyz.irc_to_xyz:main',]
        },
    version = version,
    author='Prof. Steven R. Kirk',
    author_email='stevenrkirk@gmail.com',
    description = "irc_to_xyz",
    url = 'https://www.beaconresearch.org'
    )
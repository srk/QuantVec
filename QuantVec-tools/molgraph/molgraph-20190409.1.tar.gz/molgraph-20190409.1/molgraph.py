# -*- coding: utf-8 -*-
"""
@author: steve

molgraph
========
A module to allow molecular graph data, including data associated with critical
points and paths between them, to be loaded from files and returned to the
calling program as a data structure.

If this file is run on its own, it executes the test code listed at the 
bottom of the file (requires an AIMAll file 'test.sum' containing test data).

This module defines 3 classes, Molgraph(), CriticalPoint() and FieldPath().
Helper functions: dotprod(a,b), project(v,ua,ub,uc)

TODO: Add support for AIMAll .extout files (for raw Hessians, etc.)
      Add support for files produced by Multiwfn
      Add support for files produced by CRITIC2      


"""
from __future__ import print_function
import math, sys

__version__ = "20190409.0001"

def dotprod(a,b):
    """
    Dot product of two 3-component vectors
    """
    return ((a[0]*b[0])+(a[1]*b[1])+(a[2]*b[2]))

def project(v,ua,ub,uc):
    """
    Project vector v onto unit basis ua,ub,uc and return new vector v2
    """
    v2x = dotprod(v,ua)
    v2y = dotprod(v,ub)
    v2z = dotprod(v,uc)
    return [v2x,v2y,v2z]


class CriticalPoint():
    """
    Critical point object, with the following data members:
    
    pos_x, pos_y, pos_z: position coordinates (real numbers)
    field: Description of field in which the CP appears (e.g. electron density)
    filetype: type of file used to fill this objects's data fields
    type: "NACP","NNACP","BCP","RCP" or "CCP"
    id: ID number or string identifying this CP
    connected: string describing connectivity information for this CP
    Rho, RhoNuc, GradRho,
    HessRho_EigVals, HessRho_Eigvec1, HessRho_EigVec2, HessRho_EigVec3
    DelSqRho
    Ellipticity
    V,G,K,L, DelSqV, DelSqG, DelSqK
    Vnuc, Ven, Vrep, DelSqVen, DelSqVrep
    Stress_EigVals, Stress_EigVec1, Stress_EigVec2, Stress_EigVec3, MinusDivStress
    ESP, ESPe, ESPn, ESPNuc, ESPeNuc, ESPnNuc
    
    For BCPs, also
    BPL, GBL_I, GBL_II, GBL_III, GBL_IV
    
    pathlist: list of FieldPath() objects associated with this CP
    All other data members follow the names and definitions used in AIMAll
    (Note: the AIMAll variable -DivStress is named here as MinusDivStress)
    
    """
    def __init__(self):
        self.pos_x = 0.0  
        self.pos_y = 0.0
        self.pos_z = 0.0
        self.field = ""
        self.filetype = ""
        self.type = ""
        self.id = ""
        self.connected = ""
        self.Rho = 0.0
        self.RhoNuc = None
        self.GradRho = [0.0,0.0,0.0]
        self.HessRho = []
        self.HessRho_EigVals = [0.0,0.0,0.0]
        self.HessRho_EigVec1 = [0.0,0.0,0.0]
        self.HessRho_EigVec2 = [0.0,0.0,0.0]
        self.HessRho_EigVec3 = [0.0,0.0,0.0]
        self.DelSqRho = 0.0
        self.Ellipticity = 0.0
        self.V = 0.0
        self.G = 0.0
        self.K = 0.0
        self.L = 0.0
        self.Vnuc = 0.0
        self.Ven = 0.0
        self.Vrep = 0.0
        self.DelSqV = 0.0
        self.DelSqVen = 0.0
        self.DelSqVrep = 0.0
        self.DelSqG = 0.0
        self.DelSqK = 0.0
        self.Stress = []
        self.Stress_EigVals = [0.0,0.0,0.0]
        self.Stress_EigVec1 = [0.0,0.0,0.0]
        self.Stress_EigVec2 = [0.0,0.0,0.0]
        self.Stress_EigVec3 = [0.0,0.0,0.0]
        self.MinusDivStress = [0.0,0.0,0.0]
        self.ESP = None
        self.ESPNuc = None
        self.ESPe = None
        self.ESPeNuc = None
        self.ESPn = None
        self.ESPnNuc = None
        self.BPL = None
        self.GBL_I = None
        self.GBL_II = None
        self.GBL_III = None
        self.GBL_IV = None
        self.pathlist = []

class FieldPath():
    """
    Object describing a path through a 3-D field, comprised of ordered
    sets of coordinates and a field variable associated with each point.
    
    Exposes the following data:
    
    description: string describing this path
    path_x,path_y,path_z: ordered lists of path point coordinates
    path_fieldvar: list of field variable(s) associated with each point
    
    """
    def __init__(self):
        self.description = ""
        self.path_x = []
        self.path_y = []
        self.path_z = []
        self.path_fieldvar = []
        
class Molgraph():
    """
    Molgraph()
    ----------
    This object holds the data from a molecular graph.

    Methods:
    * Molgraph.read(fname)  f = name of input file
      Read molecular graph from file.       
      At the moment, the data can only be read from an AIMAll .sum  or .sumviz file
      (the latter file type holds detailed path data)
    * Molgraph.nuctoxyz(f)  f = file descriptor
      Output nuclear coordinates in XYZ format
    * Molgraph.change_origin(onew)  onew = [ox,oy,oz]   3-D coordinates of new origin
      Change origin of all position variables in the molecular graph
    * Molgraph.change_axes(xnew,ynew,znew)  xnew,ynew,znew = [xp,yp,zp], unit vectors of new axes in old coord system
      Transform all positions and directions in molecular graph to new coordinate frame

    Exposes the following data (INCOMPLETE LIST - SEE BELOW FOR MORE):

    atom_label: list of atom labels
    atom_charge: list of atomic nuclear charges
    atom_x,atom_y,atom_z : lists of nuclear coordinates
    cplist: list of CriticalPoint objects
    num_ncp, num_nna, num_bcp,num_rcp,num_ccp: numbers of each type of critical point
    filetype: string describing data file type
    method: theoretical method used 
    filename: filename of input file
    
    """
    
    def read_aimall_sum(self,fname):
        """
        Read molecular graph data from an AIMAll .sum or .sumviz file
        """
        try:
            f = open(fname.strip())
            #
            self.codeversion = (f.readline()).strip()
            while True: # wavefunction filename
                line = f.readline().strip()
                if line.startswith("Wfx File:") or line.startswith("Wfn File:"):
                    break
            self.wf_file = (line[9:]).strip()
            while True: # wavefunction title 
                line = f.readline().strip()
                if line.startswith("Wfx Title:") or line.startswith("Wfn Title:"):
                    break
            self.title = (line[10:]).strip()
            while True: # theoretical model
                line = f.readline().strip()
                if line.startswith("Model:"):
                    break
            self.model = (line[6:]).strip() 
            while True: # Atom types, charges and positions
                line = f.readline()
                if line.startswith("Atom"):
                    break
            line = f.readline()
            line = f.readline()
            while (not line.strip() == ""): # Atomic data, then blank line
                atomdata = line.split()
                self.atom_label.append(atomdata[0])
                self.atom_charge.append(float(atomdata[1]))
                self.atom_x.append(float(atomdata[2]))
                self.atom_y.append(float(atomdata[3]))
                self.atom_z.append(float(atomdata[4]))
                line = f.readline()
            # Other molecular properties
            while True: # molecular charge
                line = f.readline().strip()
                if line.startswith("Molecular charge"):
                    break
            #line = f.readline()
            self.mol_charge = float(line.split()[-1])
            line = f.readline()
            self.mol_energy = float(line.split()[-1])
            line = f.readline()
            self.mol_virial_ratio = float(line.split()[-1])
            # Now store the data from each critical point
            line = f.readline()
            while True: # Critical point data
                if line.startswith("Number of"):
                    break
                elif line.startswith("CP#"): # start parsing the CP information
                    thiscp = CriticalPoint()
                    tokens = line.split()
                    thiscp.pos_x = float(tokens[-3])
                    thiscp.pos_y = float(tokens[-2])
                    thiscp.pos_z = float(tokens[-1])
                    tokens = (f.readline()).split()
                    thiscp.type = tokens[3]
                    thiscp.connected = "-".join(tokens[4:])
                    tokens = (f.readline()).split() # Rho (and possibly RhoNuc)
                    thiscp.Rho = float(tokens[2])
                    if thiscp.type == "NACP":
                        thiscp.RhoNuc = float(tokens[-1])
                    tokens = (f.readline()).split() # GradRho
                    thiscp.GradRho[0] = float(tokens[-3])
                    thiscp.GradRho[1] = float(tokens[-2])
                    thiscp.GradRho[2] = float(tokens[-1])
                    tokens = (f.readline()).split() # HessRho_EigVals
                    thiscp.HessRho_EigVals[0] = float(tokens[-3])
                    thiscp.HessRho_EigVals[1] = float(tokens[-2])
                    thiscp.HessRho_EigVals[2] = float(tokens[-1])
                    tokens = (f.readline()).split() # HessRho_EigVec1
                    thiscp.HessRho_EigVec1[0] = float(tokens[-3])
                    thiscp.HessRho_EigVec1[1] = float(tokens[-2])
                    thiscp.HessRho_EigVec1[2] = float(tokens[-1])
                    tokens = (f.readline()).split() # HessRho_EigVec2
                    thiscp.HessRho_EigVec2[0] = float(tokens[-3])
                    thiscp.HessRho_EigVec2[1] = float(tokens[-2])
                    thiscp.HessRho_EigVec2[2] = float(tokens[-1])
                    tokens = (f.readline()).split() # HessRho_EigVec3
                    thiscp.HessRho_EigVec3[0] = float(tokens[-3])
                    thiscp.HessRho_EigVec3[1] = float(tokens[-2])
                    thiscp.HessRho_EigVec3[2] = float(tokens[-1])
                    tokens = (f.readline()).split() # DelSqRho
                    thiscp.DelSqRho = float(tokens[2])
                    tokens = (f.readline()).split() # Ellipticity
                    if thiscp.type == "BCP":
                        thiscp.Ellipticity = float(tokens[-1])
                    tokens = (f.readline()).split() # V
                    thiscp.V = float(tokens[2])
                    tokens = (f.readline()).split() # G
                    thiscp.G = float(tokens[2])
                    tokens = (f.readline()).split() # K
                    thiscp.K = float(tokens[2])
                    tokens = (f.readline()).split() # L
                    thiscp.L = float(tokens[2])
                    tokens = (f.readline()).split() # Vnuc
                    thiscp.Vnuc = float(tokens[2])
                    tokens = (f.readline()).split() # Ven
                    thiscp.Ven = float(tokens[2])
                    tokens = (f.readline()).split() # Vrep
                    thiscp.Vrep = float(tokens[2])
                    tokens = (f.readline()).split() # DelSqV
                    thiscp.DelSqV = float(tokens[2])
                    tokens = (f.readline()).split() # DelSqVen
                    thiscp.DelSqVen = float(tokens[2])
                    tokens = (f.readline()).split() # DelSqVrep
                    thiscp.DelSqVrep = float(tokens[2])
                    tokens = (f.readline()).split() # DelSqG
                    thiscp.DelSqG = float(tokens[2])
                    tokens = (f.readline()).split() # DelSqK
                    thiscp.DelSqK = float(tokens[2])
                    tokens = (f.readline()).split() # Stress_EigVals
                    thiscp.Stress_EigVals[0] = float(tokens[-3])
                    thiscp.Stress_EigVals[1] = float(tokens[-2])
                    thiscp.Stress_EigVals[2] = float(tokens[-1])
                    tokens = (f.readline()).split() # Stress_EigVec1
                    thiscp.Stress_EigVec1[0] = float(tokens[-3])
                    thiscp.Stress_EigVec1[1] = float(tokens[-2])
                    thiscp.Stress_EigVec1[2] = float(tokens[-1])
                    tokens = (f.readline()).split() # Stress_EigVec2
                    thiscp.Stress_EigVec2[0] = float(tokens[-3])
                    thiscp.Stress_EigVec2[1] = float(tokens[-2])
                    thiscp.Stress_EigVec2[2] = float(tokens[-1])
                    tokens = (f.readline()).split() # Stress_EigVec3
                    thiscp.Stress_EigVec3[0] = float(tokens[-3])
                    thiscp.Stress_EigVec3[1] = float(tokens[-2])
                    thiscp.Stress_EigVec3[2] = float(tokens[-1])
                    tokens = (f.readline()).split() # MinusDivStress
                    thiscp.MinusDivStress[0] = float(tokens[-3])
                    thiscp.MinusDivStress[1] = float(tokens[-2])
                    thiscp.MinusDivStress[2] = float(tokens[-1])
                    # check for ESP data
                    tokens = (f.readline()).split()
                    if tokens[0]=="ESP":
                        thiscp.ESP = float(tokens[2])
                        if thiscp.type == "NACP":
                            thiscp.ESPNuc == float(tokens[-1])
                        tokens = (f.readline()).split()
                        thiscp.ESPe = float(tokens[2])
                        if thiscp.type == "NACP":
                            thiscp.ESPeNuc == float(tokens[-1])
                        tokens = (f.readline()).split()
                        thiscp.ESPn = float(tokens[2])
                        if thiscp.type == "NACP":
                            thiscp.ESPnNuc == float(tokens[-1])
                    #
                    # check for bond path length data, path data
                    # if only a blank line, we are done with this critical point
                    while True:
                        line = f.readline()
                        line = line.strip()
                        if line == "": # blank line, done with this CP
                            break
                        if line.startswith("BPL"): # parse BCP path length data
                            bcptokens = line.split()
                            thiscp.BPL = float(bcptokens[2])
                            bcptokens = (f.readline()).split()
                            thiscp.GBL_I = float(bcptokens[2])
                            bcptokens = (f.readline()).split()
                            thiscp.GBL_II = float(bcptokens[2])
                            bcptokens = (f.readline()).split()
                            thiscp.GBL_III = float(bcptokens[2])
                            bcptokens = (f.readline()).split()
                            thiscp.GBL_IV = float(bcptokens[2])
                        if line.split()[1] == "sample": # parse path data if present
                            p = FieldPath()
                            p.description = line
                            numpoints = int(line.split()[0])
                            for i in range (numpoints):
                                tokens = (f.readline()).split()
                                p.path_x.append(float(tokens[0]))
                                p.path_y.append(float(tokens[1]))
                                p.path_z.append(float(tokens[2]))
                                p.path_fieldvar.append(float(tokens[3]))
                            thiscp.pathlist.append(p)
                    # done with this CP        
                    self.cplist.append(thiscp)
                line = f.readline()
            # read the numbers of critical points
            self.num_ncp = int(line.split()[-1])
            self.num_nna = int((f.readline()).split()[-1])
            self.num_bcp = int((f.readline()).split()[-1])
            self.num_rcp = int((f.readline()).split()[-1])
            self.num_ccp = int((f.readline()).split()[-1])
            f.close()
        except IOError as e:
            print("Input file error({0}): {1}".format(e.errno, e.strerror))

    def write_aimall_sumviz(self,fname):
        """
        Write out a molecular graph in AIMAll .sumviz format
        Use boilerplate strings for headers and footers
        """
        bplate1 = '\n'.join(['AIMSum (Version 14.06.21, Professional)',
                            'Copyright (c) 1997-2014 by Todd A. Keith',
                            'AIMSum is a component of the AIMAll package ( http://aim.tkgristmill.com )',
                            '',
                            'Much of the Quantum Theory of Atoms in Molecules (QTAIM) is described in the book:',
                            '  "Atoms in Molecules - A Quantum Theory"',
                            '  R.F.W. Bader, Oxford University Press, Oxford, 1990',
                            '',
                            'For additional references see:  http://aim.tkgristmill.com/references.html',
                            '',
                            'Wfx File:  {0}',
                            'Sum File:  {1}',
                            '',
                            'SumViz File:  {2}',
                            ''])+'\n'
        bplate2 = '\n'.join(['Wfx Title:  {0}',                                                                  
                            ' ',
                            'Total memory allocated for AIMSum =        0.000 Megabytes',
                            '',
                            'Atomic units (a.u.) used throughout, except where stated otherwise',
                            '',
                            'Model:  {1}',
                            ' ',
                            'Restricted, natural orbital wavefunction.',
                            '  Number of electrons (from MO Occs)                   =           0.0000000000',
                            '  Number of Alpha electrons (from MO Occs)             =           0.0000000000',
                            '  Number of Beta electrons (from MO Occs)              =           0.0000000000',
                            '  Number of electron pairs (N*(N-1)/2)                 =           0.0000000000',
                            '  Number of electron pairs (from Muller 2EDM)          =           0.0000000000',
                            '  Number of electron pairs (from Muller 2EDM, no SOSI) =           0.0000000000',
                            ' ', 
                            'Nuclear Charges and Cartesian Coordinates:',
                            '-------------------------------------------------------------------------------',
                            'Atom      Charge                X                  Y                  Z',
                            '-------------------------------------------------------------------------------'])+'\n'
        bplate3 = '\n'.join(['', 
                            'Molecular charge q(Mol) from the wfx file:   0.0000000000E0  ',
                            'Molecular energy E(Mol) from the wfx file:   0.0000000000E0  ',
                            'Molecular virial ratio (-V(Mol)/T(Mol)) from the wfx file:   2.000           ',
                            ' ',
                            'Electron Density Critical Point Analysis of Molecular Structure:               ',
                            '---------------------------------------------------------------                ',
                            '  NACP = Nuclear Attractor Critical Point                                      ',
                            '  NNACP = Non-Nuclear Attractor Critical Point                                 ',
                            '  BCP = Bond Critical Point                                                    ',
                            '  RCP = Ring Critical Point                                                    ',
                            '  CCP = Cage Critical Point                                                    ',
                            '  Rho = Electron Density                                                       ',
                            '  GradRho = Gradient of Electron Density                                       ',
                            '  HessRho_EigVals = Eigenvalues of the Hessian of Rho, Ascending Order         ',
                            '  HessRho_EigVecs = Eigenvectors of the Hessian of Rho                         ',
                            '  DelSqRho = Laplacian of Rho = Trace of Hessian of Rho                        ',
                            '  Bond Ellipticity = (HessRho_EigVal(1) / HessRho_EigVal(2)) - 1               ',
                            '  V = Virial Field = Potential Energy Density = Trace of Stress Tensor         ',
                            '  G = Lagrangian Form of Kinetic Energy Density                                ',
                            '  K = Hamiltonian Form of Kinetic Energy Density                               ',
                            '  L = K - G = Lagrangian Density = (-1/4)DelSqRho                              ',
                            '  Vnuc = Electrostatic Potential from Nuclei                                   ',
                            '  Ven = Electron-nuclear attractive contribution to Virial Field V             ',
                            '  Vrep = V - Ven = Repulsive contribution to Virial Field V                    ',
                            '  DelSqV = Laplacian of V                                                      ',
                            '  DelSqVen = Laplacian of Ven                                                  ',
                            '  DelSqVrep = Laplacian of Vrep                                                ',
                            '  DelSqG = Laplacian of G                                                      ',
                            '  DelSqK = Laplacian of K                                                      ',
                            '  Stress_EigVals = Eigenvalues of Stress Tensor, Ascending Order               ',
                            '  Stress_EigVecs = Eigenvectors of Stress Tensor                               ',
                            '  -DivStress = Ehrenfest Force Density = Minus Divergence of Stress Tensor     ',
                            '  ESP = Total Electrostatic Potential                                          ',
                            '  ESPe = Electrostatic Potential from Electrons                                ',
                            '  ESPn = Electrostatic Potential from Nuclei                                   ',
                            '  BP = Bond Path                                                               ',
                            '  BPL = Bond Path Length                                                       ',
                            '  GBL = Geometric Bond Length                                                  ',
                            '  GBL_I = Distance Between Nuclear Attractors                                  ',
                            '  GBL_II = Distance Between Nuclei                                             ',
                            '  GBL_III = Sum of Distances Between BCP and Nuclear Attractors                ',
                            '  GBL_IV = Sum of Distances Between BCP and Nuclei                             ',
                            ''])+'\n'
        bplate_cpsummary = '\n'.join(['Number of NACPs  = {0:6d}',
                                     'Number of NNACPs = {1:6d}',
                                     'Number of BCPs   = {2:6d}',
                                     'Number of RCPs   = {3:6d}',
                                     'Number of CCPs   = {4:6d}',
                                     'NumNACP + NumNNACP - NumBCP + NumRCP - NumCCP = {5:6d}',
                                     'Poincare-Hopf Relationship is {6}',
                                     '',
                                     'Total time for electron density critical point search, analysis and connectivity = 1 sec (NProc = 1)',
                                     '', 
                                     '', 
                                     'Total time for AIMSum = 0 sec (NProc = 1)'])+'\n'

        with open(fname,'w') as f:
            cpcount = 0
            # write header boilerplates
            f.write(bplate1.format(self.wf_file,'None',fname))
            f.write(bplate2.format(self.title,self.model))
            # write nuclei types and coordinates
            for i in range(0,len(self.atom_x)):
                nlabel = self.atom_label[i]
                ncharge = self.atom_charge[i]
                nx = self.atom_x[i]
                ny = self.atom_y[i]
                nz = self.atom_z[i]
                f.write('{0:8}{1:6}         {2:18.10E} {3:18.10E} {4:18.10E}\n'.format(nlabel,ncharge,nx,ny,nz))
            # write more boilerplate
            f.write(bplate3)
            # write per-CP information (reorder CP list with NACPs/NNAs first)
            nacps = [ cp for cp in self.cplist if cp.type.startswith('N') ]
            othercps = [ cp for cp in self.cplist if not cp.type.startswith('N') ]
            self.cplist = nacps + othercps
            for cp in self.cplist:
                cpcount = cpcount + 1
                cptype = cp.type
                cpconnected = cp.connected.replace('-',' ')
                if cpconnected.strip()=='':
                    cpconnected = '{0} {1}'.format(self.atom_label[0], self.atom_label[1])
                cpx = cp.pos_x
                cpy = cp.pos_y
                cpz = cp.pos_z
                firstcpline = 'CP# {0:<6} Coords = {1:21.14E} {2:21.14E} {3:21.14E}\n'.format(cpcount,cpx,cpy,cpz)
                f.write(firstcpline)

                if cptype.startswith('N'):  # NACP/NNACP =================================== NCP/NNACP
                    f.write('           Type = (3,-3) {0} {1}\n'.format(cptype,cpconnected.split(' ')[0]))
                    if cp.type == 'NACP': 
                        if cp.RhoNuc is None:  # for an NCP with no separate RhoNuc density, set RhoNuc = Rho
                            cp.RhoNuc = cp.Rho
                        f.write('           Rho = {0:17.10E}     Rho at Nucleus = {1:17.10E}\n'.format(cp.Rho,cp.RhoNuc))
                    else:
                        f.write('           Rho = {0:17.10E}\n'.format(cp.Rho))
                    f.write('           GradRho = {0:17.10E} {1:17.10E} {2:17.10E}\n'.format(cp.GradRho[0],cp.GradRho[1],cp.GradRho[2]))
                    f.write('           HessRho_EigVals = {0:17.10E} {1:17.10E} {2:17.10E}\n'.format(
                                                          cp.HessRho_EigVals[0],cp.HessRho_EigVals[1],cp.HessRho_EigVals[2]))
                    f.write('           HessRho_EigVec1 = {0:17.10E} {1:17.10E} {2:17.10E}\n'.format(
                                                          cp.HessRho_EigVec1[0],cp.HessRho_EigVec1[1],cp.HessRho_EigVec1[2]))
                    f.write('           HessRho_EigVec2 = {0:17.10E} {1:17.10E} {2:17.10E}\n'.format(
                                                          cp.HessRho_EigVec2[0],cp.HessRho_EigVec2[1],cp.HessRho_EigVec2[2]))
                    f.write('           HessRho_EigVec3 = {0:17.10E} {1:17.10E} {2:17.10E}\n'.format(
                                                          cp.HessRho_EigVec3[0],cp.HessRho_EigVec3[1],cp.HessRho_EigVec3[2]))
                    f.write('           DelSqRho = {0:17.10E}\n'.format(cp.DelSqRho)) 
                    f.write('           Bond Ellipticity = NA\n')
                    f.write('           V = {0:17.10E}\n'.format(cp.V))
                    f.write('           G = {0:17.10E}\n'.format(cp.G))
                    f.write('           K = {0:17.10E}\n'.format(cp.K))
                    f.write('           L = {0:17.10E}\n'.format(cp.L))
                    f.write('           Vnuc = {0:17.10E}\n'.format(cp.Vnuc))
                    f.write('           Ven = {0:17.10E}\n'.format(cp.Ven))
                    f.write('           Vrep = {0:17.10E}\n'.format(cp.Vrep))
                    f.write('           DelSqV = {0:17.10E}\n'.format(cp.DelSqV))
                    f.write('           DelSqVen = {0:17.10E}\n'.format(cp.DelSqVen))
                    f.write('           DelSqVrep = {0:17.10E}\n'.format(cp.DelSqVrep))
                    f.write('           DelSqG = {0:17.10E}\n'.format(cp.DelSqG))
                    f.write('           DelSqK = {0:17.10E}\n'.format(cp.DelSqK))
                    f.write('           Stress_EigVals = {0:17.10E} {1:17.10E} {2:17.10E}\n'.format(
                                                         cp.Stress_EigVals[0],cp.Stress_EigVals[1],cp.Stress_EigVals[2]))
                    f.write('           Stress_EigVec1 = {0:17.10E} {1:17.10E} {2:17.10E}\n'.format(
                                                         cp.Stress_EigVec1[0],cp.Stress_EigVec1[1],cp.Stress_EigVec1[2]))
                    f.write('           Stress_EigVec2 = {0:17.10E} {1:17.10E} {2:17.10E}\n'.format(
                                                         cp.Stress_EigVec2[0],cp.Stress_EigVec2[1],cp.Stress_EigVec2[2]))
                    f.write('           Stress_EigVec3 = {0:17.10E} {1:17.10E} {2:17.10E}\n'.format(
                                                         cp.Stress_EigVec3[0],cp.Stress_EigVec3[1],cp.Stress_EigVec3[2]))
                    f.write('           -DivStress = {0:17.10E} {1:17.10E} {2:17.10E}\n'.format(
                                                     cp.MinusDivStress[0],cp.MinusDivStress[1],cp.MinusDivStress[2],))
                    if cp.ESPNuc is None:
                        cp.ESPNuc = -0.0
                        cp.ESPeNuc = -0.0
                        cp.ESPnNuc = -0.0
                    f.write('           ESP =  {0:17.10E}     ESP at Nucleus =  {1:17.10E}\n'.format(cp.ESP,cp.ESPNuc))
                    f.write('           ESPe = {0:17.10E}     ESPe at Nucleus = {1:17.10E}\n'.format(cp.ESPe,cp.ESPeNuc))
                    f.write('           ESPn = {0:17.10E}     ESPn at Nucleus = {1:17.10E}\n'.format(cp.ESPn,cp.ESPnNuc))

                elif cptype =='BCP':  # BCP ================================================ BCP
                    f.write('           Type = (3,-1) {0} {1}\n'.format(cptype,cpconnected))
                    f.write('           Rho = {0:17.10E}\n'.format(cp.Rho))
                    f.write('           GradRho = {0:17.10E} {1:17.10E} {2:17.10E}\n'.format(cp.GradRho[0],cp.GradRho[1],cp.GradRho[2]))
                    f.write('           HessRho_EigVals = {0:17.10E} {1:17.10E} {2:17.10E}\n'.format(
                                                          cp.HessRho_EigVals[0],cp.HessRho_EigVals[1],cp.HessRho_EigVals[2]))
                    f.write('           HessRho_EigVec1 = {0:17.10E} {1:17.10E} {2:17.10E}\n'.format(
                                                          cp.HessRho_EigVec1[0],cp.HessRho_EigVec1[1],cp.HessRho_EigVec1[2]))
                    f.write('           HessRho_EigVec2 = {0:17.10E} {1:17.10E} {2:17.10E}\n'.format(
                                                          cp.HessRho_EigVec2[0],cp.HessRho_EigVec2[1],cp.HessRho_EigVec2[2]))
                    f.write('           HessRho_EigVec3 = {0:17.10E} {1:17.10E} {2:17.10E}\n'.format(
                                                          cp.HessRho_EigVec3[0],cp.HessRho_EigVec3[1],cp.HessRho_EigVec3[2]))
                    f.write('           DelSqRho = {0:17.10E}\n'.format(cp.DelSqRho)) 
                    f.write('           Bond Ellipticity = {0:17.10E}\n'.format(cp.Ellipticity))
                    f.write('           V = {0:17.10E}\n'.format(cp.V))
                    f.write('           G = {0:17.10E}\n'.format(cp.G))
                    f.write('           K = {0:17.10E}\n'.format(cp.K))
                    f.write('           L = {0:17.10E}\n'.format(cp.L))
                    f.write('           Vnuc = {0:17.10E}\n'.format(cp.Vnuc))
                    f.write('           Ven = {0:17.10E}\n'.format(cp.Ven))
                    f.write('           Vrep = {0:17.10E}\n'.format(cp.Vrep))
                    f.write('           DelSqV = {0:17.10E}\n'.format(cp.DelSqV))
                    f.write('           DelSqVen = {0:17.10E}\n'.format(cp.DelSqVen))
                    f.write('           DelSqVrep = {0:17.10E}\n'.format(cp.DelSqVrep))
                    f.write('           DelSqG = {0:17.10E}\n'.format(cp.DelSqG))
                    f.write('           DelSqK = {0:17.10E}\n'.format(cp.DelSqK))
                    f.write('           Stress_EigVals = {0:17.10E} {1:17.10E} {2:17.10E}\n'.format(
                                                         cp.Stress_EigVals[0],cp.Stress_EigVals[1],cp.Stress_EigVals[2]))
                    f.write('           Stress_EigVec1 = {0:17.10E} {1:17.10E} {2:17.10E}\n'.format(
                                                         cp.Stress_EigVec1[0],cp.Stress_EigVec1[1],cp.Stress_EigVec1[2]))
                    f.write('           Stress_EigVec2 = {0:17.10E} {1:17.10E} {2:17.10E}\n'.format(
                                                         cp.Stress_EigVec2[0],cp.Stress_EigVec2[1],cp.Stress_EigVec2[2]))
                    f.write('           Stress_EigVec3 = {0:17.10E} {1:17.10E} {2:17.10E}\n'.format(
                                                         cp.Stress_EigVec3[0],cp.Stress_EigVec3[1],cp.Stress_EigVec3[2]))
                    f.write('           -DivStress = {0:17.10E} {1:17.10E} {2:17.10E}\n'.format(
                                                     cp.MinusDivStress[0],cp.MinusDivStress[1],cp.MinusDivStress[2],))
                    f.write('           ESP =  {0:17.10E}\n'.format(cp.ESP))
                    f.write('           ESPe = {0:17.10E}\n'.format(cp.ESPe))
                    f.write('           ESPn = {0:17.10E}\n'.format(cp.ESPn))
                    # bond path length
                    f.write('           BPL = {0:17.10E} = {1:17.10E} + {2:17.10E}\n'.format(cp.BPL,cp.BPL,-0.0))
                    f.write('           GBL_I = {0:17.10E}\n'.format(cp.GBL_I))
                    f.write('           GBL_II = {0:17.10E}\n'.format(cp.GBL_II))
                    f.write('           GBL_III = {0:17.10E} = {1:17.10E} + {2:17.10E}\n'.format(cp.GBL_III,cp.GBL_III,-0.0))
                    f.write('           GBL_IV = {0:17.10E} = {1:17.10E} + {2:17.10E}\n'.format(cp.GBL_IV,cp.GBL_IV,-0.0))
                    numpaths = len(cp.pathlist)
                    if numpaths == 0:  # no paths present, make path headers with zero points
                        asyms = cp.connected.split('-')
                        #asyms = [self.atom_label[0],self.atom_label[1] ]
                        npathpoints=1
                        f.write('{0:15d} sample points along path from BCP to atom {1}\n'.format(npathpoints,asyms[0]))
                        f.write('          {0:19.10E}{1:19.10E}{2:19.10E}{3:19.10E}    \n'.format(cpx,cpy,cpz,cp.Rho))
                        f.write('{0:15d} sample points along path from BCP to atom {1}\n'.format(npathpoints,asyms[1]))
                        f.write('          {0:19.10E}{1:19.10E}{2:19.10E}{3:19.10E}    \n'.format(cpx,cpy,cpz,cp.Rho))
                        f.write('{0:15d} sample points along IAS +EV1 path from BCP\n'.format(npathpoints))
                        f.write('          {0:19.10E}{1:19.10E}{2:19.10E}{3:19.10E}    \n'.format(cpx,cpy,cpz,cp.Rho))
                        f.write('{0:15d} sample points along IAS -EV1 path from BCP\n'.format(npathpoints))
                        f.write('          {0:19.10E}{1:19.10E}{2:19.10E}{3:19.10E}    \n'.format(cpx,cpy,cpz,cp.Rho))
                        f.write(' {0:15d} sample points along IAS +EV2 path from BCP\n'.format(npathpoints))
                        f.write('          {0:19.10E}{1:19.10E}{2:19.10E}{3:19.10E}    \n'.format(cpx,cpy,cpz,cp.Rho))
                        f.write('{0:15d} sample points along IAS -EV2 path from BCP\n'.format(npathpoints))
                        f.write('          {0:19.10E}{1:19.10E}{2:19.10E}{3:19.10E}    \n'.format(cpx,cpy,cpz,cp.Rho))
                    else:
                        for thispath in cp.pathlist:
                            f.write('            {0}\n'.format(thispath.description))
                            for i in range(0,len(thispath.path_x)):
                                f.write('          {0:19.10E}{1:19.10E}{2:19.10E}{3:19.10E}    \n'.format(
                                                   thispath.path_x[i],thispath.path_y[i],thispath.path_z[i],thispath.path_fieldvar[i]))
                elif cptype =='RCP':  # RCP ================================================ RCP
                    f.write('           Type = (3,+1) {0} {1}\n'.format(cptype,cpconnected))
                    f.write('           Rho = {0:17.10E}\n'.format(cp.Rho))
                    f.write('           GradRho = {0:17.10E} {1:17.10E} {2:17.10E}\n'.format(cp.GradRho[0],cp.GradRho[1],cp.GradRho[2]))
                    f.write('           HessRho_EigVals = {0:17.10E} {1:17.10E} {2:17.10E}\n'.format(
                                                          cp.HessRho_EigVals[0],cp.HessRho_EigVals[1],cp.HessRho_EigVals[2]))
                    f.write('           HessRho_EigVec1 = {0:17.10E} {1:17.10E} {2:17.10E}\n'.format(
                                                          cp.HessRho_EigVec1[0],cp.HessRho_EigVec1[1],cp.HessRho_EigVec1[2]))
                    f.write('           HessRho_EigVec2 = {0:17.10E} {1:17.10E} {2:17.10E}\n'.format(
                                                          cp.HessRho_EigVec2[0],cp.HessRho_EigVec2[1],cp.HessRho_EigVec2[2]))
                    f.write('           HessRho_EigVec3 = {0:17.10E} {1:17.10E} {2:17.10E}\n'.format(
                                                          cp.HessRho_EigVec3[0],cp.HessRho_EigVec3[1],cp.HessRho_EigVec3[2]))
                    f.write('           DelSqRho = {0:17.10E}\n'.format(cp.DelSqRho)) 
                    f.write('           Bond Ellipticity = NA\n')
                    f.write('           V = {0:17.10E}\n'.format(cp.V))
                    f.write('           G = {0:17.10E}\n'.format(cp.G))
                    f.write('           K = {0:17.10E}\n'.format(cp.K))
                    f.write('           L = {0:17.10E}\n'.format(cp.L))
                    f.write('           Vnuc = {0:17.10E}\n'.format(cp.Vnuc))
                    f.write('           Ven = {0:17.10E}\n'.format(cp.Ven))
                    f.write('           Vrep = {0:17.10E}\n'.format(cp.Vrep))
                    f.write('           DelSqV = {0:17.10E}\n'.format(cp.DelSqV))
                    f.write('           DelSqVen = {0:17.10E}\n'.format(cp.DelSqVen))
                    f.write('           DelSqVrep = {0:17.10E}\n'.format(cp.DelSqVrep))
                    f.write('           DelSqG = {0:17.10E}\n'.format(cp.DelSqG))
                    f.write('           DelSqK = {0:17.10E}\n'.format(cp.DelSqK))
                    f.write('           Stress_EigVals = {0:17.10E} {1:17.10E} {2:17.10E}\n'.format(
                                                         cp.Stress_EigVals[0],cp.Stress_EigVals[1],cp.Stress_EigVals[2]))
                    f.write('           Stress_EigVec1 = {0:17.10E} {1:17.10E} {2:17.10E}\n'.format(
                                                         cp.Stress_EigVec1[0],cp.Stress_EigVec1[1],cp.Stress_EigVec1[2]))
                    f.write('           Stress_EigVec2 = {0:17.10E} {1:17.10E} {2:17.10E}\n'.format(
                                                         cp.Stress_EigVec2[0],cp.Stress_EigVec2[1],cp.Stress_EigVec2[2]))
                    f.write('           Stress_EigVec3 = {0:17.10E} {1:17.10E} {2:17.10E}\n'.format(
                                                         cp.Stress_EigVec3[0],cp.Stress_EigVec3[1],cp.Stress_EigVec3[2]))
                    f.write('           -DivStress = {0:17.10E} {1:17.10E} {2:17.10E}\n'.format(
                                                     cp.MinusDivStress[0],cp.MinusDivStress[1],cp.MinusDivStress[2],))
                    f.write('           ESP =  {0:17.10E}\n'.format(cp.ESP))
                    f.write('           ESPe = {0:17.10E}\n'.format(cp.ESPe))
                    f.write('           ESPn = {0:17.10E}\n'.format(cp.ESPn))
#            128 sample points along path from RCP to BCP between atoms O1 and H3
                    numpaths = len(cp.pathlist)
                    if numpaths == 0:  # no paths present, make path headers with one point
                        #asyms = cp.connected.split('-')
                        npathpoints = 1
                        asyms = [self.atom_label[0],self.atom_label[1] ]
                        f.write('{0:15d} sample points along path from RCP to BCP between atoms {1} and {2}\n'.format(npathpoints,asyms[0],asyms[1]))
                        f.write('          {0:19.10E}{1:19.10E}{2:19.10E}{3:19.10E}    \n'.format(cpx,cpy,cpz,cp.Rho))
                        f.write('{0:15d} sample points along path from RCP to BCP between atoms {1} and {2}\n'.format(npathpoints,asyms[0],asyms[1]))
                        f.write('          {0:19.10E}{1:19.10E}{2:19.10E}{3:19.10E}    \n'.format(cpx,cpy,cpz,cp.Rho))
                        #f.write('              0 sample points along path from BCP to atom {0}\n'.format(asyms[1]))
                        #f.write('              0 sample points along IAS +EV1 path from BCP\n')
                        #f.write('              0 sample points along IAS -EV1 path from BCP\n')
                        #f.write('              0 sample points along IAS +EV2 path from BCP\n')
                        #f.write('              0 sample points along IAS -EV2 path from BCP\n')
                    else:
                        for thispath in cp.pathlist:
                            f.write('            {0}\n'.format(thispath.description))
                            for i in range(0,len(thispath.path_x)):
                                f.write('          {0:19.10E}{1:19.10E}{2:19.10E}{3:19.10E}    \n'.format(
                                                   thispath.path_x[i],thispath.path_y[i],thispath.path_z[i],thispath.path_fieldvar[i]))
                elif cptype =='CCP':  # ====================================================== CCP
                    f.write('           Type = (3,+3) {0} {1}\n'.format(cptype,cpconnected))
                    f.write('           Rho = {0:17.10E}\n'.format(cp.Rho))
                    f.write('           GradRho = {0:17.10E} {1:17.10E} {2:17.10E}\n'.format(cp.GradRho[0],cp.GradRho[1],cp.GradRho[2]))
                    f.write('           HessRho_EigVals = {0:17.10E} {1:17.10E} {2:17.10E}\n'.format(
                                                           cp.HessRho_EigVals[0],cp.HessRho_EigVals[1],cp.HessRho_EigVals[2]))
                    f.write('           HessRho_EigVec1 = {0:17.10E} {1:17.10E} {2:17.10E}\n'.format(
                                                           cp.HessRho_EigVec1[0],cp.HessRho_EigVec1[1],cp.HessRho_EigVec1[2]))
                    f.write('           HessRho_EigVec2 = {0:17.10E} {1:17.10E} {2:17.10E}\n'.format(
                                                           cp.HessRho_EigVec2[0],cp.HessRho_EigVec2[1],cp.HessRho_EigVec2[2]))
                    f.write('           HessRho_EigVec3 = {0:17.10E} {1:17.10E} {2:17.10E}\n'.format(
                                                           cp.HessRho_EigVec3[0],cp.HessRho_EigVec3[1],cp.HessRho_EigVec3[2]))
                    f.write('           DelSqRho = {0:17.10E}\n'.format(cp.DelSqRho)) 
                    f.write('           Bond Ellipticity = NA\n')
                    f.write('           V = {0:17.10E}\n'.format(cp.V))
                    f.write('           G = {0:17.10E}\n'.format(cp.G))
                    f.write('           K = {0:17.10E}\n'.format(cp.K))
                    f.write('           L = {0:17.10E}\n'.format(cp.L))
                    f.write('           Vnuc = {0:17.10E}\n'.format(cp.Vnuc))
                    f.write('           Ven = {0:17.10E}\n'.format(cp.Ven))
                    f.write('           Vrep = {0:17.10E}\n'.format(cp.Vrep))
                    f.write('           DelSqV = {0:17.10E}\n'.format(cp.DelSqV))
                    f.write('           DelSqVen = {0:17.10E}\n'.format(cp.DelSqVen))
                    f.write('           DelSqVrep = {0:17.10E}\n'.format(cp.DelSqVrep))
                    f.write('           DelSqG = {0:17.10E}\n'.format(cp.DelSqG))
                    f.write('           DelSqK = {0:17.10E}\n'.format(cp.DelSqK))
                    f.write('           Stress_EigVals = {0:17.10E} {1:17.10E} {2:17.10E}\n'.format(
                                                         cp.Stress_EigVals[0],cp.Stress_EigVals[1],cp.Stress_EigVals[2]))
                    f.write('           Stress_EigVec1 = {0:17.10E} {1:17.10E} {2:17.10E}\n'.format(
                                                         cp.Stress_EigVec1[0],cp.Stress_EigVec1[1],cp.Stress_EigVec1[2]))
                    f.write('           Stress_EigVec2 = {0:17.10E} {1:17.10E} {2:17.10E}\n'.format(
                                                         cp.Stress_EigVec2[0],cp.Stress_EigVec2[1],cp.Stress_EigVec2[2]))
                    f.write('           Stress_EigVec3 = {0:17.10E} {1:17.10E} {2:17.10E}\n'.format(
                                                         cp.Stress_EigVec3[0],cp.Stress_EigVec3[1],cp.Stress_EigVec3[2]))
                    f.write('           -DivStress = {0:17.10E} {1:17.10E} {2:17.10E}\n'.format(
                                                     cp.MinusDivStress[0],cp.MinusDivStress[1],cp.MinusDivStress[2],))
                    f.write('           ESP =  {0:17.10E}\n'.format(cp.ESP))
                    f.write('           ESPe = {0:17.10E}\n'.format(cp.ESPe))
                    f.write('           ESPn = {0:17.10E}\n'.format(cp.ESPn))
                f.write('\n')
            # write CP number summary
            phsum = self.num_ncp + self.num_nna - self.num_bcp + self.num_rcp - self.num_ccp
            if phsum == 1:
                phstate='Satisfied'
            else:
                phstate='not Satisfied'
            f.write(bplate_cpsummary.format(self.num_ncp,self.num_nna,self.num_bcp,self.num_rcp,self.num_ccp,
                                            phsum,phstate))
            
    def read_critic(self,fname):
        """
        Read molecular graph data from an output file produced using the CRITIC2 code
        """
        crystalmode = None  # inputfile is for a MOLECULE or a CRYSTAL
        au2ang = 0.529177
        typedict = { 'nucleus':'NACP', 'nnattr':'NNACP', 'bond':'BCP', 'ring':'RCP', 'cage':'CCP' }
        self.wf_file=''
        self.title=''
        self.model=''
        #print('DEBUG:test .critic reading')
        print('\nCRITIC2 import test\n===========\n')
        try:
            with open(fname.strip()) as f:
                #print('DEBUG: {0}'.format(fname.strip()))
                while True:  # software version
                    line = f.readline().strip()
                    if line.startswith("+ critic2"):
                        break
                self.codeversion = ' '.join(line.split()[1:])
                while True:  # scan for datatype (CRYSTAL or MOLECULE)
                    line = f.readline().strip()
                    if line.startswith('* Crystal structure'):
                        crystalmode = True
                        break
                    elif line.startswith('* Molecular structure'):
                        crystalmode = False
                        break
                while True:  # atom labels and coordinates
                    line = f.readline().strip()
                    if line.startswith('+ List of atoms in Cartesian coordinates'):
                        break
                # parse atom labels and coordinates
                # get units
                if line.endswith('(ang_):'):  # coordinates are given in angstrom, convert to au
                    unitmult = 1.0/au2ang
                    print('Converting atom coordinates to atomic units')
                else:
                    unitmult = 1.0
                line = f.readline()  # header line
                line = f.readline()  # first line of atomic position data
                while (line.strip() != ''):
                    tokens = line.split()
                    # idnumber x y z symbol_ Z
                    atomid = int(tokens[0])
                    x = float(tokens[1])
                    y = float(tokens[2])
                    z = float(tokens[3])
                    if tokens[5].endswith('_'):  # e.g. in non-molecular data
                        sym = tokens[5].strip('_')+str(atomid)  # remove trailing _, add atom number
                    else:
                        sym = tokens[5]
                    self.atom_label.append(sym)
                    self.atom_x.append(x*unitmult)
                    self.atom_y.append(y*unitmult)
                    self.atom_z.append(z*unitmult)
                    self.atom_charge.append(tokens[6])
                    # done with this line                
                    line = f.readline()  # read another line
                natoms= len(self.atom_x)
                #print('DEBUG: found {0} atoms'.format(natoms))
                # done with atom coordinates
                #while True: # atom charges
                #    line = f.readline().strip()
                #    if line.startswith('+ List of atomic charges and atomic numbers'):
                #        break
                #line = f.readline()  # header line
                #line = f.readline()
                #for i in range(0,len(self.atom_x)):
                #    tokens = line.split()
                #    atomcharge = float(tokens[3])
                #    self.atom_charge.append(atomcharge)
                # load field information
                while True: # atom charges
                    line = f.readline().strip()
                    if line.startswith('+ Field number'):
                        line = f.readline().strip()
                        if line.split()[-1] != '<promolecular>':
                            break
                # parse field details
                self.wf_file = ' '.join(line.split()[1:])
                # title and model
                line = f.readline()  # Type:
                line = f.readline()  # Wavefunction type
                self.title = self.wf_file
                self.model = ' '.join(line.split()[2:])
                print('Filename = {0}'.format(self.title))
                print('Model = {0}'.format(self.model))
                
                # Now find the critical point numbers
                while True: # CP numbers and data
                    line = f.readline().strip()
                    if line.startswith('* Critical point list, final report'):
                        break
                line = f.readline()
                tokens = line.split()
                self.num_ncp = int(tokens[3][:tokens[3].index('(')])
                self.num_bcp = int(tokens[4][:tokens[4].index('(')])
                self.num_rcp = int(tokens[5][:tokens[5].index('(')])
                self.num_ccp = int(tokens[6][:tokens[6].index('(')])
                print('CP numbers n={0},b={1},r={2},c={3}'.format(self.num_ncp,self.num_bcp,self.num_rcp,self.num_ccp))
                
                # extract the individual critical point data
                line = f.readline()
                line = f.readline().strip()
                assert line.startswith('#')  # assert this is the header line for the CP data
                tokens = line.split()
                if (tokens[5] == '(ang_)'):  # coordinates are given in angstrom, convert to au
                    print('Converting CP coordinates from Angstroms to atomic units')
                    unitmult = 1.0/au2ang
                else:
                    unitmult = 1.0
                
                # begin parsing CP data lines
                line = f.readline()
                while (line.strip() != ''):  # loop over CP data lines
                    tokens = line.split()
                    thiscp = CriticalPoint()
                    thiscp.id = int(tokens[0])
                    thiscp.pos_x = float(tokens[-7])*unitmult  
                    thiscp.pos_y = float(tokens[-6])*unitmult  
                    thiscp.pos_z = float(tokens[-5])*unitmult  
                    thiscp.Rho = float(tokens[-3])
                    thiscp.DelSqRho = float(tokens[-1])
                    thiscp.type = typedict[tokens[-8]]  # translate to AIMAll BCP type string
                    thiscp.connected = tokens[-4]  # temporarily set the connected string
                    # depending on the type, set the name and the 'connected' string
                    if thiscp.type == "NACP":
                        thiscp.RhoNuc = thiscp.Rho
                        thiscp.ESPNuc = -0.0
                        thiscp.ESPeNuc = -0.0
                        thiscp.ESPnNuc = -0.0
                    thiscp.BPL=-0.0
                    thiscp.GBL_I=-0.0
                    thiscp.GBL_II=-0.0
                    thiscp.GBL_III=-0.0
                    thiscp.GBL_IV=-0.0
                    thiscp.ESP = -0.0
                    thiscp.ESPe = -0.0
                    thiscp.ESPn = -0.0
                    # done with this CP        
                    self.cplist.append(thiscp)
                    line = f.readline()
                # 


                # fix up the BCP names
                
                while True: # Analysis of system bonds
                    line = f.readline().strip()
                    if line.startswith('* Analysis of system bonds'):
                        break
                while True: # scan down to find first line starting with a number
                    line = f.readline().strip()
                    if not line.startswith('#'):
                        break
                # parse BCP properties here
                print('Got to here')
                while line.strip() != '':  # for non-blank lines
                    tokens=line.split()
                    thisbcpid = int(tokens[0])
                    thisbcpatom1 = tokens[1]
                    thisbcpatom2 = tokens[3]
                    for cp in self.cplist:
                        if cp.id == thisbcpid:
                            cp.connected = thisbcpatom1+'-'+thisbcpatom2
                            break
                    line = f.readline()
                    # also BPL information available here

                print('DEBUG: CP properties known so far')
                print('ID  Type   Name  Coordinates(au)')
                for cp in self.cplist:
                    print('{0} {1} {2} {3} {4} {5}'.format(cp.id,cp.type,cp.connected,cp.pos_x,cp.pos_y,cp.pos_z))

        except IOError as e:
            print("Input file error({0}): {1}".format(e.errno, e.strerror))

    def read(self,fname):
    # determine type of input file, assume file exists
        self.codeversion =''
        self.mol_charge = 0.0
        self.mol_energy = 0.0
        self.mol_virial_ratio = 0.0
        self.atom_label = []
        self.atom_charge = []
        self.atom_x = []
        self.atom_y = []
        self.atom_z = []
        self.cplist = []
        self.num_ncp = 0
        self.num_nna = 0
        self.num_bcp = 0
        self.num_rcp = 0
        self.num_ccp = 0
        self.filename = fname
        if fname.endswith(".sumviz"):
            self.filetype = "AIMAll .sumviz file"
            self.read_aimall_sum(fname)
        elif fname.endswith(".sum"):
            self.filetype = "AIMAll .sum file"
            self.read_aimall_sum(fname)
        elif fname.endswith(".critic") or fname.endswith(".cro"):
            self.filetype = "CRITIC2 output file"
            self.read_critic(fname)
        else:
            self.filetype = "Unrecognised input file type" 
    
    def change_origin(self, newo):
        """
        Change the coordinate origin for all positional coordinates
        """
        #print('Old positions')
        #for i in range(0,len(self.atom_x)):
        #    print('{0} {1} {2} {3}'.format(self.atom_label[i],self.atom_x[i],self.atom_y[i],self.atom_z[i]))
        ox = newo[0]
        oy = newo[1]
        oz = newo[2]
        # adjust nuclear positions for new origin
        self.atom_x = [x - ox for x in self.atom_x]
        self.atom_y = [y - oy for y in self.atom_y]
        self.atom_z = [z - oz for z in self.atom_z]
        # adjust CP positions for new origin
        for cp in self.cplist: 
            cp.pos_x = cp.pos_x - ox
            cp.pos_y = cp.pos_y - oy
            cp.pos_z = cp.pos_z - oz
            # adjust all coordinates in attached paths for new origin
            for cp_path in cp.pathlist:
                for point_path_x in cp_path.path_x:
                    point_path_x = point_path_x - ox
                for point_path_y in cp_path.path_y:
                    point_path_y = point_path_y - oy 
                for point_path_z in cp_path.path_z:
                    point_path_z = point_path_z - oz                     
 
    def change_axes(self,xnew,ynew,znew):
        """
        Transform all positional data and vectors to new coordinate frame
        Input: xnew,ynew,znew: 3-component vectors of new unit axis vectors
        Affects positions (including paths), vector quantities 
        NOTE: FOR NOW ONLY HANDLE POSITIONS AND EIGENVECTORS!!
        """
        # Ensure normalization on new axes vectors
        moda = math.sqrt(dotprod(xnew,xnew))
        modb = math.sqrt(dotprod(ynew,ynew))
        modc = math.sqrt(dotprod(znew,znew))
        xnew = [xnew[0]/moda,xnew[1]/moda,xnew[2]/moda]
        ynew = [ynew[0]/modb,ynew[1]/modb,ynew[2]/modb]
        znew = [znew[0]/modc,znew[1]/modc,znew[2]/modc]
        # Modify nuclear positions for new coordinate frame
        for i in range(0,len(self.atom_x)):
            p = project([self.atom_x[i],self.atom_y[i],self.atom_z[i]],xnew,ynew,znew)
            self.atom_x[i] = p[0]
            self.atom_y[i] = p[1]
            self.atom_z[i] = p[2]
        # adjust CP positions for new coordinate frame
        for cp in self.cplist:
            # update CP position
            p = project([cp.pos_x,cp.pos_y,cp.pos_z],xnew,ynew,znew)
            cp.pos_x = p[0]
            cp.pos_y = p[1]
            cp.pos_z = p[2]
            # adjust all coordinates in attached paths for new coordinate frame
            # origin shift assumed to be already applied
            for cp_path in cp.pathlist:
                for i in range(0,len(cp_path.path_x)):
                    p = project([cp.path_x[i],cp.path_y[i],cp.path_z[i]],xnew,ynew,znew)
                    cp.path_x[i] = p[0]
                    cp.path_y[i] = p[1]
                    cp.path_z[i] = p[2]
           
            #  adjust all vector quantities            
            eh1 = project(cp.HessRho_EigVec1,xnew,ynew,znew)
            cp.HessRho_EigVec1 = eh1
            eh2 = project(cp.HessRho_EigVec2,xnew,ynew,znew)
            cp.HessRho_EigVec2 = eh2
            eh3 = project(cp.HessRho_EigVec3,xnew,ynew,znew)
            cp.HessRho_EigVec3 = eh3
            es1 = project(cp.Stress_EigVec1,xnew,ynew,znew)
            cp.Stress_EigVec1 = es1
            es2 = project(cp.Stress_EigVec2,xnew,ynew,znew)
            cp.Stress_EigVec2 = es2
            es3 = project(cp.Stress_EigVec3,xnew,ynew,znew)
            cp.Stress_EigVec3 = es3
            # Adjust GradRho
            grho = project(cp.GradRho,xnew,ynew,znew)
            cp.GradRho = grho
            # Adjust MinusDivStress
            mds=project(cp.MinusDivStress,xnew,ynew,znew)
            cp.MinusDivStress = mds

    def nuctoxyz(self,f):
        """
        Sends the nuclear coordinates of the molecular graph, in XYZ file format, to the file descriptor f.
        Includes original molecular graph file name and extracted model information in info line.
        Input coordinates assumed in atomic units
        Output coordinates are in Angstrom
        """
        au2ang = 0.529177
        natoms = len(self.atom_x)
        f.write('{0}\n'.format(natoms))
        f.write('{0} Model:{1}\n'.format(self.filename,self.model))
        for i in range (0,natoms):
            f.write('{} {: .10f} {: .10f} {: .10f}\n'.format(self.atom_label[i].strip('0123456789'),
                                                             self.atom_x[i]*au2ang,
                                                             self.atom_y[i]*au2ang,
                                                             self.atom_z[i]*au2ang))

    def trimpaths(self):
        """
        Remove path data from all critical points, if present.
        This might help reduce memory usage.
        """
        for cp in self.cplist:
            if (len(cp.pathlist) > 0):
                cp.pathlist = []  
                                                        
    def write_mgpviz(self,f):
        """
        Write data from a 'molgraph' instance to an AIMAll .mgpviz format file on file descriptor f
        """
        
        # Write header data
        f.write('{0}\n{1}\n{2}\n\n{3}\n{4}\n\n'.format(' AIMExt (Version 14.11.23, Professional)',
                                                     ' Portions Copyright (c) 1997-2014 by Todd A. Keith',
                                                     ' AIMExt is a component of the AIMAll package ( http://aim.tkgristmill.com )',
                                                     ' AIMExt is a heavily modified and extended version of the EXTREME program',
                                                     ' developed by members of R.F.W. Bader''s research group'))
        f.write('{0}\n{1}\n{2}\n\n{4}\n'.format(' Much of the Quantum Theory of Atoms in Molecules (QTAIM) is described in the book: ',
                                                '   "Atoms in Molecules - A Quantum Theory"',
                                                '   R.F.W. Bader, Oxford University Press, Oxford, 1990',
                                                ' For additional references see:  http://aim.tkgristmill.com/references.html'))
        f.write('{0}  {1}\n{2}  {3}\n{4}  {5}\n\n{6}  {7}\n\n'.format(' Wfn File:','unknown',
                                                                      ' ExtOut File:','unknown',
                                                                      ' Mgp File:','unknown',
                                                                      ' MgpViz File:','thisfilename'))
        f.write('{0}  {1}\n{2}  {3}\n\n{4}\n{5}\n{6}\n'.format(' Wfn Title:','unknown',                        
                                                               ' Job Title:','Auto',
                                                               'Nuclear Charges and Cartesian Coordinates:',80*'-'))
        f.write('Atom      Charge                X                  Y                  Z\n')
        f.write('{0}\n'.format(80*'-'))
        # now nuclear and NNA coordinates
        for i in range (0,len(self.atom_label)):
            # NEED LOGIC FOR SYMBOL-NUMBER NAMING
            f.write("{0: <7s} {1: >6.1F}         {2:19.10E}{3:19.10E}{4:19.10E}\n".format(self.atom_label[i],
                                                   self.atom_charge[i],
                                                   self.atom_x[i],self.atom_y[i],self.atom_z[i]))
        #C2         6.0           1.1145053800E+00   0.0000000000E+00   0.0000000000E+00
        #H3         1.0          -3.1060114100E+00   0.0000000000E+00   0.0000000000E+00
        #H4         1.0           3.1060114100E+00   0.0000000000E+00   0.0000000000E+00
        #NNA        0.0           0.0000000000E+00   0.0000000000E+00   0.0000000000E+00
        #Cl5       17.0          -3.5002606675E+00   1.8393226728E+00   0.0000000000E+00
        #
        f.write('Total number of electron density critical points found = {0}'.format(0)) # output total number of CPs here
        f.write('\n')
        f.write('Electron Density Critical Point Analysis of Molecular Structure:\n')
        f.write('---------------------------------------------------------------\n')
        f.write('  NACP = Nuclear Attractor Critical Point\n')
        f.write('  NNACP = Non-Nuclear Attractor Critical Point\n')
        f.write('  BCP = Bond Critical Point\n')
        f.write('  RCP = Ring Critical Point\n')
        f.write('  CCP = Cage Critical Point\n')
        f.write('  Rho = Electron Density\n')
        f.write('  GradRho = Gradient of Electron Density\n')
        f.write('  HessRho_EigVals = Eigenvalues of the Hessian of Rho, Ascending Order\n')
        f.write('  HessRho_EigVecs = Eigenvectors of the Hessian of Rho\n')
        f.write('  DelSqRho = Laplacian of Rho = Trace of Hessian of Rho\n')
        f.write('  Bond Ellipticity = (HessRho_EigVal(1) / HessRho_EigVal(2)) - 1\n')
        f.write('  V = Virial Field = Potential Energy Density = Trace of Stress Tensor\n')
        f.write('  G = Lagrangian Form of Kinetic Energy Density\n')
        f.write('  K = Hamiltonian Form of Kinetic Energy Density\n')
        f.write('  L = K - G = Lagrangian Density = (-1/4)DelSqRho\n')
        f.write('  Vnuc = Electrostatic Potential from Nuclei\n')
        f.write('  Ven = Electron-nuclear attractive contribution to Virial Field V\n')
        f.write('  Vrep = V - Ven = Repulsive contribution to Virial Field V\n')
        f.write('  DelSqV = Laplacian of V\n')
        f.write('  DelSqVen = Laplacian of Ven\n')
        f.write('  DelSqVrep = Laplacian of Vrep\n')
        f.write('  DelSqG = Laplacian of G\n')
        f.write('  DelSqK = Laplacian of K\n')
        f.write('  Stress_EigVals = Eigenvalues of Stress Tensor, Ascending Order\n')
        f.write('  Stress_EigVecs = Eigenvectors of Stress Tensor\n')
        f.write('  -DivStress = Ehrenfest Force Density = Minus Divergence of Stress Tensor\n')
        f.write('  BP = Bond Path\n')
        f.write('  BPL = Bond Path Length\n')
        f.write('  GBL = Geometric Bond Length\n')
        f.write('  GBL_I = Distance Between Nuclear Attractors\n')
        f.write('  GBL_II = Distance Between Nuclei\n')
        f.write('  GBL_III = Sum of Distances Between BCP and Nuclear Attractors\n')
        f.write('  GBL_IV = Sum of Distances Between BCP and Nuclei\n')
#  
#  then for each attractor, e.g.
#CP# 4      Coords =  3.06709718188149E+00  0.00000000000000E+00  0.00000000000000E+00
#           Type = (3,-3) NACP H4
#           Rho =  4.2212792555E-01     Rho at Nucleus =  4.1628879336E-01
#           GradRho = -1.2351231149E-15  0.0000000000E+00  0.0000000000E+00
#           HessRho_EigVals = -8.2583572401E+00 -8.2583572401E+00 -7.2807521929E+00
#           HessRho_EigVec1 =  0.0000000000E+00  0.0000000000E+00  1.0000000000E+00
#           HessRho_EigVec2 =  0.0000000000E+00  1.0000000000E+00  0.0000000000E+00
#           HessRho_EigVec3 =  1.0000000000E+00  0.0000000000E+00  0.0000000000E+00
#           DelSqRho = -2.3797466673E+01
#           Bond Ellipticity = NA
#           V = -5.9640087434E+00
#           G =  7.3210375754E-03
#           K =  5.9566877059E+00
#           L =  5.9493666683E+00
#           Vnuc =  3.0367230112E+01
#           Ven = -1.2818855852E+01
#           Vrep =  6.8548471086E+00
#           DelSqV =  1.4985436136E+03
#           DelSqVen =  7.2266314656E+02
#           DelSqVrep =  7.7588046709E+02
#           DelSqG =  1.1243537181E+02
#           DelSqK = -1.6109789855E+03
#           Stress_EigVals = -2.0717704853E+00 -2.0717704853E+00 -1.8204677728E+00
#           Stress_EigVec1 =  0.0000000000E+00  0.0000000000E+00  1.0000000000E+00
#           Stress_EigVec2 =  0.0000000000E+00  1.0000000000E+00  0.0000000000E+00
#           Stress_EigVec3 =  1.0000000000E+00  0.0000000000E+00  0.0000000000E+00
#           -DivStress =  1.9237784607E+01  0.0000000000E+00  0.0000000000E+00
#
#CP# 5      Coords =  1.60461596351594E-09  0.00000000000000E+00  0.00000000000000E+00
#           Type = (3,-3) NNACP NNA
#           Rho =  4.4068102734E-01     Rho at Nucleus =  4.4068102734E-01
#           GradRho = -1.2708745486E-16  0.0000000000E+00  0.0000000000E+00
#           HessRho_EigVals = -7.3687500653E-01 -7.3687500653E-01 -8.5916517482E-02
#           HessRho_EigVec1 =  0.0000000000E+00  0.0000000000E+00  1.0000000000E+00
#           HessRho_EigVec2 =  0.0000000000E+00  1.0000000000E+00  0.0000000000E+00
#           HessRho_EigVec3 =  1.0000000000E+00  0.0000000000E+00  0.0000000000E+00
#           DelSqRho = -1.5596665306E+00
#           Bond Ellipticity = NA
#           V = -1.0283617073E+00
#           G =  3.1922253731E-01
#           K =  7.0913916995E-01
#           L =  3.8991663264E-01
#           Vnuc =  1.1411020823E+01
#           Ven = -5.0286203795E+00
#           Vrep =  4.0002586722E+00
#           DelSqV =  6.3177476572E-01
#           DelSqVen =  1.7797387258E+01
#           DelSqVrep = -1.7165612492E+01
#           DelSqG =  1.4860784334E+00
#           DelSqK = -2.1178531991E+00
#           Stress_EigVals = -4.8781339457E-01 -4.8781339457E-01 -5.2734918112E-02
#           Stress_EigVec1 =  0.0000000000E+00  0.0000000000E+00  1.0000000000E+00
#           Stress_EigVec2 =  0.0000000000E+00  1.0000000000E+00  0.0000000000E+00
#           Stress_EigVec3 =  1.0000000000E+00  0.0000000000E+00  0.0000000000E+00
#           -DivStress =  6.5937796781E-09  0.0000000000E+00  0.0000000000E+00
#  
#  then for each BCP
#           
        atom1name = 'A1'
        atom2name = 'A2'
        atom3name = 'A3'
        atom4name = 'A4'            
        for i in range(0, len(this.cplist)):
            cp = this.cplist[i]
            if (cp.type == "BCP" or cp.type == "RCP" or cp.type == "CCP"):
                f.write('\nCP# {0} Coords ={1}{2}{3}\n'.format(i,cp.pos_x,cp.pos_y,cp.pos_z))
                if cp.type == 'BCP':
                    f.write('Type =(3, -1) BCP {0} {1}\n'.format(atom1name,atom2name))
                elif cp.type == 'RCP':
                    f.write('Type =(3, +1) RCP {0} {1} {2}\n'.format(atom1name,atom2name,atom3name))
                else:
                    f.write('Type =(3, +3) CCP {0} {1} {2} {3}\n'.format(atom1name,atom2name,atom3name,atom4name))                  
                    f.write("           Rho = {0:17.10E}\n           GradRho = {1:17.10E} {2:17.10E} {3:17.10E}\n".format(
                              cp.Rho,cp.GradRho[0],cp.GradRho[1],cp.GradRho[2]))
#        if cp.type == "BCP":
#            print("BPL     = {0:17.10E}\n".format(cp.BPL))
#            print("GBL_I   = {0:17.10E}\n".format(cp.GBL_I))
#            print("GBL_II  = {0:17.10E}\n".format(cp.GBL_II))
#            print("GBL_III = {0:17.10E}\n".format(cp.GBL_III))
#            print("GBL_IV  = {0:17.10E}\n".format(cp.GBL_IV))

#CP# 6      Coords = -2.51006849508491E-01  0.00000000000000E+00  0.00000000000000E+00
#           Type = (3,-1) BCP NNA C1
#           Rho =  4.3895980268E-01
#           GradRho = -1.3877787808E-17  0.0000000000E+00  0.0000000000E+00
#           HessRho_EigVals = -7.5142177089E-01 -7.5142177089E-01  3.2345504651E-01
#           HessRho_EigVec1 =  0.0000000000E+00  0.0000000000E+00  1.0000000000E+00
#           HessRho_EigVec2 =  0.0000000000E+00  1.0000000000E+00  0.0000000000E+00
#           HessRho_EigVec3 =  1.0000000000E+00  0.0000000000E+00  0.0000000000E+00
#           DelSqRho = -1.1793884953E+00
#           Bond Ellipticity =  0.0000000000E+00
#           V = -1.2798709400E+00
#           G =  4.9251190809E-01
#           K =  7.8735903191E-01
#           L =  2.9484712382E-01
#           Vnuc =  1.1990578427E+01
#           Ven = -5.2633819403E+00
#           Vrep =  3.9835110003E+00
#           DelSqV = -7.6200873076E+00
#           DelSqVen =  1.4141550248E+01
#           DelSqVrep = -2.1761637556E+01
#           DelSqG =  1.2455236571E+01
#           DelSqK = -4.8351492633E+00
#           Stress_EigVals = -5.4869277968E-01 -5.4869277968E-01 -1.8248538064E-01
#           Stress_EigVec1 =  0.0000000000E+00  0.0000000000E+00  1.0000000000E+00
#           Stress_EigVec2 =  0.0000000000E+00  1.0000000000E+00  0.0000000000E+00
#           Stress_EigVec3 =  1.0000000000E+00  0.0000000000E+00  0.0000000000E+00
#           -DivStress = -1.4679163307E+00  0.0000000000E+00  0.0000000000E+00
#           BPL =  1.1145104969E+00 =  2.5100684340E-01 +  8.6350365350E-01
#           GBL_I =  1.1145104969E+00
#           GBL_II =  1.1145053800E+00
#           GBL_III =  1.1145104969E+00 =  2.5100684340E-01 +  8.6350365350E-01
#           GBL_IV =  1.1145053800E+00 =  2.5100684951E-01 +  8.6349853049E-01
#           0 sample points along path from BCP to atom NNA     
#           0 sample points along path from BCP to atom C1      
#           0 sample points along IAS +EV1 path from BCP
#           0 sample points along IAS -EV1 path from BCP
#           0 sample points along IAS +EV2 path from BCP
#           0 sample points along IAS -EV2 path from BCP
#  
#  finally
        f.write('Number of NACPs  = {0: >6d}\n'.format(this.num_ncp))
        f.write('Number of NNACPs = {0: >6d}\n'.format(this.num_nna))
        f.write('Number of BCPs   = {0: >6d}\n'.format(this.num_bcp))
        f.write('Number of RCPs   = {0: >6d}\n'.format(this.num_rcp))
        f.write('Number of CCPs   = {0: >6d}\n'.format(this.num_ccp))
        thisphsum = this.num_ncp + this.num_nna - this.num_bcp + this.num_rcp - this.num_ccp
        f.write('NumNACP + NumNNACP - NumBCP + NumRCP - NumCCP = {0}\n'.format(thisphsum))
        if (thisphsum == 1):
            f.write('Poincare-Hopf Relationship is Satisfied\n')
        else:
            f.write('Poincare-Hopf Relationship is not Satisfied\n')
            
        f.write('\n Total time for electron density critical point search, analysis and connectivity = 0 sec (NProc = 1)\n\n')
        # end of routine
        
    def align(self,atom_o,atom_ox,atom_oxy):
        """
        Align coordinates, vectors and tensors of the molecular graph so that:
        * Nucleus called 'atom_o' is the new origin
        * Straight line joining 'atom_o' and 'atom_ox' is the new x-axis
        * Nucleus 'atom_oxy' defines the x-y plane
        * z-axis is crossproduct(x,y)
        """
        # first, check that the requested atom names exist
        if ((not atom_o in self.atom_label) or (not atom_ox in self.atom_label) or (not atom_oxy in self.atom_label)):
            print('ALIGNMENT ERROR: one or more of {0},{1} or {2} not found in current molecular graph. No action taken.'.format(atom_o,atom_ox,atom_oxy))
            return
        # Check that three different atom names have been given
        if (atom_o == atom_ox) or (atom_o == atom_oxy) or (atom_ox == atom_oxy):
            print('ALIGNMENT ERROR: one or more atom names are duplicated. Alignment needs 3 different atom names. No action taken.')
            return
        # get coordinates of alignment atoms
        try:
            natom1 = self.atom_label.index(atom_o)
            natom2 = self.atom_label.index(atom_ox)
            natom3 = self.atom.label.index(atom_oxy)
        except ValueError:
            print('ALIGNMENT ERROR: one of the selected atoms was not found')
            sys.exit()
        # Fetch the coordinates
        o = [self.atom_x[natom1],self.atom_y[natom1],self.atom_z[natom1] ]
        ox = [self.atom_x[natom2],self.atom_y[natom2],self.atom_z[natom2] ]
        oxy = [self.atom_x[natom3],self.atom_y[natom3],self.atom_z[natom3] ]        
        # Build the new unit vectors
        newx = [ ox[0]-o[0], ox[1]-o[1], ox[2]-o[2] ]
        tmpy = [ oxy[0]-o[0], oxy[1]-o[1], oxy[2]-o[2] ]
        #     New x-direction unit vector
        modx = math.sqrt(bu.dotprod(newx,newx))
        unitx[0] = newx[0]/modx
        unitx[1] = newx[1]/modx
        unitx[2] = newx[2]/modx
        #     New y-direction unit vector        
        mody_x = bu.dotprod(unitx,tmpy)  # projection of tmpy onto new unit x-vector
        y_x = [0.0,0.0,0.0]              # component of tmpy vector along unit x
        y_x[0] = mody_x*unitx[0]
        y_x[1] = mody_x*unitx[1]
        y_x[2] = mody_x*unitx[2]
        newy = [0.0,0.0,0.0]             # initialize new y axis 
        newy[0] = tmpy[0] - y_x[0]
        newy[1] = tmpy[1] - y_x[1]
        newy[2] = tmpy[2] - y_x[2]
        mody = math.sqrt(bu.dotprod(newy,newy))
        unity = [0.0,0.0,0.0]
        unity[0] = newy[0]/mody
        unity[1] = newy[1]/mody
        unity[2] = newy[2]/mody
        #     New unitz as a vector cross product  = unitx (X) unity
        unitz = bu.vectorproduct(unitx,unity)
        
        # ALIGNMENT: Phase 1 - change of origin
        self.change_origin(o)
        # ALIGNMENT: Phase 2 - change of axes
        self.change_axes(unitx,unity,unitz)
        
        
        
if __name__ == "__main__":
    print ("molgraph test")
    print ("molgraph version = {0}".format(__version__))
    t = Molgraph()
    t.read("test.sumviz") # example AIMAll .sum file
    print("Input file name = {0}".format(t.filename))
    print("Input file type = {0}".format(t.filetype))
    print("Code version = {0}".format(t.codeversion))
    print("Wavefunction file = {0}".format(t.wf_file))
    print("Title = {0}".format(t.title))
    print("Model = {0}".format(t.model))
    print("Atom data")
    for i in range (0,len(t.atom_label)):
        print("{0} {1} {2} {3} {4}".format(t.atom_label[i],t.atom_charge[i],
              t.atom_x[i],t.atom_y[i],t.atom_z[i]))
    print("Molecular charge: {0} Molecular Energy: {1}".format(t.mol_charge,t.mol_energy))
    print("Molecular virial ratio: {0}".format(t.mol_virial_ratio))
    print("Critical points")
    for cp in t.cplist:
        print ("\n{0} : {1} {2} {3}".format(cp.type,cp.pos_x,cp.pos_y,cp.pos_z))
        print ("Rho = {0:17.10E}\nGradRho = {1:17.10E} {2:17.10E} {3:17.10E}".format(
                cp.Rho,cp.GradRho[0],cp.GradRho[1],cp.GradRho[2]))
        if cp.type == "BCP":
            print("BPL     = {0:17.10E}".format(cp.BPL))
            print("GBL_I   = {0:17.10E}".format(cp.GBL_I))
            print("GBL_II  = {0:17.10E}".format(cp.GBL_II))
            print("GBL_III = {0:17.10E}".format(cp.GBL_III))
            print("GBL_IV  = {0:17.10E}".format(cp.GBL_IV))            
            print("This BCP has {0} associated paths with lengths:".format(len(cp.pathlist)))
            for thispath in cp.pathlist:
                print(len(thispath.path_x)) 
            
    print("Critical point counts: {0} {1} {2} {3} {4}".format(
                            t.num_ncp,t.num_nna,t.num_bcp,t.num_rcp,t.num_ccp))
    print('Test output of created sumviz file test_out.sumviz')
    t.write_aimall_sumviz('test1_out.sumviz')
    # test reading of CRITIC2 .critic file 
    t2 = Molgraph()
    t2.read("test.cro") # example CRITIC2 .cro file
    print("Input file name = {0}".format(t2.filename))
    print("Input file type = {0}".format(t2.filetype))
    print("Code version = {0}".format(t2.codeversion))
    print("Wavefunction file = {0}".format(t2.wf_file))
    print("Title = {0}".format(t2.title))
    print("Model = {0}".format(t2.model))
    print("Atom data")
    for i in range (0,len(t2.atom_label)):
        print("{0} {1} {2} {3} {4}".format(t2.atom_label[i],t2.atom_charge[i],
              t2.atom_x[i],t2.atom_y[i],t2.atom_z[i]))
    print("Molecular charge: {0} Molecular Energy: {1}".format(t2.mol_charge,t2.mol_energy))
    print("Molecular virial ratio: {0}".format(t2.mol_virial_ratio))
    print("Critical points")
    for cp in t2.cplist:
        print ("\n{0} : {1} {2} {3}".format(cp.type,cp.pos_x,cp.pos_y,cp.pos_z))
        print ("Rho = {0:17.10E}\nGradRho = {1:17.10E} {2:17.10E} {3:17.10E}".format(
                cp.Rho,cp.GradRho[0],cp.GradRho[1],cp.GradRho[2]))
        if cp.type == "BCP":
            print("BPL     = {0:17.10E}".format(cp.BPL))
            print("GBL_I   = {0:17.10E}".format(cp.GBL_I))
            print("GBL_II  = {0:17.10E}".format(cp.GBL_II))
            print("GBL_III = {0:17.10E}".format(cp.GBL_III))
            print("GBL_IV  = {0:17.10E}".format(cp.GBL_IV))            
            print("This BCP has {0} associated paths with lengths:".format(len(cp.pathlist)))
            for thispath in cp.pathlist:
                print(len(thispath.path_x)) 
            
    print("Critical point counts: {0} {1} {2} {3} {4}".format(
                            t2.num_ncp,t2.num_nna,t2.num_bcp,t2.num_rcp,t2.num_ccp))
    
    print('Test output of created xyz file test_critic2_out.xyz')
    t2.nuctoxyz(open('test_critic2_out.xyz','w'))
    print('Test output of created sumviz file test_critic2_out.sumviz')
    t2.write_aimall_sumviz('test_critic2_out.sumviz')      

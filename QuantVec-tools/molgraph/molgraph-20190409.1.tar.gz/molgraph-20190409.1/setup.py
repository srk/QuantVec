# -*- coding: utf-8 -*-
"""setup.py: setuptools control."""

import re
from setuptools import setup

version = re.search(
    '^__version__\s*=\s*"(.*)"',
    open('molgraph.py').read(),
    re.M
    ).group(1)

setup(
    name = "molgraph",
    py_modules=['molgraph'],
    version = version,
    author='Prof. Steven R. Kirk',
    author_email='stevenrkirk@gmail.com',
    description = "molgraph",
    url = 'https://www.beaconresearch.org',
    )

# -*- coding: utf-8 -*-
"""
@author: steve

molgraph
========
A module to allow molecular graph data, including data associated with critical
points and paths between them, to be loaded from files and returned to the
calling program as a data structure.

If this file is run on its own, it executes the test code listed at the 
bottom of the file (requires an AIMAll file 'test.sum' containing test data).

This module defines 3 classes, Molgraph(), CriticalPoint() and FieldPath().
Helper functions: dotprod(a,b), project(v,ua,ub,uc)

TODO: Add support for AIMAll .extout files (for raw Hessians, etc.)
      Add support for files produced by Multiwfn      


"""

import math,sys,re,pathlib,copy
import numpy as np

__version__ = "20250919.0001"

def dotprod(a,b):
    """
    Dot product of two 3-component vectors
    """
    return ((a[0]*b[0])+(a[1]*b[1])+(a[2]*b[2]))
    
def project(v,ua,ub,uc):
    """
    Project vector v onto unit basis ua,ub,uc and return new vector v2
    """
    v2x = dotprod(v,ua)
    v2y = dotprod(v,ub)
    v2z = dotprod(v,uc)
    return [v2x,v2y,v2z]
    
def lookfor(f, pattern):
    """
    Read lines sequentially from file descriptor f until a pattern is found, return matching line or empty strins
    """
    
    while True:
        line = f.readline()
        if not line:
            line = ''
            break
        if (line.find(pattern) >= 0):
            break   
    return line 

def cartdist(p,q):
    """
    Return cartesian distance between two input Cartesian 3D points (np.array) 
    """
    dx = q[0]-p[0]
    dy = q[1]-p[1]
    dz = q[2]-p[2]
    return math.sqrt((dx*dx)+(dy*dy)+(dz*dz))   

def cpcrystdist(fr1,o,a,b,c,n,fr2list):
    """
    Given a (fx,fy,fz) fractional crystal coordinate point fr1 in a crystal cell specified by origin vector o and
    crystal basis vectors a,b,c, return :
    * the index of the best(closest) periodic copy (CPC) to fr1 from a list of other points 'fr2list'
    * CPC cell index (-1,0,1) in a-direction
    * CPC cell index (-1,0,1) in b-direction
    * CPC cell index (-1,0,1) in c-direction
    * The distance 'mindist' between fr1 and the best point
    n is the number of neighbours to scan  
    """
    mindist = 1.0E6
    r1 = o + (fr1[0]*a)+(fr1[1]*b)+(fr1[2]*c)
    closestfr2 = np.array([0.0,0.0,0.0],dtype=np.float64)
    closesti = 0
    closestj = 0
    closestk = 0
    closest_index = -1
    #print('fr1=',fr1)
    #print('fr2list=',fr2list)
    count = -1
    for fr2 in fr2list:
        count = count+1
        dist = 0.0
        #print('considering periodic copies of ',fr2)
        for i in range(-1*n,n+1,1):
            for j in range(-1*n,n+1,1):
                for k in range(-1*n,n+1,1):
                    testfx = fr2[0]+float(i)
                    testfy = fr2[1]+float(j)
                    testfz = fr2[2]+float(k)
                    r2 = o + (testfx*a)+(testfy*b)+(testfz*c)

                    dr = r2-r1
                    dist = np.sqrt(dr.dot(dr))
                    #print(i,j,k,testfx,testfx,testfz,dist)                    
                    if dist < mindist:
                        closestfr2 = fr2
                        closesti = i
                        closestj = j
                        closestk = k
                        mindist = dist
                        closest_index = count
    #print('==')
    #print('Closest point to fractional coordinates ({3},{4},{5}) with Cartesian coordinates ({0},{1},{2}) is'.format(r1[0],r1[1],r1[2],fr1[0],fr1[1],fr1[2]))
    #print('Point number {0} with fractional coordinates ({1},{2},{3})'.format(closest_index,closestfr2[0],closestfr2[1],closestfr2[2]))
    #print('with cell shifts ({0}*a, {1}*b, {2}*c) and absolute distance {3}'.format(closesti,closestj,closestk,mindist) )
    #
    return closest_index, closesti, closestj, closestk, mindist

def closestcart(fr1,o,a,b,c,n,refcart):
    """
    Given a (fx,fy,fz) fractional crystal coordinate point fr1 in a crystal cell specified by origin vector o and
    crystal basis vectors a,b,c, return :
    * the cartesian position index of the best(closest) periodic copy (CPC) of fr1 to refcart 
    n is the number of neighbouring cells to scan  
    """
    mindist = 1.0E6
    outr = np.array([0.0,0.0,0.0],dtype=np.float64)
    #print('considering periodic copies of ',fr2)
    for i in range(-1*n,n+1,1):
        for j in range(-1*n,n+1,1):
            for k in range(-1*n,n+1,1):
                testx = fr1[0]+float(i)
                testy = fr1[1]+float(j)
                testz = fr1[2]+float(k)
                cartr1 = o + (testx*a)+(testy*b)+(testz*c)
                dr = cartr1-refcart
                dist = np.sqrt(dr.dot(dr))
                if dist < mindist:
                    mindist = dist
                    outr = cartr1
                    besti = i
                    bestj = j
                    bestk = k
    #print('==')
    #print('Closest point to fractional coordinates ({3},{4},{5}) with Cartesian coordinates ({0},{1},{2}) is'.format(r1[0],r1[1],r1[2],fr1[0],fr1[1],fr1[2]))
    #print('Point number {0} with fractional coordinates ({1},{2},{3})'.format(closest_index,closestfr2[0],closestfr2[1],closestfr2[2]))
    #print('with cell shifts ({0}*a, {1}*b, {2}*c) and absolute distance {3}'.format(closesti,closestj,closestk,mindist) )
    #
    if mindist > 0.2:
        print('Error in closestcart')
        print('Frac {0}, idx=({1},{2},{3}), dist={4}'.format(fr1,besti,bestj,bestk,mindist))
        print('refcart = {0}'.format(refcart))
        print('outr = {0}'.format(outr))
        sys.exit()        
    return outr

def getfrac(r,box_o,box_a,box_b,box_c):
    """
    Return an np.array with the fractional coordinates of a Cartesian point r in a box
    with origin box_o and lattice vectors box_a,box_b,box_c
    """
    ox = r[0] - box_o[0]
    oy = r[1] - box_o[1]
    oz = r[2] - box_o[2]
    mod2_a = (box_a[0]*box_a[0])+(box_a[1]*box_a[1])+(box_a[2]*box_a[2])
    mod2_b = (box_b[0]*box_b[0])+(box_b[1]*box_b[1])+(box_b[2]*box_b[2])
    mod2_c = (box_c[0]*box_c[0])+(box_c[1]*box_c[1])+(box_c[2]*box_c[2])
    frac_x = ((box_a[0]*ox)+(box_a[1]*oy)+(box_a[2]*oz))/mod2_a
    frac_y = ((box_b[0]*ox)+(box_b[1]*oy)+(box_b[2]*oz))/mod2_b
    frac_z = ((box_c[0]*ox)+(box_c[1]*oy)+(box_c[2]*oz))/mod2_c
    return np.array([frac_x,frac_y,frac_z],dtype=np.float64)

def getcart(fr,box_o,box_a,box_b,box_c):
    """
    Return an np.array with the Cartesian coordinates of a fractional point fr with
    box_o: np.array containing origin position
    box_a: np.array containing box a-vector
    box_b: np.array containing box b-vector
    box_c: np.array containing box c-vector
    """
    return (box_o + (fr[0]*box_a)+(fr[1]*box_b)+(fr[2]*box_c)) 

    
class CriticalPoint():
    """
    Critical point object, with the following data members:
    
    pos_x, pos_y, pos_z: position coordinates (real numbers)
    field:               Description of field in which the CP appears (e.g. electron density)
    filetype:            type of file used to fill this objects's data fields
    type:                "NACP","NNACP","BCP","RCP" or "CCP"
    id:                  ID number or string identifying this CP
    connected:           string describing connectivity information for this CP

    Rho, RhoNuc, GradRho, HessRho_EigVals, HessRho_Eigvec1, HessRho_EigVec2, HessRho_EigVec3
    DelSqRho, Ellipticity, V,G,K,L, DelSqV, DelSqG, DelSqK
    Vnuc, Ven, Vrep, DelSqVen, DelSqVrep
    Stress_EigVals, Stress_EigVec1, Stress_EigVec2, Stress_EigVec3, MinusDivStress
    ESP, ESPe, ESPn, ESPNuc, ESPeNuc, ESPnNuc
    
    For BCPs, also
    BPL, GBL_I, GBL_II, GBL_III, GBL_IV
    
    pathlist: list of FieldPath() objects associated with this CP

    All other data members follow the names and definitions used in AIMAll
    (Note: the AIMAll variable -DivStress is named here as MinusDivStress)
    
    """
    def __init__(self):
        self.pos_x = 0.0  
        self.pos_y = 0.0
        self.pos_z = 0.0
        self.field = ""
        self.filetype = ""
        self.type = ""
        self.id = ""
        self.iscloneof = None
        self.label = ""
        self.connected = ""
        self.Rho = 0.0
        self.GradRho = [0.0,0.0,0.0]
        self.HessRho = []
        self.HessRho_EigVals = [0.0,0.0,0.0]
        self.HessRho_EigVec1 = [0.0,0.0,0.0]
        self.HessRho_EigVec2 = [0.0,0.0,0.0]
        self.HessRho_EigVec3 = [0.0,0.0,0.0]
        self.DelSqRho = 0.0
        self.Ellipticity = 0.0
        self.V = 0.0
        self.G = 0.0
        self.K = 0.0
        self.L = 0.0
        self.Vnuc = 0.0
        self.Ven = 0.0
        self.Vrep = 0.0
        self.DelSqV = 0.0
        self.DelSqVen = 0.0
        self.DelSqVrep = 0.0
        self.DelSqG = 0.0
        self.DelSqK = 0.0
        self.Stress = []
        self.Stress_EigVals = [0.0,0.0,0.0]
        self.Stress_EigVec1 = [0.0,0.0,0.0]
        self.Stress_EigVec2 = [0.0,0.0,0.0]
        self.Stress_EigVec3 = [0.0,0.0,0.0]
        self.MinusDivStress = [0.0,0.0,0.0]
        self.ESP = None
        self.ESPNuc = None
        self.ESPe = None
        self.ESPeNuc = None
        self.ESPn = None
        self.ESPnNuc = None
        self.attractors = []
        self.attractorsBPL = []
        self.BPL = None
        self.GBL_I = None
        self.GBL_II = None
        self.GBL_III = None
        self.GBL_IV = None
        self.pathlist = []

class FieldPath():
    """
    Object describing a path through a 3-D field, comprised of ordered
    sets of coordinates and a field variable associated with each point.
    
    Exposes the following data:
    
    description: string describing this path
    path_x,path_y,path_z: ordered lists of path point coordinates
    directions: unit vector (list) of initial direction
    path_fieldvar: list of field variable(s) associated with each point
    
    """
    def __init__(self):
        self.description = ""
        self.direction = []
        self.path_x = []
        self.path_y = []
        self.path_z = []
        self.path_fieldvar = []
        self.path_vecfieldvar = []
        self.path_matfieldvar = []
        
    def length(self):
        """
        Return length of path
        """
        totlength = 0.0
        for i in range(1,len(self.path_x)):
            dx = self.path_x[i] - self.path_x[i-1]
            dy = self.path_y[i] - self.path_y[i-1]
            dz = self.path_z[i] - self.path_z[i-1]
            totlength = totlength + math.sqrt( (dx*dx)+(dy*dy)+(dz*dz) )
        return totlength
        
class Molgraph():
    """
    Molgraph()
    ----------
    This object holds the data from a molecular graph.

    Methods:
    * Molgraph.read(fname)  f = name of input file
      Read molecular graph from file.       
      At the moment, the data can only be read from an AIMAll .sum  or .sumviz file
      (the latter file type holds detailed path data)

    * Molgraph.nuctoxyz(f)  f = file descriptor
      Output nuclear coordinates in XYZ format

    * Molgraph.change_origin(onew)  onew = [ox,oy,oz]   3-D coordinates of new origin
      Change origin of all position variables in the molecular graph

    * Molgraph.change_axes(xnew,ynew,znew)  xnew,ynew,znew = [xp,yp,zp], unit vectors of new axes in old coord system
      Transform all positions and directions in molecular graph to new coordinate frame

    Exposes the following data (INCOMPLETE LIST - SEE BELOW FOR MORE):

    atom_label:                                   list of atom labels
    atom_charge:                                  list of atomic nuclear charges
    atom_x,atom_y,atom_z :                        lists of nuclear coordinates
    cplist:                                       list of CriticalPoint objects
    num_ncp, num_nna, num_bcp,num_rcp,num_ccp:    numbers of each type of critical point
    filetype:                                     string describing originating data file type
    method:                                       theoretical method used 
    filename:                                     filename of input file
    
    """
    
    def read_aimall_sum(self,fname,**kwargs):
        """
        Read molecular graph data from an AIMAll .sum or .sumviz file
        """
        debug = False
        if kwargs:
            debug = kwargs['debug']
        if debug:
            print('DEBUG: entering .sumviz file reader')
        try:
            f = open(fname.strip())
            #
            self.codeversion = (f.readline()).strip()
            if debug:
                print(self.codeversion)
            while True: # wavefunction filename
                line = f.readline().strip()
                if line.startswith("Wfx File:") or line.startswith("Wfn File:"):
                    break
            self.wf_file = (line[9:]).strip()
            if debug:
                print(self.wf_file)
            self.title = ''
            # wavefunction title 
            #line = f.readline().strip()
            line = lookfor(f,'Wfx Title:')
            # if debug:
            print(line)
            #self.title = (line[10:]).strip()   # TODO: change this for multi-line titles
            self.title = line.split(':')[1].strip()
            #print(self.title)
            while True: # theoretical model
                line = f.readline().strip()
                if line.startswith("Model:"):
                    break
            self.model = (line[6:]).strip() 
            #print(self.model)
            while True: # Atom types, charges and positions
                line = f.readline()
                if line.startswith("Atom"):
                    break
            line = f.readline()
            line = f.readline()
            while (not line.strip() == ""): # Atomic data, then blank line
                atomdata = line.split()
                self.atom_label.append(atomdata[0])
                self.atom_charge.append(float(atomdata[1]))
                self.atom_x.append(float(atomdata[2]))
                self.atom_y.append(float(atomdata[3]))
                self.atom_z.append(float(atomdata[4]))
                line = f.readline()
            # Other molecular properties
            while True: # molecular charge
                line = f.readline().strip()
                if line.startswith("Molecular charge"):
                    break
            #line = f.readline()
            self.mol_charge = float(line.split()[-1])
            line = f.readline()
            self.mol_energy = float(line.split()[-1])
            line = f.readline()
            self.mol_virial_ratio = float(line.split()[-1])
            # Now store the data from each critical point
            line = f.readline()
            while True: # Critical point data
                if line.startswith("Number of"):
                    break
                elif line.startswith("CP#"): # start parsing the CP information
                    thiscp = CriticalPoint()
                    tokens = line.split()
                    thiscp.pos_x = float(tokens[-3])
                    thiscp.pos_y = float(tokens[-2])
                    thiscp.pos_z = float(tokens[-1])
                    tokens = (f.readline()).split()
                    thiscp.type = tokens[3]
                    thiscp.connected = "-".join(tokens[4:])
                    tokens = (f.readline()).split() # Rho (and possibly RhoNuc)
                    thiscp.Rho = float(tokens[2])
                    if thiscp.type == "NACP":
                        thiscp.RhoNuc = float(tokens[-1])
                    tokens = (f.readline()).split() # GradRho
                    thiscp.GradRho[0] = float(tokens[-3])
                    thiscp.GradRho[1] = float(tokens[-2])
                    thiscp.GradRho[2] = float(tokens[-1])
                    tokens = (f.readline()).split() # HessRho_EigVals
                    thiscp.HessRho_EigVals[0] = float(tokens[-3])
                    thiscp.HessRho_EigVals[1] = float(tokens[-2])
                    thiscp.HessRho_EigVals[2] = float(tokens[-1])
                    tokens = (f.readline()).split() # HessRho_EigVec1
                    thiscp.HessRho_EigVec1[0] = float(tokens[-3])
                    thiscp.HessRho_EigVec1[1] = float(tokens[-2])
                    thiscp.HessRho_EigVec1[2] = float(tokens[-1])
                    tokens = (f.readline()).split() # HessRho_EigVec2
                    thiscp.HessRho_EigVec2[0] = float(tokens[-3])
                    thiscp.HessRho_EigVec2[1] = float(tokens[-2])
                    thiscp.HessRho_EigVec2[2] = float(tokens[-1])
                    tokens = (f.readline()).split() # HessRho_EigVec3
                    thiscp.HessRho_EigVec3[0] = float(tokens[-3])
                    thiscp.HessRho_EigVec3[1] = float(tokens[-2])
                    thiscp.HessRho_EigVec3[2] = float(tokens[-1])
                    tokens = (f.readline()).split() # DelSqRho
                    thiscp.DelSqRho = float(tokens[2])
                    tokens = (f.readline()).split() # Ellipticity
                    if thiscp.type == "BCP":
                        thiscp.Ellipticity = float(tokens[-1])
                    tokens = (f.readline()).split() # V
                    thiscp.V = float(tokens[2])
                    tokens = (f.readline()).split() # G
                    thiscp.G = float(tokens[2])
                    tokens = (f.readline()).split() # K
                    thiscp.K = float(tokens[2])
                    tokens = (f.readline()).split() # L
                    thiscp.L = float(tokens[2])
                    tokens = (f.readline()).split() # Vnuc
                    thiscp.Vnuc = float(tokens[2])
                    tokens = (f.readline()).split() # Ven
                    thiscp.Ven = float(tokens[2])
                    tokens = (f.readline()).split() # Vrep
                    thiscp.Vrep = float(tokens[2])
                    tokens = (f.readline()).split() # DelSqV
                    thiscp.DelSqV = float(tokens[2])
                    tokens = (f.readline()).split() # DelSqVen
                    thiscp.DelSqVen = float(tokens[2])
                    tokens = (f.readline()).split() # DelSqVrep
                    thiscp.DelSqVrep = float(tokens[2])
                    tokens = (f.readline()).split() # DelSqG
                    thiscp.DelSqG = float(tokens[2])
                    tokens = (f.readline()).split() # DelSqK
                    thiscp.DelSqK = float(tokens[2])
                    tokens = (f.readline()).split() # Stress_EigVals
                    #print(tokens)
                    thiscp.Stress_EigVals[0] = float(tokens[-3])
                    thiscp.Stress_EigVals[1] = float(tokens[-2])
                    thiscp.Stress_EigVals[2] = float(tokens[-1])
                    tokens = (f.readline()).split() # Stress_EigVec1
                    thiscp.Stress_EigVec1[0] = float(tokens[-3])
                    thiscp.Stress_EigVec1[1] = float(tokens[-2])
                    thiscp.Stress_EigVec1[2] = float(tokens[-1])
                    tokens = (f.readline()).split() # Stress_EigVec2
                    thiscp.Stress_EigVec2[0] = float(tokens[-3])
                    thiscp.Stress_EigVec2[1] = float(tokens[-2])
                    thiscp.Stress_EigVec2[2] = float(tokens[-1])
                    tokens = (f.readline()).split() # Stress_EigVec3
                    thiscp.Stress_EigVec3[0] = float(tokens[-3])
                    thiscp.Stress_EigVec3[1] = float(tokens[-2])
                    thiscp.Stress_EigVec3[2] = float(tokens[-1])
                    tokens = (f.readline()).split() # MinusDivStress
                    thiscp.MinusDivStress[0] = float(tokens[-3])
                    thiscp.MinusDivStress[1] = float(tokens[-2])
                    thiscp.MinusDivStress[2] = float(tokens[-1])
                    # check for ESP data
                    tokens = (f.readline()).split()
                    if tokens[0]=="ESP":
                        thiscp.ESP = float(tokens[2])
                        if thiscp.type == "NACP":
                            thiscp.ESPNuc == float(tokens[-1])
                        tokens = (f.readline()).split()    
                        thiscp.ESPe = float(tokens[2])
                        if thiscp.type == "NACP":
                            thiscp.ESPeNuc == float(tokens[-1])
                        tokens = (f.readline()).split()                        
                        thiscp.ESPn = float(tokens[2])
                        if thiscp.type == "NACP":
                            thiscp.ESPnNuc == float(tokens[-1])
                    #
                    # check for bond path length data, path data
                    # if only a blank line, we are done with this critical point
                    while True:
                        line = f.readline()
                        line = line.strip()
                        if line == "": # blank line, done with this CP
                            break
                        if line.startswith("BPL"): # parse BCP path length data
                            bcptokens = line.split()
                            thiscp.BPL = float(bcptokens[2])
                            bcptokens = (f.readline()).split()
                            thiscp.GBL_I = float(bcptokens[2])
                            bcptokens = (f.readline()).split()
                            thiscp.GBL_II = float(bcptokens[2])
                            bcptokens = (f.readline()).split()
                            thiscp.GBL_III = float(bcptokens[2])
                            bcptokens = (f.readline()).split()
                            thiscp.GBL_IV = float(bcptokens[2])
                        if line.split()[1] == "sample": # parse path data if present
                            p = FieldPath()
                            p.description = line
                            numpoints = int(line.split()[0])
                            for i in range (numpoints):
                                tokens = (f.readline()).split()
                                p.path_x.append(float(tokens[0]))
                                p.path_y.append(float(tokens[1]))
                                p.path_z.append(float(tokens[2]))
                                p.path_fieldvar.append(float(tokens[3]))
                            thiscp.pathlist.append(p)
                    # done with this CP        
                    self.cplist.append(thiscp)
                line = f.readline()
            # read the numbers of critical points
            self.num_ncp = int(line.split()[-1])
            self.num_nna = int((f.readline()).split()[-1])
            self.num_bcp = int((f.readline()).split()[-1])
            self.num_rcp = int((f.readline()).split()[-1])
            self.num_ccp = int((f.readline()).split()[-1])
            f.close()
            #
            #for cp in self.cplist:
            #    print('----- read_sumviz')
            #    print('{0} {1}'.format(cp.type, cp.connected))
            #print ('------')
        except IOError as e:
            print("Input file error({0}): {1}".format(e.errno, e.strerror))
            print("in file: {0}".format(fname))
                                
    def read_critic2(self,fname,**kwargs):
        """
        Read molecular graph data from an output file produced using the CRITIC2 code
        """
        au2ang = 0.5291772410903 # conversion factor from atomic length units (Bohr) to Angstrom

        print('In read_critic2')
        debug = kwargs['debug']
        if debug:
            print('*** read_critic2 DEBUG MODE ***')
        # initialize species arrays
        spc_Z=[]
        spc_name=[]
        spc_charge=[]
        spc_pscharge=[]
        fluxname = str(pathlib.Path(fname.strip()).stem)+'_flux.txt'
        try:
            with open(fname.strip(),'r') as f:
                #  
                line = lookfor(f,"+ critic2")  # code version
                self.codeversion = line[1:]
                #print('PARSE: self.codeversion = {0}'.format(self.codeversion))
                # IS THE FILE DESCRIBING A MOLECULE OR A CRYSTAL?
                while True:
                    line = lookfor(f,'%%')
                    if 'crystal' in line.lower() or 'molecule' in line.lower():
                        if 'crystal' in line.lower():
                            iscrystal = True
                            break
                        if 'molecule' in line.lower():
                            iscrystal = False
                            break
                #
                if iscrystal:
                    print('Input is a 3-D periodic cell (crystal)')
                else:
                    print('Input is a molecule')
                # DENSITY/WF FILE FROM WHICH THE CRITIC2 RUN CALCULATED PROPERTIES/CPs 
                line = lookfor(f,'From:')

                self.wf_file = line.split()[-1]
                print('Calculated from: ',self.wf_file)
                line = lookfor(f,'+ List of atomic species:') # atomic species
                while True:  # skip headers and comments
                    line = f.readline()
                    if not line.startswith('#'):
                        break
                while (line.strip() != ''): # loop over species lines
                    tokens=line.split()
                    spc_Z.append(int(tokens[1]))             # atomic number
                    spc_name.append(tokens[2].strip('_'))    # species name
                    spc_charge.append(float(tokens[3]))      # species charge
                    if len(tokens) == 5:
                        spc_pscharge.append(float(tokens[4].strip('-')+'0' ))
                    else:
                        spc_pscharge.append(0.0)
                    line=f.readline()
                numspc=len(spc_Z)
                print('Number of species = {0}'.format(numspc))
                for i in range(0,numspc):
                    print('{0:4d} {1:3d} {2:4s} {3:10.5f} {4:10.5f}'.format(i,spc_Z[i],spc_name[i], \
                                                                     spc_charge[i],spc_pscharge[i]))                
                #
                if iscrystal:
                    print('This is a crystal - detecting fractional coordinates of nuclei')
                    atomfracs = []
                    line = lookfor(f,'List of atoms in the unit cell (cryst. coords.)')
                    # skip next 4 lines
                    for i in range(0,4):
                        line = f.readline()
                    line = f.readline()
                    while line.strip() != '':
                        tokens = line.split()
                        thisfrac = [float(tokens[1]), float(tokens[2]),float(tokens[3])]
                        atomfracs.append(thisfrac)
                        #print('{0:} {1:} {2:}',format(tokens[-4],tokens[0],thisfrac[0],thisfrac[1],thisfrac[2] ))                        
                        print('{0} {1} {2} {3} {4}'.format(tokens[-4],tokens[0],thisfrac[0],thisfrac[1],thisfrac[2] ))
                        line = f.readline()

                # FIRST, the atom coordinates
                #
                line = lookfor(f,"+ List of atoms in Cartesian coordinates") # SEARCH: atom labels and coordinates
                # parse atom labels and coordinates
                # get units
                if '(ang_)' in line:      # ccordinates are given in angstrom, convert to au
                    unitmult = 1.0/au2ang
                else:
                    unitmult = 1.0
                while True:  # skip headers and comment lines starting with #
                    line = f.readline()
                    if not line.startswith('#'):
                        break

                # READ AND PRINT NUCLEAR COORDINATE DATA
                atomindex = -1
                while (line.strip() != ''):
                    atomindex = atomindex + 1
                    tokens = line.split()
                    # idnumber x y z symbol_ Z
                    atomid = int(tokens[0])
                    x = float(tokens[1])
                    y = float(tokens[2])
                    z = float(tokens[3])
                    spc = int(tokens[4])                        # this is the species number
                    self.atom_charge.append(spc_charge[spc-1])  # extract charge from prebuilt species table
                    sym = tokens[5].strip('_')                  # remove trailing _ from symbol;
                    if not iscrystal:
                        self.atom_label.append(sym+str(atomid))     # Make initial label from symbol+atom number
                    else:
                        frac = atomfracs[atomindex]
                        self.atom_label.append(sym+str(atomid)+'_'+celllabel(frac))
                    self.atom_x.append(x*unitmult)
                    self.atom_y.append(y*unitmult)
                    self.atom_z.append(z*unitmult)
                    # done with this line                
                    line = f.readline()  # read another line
                    
                print(' == Read nuclear coordinates ==')
                for i in range(0, len(self.atom_label)):
                    print('{0:8s} {1:17.10E} {2:17.10E} {3:17.10E} {4:17.10E}'.format(self.atom_label[i],
                                                       self.atom_x[i],self.atom_y[i],self.atom_z[i],
                                                       self.atom_charge[i]))
                
                # if a crystal, extract a,b,c in list-of-strings form
                # then go back and modify atom names
                if iscrystal:
                    line = lookfor(f,"crys to car")
                    crys2carm = np.array( [[ 0.0, 0.0, 0.0],[0.0,0.0,0.0],[0.0,0.0,0.0]],dtype=np.float64)
                    for i in range(0,3):
                        line = f.readline()
                        tokens = line.split()
                        for j in range(0,3):
                            crys2carm[i,j] = float(tokens[j])
                    box_a = crys2carm[0,:]
                    box_b = crys2carm[1,:]
                    box_c = crys2carm[2,:]
                    box_o = np.array([0.0,0.0,0.0],dtype=np.float64)                    
                    cell_a = [ str(box_a[j]) for j in range(0,3) ]
                    cell_b = [ str(box_b[j]) for j in range(0,3) ]
                    cell_c = [ str(box_c[j]) for j in range(0,3) ]
                
                # LOAD FIELD INFORMATION
                line = lookfor(f,"+ Field number 1")
                # title and model
                self.title = self.wf_file
                if iscrystal:  # append CRYSTAL data to title string
                    self.title = self.title +  ' CRYSTAL {0.0,0.0,0.0}'\
                                            +  ' {'+','.join(cell_a)+'}'\
                                            +  ' {'+','.join(cell_b)+'}'\
                                            +  ' {'+','.join(cell_c)+'}'
                    print('Appended CRYSTAL data to title line')
                    print('{0}'.format(self.title))
                    #self.wf_file = 
                self.model = ''
                print('Read in field data from : {0}'.format(self.wf_file))

                # Now find the numbers of critical points
                self.num_ncp = 0
                self.num_nna = 0
                self.num_bcp = 0
                self.num_rcp = 0
                self.num_ccp = 0
                
                # EXTRACT CRITICAL POINT TYPES AND LOCATIONS
                # First, skip to the final cp list
                line = lookfor(f,'Critical point list, final report')    # SEARCH
                if line == '':
                    print('Critical point list, final report not found!')
                    sys.exit()
                else:
                    print(line)
                # now look for the line indicating
                line = lookfor(f,'position')    # this jumps to the table header line
                if line == '':
                    print('position header keyword not found in cro file')
                    sys.exit()
                print(line)
                tokens = line.split()
                if ('(ang_)' in line):  # coordinates are given in angstrom, convert to au
                    unitmult = 1.0/au2ang
                else: # crystal coordinates or cartesian bohr
                    unitmult = 1.0
                # 
                #numcps = self.num_ncp + self.num_bcp + self.num_rcp + self.num_ccp
                # ===========================================================
                # e.g.
                # for a crystal, 
                # 9 C1 (3,-1) bond  1.00000000  0.00000007  0.66526194 1 b18 1.58748485E-01  5.13361118E-16 -1.26731900E-01                
                print('Reading CP lines')
                line = f.readline()            # skip the table header line
                print(line)
                while not line.strip() == '':  # loop over detected lines until blank line found
                    tokens = line.split()
                    thiscp = CriticalPoint()  # create new CP
                    cpnum = int(tokens[0])    # Critic2 CP number
                    # parse fields
                    if iscrystal:  # convert crystal coordinates to Cartesian, 'pg' and 'mult' fields are present
                        cr = np.array( [float(tokens[-8])*unitmult,
                                        float(tokens[-7])*unitmult,
                                        float(tokens[-6])*unitmult ], dtype=np.float64)
                        cartr = crys2carm.dot(cr)
                        thiscp.pos_x = cartr[0]
                        thiscp.pos_y = cartr[1]
                        thiscp.pos_z = cartr[2]                        
                    else:          # coordinates are already Cartesian, no 'mult' or 'pg' field
                        thiscp.pos_x = float(tokens[-7])*unitmult  # convert to au
                        thiscp.pos_y = float(tokens[-6])*unitmult  # convert to au
                        thiscp.pos_z = float(tokens[-5])*unitmult  # convert to au
                    #
                    thiscp.Rho = float(tokens[-3])
                    thiscp.DelSqRho = float(tokens[-1])                    
                    thiscp.id = tokens[-4].strip('_')   # id from 4th to last column
                    thiscp.label = thiscp.id
                    #
                    if 'nucleus' in line:
                        self.num_ncp = self.num_ncp+1   # increase NCP count
                        thiscp.type = 'NACP'
                        thiscp.RhoNuc = thiscp.Rho
                        thiscp.id = cpnum
                        thiscp.connected = self.atom_label[cpnum-1]           # Atom name                  
                    elif 'bond' in line:
                        thiscp.type = 'BCP'
                        self.num_bcp = self.num_bcp+1   # increase BCP count
                        thiscp.id = cpnum
                    elif 'ring' in line:
                        thiscp.type = 'RCP'
                        thiscp.num_rcp = self.num_rcp+1 # increase RCP count
                    elif 'cage' in line:
                        thiscp.type = 'CCP'
                        self.num_ccp = self.num_ccp+1   # increase CCP count
                    elif 'nnattr' in line:
                        thiscp.type = 'NNACP'
                        self.num_nna = self.num_nna+1   # increase NNACP count
                        thiscp.RhoNuc = thiscp.Rho
                        thiscp.id = cpnum
                        thiscp.connected = 'NNA'+str(cpnum)                        
                    else:
                        print('Unknown CP type for CP {0}: {1}'.format(i,line))
                        sys.exit()    
                    # initialize all bondpath-related numbers 
                    thiscp.BPL=-0.0
                    thiscp.GBL_I=-0.0
                    thiscp.GBL_II=-0.0
                    thiscp.GBL_III=-0.0
                    thiscp.GBL_IV=-0.0
                    # store this CP      
                    self.cplist.append(thiscp)
                    # read the next line and repeat                    
                    line = f.readline()
                print('Finished reading CP lines')
                # print totals and Morse sum
                print('NCP {0} NNA {1} BCP {2} RCP {3} CCP {4}'.format(self.num_ncp,self.num_nna,self.num_bcp,self.num_rcp,self.num_ccp))
                print('Morse sum = {0}'.format(self.num_ncp + self.num_nna - self.num_bcp + self.num_rcp -self.num_ccp))
                
                # Set the BCP names, remove bogus BCPs with same start and end attractor
                # From the 'Analysis of System bonds' section
                # ncp  End-1    End-2   r1(bohr) r2(bohr)  r1/r2  r1-B-r2  p1(bohr) p2(bohr)
                # 9    S_ (8)   H_ (4)   1.8894   0.8282   2.2813  180.00   1.8894   0.8290
                line = lookfor(f,'ncp  End-1')           # SEARCH          
                for i in range(0,self.num_bcp):
                    line = f.readline()
                    tokens=line.split()
                    cpnum = int(tokens[0]) # the CP number
                    ends = [ int(s) for s in re.findall('\\(([0-9]*)\\)',line) ]
                    endnames = [ self.cplist[j-1].connected for j in ends ]
                    #end1pos = 
                    if endnames[0] != endnames[1]:   # different attractors at ends of the bond path ?
                        self.cplist[cpnum-1].connected = '-'.join(endnames)
                        self.cplist[cpnum-1].attractorsBPL.append(float(tokens[-2]))
                        self.cplist[cpnum-1].attractorsBPL.append(float(tokens[-1]))
                        self.cplist[cpnum-1].BPL = float(tokens[-2])+float(tokens[-1])
                    else:
                        self.cplist[cpnum-1].connected = 'A1 A2'
                        self.cplist[cpnum-1].type = 'NNACP'
                    #print('BCP {0} {1} {2} >{3}<'.format(cpnum,endnames[0],endnames[1],self.cplist[cpnum].connected)) 

                # Parse the 'bcp and rcp connectivity table'
                # This allows explicit account to be taken of crystal repeats of NCPs
                if iscrystal:
                    line = lookfor(f,'bcp and rcp connectivity table')   # SEARCH 
                    if line=='':
                        print('Could not find line matching (bcp and rcp connectivity table) in CRITIC2 output, exiting')
                        sys.exit()
                    line = f.readline()
                    line = f.readline() 
                    # skip past current list of NCPs to first BCP line
                    line = lookfor(f,'  b  ')
                    print(' \nScanning for extra bond path endpoints')
                    for i in range(0,self.num_bcp):
                        tokens = line.split()
                        if len(tokens) < 1:
                            print('Error parsing line:{0} in {1}'.format(line,fname))
                        print(tokens)
                        cpnum = int(tokens[0])
                        currentbcplabel = self.cplist[cpnum-1].connected
                        print('\nCurrent BCP {0} label is {1}'.format(cpnum,currentbcplabel))
                        numtokens = len(tokens)
                        if numtokens == 18:   # full line with both ends and lvecs
                            end1 = int(tokens[-12])   # CP number of NCP at end 1
                            lvec1 = [int(tokens[-10]),int(tokens[-9]),int(tokens[-8])]
                            end2 = int(tokens[-6])    # CP number of NCP at end 2
                            lvec2 = [int(tokens[-4]),int(tokens[-3]),int(tokens[-2])]
                            print('Endpoint candidates: ',end1,lvec1,end2,lvec2)
                            needs_relabel = True   # assume relabelling is needed

                            # Add a new nucleus and NCP matching the first endpoint if needed
                            #if not (lvec1[0] == 0 and lvec1[1] == 0 and lvec1[2] == 0):
                            # end 1 is out of base cell
                            newsuffix1 = celllabel([float(p) for p in lvec1])
                            nametomatch1 = self.cplist[end1-1].label.split('_')[0]+str(end1)
                            #nametomatch1 = self.cplist[end1-1].label                            
                            fullmatch1 = nametomatch1+'_'+newsuffix1
                            print('Mentioned attractor {0} in cell {1} called {2}'.format(nametomatch1,lvec1,fullmatch1))
                            # add a new atom name, check if it exists first
                            print('Searching for an endpoint called ',fullmatch1)
                            end1exists = False
                            for ncp in self.cplist:
                                if (ncp.type == 'NACP' or ncp.type == 'NNACP') and ncp.label == fullmatch1:
                                    print('Found an existing attractor with this name')
                                    end1exists = True
                                    end1label = ncp.label
                                    break
                            if not end1exists:  # No such NCP exists, create it
                                print('No existing attractor with this name, creating one')
                                # Add the new NCP as a clone of the other one
                                newncp = copy.deepcopy(self.cplist[end1-1])
                                # modify the clone with updated id, label and coordinates
                                newncp.id = end1 
                                newncp.label = fullmatch1
                                end1label = fullmatch1
                                shift1 = (float(lvec1[0])*box_a)+(float(lvec1[1])*box_b)+(float(lvec1[2])*box_c)
                                #print('calculated shift for this NCP copy is', shift1)
                                newncp.pos_x = newncp.pos_x+shift1[0]
                                newncp.pos_y = newncp.pos_y+shift1[1]
                                newncp.pos_z = newncp.pos_z+shift1[2]
                                # add the new NCP to cplist
                                self.cplist.append(newncp)
                                # then add the new nucleus to the list of nuclei
                                self.atom_label.append(fullmatch1)
                                self.atom_charge.append(0.0)
                                self.atom_x.append(newncp.pos_x)
                                self.atom_y.append(newncp.pos_y)
                                self.atom_z.append(newncp.pos_z)
                                print('\nNew list of NCPs is')
                                for cp in self.cplist:
                                    if cp.type == 'NCP' or cp.type == 'NACP':
                                        print (cp.label, cp.pos_x, cp.pos_y, cp.pos_z)
                                #print('New list of nuclei is')
                                #for i in range(0,len(self.atom_label)):
                                #    print('{0} {1} {2} {3}'.format(self.atom_label[i],self.atom_x[i],self.atom_y[i],self.atom_z[i]))
                                needs_relabel = True
                                print('\n')

                            # finished adding a new nucleus and NCP if needed
                            # Add a new nucleus and NCP matching the second endpoint if needed
                            #if not (lvec2[0] == 0 and lvec2[1] == 0 and lvec2[2] == 0):
                            # end 2 is out of base cell
                            newlabel2 = celllabel([float(p) for p in lvec2])
                            # add a new atom name, check if it exists first
                            end2exists = False
                            nametomatch2 = self.cplist[end2-1].label.split('_')[0]+str(end2)
                            #nametomatch1 = self.cplist[end1-1].label                            
                            fullmatch2 = nametomatch2+'_'+newlabel2
                            print('Mentioned attractor {0} in cell {1} called {2}'.format(nametomatch2,lvec2,fullmatch2))
                            for cp in self.cplist:
                                if (cp.type == 'NACP' or cp.type == 'NNACP') and cp.label == fullmatch2:
                                    end2exists = True
                                    end2label = cp.label
                                    break
                            if end2exists:
                                print('Found an existing attractor with this name')
                            else:
                                print('No existing attractor with this name, creating one')
                                # then add the new NCP as a clone of the other one
                                newncp = copy.deepcopy(self.cplist[end2-1])
                                newncp.id = end2
                                newncp.Rho = self.cplist[end2-1].Rho
                                newncp.RhoNuc = self.cplist[end2-1].RhoNuc
                                print('Rhonuc set')
                                newncp.label = fullmatch2
                                end2label = fullmatch2
                                shift2 = (float(lvec2[0])*box_a)+(float(lvec2[1])*box_b)+(float(lvec2[2])*box_c)
                                #print('calculated shift for this NCP copy is', shift2)
                                newncp.pos_x = newncp.pos_x+shift2[0]
                                newncp.pos_y = newncp.pos_y+shift2[1]
                                newncp.pos_z = newncp.pos_z+shift2[2]
                                # add the new NCP
                                self.cplist.append(newncp)
                                # then add the new nucleus to the list
                                self.atom_label.append(fullmatch2)
                                self.atom_charge.append(0.0)
                                self.atom_x.append(newncp.pos_x)
                                self.atom_y.append(newncp.pos_y)
                                self.atom_z.append(newncp.pos_z)
                                print('\nNew list of NCPs is')
                                for cp in self.cplist:
                                    if cp.type == 'NCP' or cp.type == 'NACP':
                                        print (cp.label, cp.pos_x, cp.pos_y, cp.pos_z)
                                #print('New list of nuclei is')
                                #for i in range(0,len(self.atom_label)):
                                #    print('{0} {1} {2} {3}'.format(self.atom_label[i],self.atom_x[i],self.atom_y[i],self.atom_z[i]))
                                needs_relabel = True
                                print('\n')

                            # fix up the label on this BCP
                            print('*** OLD name was',currentbcplabel)
                            newbcplabel = end1label+' '+end2label
                            print('*** NEW name is',newbcplabel)
                            self.cplist[cpnum-1].label = newbcplabel
                            self.cplist[cpnum-1].connected = newbcplabel
                            #Read the next BCP line and loop                                        
                            line = f.readline()
                            

                
                # Extract properties of critical points
                line = lookfor(f,'* Additional properties at the critical points')
                line = f.readline()
                while True:
                    if line.startswith('+ Critical point no.'):
                        # found critical point data, read it
                        tokens = line.split()
                        cpnum = int(tokens[-1])
                        cp = self.cplist[cpnum-1]
                        tokens = lookfor(f,'  Gradient (grad f):').split()
                        cp.GradRho = [ float(tokens[-3]), float(tokens[-2]), float(tokens[-1]) ]
                        # Hessian properties
                        line = lookfor(f,'Hessian:')
                        hess1 = [float(t) for t in f.readline().split()]
                        hess2 = [float(t) for t in f.readline().split()]
                        hess3 = [float(t) for t in f.readline().split()]
                        hess = np.array( [ hess1, hess2, hess3 ],dtype=np.float64 )
                        cp.HessRho = [hess1, hess2, hess3]
                        #print('CP# {0} Hess = {1}'.format(cpnum,hess))
                        evals,evecs=np.linalg.eigh(hess)

                        cp.HessRho_EigVals = evals.tolist()
                        cp.HessRho_EigVec1 = evecs[:,0].tolist()
                        cp.HessRho_EigVec2 = evecs[:,1].tolist()
                        cp.HessRho_EigVec3 = evecs[:,2].tolist()
                        if cp.type == 'BCP':
                            cp.Ellipticity = abs(evals[0]/evals[1]) - 1.0
                    # Stress Tensor properties
                    if 'Stress tensor: ' in line:  # if stress tensor data present
                        stress1 = [float(t) for t in f.readline().split()]
                        stress2 = [float(t) for t in f.readline().split()]
                        stress3 = [float(t) for t in f.readline().split()]
                        stress = np.array( [ stress1, stress2, stress3 ],dtype=np.float64 )
                        #print('CP# {0} stress = {1}'.format(cpnum,stress))
                        sevals,sevecs=np.linalg.eigh(stress)
                        cp.Stress_EigVals = evals.tolist()
                        cp.Stress_EigVec1 = evecs[:,0].tolist()
                        cp.Stress_EigVec2 = evecs[:,1].tolist()
                        cp.Stress_EigVec3 = evecs[:,2].tolist()
                    if line.startswith('End AUTO'):
                        break
                    line = f.readline()


        except IOError as e:
            print("Input file error({0}): {1}".format(e.errno, e.strerror))
            sys.exit() 

        # FINISHED WITH MAIN CRITIC2 OUTPUT FILE   
        print('Finished parsing critical point data from CRITIC2 output file')

        #
        # Parse the FLUXPRINT output file for path details, if present
        #
        print( '=== SCANNING FOR PATH DATA IN FLUXPRINT OUTPUT ===') 
        print('Scanning paths from {0}'.format(fluxname))
        #dummy = input()
        # Check if FLUXPRINT file exists
        if pathlib.Path(fluxname).is_file():
            # FLUXPRINT output is present
            numfluxpaths = 0
            with open(fluxname,'r') as pathf:
                # Scanning the FLUXPRINT file        
                while True:  # repeat until no more FLUXPRINT path information
                    #dummy=input('Press return for next path')
                    print('===== FLUXPRINT: new path =====')
                    line = lookfor(pathf,'number of points')
                    if not line: # break at end of file
                        break
                    # found path data
                    numfluxpaths = numfluxpaths + 1
                    npathpoints = int(line.split()[-1])  # number of points in this path
                    # Find which BCP is involved 
                    line = lookfor(pathf,'name:')
                    tokens = line.split()
                    fromid = tokens[2]           # ID of start BCP
                    fromcpnum = int(tokens[-3])  # number of start BCP
                    if debug:
                        print('Path starts from CP ID {0}'.format(fromid))
                    # Where does FLUXPRINT think the BCP is?
                    # search for matching BCP object, store first BCP found to match the given ID 
                    fromcp = None
                    # 
                    if not iscrystal: # deal with easier MOLECULAR CASE
                        if debug:
                            print('Molecule')
                        # Molecular case : get cartesian position of the BCP
                        # replaced the following line - seems for molecules it's in ang_
                        #line = lookfor(pathf,'starting position (bohr)')                     
                        line = lookfor(pathf,'starting position')
                        if 'cryst' in line:
                            line = lookfor(pathf,'starting position')
                        if 'ang_ ' in line:  # positions in angstroms
                            posmult = 1.0/au2ang
                            if debug:
                                print('Positions given in Angstrom')
                        else:   # positions in bohr
                            posmult = 1.0
                            if debug:
                                print('Positions given in bohr')

                        if line == '':
                            print('Could not find a starting point')

                        if debug:
                            print(line)
                        tokens = line.split()
                        fromcpcartraw = np.array( [float(tokens[-3]),float(tokens[-2]),float(tokens[-1])],dtype=np.float64)
                        fromcpcart = posmult*fromcpcartraw
                        #print('FLUXPRINT: molecule BCP position is: Cartesian (ang_) {0}'.format(fromcpcartang))
                        print('FLUXPRINT: molecule BCP position is: Cartesian (au):  {0}'.format(fromcpcart))
                        fromcp = self.cplist[fromcpnum-1]
                        oldcart = fromcpcart  # store the origin BCP coordinates (au)
                        line = lookfor(pathf,'starting path direction')
                        pathstartdir = np.array([ float(i) for i in line.split()[-3:]],dtype=np.float64)
                        print('Path starts in direction {0}'.format(pathstartdir))
                        print('BCP at start of this path is CP number {0}, named {1}'.format(fromcpnum,fromcp.connected))
                        # find the attractor
                        line = lookfor(pathf,'name') # name of endpoint
                        tokens = line.split()
                        toid = tokens[2]             # name of end CP
                        isabp = True  # flag to indicate if this is a bond path
                        if toid == 'n/a' :  # this is likely an IAS path
                            isabp = False
                            print('End of this path is not an attractor - likely an IAS path')
                        else:
                            isabp = True
                            tocpnum = int(tokens[-3])    # number of end CP
                            tocp = self.cplist[tocpnum-1]
                            endsym = toid.partition('_')[0]
                            print('End attractor called {0} with label {1},{2}'.format(endsym,tocp.label,tocp.connected))
                            line = lookfor(pathf,'end position')
                            if 'cryst' in line:   # ignore the 'cryst' position if any
                                 line = lookfor(pathf,'end position')  # read the cartesian instead
                            # units will match previous posmult     
                            #line = lookfor(pathf,'end position (ang_)') # second is the cartesian coordinates
                            ncpposcart = np.array([ posmult*float(i) for i in line.split()[-3:]],dtype=np.float64)  # this is cart!
                            print('FLUXPRINT: Attractor position is: Cartesian:  {0}'.format(ncpposcart))   
                    else: # CRYSTAL case: get fractional -> cartesian position of the BCP
                        # where does FLUXPRINT think the BCP is?
                        line = lookfor(pathf,'starting position (cryst.)')
                        bcpposfrac = np.array([ float(i) for i in line.split()[-3:]],dtype=np.float64)
                        line = lookfor(pathf,'starting position')
                        bcpposcart = np.array([ float(i) for i in line.split()[-3:]],dtype=np.float64)
                        print('FLUXPRINT thinks the BCP position is')
                        print('Fractional: {0}'.format(bcpposfrac))
                        print(' Cartesian: {0}'.format(bcpposcart))
                        line = lookfor(pathf,'starting path direction')
                        pathstartdir = np.array([ float(i) for i in line.split()[-3:]],dtype=np.float64)
                        print('Path starts in direction {0}'.format(pathstartdir))
                        # find the attractor
                        line = lookfor(pathf,'name') # name of endpoint
                        tokens = line.split()
                        toid = tokens[2]             # name of end CP
                        tocpnum = int(tokens[-3])    # number of end CP
                        tocp = self.cplist[tocpnum-1]
                        endsym = toid.partition('_')[0]
                        print('End attractor called {0} with label {1},{2}'.format(endsym,tocp.label,tocp.connected))
                        #line = lookfor(pathf,'end position') # first is the crystal coordinates
                        line = lookfor(pathf,'end position (bohr)') # second is the cartesian coordinates
                        ncpposfrac = np.array([ float(i) for i in line.split()[-3:]],dtype=np.float64)  # this is cart!
                        print('at cartesian position {0}'.format(ncpposfrac))
                        #                 
                        #realfrac = getfrac(bcpposcart,box_o,box_a,box_b,box_c)
                        cartmindist = 1.0E6
                        cplistidx = -1
                        for cp in self.cplist: # which existing BCP *Cartesian* location is closest 
                            cplistidx = cplistidx+1
                            if cp.type == 'BCP' and endsym in cp.connected:
                                calcdist = cartdist(bcpposcart,np.array([cp.pos_x,cp.pos_y,cp.pos_z],dtype=np.float64))
                                if calcdist < cartmindist:
                                    cartmindist = calcdist
                                    cplistsel = cplistidx
                        if cartmindist < 0.01:
                            thisid = self.cplist[cplistsel].id
                            thislabel = self.cplist[cplistsel].connected
                            thisx = self.cplist[cplistsel].pos_x
                            thisy = self.cplist[cplistsel].pos_y
                            thisz = self.cplist[cplistsel].pos_z
                            #cidxa =                  
                            print('Closest existing BCP is CP number {0}, label {1} at distance {2}'.format(thisid,thislabel,cartmindist ))
                            print('Cartesian coords: {0}, {1}, {2}'.format(thisx,thisy,thisz))
                        else:
                            print('Best detected existing BCP was too far away ({0})'.format(cartmindist))
                            sys.exit()
                            #continue
                        fromcp = self.cplist[cplistsel]
                        fromcpcart = np.array([fromcp.pos_x,fromcp.pos_y,fromcp.pos_z],dtype=np.float64)
                        #
                        # Print this BCP's existing path data
                        pllen = len(fromcp.pathlist)
                        print('This BCP already has {0} associated paths'.format(pllen))                        
                        for pli in fromcp.pathlist:
                            print('Path direction: {0}'.format(pli.direction))

                    # For both molecules and crystals
                    #  GRAB PATH DATA LINES FROM THE FILE                        
                    line = lookfor(pathf,'rhoxx') # Skip to path data
                    # Read ALL the path lines first to a list of lists of floats
                    print('Reading path data')                                                                           
                    pathlines = []
                    pathlinecount = 0
                    try:
                        for i in range (npathpoints):
                            line = pathf.readline()
                            linetokens = line.split()
                            #print(linetokens)
                            try:
                                pathlines.append( [ float(j) for j in linetokens ])
                                pathlinecount += 1
                            except:
                                print('ERROR at line {0}:{1}'.format(i,linetokens))
                                sys.exit()
                    except IOError as e:
                            print('Error reading FLUXPRINT file {0}'.format(fluxname))
                            print('at path between BCP {0} and attractor {1}'.format(fromcpnum,tocpnum))
                            print('Expected {0} path points, got {1}'.format(npathpoints,pathlinecount))
                            sys.exit()                    

                    #
                    # STEP 1: add 'fromcp' to path object
                    #
                    #currpathcart = np.array([fromcp.pos_x,fromcp.pos_y,fromcp.pos_z],dtype=np.float64)
                    currpathcart = fromcpcart
                    #
                    # Start building
                    p = FieldPath()              # Make a new FieldPath object
                    if isabp: 
                        p.description = '{0} sample points along path from BCP to attractor {1}'.format(npathpoints,tocp.connected)
                    else:
                        p.description = '{0} sample points along IAS +EV path from BCP'.format(npathpoints) 
                    p.direction = pathstartdir                           
                    # Make the first point in path object p be the BCP itself
                    p.path_x.append(fromcpcart[0])
                    p.path_y.append(fromcpcart[1])
                    p.path_z.append(fromcpcart[2])
                    p.path_fieldvar.append(fromcp.Rho)
                    p.path_vecfieldvar.append(np.array(fromcp.GradRho,dtype=np.float64))
                    h = fromcp.HessRho
                    p.path_matfieldvar.append(np.array([[ h[0][0], h[0][1], h[0][2]  ],
                                                        [ h[1][0], h[1][1], h[1][2]  ],
                                                        [ h[2][0], h[2][1], h[2][2]  ] ],dtype=np.float64))
                    pathindex = 0
                    #
                    # STEP 2 : LOOP OVER ALL POINTS IN THE PATH
                    oldcart = fromcpcart                    
                    for pl in pathlines:
                        if len(pl) < 4:  # trap shorter than expected path line
                            print('Shorter than expected path line')
                            print(pl)
                            sys.exit()
                        # Get current point on path (cartesian or fractional)     
                        point = np.array([pl[0],pl[1],pl[2]],dtype=np.float64)
                        #print ('Path point {0}/{1}'.format(pathindex+1, len(pathlines)))
                        if iscrystal:
                            # path point cordinates are fractional
                            pointfr=point
                            cartr = closestcart(pointfr,box_o,box_a,box_b,box_c,1,oldcart)
                            oldcart = cartr
                        else: 
                            cartr = posmult*point
                            oldcart = cartr
                        #    
                        # Store final calculated coordinates of path point with local scalars,vector and tensor
                        p.path_x.append(cartr[0])                 # Cartesian x
                        p.path_y.append(cartr[1])                 # Cartesian y
                        p.path_z.append(cartr[2])                 # Cartesian z
                        p.path_fieldvar.append(pl[3])  # rho
                        p.path_vecfieldvar.append(np.array([pl[4],pl[5],pl[6]],dtype=np.float64))  # grad rho
                        if len(pl) == 16:   # All hessian terms are present
                            p.path_matfieldvar.append(np.array([[ pl[7], pl[8], pl[9] ],
                                                                [ pl[10],pl[11],pl[12]],
                                                                [ pl[13],pl[14],pl[15]] ],dtype=np.float64))
                        else:                 # Upper triangle for Hessian only, expand into full Hessian
                            p.path_matfieldvar.append(np.array([[ pl[7], pl[8], pl[9] ],
                                                                [ pl[8], pl[10],pl[11]],
                                                                [ pl[9], pl[11],pl[12]] ],dtype=np.float64))
                        pathindex = pathindex + 1 # increment path counter
                        #print('{0}/{1}'.format(pathindex,len(pathlines)))
                        # update oldcart
                        oldcart = cartr
                        
                    #                                    
                    # Measure FieldPath length
                    print('Built this path')
                    partbpl = p.length()
                    print('Partial path length = {0}'.format(partbpl))
                    if partbpl > 100.0:  # Check for broken path
                        print('Broken path')
                        for i in range(0,len(p.path_x)-1):
                            print('{0} : {1} {2} {3}'.format(i,p.path_x[i],p.path_y[i],p.path_z[i]))
                        sys.exit()
                    #    
                   
                    thisbcp = fromcp
                    if isabp:
                        # if this ia a bond path check if this path already exists
                        #beginp = np.array([p.path_x[0],p.path_y[0],p.path_z[0]],dtype=np.float64 )
                        #endp = np.array([p.path_x[-1],p.path_y[-1],p.path_z[-1]],dtype=np.float64 )
                        pathdupe = False
                        if len(thisbcp.pathlist) > 1: # already has 2 attached path, mark as dupe
                            pathdupe = True
                        elif len(thisbcp.pathlist) == 1 : # already has one path, check for opposite directions
                            existingdir = thisbcp.pathlist[0].direction
                            if np.dot(existingdir,pathstartdir) > 0:  # parallelish
                                pathdupe = True
                                                    # pathstartdir
                        #for p2 in thisbcp.pathlist:
                            #if len()
                            # check for duplicate paths 
                            #beginthis = np.array([p2.path_x[0],p2.path_y[0],p2.path_z[0]],dtype=np.float64 )
                            #endthis = np.array([p2.path_x[-1],p2.path_y[-1],p2.path_z[-1]],dtype=np.float64 )
                            #if (cartdist(beginp,beginthis) < 0.05) and (cartdist(endp,endthis) < 0.05):
                                #pathdupe = True

                        if not pathdupe: # Append new FieldPath object to BCP's pathlist
                            
                            thisbcp.pathlist.append(p)
                            maxdist = 0.0
                        else:            # Reject new path and break
                            print('Path already exists - REJECTING')
                            pathdupe = False
                            continue                      

                            
                        print('For this BCP at {0}, have found the following partial bond lengths'.format(thisbcp.pos_x,thisbcp.pos_y,thisbcp.pos_z))
                        for i in thisbcp.pathlist:
                            start = '({0},{1},{2})'.format(i.path_x[0],i.path_y[0],i.path_z[0])
                            end = '({0},{1},{2})'.format(i.path_x[-1],i.path_y[-1],i.path_z[-1])                        
                            print('Partial bond length: {0} {1}->{2}'.format(i.length(),start,end))
                        #thisbcp.BPL = thisbcp.BPL + p.length()
                # End of loop over paths in FLUX file
            # FLUX file done, automatically closed 
            # Now review how many paths were retrieved for each BCP
            print('*** Path number check ***')
            print('FLUXPRINT file contained {0} paths'.format(numfluxpaths))
            numbuilt = 0
            for cp in self.cplist:
                if cp.type == 'BCP':
                    print('BCP ID {0}:{1} has {2} found paths'.format(cp.id,cp.connected,len(cp.pathlist))  )
                    numbuilt = numbuilt + len(cp.pathlist)
            print('There are {0} paths attached to BCPs'.format(numbuilt))
            print('*** End of path number check ***')
            #dummy = input('Press Enter')
               
        else:  
            print('The file {0} containing path data was not found'.format(fluxname))
        
    def read(self,fname,**kwargs):
        """ 
        Determine type of input file, assume file exists, delegate to format-specific routines
        """
        self.mol_charge = 0.0
        self.mol_energy = 0.0
        self.mol_virial_ratio = 0.0
        self.atom_label = []
        self.atom_charge = []
        self.atom_x = []
        self.atom_y = []
        self.atom_z = []
        self.cplist = []
        self.num_ncp = 0
        self.num_nna = 0
        self.num_bcp = 0
        self.num_rcp = 0
        self.num_ccp = 0
        self.filename = fname
        self.wf_file = ''
        if fname.endswith(".sumviz"):
            self.filetype = "AIMAll .sumviz file"
            self.read_aimall_sum(fname,**kwargs)
        elif fname.endswith(".sum"):
            self.filetype = "AIMAll .sum file"
            self.read_aimall_sum(fname,**kwargs)
        elif fname.endswith(".critic") or fname.endswith(".cro"):
            self.filetype = "CRITIC2 output file"
            self.read_critic2(fname,**kwargs)
        else:
            self.filetype = "Unrecognised input file type" 
    
    def change_origin(self, newo):
        """
        Change the coordinate origin for all positional coordinates
        """
        #print('Old positions')
        #for i in range(0,len(self.atom_x)):
        #    print('{0} {1} {2} {3}'.format(self.atom_label[i],self.atom_x[i],self.atom_y[i],self.atom_z[i]))
        ox = newo[0]
        oy = newo[1]
        oz = newo[2]
        # adjust nuclear positions
        self.atom_x = [x - ox for x in self.atom_x]
        self.atom_y = [y - oy for y in self.atom_y]
        self.atom_z = [z - oz for z in self.atom_z]
        # adjust CP positions
        for cp in self.cplist: 
            cp.pos_x = cp.pos_x - ox
            cp.pos_y = cp.pos_y - oy
            cp.pos_z = cp.pos_z - oz
            # adjust all coordinates in attached paths
            for cp_path in cp.pathlist:
                for point_path_x in cp_path.path_x:
                    point_path_x = point_path_x - ox
                for point_path_y in cp_path.path_y:
                    point_path_y = point_path_y - oy 
                for point_path_z in cp_path.path_z:
                    point_path_z = point_path_z - oz                     
 
    def change_axes(self,xnew,ynew,znew):
        """
        Transform all positional data and vectors to new coordinate frame
        Input: xnew,ynew,znew: 3-component vectors of new unit axis vectors
        Affects positions (including paths), vector quantities 
        NOTE: FOR NOW ONLY HANDLE POSITIONS AND EIGENVECTORS!!
        """
        # Ensure normalization on new axes vectors
        moda = math.sqrt(dotprod(xnew,xnew))
        modb = math.sqrt(dotprod(ynew,ynew))
        modc = math.sqrt(dotprod(znew,znew))
        xnew = [xnew[0]/moda,xnew[1]/moda,xnew[2]/moda]
        ynew = [ynew[0]/modb,ynew[1]/modb,ynew[2]/modb]
        znew = [znew[0]/modc,znew[1]/modc,znew[2]/modc]
        # Modify nuclear positions for new coordinate frame
        for i in range(0,len(self.atom_x)):
            p = project([self.atom_x[i],self.atom_y[i],self.atom_z[i]],xnew,ynew,znew)
            self.atom_x[i] = p[0]
            self.atom_y[i] = p[1]
            self.atom_z[i] = p[2]
        # adjust CP positions
        for cp in self.cplist:
            p = project([cp.pos_x,cp.pos_y,cp.pos_z],xnew,ynew,znew)
            cp.pos_x = p[0]
            cp.pos_y = p[1]
            cp.pos_z = p[2]
            # adjust all coordinates in attached paths
            #for cp_path in cp.pathlist:
            #    for i in range(0,len(cp_path.path_x)):
            #        p = [ cp.path_x[i],cp.path_y[i],cp.path_z[i] ]
            #    for point_path_x in cp_path.path_x:
            #        point_path_x = point_path_x - ox
            #    for point_path_y in cp_path.path_y:
            #        point_path_y = point_path_y - oy 
            #    for point_path_z in cp_path.path_z:
            #        point_path_z = point_path_z - oz
            #  
            #  adjust all eigenvectors            
            eh1 = project(cp.HessRho_EigVec1,xnew,ynew,znew)
            cp.HessRho_EigVec1 = eh1
            eh2 = project(cp.HessRho_EigVec2,xnew,ynew,znew)
            cp.HessRho_EigVec2 = eh2
            eh3 = project(cp.HessRho_EigVec3,xnew,ynew,znew)
            cp.HessRho_EigVec3 = eh3
            es1 = project(cp.Stress_EigVec1,xnew,ynew,znew)
            cp.Stress_EigVec1 = es1
            es2 = project(cp.Stress_EigVec2,xnew,ynew,znew)
            cp.Stress_EigVec2 = es2
            es3 = project(cp.Stress_EigVec3,xnew,ynew,znew)
            cp.Stress_EigVec3 = es3

    def nuctoxyz(self,f):
        """
        Sends the nuclear coordinates of the molecular graph, in XYZ file format, to the file descriptor f.
        Includes original molecular graph file name and extracted model information in info line.
        """
        au2ang = 0.52917721067
        natoms = len(self.atom_x)
        f.write('{0}\n'.format(natoms))
        f.write('{0} Model:{1}\n'.format(self.filename,self.model))
        for i in range (0,natoms):
            f.write('{} {: .10f} {: .10f} {: .10f}\n'.format(self.atom_label[i].strip('0123456789'),
                                                             self.atom_x[i]*au2ang,
                                                             self.atom_y[i]*au2ang,
                                                             self.atom_z[i]*au2ang))

    def trimpaths(self):
        """
        Remove path data from all critical points, if present.
        This might help reduce memory usage.
        """
        for cp in self.cplist:
            if (len(cp.pathlist) > 0):
                cp.pathlist = []  
                                                        
    def write_mgpviz(self,f):
        """
        Write data from a 'molgraph' instance to an AIMAll .mgpviz format file on file descriptor f
        """
        
        # Write header data
        f.write('{0}\n{1}\n{2}\n\n{3}\n{4}\n\n'.format(' AIMExt (Version 14.11.23, Professional)',
                                                     ' Portions Copyright (c) 1997-2014 by Todd A. Keith',
                                                     ' AIMExt is a component of the AIMAll package ( http://aim.tkgristmill.com )',
                                                     ' AIMExt is a heavily modified and extended version of the EXTREME program',
                                                     ' developed by members of R.F.W. Bader''s research group'))
        f.write('{0}\n{1}\n{2}\n\n{3}\n'.format(' Much of the Quantum Theory of Atoms in Molecules (QTAIM) is described in the book: ',
                                                '   "Atoms in Molecules - A Quantum Theory"',
                                                '   R.F.W. Bader, Oxford University Press, Oxford, 1990',
                                                ' For additional references see:  http://aim.tkgristmill.com/references.html'))
        f.write('{0}  {1}\n{2}  {3}\n{4}  {5}\n\n{6}  {7}\n\n'.format(' Wfn File:',self.wf_file,
                                                                      ' ExtOut File:','unknown',
                                                                      ' Mgp File:','unknown',
                                                                      ' MgpViz File:','thisfilename'))
        f.write('{0}  {1}\n{2}  {3}\n\n{4}\n{5}\n'.format(' Wfn Title:',self.title,                        
                                                               ' Job Title:','Auto',
                                                               'Nuclear Charges and Cartesian Coordinates:',
                                                               80*'-'))
        f.write('Atom      Charge                X                  Y                  Z\n')
        f.write('{0}\n'.format(80*'-'))
        # now nuclear and NNA coordinates
        for i in range (0,len(self.atom_label)):
            # NEED LOGIC FOR SYMBOL-NUMBER NAMING
            f.write("{0: <7s} {1: >6.1F}         {2:19.10E}{3:19.10E}{4:19.10E}\n".format(self.atom_label[i],
                                                   self.atom_charge[i],
                                                   self.atom_x[i],self.atom_y[i],self.atom_z[i]))
        #C2         6.0           1.1145053800E+00   0.0000000000E+00   0.0000000000E+00
        #H3         1.0          -3.1060114100E+00   0.0000000000E+00   0.0000000000E+00
        #H4         1.0           3.1060114100E+00   0.0000000000E+00   0.0000000000E+00
        #NNA        0.0           0.0000000000E+00   0.0000000000E+00   0.0000000000E+00
        #Cl5       17.0          -3.5002606675E+00   1.8393226728E+00   0.0000000000E+00
        #
        totcps = self.num_ncp+self.num_nna+self.num_bcp+self.num_rcp+self.num_ccp
        f.write('\nTotal number of electron density critical points found = {0}\n'.format(totcps)) # output total number of CPs here
        f.write('\n')
        f.write('Electron Density Critical Point Analysis of Molecular Structure:\n')
        f.write('---------------------------------------------------------------\n')
        f.write('  NACP = Nuclear Attractor Critical Point\n')
        f.write('  NNACP = Non-Nuclear Attractor Critical Point\n')
        f.write('  BCP = Bond Critical Point\n')
        f.write('  RCP = Ring Critical Point\n')
        f.write('  CCP = Cage Critical Point\n')
        f.write('  Rho = Electron Density\n')
        f.write('  GradRho = Gradient of Electron Density\n')
        f.write('  HessRho_EigVals = Eigenvalues of the Hessian of Rho, Ascending Order\n')
        f.write('  HessRho_EigVecs = Eigenvectors of the Hessian of Rho\n')
        f.write('  DelSqRho = Laplacian of Rho = Trace of Hessian of Rho\n')
        f.write('  Bond Ellipticity = (HessRho_EigVal(1) / HessRho_EigVal(2)) - 1\n')
        f.write('  V = Virial Field = Potential Energy Density = Trace of Stress Tensor\n')
        f.write('  G = Lagrangian Form of Kinetic Energy Density\n')
        f.write('  K = Hamiltonian Form of Kinetic Energy Density\n')
        f.write('  L = K - G = Lagrangian Density = (-1/4)DelSqRho\n')
        f.write('  Vnuc = Electrostatic Potential from Nuclei\n')
        f.write('  Ven = Electron-nuclear attractive contribution to Virial Field V\n')
        f.write('  Vrep = V - Ven = Repulsive contribution to Virial Field V\n')
        f.write('  DelSqV = Laplacian of V\n')
        f.write('  DelSqVen = Laplacian of Ven\n')
        f.write('  DelSqVrep = Laplacian of Vrep\n')
        f.write('  DelSqG = Laplacian of G\n')
        f.write('  DelSqK = Laplacian of K\n')
        f.write('  Stress_EigVals = Eigenvalues of Stress Tensor, Ascending Order\n')
        f.write('  Stress_EigVecs = Eigenvectors of Stress Tensor\n')
        f.write('  -DivStress = Ehrenfest Force Density = Minus Divergence of Stress Tensor\n')
        f.write('  BP = Bond Path\n')
        f.write('  BPL = Bond Path Length\n')
        f.write('  GBL = Geometric Bond Length\n')
        f.write('  GBL_I = Distance Between Nuclear Attractors\n')
        f.write('  GBL_II = Distance Between Nuclei\n')
        f.write('  GBL_III = Sum of Distances Between BCP and Nuclear Attractors\n')
        f.write('  GBL_IV = Sum of Distances Between BCP and Nuclei\n')
#  
#  then for each attractor, e.g.
#CP# 4      Coords =  3.06709718188149E+00  0.00000000000000E+00  0.00000000000000E+00
#           Type = (3,-3) NACP H4
#           Rho =  4.2212792555E-01     Rho at Nucleus =  4.1628879336E-01
#           GradRho = -1.2351231149E-15  0.0000000000E+00  0.0000000000E+00
#           HessRho_EigVals = -8.2583572401E+00 -8.2583572401E+00 -7.2807521929E+00
#           HessRho_EigVec1 =  0.0000000000E+00  0.0000000000E+00  1.0000000000E+00
#           HessRho_EigVec2 =  0.0000000000E+00  1.0000000000E+00  0.0000000000E+00
#           HessRho_EigVec3 =  1.0000000000E+00  0.0000000000E+00  0.0000000000E+00
#           DelSqRho = -2.3797466673E+01
#           Bond Ellipticity = NA
#           V = -5.9640087434E+00
#           G =  7.3210375754E-03
#           K =  5.9566877059E+00
#           L =  5.9493666683E+00
#           Vnuc =  3.0367230112E+01
#           Ven = -1.2818855852E+01
#           Vrep =  6.8548471086E+00
#           DelSqV =  1.4985436136E+03
#           DelSqVen =  7.2266314656E+02
#           DelSqVrep =  7.7588046709E+02
#           DelSqG =  1.1243537181E+02
#           DelSqK = -1.6109789855E+03
#           Stress_EigVals = -2.0717704853E+00 -2.0717704853E+00 -1.8204677728E+00
#           Stress_EigVec1 =  0.0000000000E+00  0.0000000000E+00  1.0000000000E+00
#           Stress_EigVec2 =  0.0000000000E+00  1.0000000000E+00  0.0000000000E+00
#           Stress_EigVec3 =  1.0000000000E+00  0.0000000000E+00  0.0000000000E+00
#           -DivStress =  1.9237784607E+01  0.0000000000E+00  0.0000000000E+00
#
#CP# 5      Coords =  1.60461596351594E-09  0.00000000000000E+00  0.00000000000000E+00
#           Type = (3,-3) NNACP NNA
#           Rho =  4.4068102734E-01     Rho at Nucleus =  4.4068102734E-01
#           GradRho = -1.2708745486E-16  0.0000000000E+00  0.0000000000E+00
#           HessRho_EigVals = -7.3687500653E-01 -7.3687500653E-01 -8.5916517482E-02
#           HessRho_EigVec1 =  0.0000000000E+00  0.0000000000E+00  1.0000000000E+00
#           HessRho_EigVec2 =  0.0000000000E+00  1.0000000000E+00  0.0000000000E+00
#           HessRho_EigVec3 =  1.0000000000E+00  0.0000000000E+00  0.0000000000E+00
#           DelSqRho = -1.5596665306E+00
#           Bond Ellipticity = NA
#           V = -1.0283617073E+00
#           G =  3.1922253731E-01
#           K =  7.0913916995E-01
#           L =  3.8991663264E-01
#           Vnuc =  1.1411020823E+01
#           Ven = -5.0286203795E+00
#           Vrep =  4.0002586722E+00
#           DelSqV =  6.3177476572E-01
#           DelSqVen =  1.7797387258E+01
#           DelSqVrep = -1.7165612492E+01
#           DelSqG =  1.4860784334E+00
#           DelSqK = -2.1178531991E+00
#           Stress_EigVals = -4.8781339457E-01 -4.8781339457E-01 -5.2734918112E-02
#           Stress_EigVec1 =  0.0000000000E+00  0.0000000000E+00  1.0000000000E+00
#           Stress_EigVec2 =  0.0000000000E+00  1.0000000000E+00  0.0000000000E+00
#           Stress_EigVec3 =  1.0000000000E+00  0.0000000000E+00  0.0000000000E+00
#           -DivStress =  6.5937796781E-09  0.0000000000E+00  0.0000000000E+00
#  
#  then for each BCP
#           
        atom1name = 'A1'
        atom2name = 'A2'
        atom3name = 'A3'
        atom4name = 'A4'            
        for i in range(0, len(self.cplist)):
            cp = self.cplist[i]
            f.write('\nCP# {0:<7d} Coords ={1:22.14E}{2:22.14E}{3:22.14E}\n'.format(i,cp.pos_x,cp.pos_y,cp.pos_z))
            if cp.type == 'NACP':
                f.write('Type = (3,-1) NACP {0} \n'.format(atom1name))            
            if cp.type == 'BCP':
                f.write('Type = (3,-1) BCP {0} {1}\n'.format(atom1name,atom2name))
            elif cp.type == 'RCP':
                f.write('Type =(3, 1) RCP {0} {1} {2}\n'.format(atom1name,atom2name,atom3name))
            else:
                f.write('Type =(3, 3) CCP {0} {1} {2} {3}\n'.format(atom1name,atom2name,atom3name,atom4name))   
                f.write("           Rho = {0:17.10E}\n           GradRho = {1:17.10E} {2:17.10E} {3:17.10E}\n".format(
                          cp.Rho,cp.GradRho[0],cp.GradRho[1],cp.GradRho[2]))
#        if cp.type == "BCP":
#            print("BPL     = {0:17.10E}\n".format(cp.BPL))
#            print("GBL_I   = {0:17.10E}\n".format(cp.GBL_I))
#            print("GBL_II  = {0:17.10E}\n".format(cp.GBL_II))
#            print("GBL_III = {0:17.10E}\n".format(cp.GBL_III))
#            print("GBL_IV  = {0:17.10E}\n".format(cp.GBL_IV))

#CP# 6      Coords = -2.51006849508491E-01  0.00000000000000E+00  0.00000000000000E+00
#           Type = (3,-1) BCP NNA C1
#           Rho =  4.3895980268E-01
#           GradRho = -1.3877787808E-17  0.0000000000E+00  0.0000000000E+00
#           HessRho_EigVals = -7.5142177089E-01 -7.5142177089E-01  3.2345504651E-01
#           HessRho_EigVec1 =  0.0000000000E+00  0.0000000000E+00  1.0000000000E+00
#           HessRho_EigVec2 =  0.0000000000E+00  1.0000000000E+00  0.0000000000E+00
#           HessRho_EigVec3 =  1.0000000000E+00  0.0000000000E+00  0.0000000000E+00
#           DelSqRho = -1.1793884953E+00
#           Bond Ellipticity =  0.0000000000E+00
#           V = -1.2798709400E+00
#           G =  4.9251190809E-01
#           K =  7.8735903191E-01
#           L =  2.9484712382E-01
#           Vnuc =  1.1990578427E+01
#           Ven = -5.2633819403E+00
#           Vrep =  3.9835110003E+00
#           DelSqV = -7.6200873076E+00
#           DelSqVen =  1.4141550248E+01
#           DelSqVrep = -2.1761637556E+01
#           DelSqG =  1.2455236571E+01
#           DelSqK = -4.8351492633E+00
#           Stress_EigVals = -5.4869277968E-01 -5.4869277968E-01 -1.8248538064E-01
#           Stress_EigVec1 =  0.0000000000E+00  0.0000000000E+00  1.0000000000E+00
#           Stress_EigVec2 =  0.0000000000E+00  1.0000000000E+00  0.0000000000E+00
#           Stress_EigVec3 =  1.0000000000E+00  0.0000000000E+00  0.0000000000E+00
#           -DivStress = -1.4679163307E+00  0.0000000000E+00  0.0000000000E+00
#           BPL =  1.1145104969E+00 =  2.5100684340E-01 +  8.6350365350E-01
#           GBL_I =  1.1145104969E+00
#           GBL_II =  1.1145053800E+00
#           GBL_III =  1.1145104969E+00 =  2.5100684340E-01 +  8.6350365350E-01
#           GBL_IV =  1.1145053800E+00 =  2.5100684951E-01 +  8.6349853049E-01
#           0 sample points along path from BCP to atom NNA     
#           0 sample points along path from BCP to atom C1      
#           0 sample points along IAS +EV1 path from BCP
#           0 sample points along IAS -EV1 path from BCP
#           0 sample points along IAS +EV2 path from BCP
#           0 sample points along IAS -EV2 path from BCP
#  
#  finally
        f.write('Number of NACPs  = {0: >6d}\n'.format(self.num_ncp))
        f.write('Number of NNACPs = {0: >6d}\n'.format(self.num_nna))
        f.write('Number of BCPs   = {0: >6d}\n'.format(self.num_bcp))
        f.write('Number of RCPs   = {0: >6d}\n'.format(self.num_rcp))
        f.write('Number of CCPs   = {0: >6d}\n'.format(self.num_ccp))
        thisphsum = self.num_ncp + self.num_nna - self.num_bcp + self.num_rcp - self.num_ccp
        f.write('NumNACP + NumNNACP - NumBCP + NumRCP - NumCCP = {0}\n'.format(thisphsum))
        if (thisphsum == 1):
            f.write('Poincare-Hopf Relationship is Satisfied\n')
        else:
            f.write('Poincare-Hopf Relationship is not Satisfied\n')
            
        f.write('\n Total time for electron density critical point search, analysis and connectivity = 0 sec (NProc = 1)\n\n')
        # end of routine

    def write_aimall(self,f,format):
        """
        Write MG to .mgpviz/.sumviz format file
        """
        sigdict = { 'NACP':'(3,-3)', 'NNACP':'(3,-3)', 'BCP':'(3,-1)', 'RCP':'(3,+1)', 'CCP':'(3,+3)' }
        # Header     
        f.write('{0}\n{1}\n{2}\n\n'.format('QuantVec (Version dev)',
                                            'Molecular graph in AIMAll native format',
                                            'A component of the QuantVec package ( http://www.github.com/srk/QuantVec )'))
        # for mgpviz
        if format == 'mgpviz':
            f.write('{0}\n{1}\n\n'.format(' QuantVec includes a heavily modified and extended version of the EXTREME program',
                                          ' developed by members of R.F.W. Bader s research group'))
        f.write('{0}\n{1}\n{2}\n\n{3}\n\n'.format(' Much of the Quantum Theory of Atoms in Molecules (QTAIM) is described in the book:',
                                                  '   "Atoms in Molecules - A Quantum Theory"',
                                                  '   R.F.W. Bader, Oxford University Press, Oxford, 1990',
                                                  ' For additional references see:  http://aim.tkgristmill.com/references.html' ))
        if format == 'mgpviz':
            f.write('{0} {1}\n{2}\n{3}\n\n{4}{5}\n\n'.format(' Wfx File:  ',self.wf_file,
                                                          ' ExtOut File:  /fake/route/extout.extout',
                                                          ' Mgp File:  /fake/route/mgp.mgp',
                                                          ' MgpViz File:  ',f.name ))
            f.write('{0} {1}\n{2}\n\n'.format(' Wfx Title:  ',self.title,
                                              ' Job Title:  Auto' ))
        else:  # for sumviz
            f.write('{0} {1}\n{2}\n\n{3}{4}\n\n{5}{6}\n\n'.format(' Wfx File:  ',self.wf_file,
                                                         ' Sum File:  /fake/route/mgp.mgp',
                                                         ' SumViz File:  ',f.name,
                                                         ' Wfx Title:  ',self.title))
            f.write('{0}\n\n{1}\n\n{2}\n\n'.format('Total memory allocated for AIMSum =        0.000 Megabytes',
                                                   'Atomic units (a.u.) used throughout, except where stated otherwise',
                                                    'Model:  Restricted SCF'))
            f.write('{0}\n{1}\n{2}\n{3}\n{4}\n{5}\n'.format('Restricted, closed-shell, single-determinant wavefunction.',
                                                            '  Number of electrons (from MO Occs)                   =           1.0000000000',
                                                            '  Number of Alpha electrons (from MO Occs)             =           1.0000000000',
                                                            '  Number of Beta electrons (from MO Occs)              =           1.0000000000',
                                                            '  Number of electron pairs (N*(N-1)/2)                 =           1.0000000000',
                                                            '  Number of electron pairs (from Muller 2EDM)          =           1.0000000000' ))
                                                            
        # both
        # WRITE NUCLEAR CHARGES AND CARTESIAN COORDINATES
        f.write('{0}\n\n{1}\n{2}\n{3}\n{4}\n'.format(' ',
            'Nuclear Charges and Cartesian Coordinates:',
            '-------------------------------------------------------------------------------', 
            'Atom      Charge                X                  Y                  Z', 
            '-------------------------------------------------------------------------------'))
        for i in range(0,len(self.atom_label)):
            f.write('{0:<8s}{1:6.1F}        {2:19.10E}{3:19.10E}{4:19.10E}\n'.format(self.atom_label[i].strip(' '),
                                                                                     self.atom_charge[i],
                                                                                     self.atom_x[i],
                                                                                     self.atom_y[i],
                                                                                     self.atom_z[i]))
        if format == 'mgpviz':
            f.write('\nTotal number of electron density critical points found = {0}\n\n'.format(0))    
        else:
            f.write('\n{0}\n{1}\n{2}\n\n'.format('Molecular charge q(Mol) from the wfx file:   0.0000000000E+00',
                                                 'Molecular energy E(Mol) from the wfx file:   0.0000000000E+00',
                                                 'Molecular virial ratio (-V(Mol)/T(Mol)) from the wfx file:   2.0000000000E+00'))
        
        # QTAIM property abbreviations
        abbrevs = ['Electron Density Critical Point Analysis of Molecular Structure:               ',
                   '---------------------------------------------------------------                ',
                   '  NACP = Nuclear Attractor Critical Point                                      ',
                   '  NNACP = Non-Nuclear Attractor Critical Point                                 ',
                   '  BCP = Bond Critical Point                                                    ',
                   '  RCP = Ring Critical Point                                                    ',
                   '  CCP = Cage Critical Point                                                    ',
                   '  Rho = Electron Density                                                       ',
                   '  GradRho = Gradient of Electron Density                                       ',
                   '  HessRho_EigVals = Eigenvalues of the Hessian of Rho, Ascending Order         ',
                   '  HessRho_EigVecs = Eigenvectors of the Hessian of Rho                         ',
                   '  DelSqRho = Laplacian of Rho = Trace of Hessian of Rho                        ',
                   '  Bond Ellipticity = (HessRho_EigVal(1) / HessRho_EigVal(2)) - 1               ',
                   '  V = Virial Field = Potential Energy Density = Trace of Stress Tensor         ',
                   '  G = Lagrangian Form of Kinetic Energy Density                                ',
                   '  K = Hamiltonian Form of Kinetic Energy Density                               ',
                   '  L = K - G = Lagrangian Density = (-1/4)DelSqRho                              ',
                   '  Vnuc = Electrostatic Potential from Nuclei                                   ',
                   '  Ven = Electron-nuclear attractive contribution to Virial Field V             ',
                   '  Vrep = V - Ven = Repulsive contribution to Virial Field V                    ',
                   '  DelSqV = Laplacian of V                                                      ',
                   '  DelSqVen = Laplacian of Ven                                                  ',
                   '  DelSqVrep = Laplacian of Vrep                                                ',
                   '  DelSqG = Laplacian of G                                                      ',
                   '  DelSqK = Laplacian of K                                                      ',
                   '  Stress_EigVals = Eigenvalues of Stress Tensor, Ascending Order               ',
                   '  Stress_EigVecs = Eigenvectors of Stress Tensor                               ',
                   '  -DivStress = Ehrenfest Force Density = Minus Divergence of Stress Tensor     ',
                   '  ESP = Total Electrostatic Potential                                          ',
                   '  ESPe = Electrostatic Potential from Electrons                                ',
                   '  ESPn = Electrostatic Potential from Nuclei                                   ',
                   '  BP = Bond Path                                                               ',
                   '  BPL = Bond Path Length                                                       ',
                   '  GBL = Geometric Bond Length                                                  ',
                   '  GBL_I = Distance Between Nuclear Attractors                                  ',
                   '  GBL_II = Distance Between Nuclei                                             ',
                   '  GBL_III = Sum of Distances Between BCP and Nuclear Attractors                ',
                   '  GBL_IV = Sum of Distances Between BCP and Nuclei                             ']
                   
        for i in range(0,len(abbrevs)):
            f.write('{0}\n'.format(abbrevs[i]))    
        #f.write('\n')
        # loop over CPs
        count = 0
        # sort CPs into the order: NCPs, NNACPs, BCPs, RCPs, CCPs
        # TODO
        sortedlist = []
        for cp in self.cplist:         # first NACPs
            if cp.type == 'NACP':
                sortedlist.append(cp)
        for cp in self.cplist:         # then NNACPs
            if cp.type == 'NNACP':
                sortedlist.append(cp)
        for cp in self.cplist:
            if cp.type == 'BCP':       # then BCPs
                sortedlist.append(cp)
        for cp in self.cplist:
            if cp.type == 'RCP':       # then RCPs
                sortedlist.append(cp)
        for cp in self.cplist:
            if cp.type == 'CCP':        # and then finally CCPs
                sortedlist.append(cp)
        self.cplist = sortedlist
        #   LOOP OVER CPs WRITING DATA TO FILE
        for cp in self.cplist:
            count = count+1

            if cp.connected == None or cp.connected.strip() =='':
                #print('Former name {0}'.format(cp.connected))            
                cpnamestring = 'A'+str(count)
                #print('Fixed name  {0}'.format(cp.connected))
            else:
                cpnamestring = cp.connected.replace("-"," ")
                #print('Usual  name {0}'.format(cp.connected))              
            f.write('\n')
            f.write('CP# {0:<7d}Coords = {1:22.14E}{2:22.14E}{3:22.14E}\n'.format(count,cp.pos_x,cp.pos_y,cp.pos_z))
            if cp.type == 'NACP' or cp.type == 'NNACP':
                if cp.type == 'NNACP':
                    cp.RhoNuc = 0.0
                f.write('           Type = {0} {1} {2}\n'.format(sigdict[cp.type],cp.type,cpnamestring))
                f.write('           Rho = {0:17.10E}     Rho at Nucleus = {1:17.10E}\n'.format(cp.Rho, cp.RhoNuc))
            else:
                f.write('           Type = {0} {1} {2}\n'.format(sigdict[cp.type],cp.type,cpnamestring))
                f.write('           Rho = {0:17.10E}\n'.format(cp.Rho))
            f.write('           GradRho ={0:18.10E}{1:18.10E}{2:18.10E}\n'.format(cp.GradRho[0],
                                                                                 cp.GradRho[1],
                                                                                 cp.GradRho[2]))
            f.write('           HessRho_EigVals ={0:18.10E}{1:18.10E}{2:18.10E}\n'.format(cp.HessRho_EigVals[0],
                                                                                           cp.HessRho_EigVals[1],
                                                                                           cp.HessRho_EigVals[2]))
            f.write('           HessRho_EigVec1 ={0:18.10E}{1:18.10E}{2:18.10E}\n'.format(cp.HessRho_EigVec1[0],
                                                                                           cp.HessRho_EigVec1[1],
                                                                                           cp.HessRho_EigVec1[2]))
            f.write('           HessRho_EigVec2 ={0:18.10E}{1:18.10E}{2:18.10E}\n'.format(cp.HessRho_EigVec2[0],
                                                                                           cp.HessRho_EigVec2[1],
                                                                                           cp.HessRho_EigVec2[2]))
            f.write('           HessRho_EigVec3 ={0:18.10E}{1:18.10E}{2:18.10E}\n'.format(cp.HessRho_EigVec3[0],
                                                                                           cp.HessRho_EigVec3[1],
                                                                                           cp.HessRho_EigVec3[2]))
            f.write('           DelSqRho ={0:18.10E}\n'.format(cp.DelSqRho))
            if cp.type == 'BCP':
                try:
                    pellip= abs(cp.HessRho_EigVals[0]/cp.HessRho_EigVals[1])-1.0
                except ZeroDivisionError:
                    #print('WARNING: division by zero error, setting ellipticity = 0')
                    pellip = 0.0
                f.write('           Bond Ellipticity ={0:18.10E}\n'.format(pellip))
            else:
                f.write('           Bond Ellipticity = NA\n') 
                
            f.write('           V ={0:18.10E}\n'.format(cp.V))  
            f.write('           G ={0:18.10E}\n'.format(cp.G))  
            f.write('           K ={0:18.10E}\n'.format(cp.K))  
            f.write('           L ={0:18.10E}\n'.format(cp.L))  
            f.write('           Vnuc ={0:18.10E}\n'.format(cp.Vnuc))
            f.write('           Ven ={0:18.10E}\n'.format(cp.Ven))  
            f.write('           Vrep ={0:18.10E}\n'.format(cp.Vrep))  
            f.write('           DelSqV ={0:18.10E}\n'.format(cp.DelSqV))  
            f.write('           DelSqVen ={0:18.10E}\n'.format(cp.DelSqVen)) 
            f.write('           DelSqVrep ={0:18.10E}\n'.format(cp.DelSqVrep)) 
            f.write('           DelSqG ={0:18.10E}\n'.format(cp.DelSqG))  
            f.write('           DelSqK ={0:18.10E}\n'.format(cp.DelSqK))            
            f.write('           Stress_EigVals ={0:18.10E}{1:18.10E}{2:18.10E}\n'.format(cp.Stress_EigVals[0],
                                                                                          cp.Stress_EigVals[1],
                                                                                          cp.Stress_EigVals[2]))
            f.write('           Stress_EigVec1 ={0:18.10E}{1:18.10E}{2:18.10E}\n'.format(cp.Stress_EigVec1[0],
                                                                                          cp.Stress_EigVec1[1],
                                                                                          cp.Stress_EigVec1[2]))
            f.write('           Stress_EigVec2 ={0:18.10E}{1:18.10E}{2:18.10E}\n'.format(cp.Stress_EigVec2[0],
                                                                                          cp.Stress_EigVec2[1],
                                                                                          cp.Stress_EigVec2[2]))
            f.write('           Stress_EigVec3 ={0:18.10E}{1:18.10E}{2:18.10E}\n'.format(cp.Stress_EigVec3[0],
                                                                                          cp.Stress_EigVec3[1],
                                                                                          cp.Stress_EigVec3[2]))
            f.write('           -DivStress ={0:18.10E}{1:18.10E}{2:18.10E}\n'.format(cp.MinusDivStress[0],
                                                                                      cp.MinusDivStress[1],
                                                                                      cp.MinusDivStress[2]))
            if cp.ESP == None:
                cp.ESP =0.0
                cp.ESPNuc = 0.0
                cp.ESPe = 0.0
                cp.ESPeNuc = 0.0
                cp.ESPn = 0.0
                cp.ESPnNuc = 0.0                
            if (cp.type=='NACP' or cp.type=='NNACP'):  # NCP-like CP
                if cp.ESPNuc == None:
                    cp.ESPNuc = 0.0
                if cp.ESPeNuc == None:
                    cp.ESPeNuc = 0.0
                if cp.ESPn == None:
                    cp.ESPn = 0.0
                if cp.ESPnNuc == None:
                    cp.ESPnNuc = 0.0                        
                f.write('           ESP = {0:18.10E}     ESP at Nucleus = {1:18.10E}\n'.format(cp.ESP, cp.ESPNuc))            
                f.write('           ESPe = {0:18.10E}     ESPe at Nucleus = {1:18.10E}\n'.format(cp.ESPe, cp.ESPeNuc))
                f.write('           ESPn = {0:18.10E}     ESPn at Nucleus = {1:18.10E}\n'.format(cp.ESPn, cp.ESPnNuc))
            else:
                f.write('           ESP = {0:18.10E}\n'.format(cp.ESP))            
                f.write('           ESPe = {0:18.10E}\n'.format(cp.ESPe))
                f.write('           ESPn = {0:18.10E}\n'.format(cp.ESPn))
            if cp.type == 'BCP':
                f.write('           BPL ={0:18.10E} ={1:18.10E} + {2:18.10E}\n'.format(cp.BPL,0.0,0.0))
                f.write('           GBL_I ={0:18.10E}\n'.format(cp.GBL_I)) 
                f.write('           GBL_II ={0:18.10E}\n'.format(cp.GBL_II)) 
                f.write('           GBL_III ={0:18.10E} ={1:18.10E} + {2:18.10E}\n'.format(cp.GBL_III,0.0,0.0))
                f.write('           GBL_IV ={0:18.10E} ={1:18.10E} + {2:18.10E}\n'.format(cp.GBL_IV,0.0,0.0))
                # BCP BOND PATH 1
                numpaths = len(cp.pathlist)
                #print('BCP {0} has {1} associated paths'.format(cp.connected,numpaths))
                if numpaths >= 1:
                    thisp = cp.pathlist[0]
                    lenpath = len(thisp.path_x)
                    bcpnamelist = cp.connected.split("-")
                    if len(bcpnamelist) != 2:
                        print('Error: internal BCP name is {0}'.format(bcpnamelist))
                        sys.exit()
                    end1name = bcpnamelist[0]
                    #print('WRITE: Path length = {0}'.format(lenpath))
                    f.write('{0:16d} sample points along path from BCP to atom {1}\n'.format(lenpath,end1name))                    
                    for i in range(0,lenpath):
                        f.write('          {0:19.10E}{1:19.10E}{2:19.10E}{3:19.10E}\n'.format(thisp.path_x[i], thisp.path_y[i],
                                                                                              thisp.path_z[i], thisp.path_fieldvar[i]))
                else:   # no path data                                                                                           
                    f.write('{0:16d} sample points along path from BCP to atom {1}\n'.format(1,end1name))
                    f.write('          {0:19.10E}{1:19.10E}{2:19.10E}{3:19.10E}\n'.format(cp.pos_x, cp.pos_y,cp.pos_z,cp.Rho))
                # BCP BOND PATH 2
                if numpaths >=2:
                    end2name = bcpnamelist[-1]
                    thisp = cp.pathlist[1]
                    lenpath = len(thisp.path_x)
                    f.write('{0:16d} sample points along path from BCP to atom {1}\n'.format(lenpath,end2name))                    
                    for i in range(0,lenpath):
                        f.write('          {0:19.10E}{1:19.10E}{2:19.10E}{3:19.10E}\n'.format(thisp.path_x[i], thisp.path_y[i],
                                                                                              thisp.path_z[i], thisp.path_fieldvar[i]))
                else:   # no path data                                                                                           
                    f.write('{0:16d} sample points along path from BCP to atom {1}\n'.format(1,end2name))
                    f.write('          {0:19.10E}{1:19.10E}{2:19.10E}{3:19.10E}\n'.format(cp.pos_x, cp.pos_y,cp.pos_z,cp.Rho))                    
                # BCP IAS +EV1 path
                if numpaths >= 3:
                    thisp = cp.pathlist[2]
                    lenpath = len(thisp.path_x)
                    f.write('{0:16d} sample points along IAS +EV1 path from {1}\n'.format(lenpath,'BCP'))                    
                    for i in range(0,lenpath):
                        f.write('          {0:19.10E}{1:19.10E}{2:19.10E}{3:19.10E}\n'.format(thisp.path_x[i], thisp.path_y[i],
                                                                                              thisp.path_z[i], thisp.path_fieldvar[i]))
                else:   # no path data                                                                                           
                    f.write('{0:16d} sample points along IAS +EV1 path from {1}\n'.format(1,'BCP'))
                    f.write('          {0:19.10E}{1:19.10E}{2:19.10E}{3:19.10E}\n'.format(cp.pos_x, cp.pos_y,cp.pos_z,cp.Rho))
                # BCP IAS -EV1 path
                if numpaths >= 4:
                    thisp = cp.pathlist[3]
                    lenpath = len(thisp.path_x)
                    f.write('{0:16d} sample points along IAS -EV1 path from {1}\n'.format(lenpath,'BCP'))                    
                    for i in range(0,lenpath):
                        f.write('          {0:19.10E}{1:19.10E}{2:19.10E}{3:19.10E}\n'.format(thisp.path_x[i], thisp.path_y[i],
                                                                                              thisp.path_z[i], thisp.path_fieldvar[i]))
                else:   # no path data                                                                                           
                    f.write('{0:16d} sample points along IAS -EV1 path from {1}\n'.format(1,'BCP'))
                    f.write('          {0:19.10E}{1:19.10E}{2:19.10E}{3:19.10E}\n'.format(cp.pos_x, cp.pos_y,cp.pos_z,cp.Rho))
                 # BCP IAS +EV2 path
                if numpaths >= 5:
                    thisp = cp.pathlist[4]
                    lenpath = len(thisp.path_x)
                    f.write('{0:16d} sample points along IAS +EV2 path from {1}\n'.format(lenpath,'BCP'))                    
                    for i in range(0,lenpath):
                        f.write('          {0:19.10E}{1:19.10E}{2:19.10E}{3:19.10E}\n'.format(thisp.path_x[i], thisp.path_y[i],
                                                                                              thisp.path_z[i], thisp.path_fieldvar[i]))
                else:   # no path data                                                                                           
                    f.write('{0:16d} sample points along IAS +EV2 path from {1}\n'.format(1,'BCP'))
                    f.write('          {0:19.10E}{1:19.10E}{2:19.10E}{3:19.10E}\n'.format(cp.pos_x, cp.pos_y,cp.pos_z,cp.Rho))
                # BCP IAS -EV2 path
                if numpaths >= 6:
                    thisp = cp.pathlist[5]
                    lenpath = len(thisp.path_x)
                    f.write('{0:16d} sample points along IAS -EV2 path from {1}\n'.format(lenpath,'BCP'))                    
                    for i in range(0,lenpath):
                        f.write('          {0:19.10E}{1:19.10E}{2:19.10E}{3:19.10E}\n'.format(thisp.path_x[i], thisp.path_y[i],
                                                                                              thisp.path_z[i], thisp.path_fieldvar[i]))
                else:   # no path data                                                                                           
                    f.write('{0:16d} sample points along IAS -EV2 path from {1}\n'.format(1,'BCP'))
                    f.write('          {0:19.10E}{1:19.10E}{2:19.10E}{3:19.10E}\n'.format(cp.pos_x, cp.pos_y,cp.pos_z,cp.Rho))                   
            # Finished writing path data for this CP
                
        #   CP counts
        f.write('\n')
        f.write('Number of NACPs  = {0:6d}\n'.format(self.num_ncp))
        f.write('Number of NNACPs = {0:6d}\n'.format(self.num_nna))
        f.write('Number of BCPs   = {0:6d}\n'.format(self.num_bcp))
        f.write('Number of RCPs   = {0:6d}\n'.format(self.num_rcp))
        f.write('Number of CCPs   = {0:6d}\n'.format(self.num_ccp))
        morse_sum = self.num_ncp+self.num_nna-self.num_bcp+self.num_rcp-self.num_ccp
        f.write('NumNACP + NumNNACP - NumBCP + NumRCP - NumCCP = {0:6d}\n'.format(morse_sum))
        if morse_sum==1:
            f.write('Poincare-Hopf Relationship is Satisfied\n')
        else:
            f.write('Poincare-Hopf Relationship is NOT Satisfied\n')
        
        f.write('\n{0}\n{1}\n{2}\n{3}\n{4}\n{5}\n{6}\n{7}\n{8}\n{9}\n'.format(
                'Bond Path Angles and Corresponding Geometric Bond Angles:',
                '--------------------------------------------------------',
                '  BPA     = A-B-C Bond Path Angle',
                '  GBA_I   = A-B-C Geometric Bond Angle in Terms of Nuclear Attractors',
                '  GBA_II  = A-B-C Geometric Bond Angle in Terms of Nuclei',
                '  GBA_III = A-B-C Geometric Bond Angle in Terms of A|B and C|B BCPs and Nuclear Attractor B',
                '  GBA_IV  = A-B-C Geometric Bond Angle in Terms of A|B and C|B BCPs and Nucleus B',
                '-------------------------------------------------------------------------------------------------',
                'Atom A    Atom B    Atom C        BPA          GBA_I         GBA_II       GBA_III       GBA_IV',
                '-------------------------------------------------------------------------------------------------'))
        for i in range(0,self.num_ncp+self.num_nna+self.num_bcp+self.num_rcp+self.num_ccp):
            f.write('X3        X1        X2      {0:14.8F}{1:14.8F}{2:14.8F}{3:14.8F}{4:14.8F}\n'.format(0.0,0.0,0.0,0.0,0.0))
                 
        f.write('\n Total time for electron density critical point search, \nanalysis and connectivity = 0.5 sec (NProc = 1)\n')
        if format == 'sumviz':
            f.write('\nTotal time for AIMSum = 0 sec (NProc = 1)  \n')           

    def calculate_gbl(self):
        '''
        Calculate and set the GBL (geometric bond length) parameters associated with the BCPs
        Find the BCP coordinates, the nuclear coordinates and the nuclear attractor coordinate, then calculate the distances
        '''
        for cp in self.cplist:
            if cp.type == 'BCP':
                bcp_x = cp.pos_x
                bcp_y = cp.pos_y
                bcp_z = cp.pos_z
                # first, find the names of the ends of the bond path
                endnames=cp.connected.replace("-"," ").split()
                # loop over nuclei
                atom1found = False
                atom1index = -1
                for anames in self.atom_label:
                    atom1index = atom1index + 1
                    if anames == endnames[0]:  # found the first nucleus
                        atom1found = True
                        n1x = self.atom_x[atom1index]
                        n1y = self.atom_y[atom1index]
                        n1z = self.atom_z[atom1index]
                atom2found = False
                atom2index = -1
                for anames in self.atom_label:
                    atom2index = atom2index + 1
                    if anames == endnames[1]:  # found the first nucleus
                        atom2found = True
                        n2x = self.atom_x[atom2index]
                        n2y = self.atom_y[atom2index]
                        n2z = self.atom_z[atom2index]
                if atom1found and atom2found:
                    ndx = n2x - n1x
                    ndy = n2y - n1y
                    ndz = n2z - n1z
                    cp.GBL_II = math.sqrt((ndx*ndx)+(ndy*ndy)+(ndz*ndz))

def celllabel(frac):
        """
        return the celllabel for a fractional coordinate in a crystal
        """
        label = ''
        for j in range(0,3):
            if frac[j] < 0.0:
                label = label + 'm'
            elif frac[j] >= 1.0:
                label = label + 'p'
            else:
                label = label + '0'
        #print( 'frac = {0} --> label = {1}',frac,label)
        return label

if __name__ == "__main__":
    print ("molgraph test")
    print ("molgraph version = {0}".format(__version__))
    t = Molgraph()
    t.read("test.sumviz") # example AIMAll .sum file
    print("Input file name = {0}".format(t.filename))
    print("Input file type = {0}".format(t.filetype))
    print("Code version = {0}".format(t.codeversion))
    print("Wavefunction file = {0}".format(t.wf_file))
    print("Title = {0}".format(t.title))
    print("Model = {0}".format(t.model))
    print("Atom data")
    for i in range (0,len(t.atom_label)):
        print("{0:5s} {1:17.10E} {2:17.10E} {3:17.10E} {4:17.10E}".format(t.atom_label[i],t.atom_charge[i],
              t.atom_x[i],t.atom_y[i],t.atom_z[i]))
    print("Molecular charge: {0} Molecular Energy: {1}".format(t.mol_charge,t.mol_energy))
    print("Molecular virial ratio: {0}".format(t.mol_virial_ratio))
    print("Critical points")
    for cp in t.cplist:
        print ("\n{0} : {1} {2} {3}".format(cp.type,cp.pos_x,cp.pos_y,cp.pos_z))
        print ("Rho = {0:17.10E}\nGradRho = {1:17.10E} {2:17.10E} {3:17.10E}".format(
                cp.Rho,cp.GradRho[0],cp.GradRho[1],cp.GradRho[2]))
        if cp.type == "BCP":
            print("BPL     = {0:17.10E}".format(cp.BPL))
            print("GBL_I   = {0:17.10E}".format(cp.GBL_I))
            print("GBL_II  = {0:17.10E}".format(cp.GBL_II))
            print("GBL_III = {0:17.10E}".format(cp.GBL_III))
            print("GBL_IV  = {0:17.10E}".format(cp.GBL_IV))            
            print("This BCP has {0} associated paths with lengths:".format(len(cp.pathlist)))
            for thispath in cp.pathlist:
                print(len(thispath.path_x)) 
            
    print("Critical point counts: {0} {1} {2} {3} {4}".format(
                            t.num_ncp,t.num_nna,t.num_bcp,t.num_rcp,t.num_ccp))
    
          

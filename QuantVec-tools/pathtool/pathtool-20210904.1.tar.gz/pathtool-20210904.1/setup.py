# -*- coding: utf-8 -*-
"""setup.py: setuptools control."""

import re
from setuptools import setup

version = re.search(
    '^__version__\s*=\s*"(.*)"',
    open('pathtool/pathtool.py').read(),
    re.M
    ).group(1)

setup(
    name = "pathtool",
    packages = ["pathtool"],
    entry_points = {
        "console_scripts": ['pathtool=pathtool.pathtool:main',]
        },
    version = version,
    author='Prof. Steven R. Kirk',
    author_email='stevenrkirk@gmail.com',
    description = "pathtool",
    url = 'https://www.beaconresearch.org',
    )

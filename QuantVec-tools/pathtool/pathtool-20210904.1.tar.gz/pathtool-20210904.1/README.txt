pathfilter README
=================

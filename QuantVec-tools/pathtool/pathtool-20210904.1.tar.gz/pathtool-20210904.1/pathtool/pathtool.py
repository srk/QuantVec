# -*- coding: utf-8 -*-
"""
@author: steve

pathtool
==========
Apply filtering to calculated paths made with framepath, AIMPAC2, etc.

"""
from __future__ import print_function
import math,argparse,os,sys,math
import numpy as np
import beacon_utils as bu
import molgraph as mg

__version__ = "20210904.0001"

def trianglearea(a,b,c):
    """
    Compute the area of a (possibly skinny) triangle, side lengths a,b,c, as accurately as possible
    Method from : http://http.cs.berkeley.edu/~wkahan/Triangle.pdf 
    """
    area = 0.0
    abc = [a, b, c]
    abc.sort(reverse=True)
    if (abc[2]-(abc[0]-abc[1])) < 0.0:  # not a real triangle
        area = 0.0
    else: 
        area = 0.25*math.sqrt(( (abc[0]+(abc[1]+abc[2]))*(abc[2]-(abc[0]-abc[1]))*(abc[2]+(abc[0]-abc[1]))*(abc[0]+(abc[1]-abc[2])) ))
    return(area)    
    
def striparea(t,u,v,w):
    """
    Area of a strip consisting of 2 (probably skinny) triangles
    v----w
    |\   |
    | \  |
    |  \ |
    |   \|
    t----u
    where t,u,v,w are 3-D point locations [x,y,z].
    """
    area = 0.0
    tu = math.sqrt(((u[0]-t[0])*(u[0]-t[0]))+((u[1]-t[1])*(u[1]-t[1]))+((u[2]-t[2])*(u[2]-t[2])))
    tv = math.sqrt(((v[0]-t[0])*(v[0]-t[0]))+((v[1]-t[1])*(v[1]-t[1]))+((v[2]-t[2])*(v[2]-t[2])))
    uv = math.sqrt(((v[0]-u[0])*(v[0]-u[0]))+((v[1]-u[1])*(v[1]-u[1]))+((v[2]-u[2])*(v[2]-u[2])))
    vw = math.sqrt(((w[0]-v[0])*(w[0]-v[0]))+((w[1]-v[1])*(w[1]-v[1]))+((w[2]-v[2])*(w[2]-v[2])))
    uw = math.sqrt(((w[0]-u[0])*(w[0]-u[0]))+((w[1]-u[1])*(w[1]-u[1]))+((w[2]-u[2])*(w[2]-u[2])))
    area = trianglearea(tu,uv,tv) + trianglearea(uv,vw,uw)
    return(area)
        
def pathlength(r):
    """
    Returns the cumulative length list of a path r (provided as a list of [x,y,z] triples)
    """
    length = 0.0
    c_length = []
    oldp = r[0]
    for p in r:  # accumulate path length over position list
        dx = p[0] - oldp[0]
        dy = p[1] - oldp[1]
        dz = p[2] - oldp[2]
        length = length + math.sqrt((dx*dx)+(dy*dy)+(dz*dz))
        c_length.append(length)
        oldp = p
    return(c_length)  # returns array of cumulative lengths for input path r

def isnum(s):
    """ Returns True is string is a number. """
    try:
        float(s)
        return True
    except ValueError:
        return False
        
def allinstring(p,s):
    """ Returns True if all strings in list p are present in string s """
    return all(item in s for item in p) 
    

def main():
    print('----------')
    print('pathtool')
    print('----------')
    print('pathtool version = {0}'.format(__version__))
    print('beacon_utils version = {0}'.format(bu.__version__))
    print(' ')    
    for line in bu.repheader():  # write run environment data
        print('{0}'.format(line))   
    
    #parser
    parser = argparse.ArgumentParser(description='Filter, measure, or make scaling profile of, path data',
                                     usage='pathtool --help for full usage information',
                                     formatter_class=argparse.RawTextHelpFormatter)
    parser.add_argument("mode", help="Usage mode:  filter (filter an existing path), \n"+
                                     "            measure (calculate lengths for an existing path), \n"+
                                     "            profile (calculate scaling profile for an existing path), \n"+
                                     "               area (calculate areas swept out by path vectors), \n"+
                                     "     projectprofile (project path eigenvectors onto a unique direction)\n\n",
                                choices=['filter','measure','profile','area','projectprofile'])
    parser.add_argument("infile", help="Name of input file")
    parser.add_argument("outfile", help="Name of output file (filtered path, profile, or path lengths data)")
    filtergroup = parser.add_argument_group('Filter mode','Options')
    filtergroup.add_argument("--keepfrac", help="Filter mode only: Minimum fraction of path to keep (0.0-1.0)\n"+
                                           "(0.0=just BCP, 1.0=whole path segment from BCP to NCP, default=1.0)",default="1.0")
    filtergroup.add_argument("--detectstyle",help="Filter mode only: When to trigger the filter \n"+
                                         "Options: lock (targeting),\n"+
                                         "         fraction (filter at specified fraction: default)",
                                          default="fraction")
    filtergroup.add_argument("--fixstyle",help="Filter mode only: Filter action \n"+
                                          "Options: interpolate (preserve number of steps: default)",
                                          default="interpolate")
    profilegroup = parser.add_argument_group('Profile mode','Options')                                       
    profilegroup.add_argument("--reverse",help="profile/projectprofile modes only: Reverse the order of the data points\n"+
                                               "for profile output and multiply first coordinate by -1",
                                      action='store_true')
    profilegroup.add_argument("--projectref",help="projectprofile modes only: projection reference direction.\n"+
                                                  "NB: MUST BE SPACE-SEPARATED STRING SURROUNDED WITH QUOTES!\n"+
                                                  "e.g. \"0.1 0.2 0.3\"\n"+
                                                  "3 atom names \"A1 A2 A3\"       (projection vector is (A1A2)x(A1A3) )\n"+
                                                  "3 numbers \"n1 n2 n3\"          (projection vector [n1,n2,n3]) or \n"+
                                                  "6 numbers \"n1 n2 n3 n4 n5 n6\" (projection vector [n1,n2,n3]->[n4,n5,n6])\n"+
                                                  "\"bcp n1 n2 n3\"                (projection vector BCP->[n1,n2,n3]) or \n"+
                                                  "\"bcp rcp A1 A2 A3 ...\"        (projection vector BCP-> RCP for the ring containing A1,A2,A3 ...)\n\n",
                                             default='')
    profilegroup.add_argument("--mg",help="projectprofile modes only: molecular graph file (e.g. .sumviz file).\n"+
                                          "This is MANDATORY if --projectref contains 3 atom names OR the string 'rcp'.",
                                     default=None)                                             
                              
    args = parser.parse_args()
    mode = args.mode
    reverse = args.reverse
    pl = args.projectref.strip().split()
    mgfname = args.mg
    #print ('projreflist={0}'.format(projreflist))
    #print (projreflist)
    #sys.exit()
 
    print ('Running in {0} mode'.format(mode))
    infile = os.path.abspath(args.infile)
    outfile = os.path.abspath(args.outfile)
    if mode == 'filter':  # this is a filter action   
        detectstyle = str(args.detectstyle)
        try:
            keepfrac = float(args.keepfrac)
        except Exception:
            print('Specified minimum fraction not recognised as a number - stopping')
            sys.exit()
        if (keepfrac < 0.0) or (keepfrac > 1.0):
            print('Specified fraction {0} is not in the range 0.0 - 1.0 - stopping'.format(triggerfrac))
            sys.exit()
        fixstyle = str(args.fixstyle)
   
    # check input file exists
    iswindows=False
    if sys.platform.startswith('win'):   # double up directory slashes if running on Windows
        iswindows=True
    if iswindows:   # double up directory slashes if running on Windows
        fname = infile.replace('\\','\\\\')
        foutname = outfile.replace('\\','\\\\')
    else:
        fname = infile
        foutname = outfile
    if (not os.path.isfile(fname)):  # check that input file exists
        print('Input file {0} does not exist!'.format(fname))
        sys.exit()
    else:
        print('Input file: {0}'.format(fname))
    # check that output file does NOT EXIST
    if (os.path.isfile(foutname)):  # check that output file does NOT exist
        print("")
        print('ERROR: Selected output file {0} already exists!'.format(foutname))
        print('Change the name or remove the existing file.')
        sys.exit()
    else:
        print('Output file: {0}'.format(foutname))    
        
    header = []
    linecount = 0
    # read header lines
    with open(fname,'r') as fin, open(foutname,'w') as fout:
        line = fin.readline()
        #print('line={0}'.format(line))
        linecount = linecount+1
        while not line == "" :  # loop to end of file
            # loop over path segments in file, expecting a header first
            print("")
            print('Reading header')
            header = []  # create a blank header
            while True:
                try:
                    matchchars =  (' ','-','0','1','2','3','4','5','6','7','8','9')
                    if not (line.startswith(matchchars)):  # If no initial space, minus or digit, use this line to assemble a header
                        print('{0}'.format(line.strip()))
                        header.append(line)
                    else:  # line starting with a space, data lines must be starting
                       break
                    line = fin.readline()
                    linecount = linecount+1
                except IndexError:
                    print('Error in input file on line {0}'.format(linecount))
                    sys.exit()
            # echo found header lines
            numlines = int(header[-1].split()[5])  # extract number of data lines from last header line
            print('Input file section has {0} data lines'.format(numlines))

            bp = []
            ev1 = []
            ev2 = []
            rpev1=[]
            rmev1=[]
            rpev2=[]
            rmev2=[]
            # READ DATA LINES into bp,ev1,ev2
            for i in range(0,numlines):  # loop over data lines
                tokens = line.split()
                point_r = [ float(i) for i in tokens[0:3] ]
                point_scaledev1 = [ float(i) for i in tokens[3:6] ]
                point_scaledev2 = [ float(i) for i in tokens[6:] ]
                bp.append(point_r)  # store point to current bond path
                ev1.append(point_scaledev1)  # store this scaled ev1 vector
                ev2.append(point_scaledev2)  # store this scaled ev2 vector
                rpev1.append( [ point_r[i]+point_scaledev1[i] for i in range(0,3) ])
                rmev1.append( [ point_r[i]-point_scaledev1[i] for i in range(0,3) ])
                rpev2.append( [ point_r[i]+point_scaledev2[i] for i in range(0,3) ])
                rmev2.append( [ point_r[i]-point_scaledev2[i] for i in range(0,3) ])                
                line = fin.readline()
                linecount= linecount+1
            
            # FINISHED READING DATA LINES
            # get initial p,q,r points, path endpoint and BPL
            cpathlen = pathlength(bp)
            bpl = cpathlen[-1]
            # get r+e1,r-e1,r+e2,r-e2 lengths

            old_r = bp[0]
            end_r = bp[-1]
            old_p = [ bp[0][0]+ev1[0][0], bp[0][1]+ev1[0][1], bp[0][2]+ev1[0][2] ]
            old_q = [ bp[0][0]+ev2[0][0], bp[0][1]+ev2[0][1], bp[0][2]+ev2[0][2] ]
            old_dp = [0.0,0.0,0.0]
            old_dq = [0.0,0.0,0.0]
            old_p_angle = 0.0
            old_q_angle = 0.0
            startarbvec = [ev1[0][0], ev1[0][1], ev1[0][2] ]
            scalefaclist = []
            scalefaclist.append(math.sqrt(bu.dotprod(startarbvec,startarbvec)))

            # initialize detector flag to false
            detect = 0
            
            # LOOP OVER PATH POINTS
            pathdist = 0.0

            for i in range(1,numlines):
                # construct current p,q,r points
                r = bp[i]                                                           # i'th point on bond path segment
                arbvec = [ev1[i][0], ev1[i][1], ev1[i][2] ]                         # arbitrary vector for scale factor extraction
                scalefac = math.sqrt(bu.dotprod(arbvec,arbvec))                     # calculated scale factor
                scalefaclist.append(scalefac)                                       # store the scaling factor for this point
                p = [ bp[i][0]+ev1[i][0], bp[i][1]+ev1[i][1], bp[i][2]+ev1[i][2] ]  # i'th point on p-path
                q = [ bp[i][0]+ev2[i][0], bp[i][1]+ev2[i][1], bp[i][2]+ev2[i][2] ]  # i'th point on q-path
                p_end = [p[0]-end_r[0],p[1]-end_r[1],p[2]-end_r[2]]                 # target vector from p_i to end of bond path
                q_end = [q[0]-end_r[0],q[1]-end_r[1],q[2]-end_r[2]]                 # target vector from q_i to end of bond path
                dr = [ r[0]-old_r[0], r[1]-old_r[1], r[2]-old_r[2] ]                # r-path step vector
                dp = [ p[0]-old_p[0], p[1]-old_p[1], p[2]-old_p[2] ]                # p-path step vector
                dq = [ q[0]-old_q[0], q[1]-old_q[1], q[2]-old_q[2] ]                # q-path step vector
                p_angle = 0.0  # not needed
                q_angle = 0.0
                #triggerlen = cpathlen[i]
                pathfrac = cpathlen[i]/bpl
                #triggerfrac = (bpl-triggerlen)/bpl
                if i > 1:  # don't calculate q_angle for second point, only subsequent ones
                    q_angle = bu.vecangle(dq,q_end)  # angle between q-step and q_target
                
                if mode == 'filter':                
                    # CHECK IF FIX TRIGGERED
                    if (detect == 0):  # fix not triggered yet, check if any trigger conditions met
                        if (detectstyle == 'lock') and i>2:             # CHECK TARGET LOCK TRIGGER
                            if (q_angle > old_q_angle) and pathfrac >= keepfrac:  # q-path is deviating more from the straight line between here and the target, fix is triggered
                                detect = 1
                                ifreeze = i
                                ev1freeze = [ ev1[i][0], ev1[i][1], ev1[i][2] ] 
                                ev2freeze = [ ev2[i][0], ev2[i][1], ev2[i][2] ]
                                triggerfrac = pathfrac
                                endlength = bpl*(1.0 - triggerfrac)
                        elif (detectstyle == 'fraction'):        # CHECK FRACTION TRIGGER
                            if (pathfrac >= keepfrac):  # requested path fraction exceeded, fix is triggered
                                detect = 1
                                ifreeze = i
                                ev1freeze = [ ev1[i][0], ev1[i][1], ev1[i][2] ]
                                ev2freeze = [ ev2[i][0], ev2[i][1], ev2[i][2] ]
                                triggerfrac = pathfrac
                                endlength = bpl*(1.0 - triggerfrac)
                    # FIX ONCE TRIGGERED
                    if (detect > 0):  # IF fix has been triggered, all remaining ev1 and ev2 given interpolated values
                        fixfrac = (bpl-cpathlen[i])/endlength
                        ev1[i] = [ fixfrac*ev1freeze[0], fixfrac*ev1freeze[1], fixfrac*ev1freeze[2] ]  # shrink ev1
                        ev2[i] = [ fixfrac*ev2freeze[0], fixfrac*ev2freeze[1], fixfrac*ev2freeze[2] ]  # shrink ev2
                        
                old_p = p    # save old p_i
                old_q = q    # save old q_i
                old_r = r    # save old r_i
                old_dp = dp  # save old p-step
                old_dq = dq  # save old q-step
                old_p_angle = p_angle  # save old p-angle
                old_q_angle = q_angle  # save old q-angle
            
            # SCALAR PROFILE OUTPUT
            if mode == 'profile':  # just print the header + profile to the output file
                print ('--> Writing path scaling profile to {0}'.format(foutname))
                print ('Reverse data flag is: {0}'.format(reverse))                
                for i in range(0,len(header)):
                    lineout = header[i].strip()
                    if i == 0:
                        if (reverse):
                            fout.write(lineout+' (REVERSED scaling profile)\n')
                        else:
                            fout.write(lineout+' (scaling profile)\n')
                    else:
                        fout.write(lineout+'\n')
                fout.write('==== Scaling factor profile (BPL={0})\n'.format(bpl))
                fout.write('Distance along path      Scaling factor\n')
                if not len(cpathlen) == len(scalefaclist):
                    print('Error: cpathlen and scalefaclist have unequal lengths {0} =/= {1}'.format(len(cpathlen),len(scalefaclist)))
                    sys.exit()
                formatstring = '  {0:>16.9E}     {1:>16.9E}'
                if (reverse):  # reverse order
                    for i in range(len(cpathlen)-1,-1,-1):
                        print(i)
                        lineout = formatstring.format(-1.0*cpathlen[i],scalefaclist[i])
                        fout.write(lineout+'\n')
                else:
                    for i in range(0,len(cpathlen)):
                        lineout = formatstring.format(cpathlen[i],scalefaclist[i])
                        fout.write(lineout+'\n')
                        
            # PROJECTION PROFILE OUTPUT
            if mode == 'projectprofile':  # just print the header + profile to the output file
                # Get projection direction
                print('**** Projection profile ****')
                pd = [0.0, 0.0, 0.0]
                
                # Check for the various cases
                rcpused = any('rcp' in item for item in pl)
                if ( len(pl) == 3) and not rcpused:
                    # CASE 1: n1 n2 n3   pure numerical projection direction vector
                    if (isnum(pl[0]) and isnum(pl[1]) and isnum(pl[2])):
                        pd = [ float(pl[0]), float(pl[1]), float(pl[2]) ]
                        print ('Projection vector is {0}'.format(pd))
                    else: # either atom names or nonsense
                        print('Expected 3 numbers, instead got: {0} {1} {2}'.format(pl[0],pl[1],pl[2]))
                        print('Checking for atom names in input, and if you specified a molecular graph')
                        if (mgfname == None):
                            print('You also need to specify a molecular graph file name with the --mg option')
                            sys.exit()
                        else:
                            thismg = mg.Molgraph()
                            thismg.read(mgfname)
                            # Check if the 3 items specified match known atom labels
                            mglabels=thismg.atom_label
                            strmglabels = ' '+' '.join(mglabels)+' '
                            print('Checking for these atom names: {0}'.format(' '.join(pl)))
                            print('in this list:{0}'.format(strmglabels))                            
                            if not ((' '+pl[0]+' ' in strmglabels) and
                                    (' '+pl[1]+' ' in strmglabels) and
                                    (' '+pl[2]+' ' in strmglabels)):
                                print('Failed to recognise 3 numbers or 3 atom names in projectref list - exiting')
                                sys.exit()
                            # Found 3 recognised atom names
                            print('Recognised the atom names A1 = {0} A2 = {1} A3 = {2}'.format(pl[0],pl[1],pl[2]))
                            print('Constructing the projection vector as cross-product A1A2 x A1A3')
                            indexa1 = mglabels.index(pl[0])  # index of atom A1
                            indexa2 = mglabels.index(pl[1])  # index of atom A2
                            indexa3 = mglabels.index(pl[2])  # index of atom A3
                            pv1 = [thismg.atom_x[indexa2]-thismg.atom_x[indexa1],
                                   thismg.atom_y[indexa2]-thismg.atom_y[indexa1],
                                   thismg.atom_z[indexa2]-thismg.atom_z[indexa1] ]
                            print('Vector 1 {0}->{1}: [{2}, {3}, {4}]'.format(pl[0],pl[1],pv1[0],pv1[1],pv1[2]))       
                            pv2 = [thismg.atom_x[indexa3]-thismg.atom_x[indexa1],
                                   thismg.atom_y[indexa3]-thismg.atom_y[indexa1],
                                   thismg.atom_z[indexa3]-thismg.atom_z[indexa1] ]
                            print('Vector 2 {0}->{1}: [{2}, {3}, {4}]'.format(pl[0],pl[2],pv2[0],pv2[1],pv2[2]))
                            pd = bu.vectorproduct(pv1,pv2)
                            print('Crossproduct: [{0}, {1}, {2}]'.format(pd[0],pd[1],pd[2]))
                            pd = bu.unitvec(pd)
                            print('         Projection vector is {0}'.format(pd))
                                                  
                elif (len(pl) == 6) and not rcpused:
                    # CASE 2: n1 n2 n3 n4 n5 n6  numerical direction vector from (n1,n2,n3) -> (n4,n,n6)
                    if (isnum(pl[0]) and isnum(pl[1]) and isnum(pl[2]) and isnum(pl[3]) and isnum(pl[4]) and isnum(pl[5])):
                        pd[0] = float(pl[3])-float(pl[0])
                        pd[1] = float(pl[4])-float(pl[1])
                        pd[2] = float(pl[5])-float(pl[2])
                        print('Start of projection vector is [{0},{1},{2}]'.format(pl[0],pl[1],pl[2]))
                        print('  End of projection vector is [{0},{1},{2}]'.format(pl[3],pl[4],pl[5]))
                        print('         Projection vector is {0}'.format(pd))
                    else:
                        print('Expected 6 numbers, instead got: {0} {1} {2} {3} {4} {5}'.format(pl[0],pl[1],pl[2],pl[3],pl[4],pl[5]))
                        sys.exit()
                
                elif (len(pl) == 4 and not rcpused):
                    # CASE 3: bcp n1 n2 n3 numerical direction vector from bcp ->(n1,n2,n3)
                    if ( pl[0].lower() == 'bcp' and isnum(pl[1]) and isnum(pl[2]) and isnum(pl[3])):
                        print('Start of projection vector is at the start of a path, i.e. at a BCP')
                        pbcp = [ bp[0][0], bp[0][1], bp[0][2] ]
                        print('Start of projection vector is [{0},{1},{2}]'.format(pbcp[0],pbcp[1],pbcp[2]))
                        print('  End of projection vector is [{0},{1},{2}]'.format(pl[1],pl[2],pl[3]))
                        pd[0] = float(pl[1])-float(pbcp[0])
                        pd[1] = float(pl[2])-float(pbcp[1])
                        pd[2] = float(pl[3])-float(pbcp[2])
                        print('         Projection vector is {0}'.format(pd))
                    else:
                        print('Expected \'bcp\' and 3 numbers, instead got: {0} {1} {2} {3}'.format(pl[0],pl[1],pl[2],pl[3]))
                        sys.exit()
                        
                elif (rcpused):
                    print('Using an RCP to define a projection vector')
                    # CASE 4: bcp rcp  :projection vector from bcp -> rcp
                    if ( pl[0].lower() == 'bcp' and rcpused ):
                        print('Start of projection vector is at the start of a path, i.e. at a BCP')
                        pbcp = [ bp[0][0], bp[0][1], bp[0][2] ]
                        # check for presence of MG file
                        if (mgfname == None):
                            print('You also need to specify a molecular graph file name with the --mg option')
                            sys.exit()
                        else:
                            thismg = mg.Molgraph()
                            thismg.read(mgfname)
                            found = False
                            # now find the ring point coordinates
                            rcplist = []
                            for cp in thismg.cplist:
                                if cp.type == 'RCP':
                                    found = True
                                    rcplist.append(cp)
                                    rcpname = cp.connected
                                    print('RCP {0} found in {1}'.format(rcpname,mgfname))
                                    #prcp = [ cp.pos_x, cp.pos_y, cp.pos_z ]
                                    #break
                            if not found:
                                print('Cannot find an RCP in {0}!'.format(mgfname))
                                sys.exit()
                            if len(rcplist) == 1:  # only one RCP found, shortcut case
                                print('Found only one RCP - using this one')
                                prcp = [ rcplist[0].pos_x, rcplist[0].pos_y, rcplist[0].pos_z ]
                            else: # complex case
                                rcplist2 = []
                                atlist = pl[2:]
                                for thisrcp in rcplist:
                                    if allinstring(atlist,thisrcp.connected):
                                        rcplist2.append(thisrcp)
                                        print('RCP name {0} contains ring atoms \"{1}\"'.format(thisrcp.connected,' '.join(atlist)))
                                if (not len(rcplist2) == 1):
                                    print('WARNING: multiple RCPs can be specified using these atoms - add another atom to the list to uniquely specify the RCP!')
                                    sys.exit()
                                 # now we have found the unique RCP of interest
                                prcp = [ rcplist2[0].pos_x, rcplist2[0].pos_y, rcplist2[0].pos_z ]
                        print('Start of projection vector is [{0},{1},{2}]'.format(pbcp[0],pbcp[1],pbcp[2]))
                        print('  End of projection vector is [{0},{1},{2}]'.format(prcp[0],prcp[1],prcp[2]))
                        pd[0] = float(prcp[0])-float(pbcp[0])
                        pd[1] = float(prcp[1])-float(pbcp[1])
                        pd[2] = float(prcp[2])-float(pbcp[2])                        
                        print('         Projection vector is {0}'.format(pd))
                    else:
                        print('Expected \"bcp rcp\", instead got: {0} {1} '.format(pl[0],pl[1]))
                        sys.exit()                

                else: # FALLTHROUGH CASE 
                    print('Not enough information to specify projection direction! Check your --projectref parameter.')
                    sys.exit()
                
                # got projection direction vector
                d = math.sqrt((pd[0]*pd[0])+(pd[1]*pd[1])+(pd[2]*pd[2]))
                upd = [ i/d for i in pd ]
                inline = '{0} {1} {2}'.format(pd[0],pd[1],pd[2])
                print('    Unit projection vector is {0}'.format(upd))
                print('CHECK: magnitude of projection vector = {0}'.format(d))
                print ('--> Writing path projection profile to {0}'.format(foutname)) 
                for i in range(0,len(header)):
                    lineout = header[i].strip()
                    if i == 0:
                        if (reverse):
                            fout.write(lineout+' (REVERSED projection profile with {0})\n'.format(inline))
                        else:
                            fout.write(lineout+' (projection profile with {0})\n'.format(inline))
                    else:
                        fout.write(lineout+'\n')
                fout.write('==== Projection profile (BPL={0})\n'.format(bpl))
                fout.write('Distance along path    E1 proj.cosine c1        1-(c1*c1)      E2 proj.cosine c2        1-(c2*c2)\n')
                if not len(cpathlen) == len(ev1):
                    print('Error: cpathlen and ev1 have unequal lengths {0} =/= {1}'.format(len(cpathlen),len(ev1)))
                    sys.exit()
                formatstring = '  {0:>16.9E}     {1:>16.9E}     {2:>16.9E}     {3:>16.9E}     {4:>16.9E}  {5}'
                
                if (reverse):  # reverse order
                    for i in range(len(cpathlen)-1,-1,-1): 
                        e1 = [ ev1[i][0], ev1[i][1], ev1[i][2] ]
                        e2 = [ ev2[i][0], ev2[i][1], ev2[i][2] ]
                        d = math.sqrt((e1[0]*e1[0])+(e1[1]*e1[1])+(e1[2]*e1[2]))
                        d2 = math.sqrt((e2[0]*e2[0])+(e2[1]*e2[1])+(e2[2]*e2[2]))
                        # make sure the eigenvectors are normalized
                        try:            
                            e1 = [ i/d for i in e1 ]  # renormalize
                        except ZeroDivisionError:
                            print("ERROR: check for zero-magnitude scaled e1 eigenvectors in the path file!")
                            sys.exit()
                        try:    
                            e2 = [ i/d2 for i in e2 ] # renormalize
                        except ZeroDivisionError:
                            print("ERROR: check for zero-magnitude scaled e2 eigenvectors in the path file!")
                            sys.exit()
                        d = math.sqrt((e1[0]*e1[0])+(e1[1]*e1[1])+(e1[2]*e1[2]))
                        d2 = math.sqrt((e2[0]*e2[0])+(e2[1]*e2[1])+(e2[2]*e2[2]))    
                        #e1 = [ i/d for i in e1 ]
                        #e2 = [ i/d2 for i in e2 ]
                        c = bu.dotprod(upd,e1)
                        c2 = bu.dotprod(upd,e2)
                        #print(' {0:>16.9E}  {1:>16.9E}  {2:>16.9E} {3:>16.9E}  {4:>16.9E}'.format(-1.0*cpathlen[i],e1[0],e1[1],e1[2], c))
                        if i==0:
                            lineout = formatstring.format(-1.0*cpathlen[i],c,1.0-(c*c),c2,1.0-(c2*c2),'# <-- BCP')
                        else:
                            lineout = formatstring.format(-1.0*cpathlen[i],c,1.0-(c*c),c2,1.0-(c2*c2),'')
                        fout.write(lineout+'\n')
                else:
                    for i in range(0,len(cpathlen)):
                        e1 = [ ev1[i][0], ev1[i][1], ev1[i][2] ]
                        e2 = [ ev2[i][0], ev2[i][1], ev2[i][2] ]
                        d = math.sqrt((e1[0]*e1[0])+(e1[1]*e1[1])+(e1[2]*e1[2]))
                        d2 = math.sqrt((e2[0]*e2[0])+(e2[1]*e2[1])+(e2[2]*e2[2]))
                        # make sure eigenvectors are normalized
                        try:            
                            e1 = [ i/d for i in e1 ]  # renormalize
                        except ZeroDivisionError:
                            print("ERROR: check for zero-magnitude scaled e1 eigenvectors in the path file!")
                            sys.exit()
                        try:    
                            e2 = [ i/d2 for i in e2 ] # renormalize
                        except ZeroDivisionError:
                            print("ERROR: check for zero-magnitude scaled e2 eigenvectors in the path file!")
                            sys.exit()
                        d = math.sqrt((e1[0]*e1[0])+(e1[1]*e1[1])+(e1[2]*e1[2]))
                        d2 = math.sqrt((e2[0]*e2[0])+(e2[1]*e2[1])+(e2[2]*e2[2]))    
                        # check for zero eigenvectors
                        if ((abs(1.0-d) > 0.001) or (abs(1.0-d2) > 0.001)):
                            # If it happens at the endpoint, extrapolate
                            if i == len(cpathlen):
                                print("INFO: Path endpoint eigenvectors extrapolated !")
                                e1 = [ ev1[i-1][0], ev1[i-1][1], ev1[i-1][2] ]
                                e2 = [ ev2[i-1][0], ev2[i-1][1], ev2[i-1][2] ]
                                d = math.sqrt((e1[0]*e1[0])+(e1[1]*e1[1])+(e1[2]*e1[2]))
                                d2 = math.sqrt((e2[0]*e2[0])+(e2[1]*e2[1])+(e2[2]*e2[2]))
                            else: # interpolate
                                print("INFO: Path point eigenvectors extrapolated at point number {0}!".format(i))
                                e1 = [ (ev1[i-1][0]+ev1[i+1][0])/2.0, (ev1[i-1][1]+ev1[i+1][1])/2.0, (ev1[i-1][2]+ev1[i+1][2])/2.0 ]
                                e2 = [ (ev2[i-1][0]+ev2[i+1][0])/2.0, (ev2[i-1][1]+ev2[i+1][1])/2.0, (ev2[i-1][2]+ev2[i+1][2])/2.0 ]
                                d = math.sqrt((e1[0]*e1[0])+(e1[1]*e1[1])+(e1[2]*e1[2]))
                                d2 = math.sqrt((e2[0]*e2[0])+(e2[1]*e2[1])+(e2[2]*e2[2]))
                        
                        #try:            
                        #    e1 = [ i/d for i in e1 ]  # renormalize
                        #except ZeroDivisionError:
                        #    print("ERROR: check for zero-magnitude e1 eigenvalues in the path file!")
                        #    sys.exit()
                        #try:    
                        #    e2 = [ i/d2 for i in e2 ] # renormalize
                        #except ZeroDivisionError:
                        #    print("ERROR: check for zero-magnitude e2 eigenvalues in the path file!")
                        #    sys.exit()
                            
                        c = bu.dotprod(upd,e1)
                        c2 = bu.dotprod(upd,e2)
                        #print(' {0:>16.9E}  {1:>16.9E}  {2:>16.9E} {3:>16.9E}  {4:>16.9E}'.format(-1.0*cpathlen[i],e1[0],e1[1],e1[2], c))
                        if i==0:
                            lineout = formatstring.format(cpathlen[i],c,1.0-(c*c),c2,1.0-(c2*c2),'# <-- BCP')
                        else:
                            lineout = formatstring.format(cpathlen[i],c,1.0-(c*c),c2,1.0-(c2*c2),'')
                        fout.write(lineout+'\n')                        
                    
            elif mode == 'filter':            
                # finished filtering, write the output header and filtered paths
                print('--> Path filtered using {0}, step {1} / {2}, fraction={3}'.format(detectstyle,ifreeze,fixstyle,triggerfrac))
                for i in range(0,len(header)):
                    lineout = header[i].strip()
                    if i == 0:
                        fout.write(lineout+' (filtered using '+detectstyle+', step '+str(ifreeze)+'/'+fixstyle+',fraction={0}'.format(triggerfrac)+' )\n')
                    else:
                        fout.write(lineout+'\n')
                formatstring = '{0:>16.9E} {1:>16.9E} {2:>16.9E} {3:>16.9E} {4:>16.9E} {5:>16.9E} {6:>16.9E} {7:>16.9E} {8:>16.9E}'
                for i in range(0,numlines):
                    lineout = formatstring.format(bp[i][0],bp[i][1],bp[i][2],ev1[i][0],ev1[i][1],ev1[i][2],ev2[i][0],ev2[i][1],ev2[i][2])
                    fout.write(lineout+'\n')
                    
            elif mode == 'measure':
                print ('--> Writing path lengths to {0}'.format(foutname))
                
                for i in range(0,len(header)):
                    lineout = header[i].strip()
                    if i == 0:
                        fout.write(lineout+' (path lengths)\n')
                    else:
                        fout.write(lineout+'\n')
                fout.write('=========== Path lengths  ==============\n')
                rpev1len = pathlength(rpev1)
                rmev1len = pathlength(rmev1)
                rpev2len = pathlength(rpev2)
                rmev2len = pathlength(rmev2)
                fout.write('NOTE! Make sure you understand EXACTLY which of these lengths corresponds to p,p\',q,q\'\n')
                fout.write('Length r = BPL = {0}'.format(bpl)+'\n')
                fout.write('Length    r+e1 = {0}'.format(rpev1len[-1])+'\n')
                fout.write('Length    r-e1 = {0}'.format(rmev1len[-1])+'\n')
                fout.write('Length    r+e2 = {0}'.format(rpev2len[-1])+'\n')
                fout.write('Length    r-e2 = {0}'.format(rmev2len[-1])+'\n')                

            elif mode == 'area':
                # calculate sums of strip areas
                areap = 0.0
                areaq = 0.0
                areapp = 0.0
                areaqq = 0.0
                for i in range(0,numlines-1):
                    t = bp[i]
                    u = bp[i+1]
                    thisev1 = ev1[i]
                    thisev2 = ev2[i]
                    nextev1 = ev1[i+1]
                    nextev2 = ev2[i+1]
                    v1  = [ t[0]+thisev1[0], t[1]+thisev1[1], t[2]+thisev1[2] ]
                    w1  = [ u[0]+nextev1[0], u[1]+nextev1[1], u[2]+nextev1[2] ]
                    areap = areap + striparea(t,u,v1,w1)
                    v2  = [ t[0]-thisev1[0], t[1]-thisev1[1], t[2]-thisev1[2] ]
                    w2  = [ u[0]-nextev1[0], u[1]-nextev1[1], u[2]-nextev1[2] ] 
                    areapp = areapp + striparea(t,u,v2,w2)                    
                    v3  = [ t[0]+thisev2[0], t[1]+thisev2[1], t[2]+thisev2[2] ]
                    w3  = [ u[0]+nextev2[0], u[1]+nextev2[1], u[2]+nextev2[2] ] 
                    areaq = areaq + striparea(t,u,v3,w3) 
                    v4  = [ t[0]-thisev2[0], t[1]-thisev2[1], t[2]-thisev2[2] ]
                    w4  = [ u[0]-nextev2[0], u[1]-nextev2[1], u[2]-nextev2[2] ] 
                    areaqq = areaqq + striparea(t,u,v4,w4)
                print ('--> Writing path areas to {0}'.format(foutname)) 
                for i in range(0,len(header)):
                    lineout = header[i].strip()
                    if i == 0:
                        fout.write(lineout+' (areas)\n')
                    else:
                        fout.write(lineout+'\n')
                fout.write('NOTE! Make sure you understand EXACTLY which of these areas corresponds to sweeping p,p\',q,q\'\n')
                fout.write('Area swept by r+e1 = {0}'.format(areap)+'\n')
                fout.write('Area swept by r-e1 = {0}'.format(areapp)+'\n')
                fout.write('Area swept by r+e2 = {0}'.format(areaq)+'\n')
                fout.write('Area swept by r-e2 = {0}'.format(areaqq)+'\n') 
                       
if __name__ == '__main__':
    main()
    
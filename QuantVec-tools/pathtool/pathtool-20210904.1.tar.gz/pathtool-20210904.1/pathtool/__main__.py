# -*- coding: utf-8 -*-


"""pathtool.__main__: executed when pathtool directory is called as script."""


from .pathtool import main
main()
# -*- coding: utf-8 -*-
"""setup.py: setuptools control."""

import re
from setuptools import setup

version = re.search(
    '^__version__\s*=\s*"(.*)"',
    open('qtrama3/qtrama3.py').read(),
    re.M
    ).group(1)

setup(
    name = "qtrama3",
    packages = ["qtrama3"],
    entry_points = {
        "console_scripts": ['qtrama3=qtrama3.qtrama3:main',]
        },
    version = version,
    author='Prof. Steven R. Kirk',
    author_email='stevenrkirk@gmail.com',
    description = "qtrama3",
    url = 'https://www.beaconresearch.org',
    install_requires=['numpy','matplotlib'],
    )

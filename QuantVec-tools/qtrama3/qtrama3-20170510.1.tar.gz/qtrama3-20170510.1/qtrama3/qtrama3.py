# -*- coding: utf-8 -*-
"""
Ramachandran angle explorer for molecular graph data. Uses the 'molgraph'
module to create molecular graph objects and critical point objects from an
any file supported by molgraph (currently AIMAll .sum/.sumviz)

Usage: python qtrama3.py [inputfile.sumviz | inputfile.sum ] {options} 

@author: steve
"""

from __future__ import print_function  # compatibility with Python 2.7

import sys
import math
import argparse
import csv
from itertools import cycle
import matplotlib as mpl
import matplotlib.pyplot as plt
import matplotlib.path as mpath
import matplotlib.patches as mpatches
import molgraph as mg      # import the Molgraph functions and classes
                           #(molgraph.py must be in same directory)
import beacon_utils as bu  # beacon_utils for dihedral angle calculator
                           #(beacon_utils.py must be in same directory)
                           
__version__ = "20170510.0001"

class AnnoteFinder(object):
    """callback for matplotlib to display an annotation when points are
    clicked on.  The point which is closest to the click and within
    xtol and ytol is identified.

    Register this function like this:

    scatter(xdata, ydata)
    af = AnnoteFinder(xdata, ydata, annotes)
    connect('button_press_event', af)
    """

    def __init__(self, xdata, ydata, annotes, ax=None, xtol=None, ytol=None):
        self.data = list(zip(xdata, ydata, annotes))
        if xtol is None:
            xtol = ((max(xdata) - min(xdata))/float(len(xdata)))/2
        if ytol is None:
            ytol = ((max(ydata) - min(ydata))/float(len(ydata)))/2
        self.xtol = xtol
        self.ytol = ytol
        if ax is None:
            self.ax = plt.gca()
        else:
            self.ax = ax
        self.drawnAnnotations = {}
        self.links = []

    def distance(self, x1, x2, y1, y2):
        """
        return the distance between two points
        """
        return(math.sqrt((x1 - x2)**2 + (y1 - y2)**2))

    def __call__(self, event):

        if event.inaxes:

            clickX = event.xdata
            clickY = event.ydata
            if (self.ax is None) or (self.ax is event.inaxes):
                annotes = []
                # print(event.xdata, event.ydata)
                for x, y, a in self.data:
                    # print(x, y, a)
                    if ((clickX-self.xtol < x < clickX+self.xtol) and
                            (clickY-self.ytol < y < clickY+self.ytol)):
                        annotes.append(
                            (self.distance(x, clickX, y, clickY), x, y, a))
                if annotes:
                    annotes.sort()
                    distance, x, y, annote = annotes[0]
                    self.drawAnnote(event.inaxes, x, y, annote)
                    for l in self.links:
                        l.drawSpecificAnnote(annote)

    def drawAnnote(self, ax, x, y, annote):
        """
        Draw the annotation on the plot
        """
        if (x, y) in self.drawnAnnotations:
            markers = self.drawnAnnotations[(x, y)]
            for m in markers:
                m.set_visible(not m.get_visible())
            self.ax.figure.canvas.draw_idle()
        else:
            t = ax.text(x, y, "%s" % (''),)
            #t = ax.text(x, y, "%s" % (annote),)            text markers disabled
            m = ax.scatter([x], [y], marker='d', c='r', zorder=100)
            self.drawnAnnotations[(x, y)] = (t, m)
            self.ax.figure.canvas.draw_idle()

    def drawSpecificAnnote(self, annote):
        annotesToDraw = [(x, y, a) for x, y, a in self.data if a == annote]
        for x, y, a in annotesToDraw:
            self.drawAnnote(self.ax, x, y, a)

def linkAnnotationFinders(afs):
  for i in range(len(afs)):
    allButSelfAfs = afs[:i]+afs[i+1:]
    afs[i].links.extend(allButSelfAfs)            
   
# check beacon_utils version
assert float(bu.__version__) >= 20160525.0001

def sortlabel(instring):
    """
    Generate a CP label with atom order sorted alphabetically separated by '-'
    """
    tokens=instring.split("-")
    tokens.sort()
    return("-".join(tokens))
# end of the sorting function

def csvdump(csvfile,header,data):
    """
    Dump da CSV file to specified filename 'csvfile'
    Start file with list of header line strings
    Continue with data lines (list of lists)
    Close file after creation
    """
    if not csvfile == 'none':
        with open(csvfile,'w',newline='') as csvf:
            csvwriter = csv.writer(csvf, dialect='excel',delimiter=',',quotechar='"', quoting=csv.QUOTE_NONNUMERIC)
            for line in header:
                csvwriter.writerow(['#'+line])
            for row in data:               
                csvwriter.writerow(row)
        
def main()
    # main code
    # argument parser
    parser = argparse.ArgumentParser(description="Ramachandran and QTAIM angle explorer for molecular graph data\n"+
                                                 "==============================================================")
    parser.add_argument("inputfile", help="AIMAll .sumviz or .sum file to examine")
    parser.add_argument("--mode", help="Analysis mode: backbone or H-bonds", 
                                    choices=['backbone', 'hbonds'],
                                    default='backbone')
    parser.add_argument("--vector", help="AIM vector to project against", 
                                    choices=['e1', 'e2','e1s','e2s','ef'],
                                    default='e2')
    parser.add_argument("--scalar", help="AIM scalar used to colour points",
                                    choices=['none','rho_ellip','rho_stiff','stress_ellip','stress_stiff'],
                                    default='none')
    parser.add_argument("--scalarcp", help="Bond critical point that is the source of the QTAIM scalar used to colour points",
                                      choices=['1','2'],default='1')
    parser.add_argument("--pointlabels", help="Information used to label clicked points",
                                      choices=['none','phi','psi'],default='none')
    parser.add_argument("--csv", help="Output .CSV format file name",
                                      default='none')
    parser.add_argument("--mixed", help="Whether or not to plot mixed Ramanchandran/QTAIM plots",
                                      choices=['no','yes'],default='no')
    args = parser.parse_args()
    projvec=args.vector
    scalar=args.scalar
    scalarcp=args.scalarcp
    plabels=args.pointlabels
    mode=args.mode
    csvfile = args.csv.strip()
    if csvfile == 'none':
        dumpcsv = False
    else:
        dumpcsv = True
    mixed=args.mixed
    
    
    # Print information header
    print("Ramachandran-QTAIM explorer for molecular graph data")
    print("====================================================")
    print('Version: {0}'.format(__version__))
    print("Using molgraph version {0}".format(mg.__version__))
    print("Using beacon_utils version {0}".format(bu.__version__))
    print('Program mode: {0}'.format(mode))
    print('Matplotlib configuration: {0}'.format(mpl.matplotlib_fname()))
    print('Projecting against: {0}'.format(projvec))
    if (dumpcsv):
        print('Dumping calculated data into CSV file: {0}'.format(csvfile))
    
    # set some Matplotlib defaults
    mpl.rcParams['legend.fontsize'] = 10 # change font sizes etc. here
    mpl.rcParams['lines.linestyle'] = ''
    mpl.rcParams['lines.marker'] = '.'
    scal_cmap = 'viridis'                # standard colour map
    
    # Import the molecular graph
    infile = args.inputfile   # The input file name is given on the command line
    t = mg.Molgraph()         # Create a new empty Molgraph object called 't'
    t.read(infile)            # Fill the empty Molgraph object with data from the file
    
    # sort all CP labels
    for cp in t.cplist:
        cp.connected = sortlabel(cp.connected)
    print('Sorted CP labels')
    
    # Select operating mode here: backbone or hbonds
    if (mode =='hbonds'):       # H-bond analysis
        # STEPS
        # 1. Find all closed-shell BCPs, divide them into 2 classes: weak and strong based on sign of H
        # 2. For each closed-shell BCP:
        #         Find the shortest (by BPL) other BCPs that connect up with the atoms of this BCP
        #         Put atoms in the following sequence:
        #         A1, A2, A3, A4 == (A,B,C,D)
        #         where A2-A3 is the closed-shell bond
        #               A1-A2 is the shorter of the two neighbouring other bonds
        #               A3-A4 is the longer of the two neighbouring other bonds
        #         Calculate angles (A1,A2,A3 normal, A2-A3 AIM vector)
        #                          (A2,A3,A4 normal, A2-A3 AIM vector)
        #         Plot this angle pair on a figure with appropriate legend and symbol type
        #
        bcplist = [cp for cp in t.cplist if cp.type =="BCP" ]
        closed_bcplist = [cp for cp in bcplist if cp.DelSqRho > 0.0]
        shared_bcplist = [cp for cp in bcplist if cp.DelSqRho < 0.0]
        # closed-shell bonds involving an H atom
        # shared-shell bonds involving an H atom
        h_closed_bcplist = [cp for cp in closed_bcplist if "H" in cp.connected]
        h_shared_bcplist = [cp for cp in shared_bcplist if "H" in cp.connected]
        h_closed_long_bcplist = [cp for cp in h_closed_bcplist if cp.K > 0.0]  # H < 0.0
        #
        types = []
        if not scalar == 'none':
            print('Symbol colours will be based on values of {0}'.format(scalar))
            
        # make a list of BCP types (e.g. H-N), then remove all repetitions
        for cp in closed_bcplist:
            names = cp.connected.split('-')
            btype = '-'.join([names[0].strip('0123456789'),names[1].strip('0123456789')])
            types.append(btype)
        dtypes = dict(zip(types, [0]*len(types)))
        for x in types:
            dtypes[x] +=1
        typelists = dict(zip(list(dtypes.keys()), [list([]) for _ in range(len(dtypes))]))
        
        # Count how many times each BCP type occurs
        for cp in closed_bcplist:
            names = cp.connected.split('-')
            btype = '-'.join([names[0].strip('0123456789'),names[1].strip('0123456789')])
            currentlist = typelists[btype]
            currentlist.append(cp.connected)
            typelists[btype] = currentlist
        print('Summary of numbers of closed-shell bonds found')
        for key in typelists.keys():
            print('{0} {1}'.format(key, len(typelists[key])))
        #
        quadlist = []
    # now ask the user what bond types to examine
        mytypes = input('Enter names of desired bond types (e.g. H-N), separated by spaces: ').strip()
        mytypesnames = mytypes.split()
    # Now loop over different types selected by the user
        for mytype in mytypesnames:
            thisbondlist = typelists[mytype]
            #print(mytype+' '+','.join(thisbondlist))
            # construct the data sets for the two variants of this type of bond 
            for thisbond in thisbondlist:
                thiscp = [cp for cp in closed_bcplist if cp.connected == thisbond ][0]
                if thiscp.K > 0.0: # negative H, 'strong'
                    cpstyle = 'strong'
                else:              # positive H, 'weak'
                    cpstyle = 'weak'
                print('{0} {1}'.format(thisbond,cpstyle ))
                bcpatomnames = thisbond.split('-')
                atomname1 = bcpatomnames[0]
                atomname2 = bcpatomnames[1]
                # NEW: 20161220 - select from full neighbour BCP lists, not just shared BCPs
                # replace 'nextshared' with 'next'
    #            nextshared1 = [cp for cp in shared_bcplist if 
    #                           (cp.connected.startswith(atomname1+'-') or cp.connected.endswith(atomname1)) ]
    #            nextshared2 = [cp for cp in shared_bcplist if 
    #                           (cp.connected.startswith(atomname2+'-') or cp.connected.endswith(atomname2)) ]
    #            print('{0} has {1} shared-shell BCPs'.format(atomname1,len(nextshared1)))
    #            print('{0} has {1} shared-shell BCPs'.format(atomname2,len(nextshared2)))
                next1 = [cp for cp in bcplist if (cp.connected != thisbond and
                               (cp.connected.startswith(atomname1+'-') or cp.connected.endswith(atomname1))) ]
                next2 = [cp for cp in bcplist if (cp.connected != thisbond and
                               (cp.connected.startswith(atomname2+'-') or cp.connected.endswith(atomname2))) ]
                print('{0} has {1} other BCPs'.format(atomname1,len(next1)))
                print('{0} has {1} other BCPs'.format(atomname2,len(next2)))     # find the shortest other bond to atom 1 and atom 2
                minbpl1 = 10000.0
                minbpl2 = 10000.0
                for cp1 in next1:     # find shortest BPL to atom 1
                    #print('1. Looking at {0}'.format(cp1.connected))
                    if (cp1.BPL < minbpl1):
                        minbpl1 = cp1.BPL
                        endcp1 = cp1
                for cp2 in next2:     # find shortest BPL to atom 2
                    #print('2. Looking at {0}'.format(cp2.connected))
                    if (cp2.BPL < minbpl2):
                        minbpl2 = cp2.BPL
                        endcp2 = cp2
                if (minbpl1 < minbpl2):     # if necessary, reorder to put shortest bond first
                    cpa = cp1
                    cpb = cp2
                else:
                    cpa = cp2
                    cpb = cp1
                #print('Using {0}({1}),{2},{3}({4})'.format(cpa.connected,cpa.BPL,thisbond,cpb.connected,cpb.BPL))
                cpa_list = cpa.connected.split('-')
                cpb_list = cpb.connected.split('-')
                atom1name = [ name for name in cpa_list if not name in bcpatomnames ][0]
                atom2name = [ name for name in cpa_list if name in bcpatomnames ][0]
                atom3name = [ name for name in bcpatomnames if not name == atom2name ][0]
                atom4name = [ name for name in cpb_list if not name == atom3name ][0]
                #print('Start of chain - {0},{1},{2},{3}'.format(atom1name,atom2name,atom3name,atom4name))
                thisquad = [ mytype,cpstyle,atom1name,atom2name,atom3name,atom4name,thiscp] 
                quadlist.append(thisquad)
               
        # the quad list is now built, now perform the list of calculations
        print('=======')
        print('Summary')
        print('=======')
        pointlist = []
        csvdata = []
        for quad in quadlist:
            print('{0} {1} {2} {3} {4} {5}'.format(quad[0],quad[1],quad[2],quad[3],quad[4],quad[5]),quad[6].connected) 
            selected_bcp = quad[6]  # retrieve the CP data object
            atom1name = quad[2]
            atom2name = quad[3]
            atom3name = quad[4]
            atom4name = quad[5]        
            # get atom coordinates and unit plane normal vectors
            a1 = [t.atom_x[t.atom_label.index(atom1name)],t.atom_y[t.atom_label.index(atom1name)],t.atom_z[t.atom_label.index(atom1name)]]
            a2 = [t.atom_x[t.atom_label.index(atom2name)],t.atom_y[t.atom_label.index(atom2name)],t.atom_z[t.atom_label.index(atom2name)]]
            a3 = [t.atom_x[t.atom_label.index(atom3name)],t.atom_y[t.atom_label.index(atom3name)],t.atom_z[t.atom_label.index(atom3name)]]
            a4 = [t.atom_x[t.atom_label.index(atom4name)],t.atom_y[t.atom_label.index(atom4name)],t.atom_z[t.atom_label.index(atom4name)]]
            n1 = bu.normal_vec([a1,a2,a3])
            n2 = bu.normal_vec([a2,a3,a4])
            #   get QT vector from appropriate BCP
            if (projvec == 'e2'):     # e2 of the Hessian of Rho
                qtvec = selected_bcp.HessRho_EigVec2
            elif (projvec == 'e1'):   # e1 of the Hessian of Rho
                qtvec = selected_bcp.HessRho_EigVec1
            elif (projvec == 'e2s'):  # e2 of the Stress Tensor
                qtvec = selected_bcp.Stress_EigVec2
            elif (projvec == 'e1s'):  # e1 of the Stress Tensor
                qtvec = selected_bcp.Stress_EigVec1
            elif (projvec == 'ef'):  # minus divergence of the Stress Tensor
                qtvec = selected_bcp.MinusDivStress
            else:
                print('Unrecognised QT projection vector given on command line: {0}'.format(projvec))
                sys.exit()
                
            # If needed, get QT scalar from appropriate BCP
            if (scalar == 'none'):
                qtscal = 0.0
            elif (scalar == 'rho_ellip'):     # standard Rho ellipticity
                qtscal = selected_bcp.Ellipticity
            elif (scalar == 'rho_stiff'):     # lambda2/lambda3
                qtscal = math.fabs(selected_bcp.HessRho_EigVals[1]/selected_bcp.HessRho_EigVals[2])
            elif (scalar == 'stress_ellip'):  # lambda1/lambda2 - 1
                qtscal = math.fabs(selected_bcp.Stress_EigVals[0]/selected_bcp.Stress_EigVals[1]) - 1.0  
            elif (scalar == 'stress_stiff'):  # lambda1/lambda3
                qtscal = math.fabs(selected_bcp.Stress_EigVals[0]/selected_bcp.Stress_EigVals[2])
                           
            # Compute angle according to earlier beta-angle definition
            angle = math.acos(bu.dotprod(n1,qtvec))*180.0/math.pi
            if angle >= 90:
                angle = angle - 180.0
            angle2 = math.acos(bu.dotprod(n2,qtvec))*180.0/math.pi
            if angle2 >= 90:
                angle2 = angle2 - 180.0
            # add graph point to list
            # data: type, cpstyle, atomXname (X=1,2,3,4), quadnames, angle1, angle2
            #       Optionally, also QT scalar
            quadname = '-'.join([atom1name,atom2name,atom3name,atom4name])
            if (scalar == 'none'):
                pointlist.append([quad[0],quad[1],quadname,angle,angle2])
            else:
                pointlist.append([quad[0],quad[1],quadname,angle,angle2,qtscal])
            # add to data list for csv dump if selected
            if (dumpcsv):
                csvdata.append([angle,angle2,quad[0], 
                                selected_bcp.connected,quadname,selected_bcp.pos_x,selected_bcp.pos_y,selected_bcp.pos_z,
                                selected_bcp.Rho,selected_bcp.DelSqRho,selected_bcp.Ellipticity,
                                selected_bcp.HessRho_EigVals[0],selected_bcp.HessRho_EigVals[1],selected_bcp.HessRho_EigVals[2],
                                selected_bcp.Stress_EigVals[0],selected_bcp.Stress_EigVals[1],selected_bcp.Stress_EigVals[2],
                                selected_bcp.V,selected_bcp.G,selected_bcp.K,selected_bcp.L,qtscal])
                                
        # dump full csvdata list to csv file if needed
        if (dumpcsv):
            csvdump(csvfile,
                    ['From qtrama3.py','Mode = '+mode,infile,'angle1 angle2 type label quad_names x y z rho lap ellip rho_eigvals stress_eigvals V G K L '+scalar],
                    csvdata)
                    
        # plotting the picture
        print('Plotting ..')
        fig = plt.figure(tight_layout=True)
        ax = fig.gca()             # get current axes
        ax.set_xlim(-90.0,90.0)    # set x-limits
        ax.set_ylim(-90.0,90.0)    # set y-limits
        ax.set_aspect('equal')     # set aspect ratio
        ax.set_xticks([-90.0,-60.0,-30.0,0.0,30.0,60.0,90.0])  # x-ticks
        ax.set_yticks([-90.0,-60.0,-30.0,0.0,30.0,60.0,90.0])  # y-ticks
        ax.grid(which='major',axis='both')    # grid lines
        color_map = plt.get_cmap(scal_cmap)   # colour map for scalars if needed
        # customize the labels: use LaTeX notation
        if (projvec == 'e2'):
            vxlabel = r'$\mathbf{\beta_{\phi}}}$'
            vylabel = r'$\mathbf{\beta_{\psi}}}$'
        elif (projvec == 'e1'):
            vxlabel = r'$\mathbf{\beta^{*}_{\phi}}$'
            vylabel = r'$\mathbf{\beta^{*}_{\psi}}$'
        elif (projvec == 'e1s'):
            vxlabel = r'$\mathbf{\beta_{\sigma\phi}}$'
            vylabel = r'$\mathbf{\beta_{\sigma\psi}}$'
        elif (projvec == 'e2s'):
            vxlabel = r'$\mathbf{\beta^{*}_{\sigma\phi}}$'
            vylabel = r'$\mathbf{\beta^{*}_{\sigma\psi}}$'
        elif (projvec == 'ef'):
            vxlabel=r'$\mathbf{EF_{\phi}$'  # not sure what this label should look like
            vylabel=r'$\mathbf{EF_{\psi}$'  # not sure what this label should look like
        ax.set_xlabel(vxlabel+' (degrees)')           # set x-labels
        ax.set_ylabel(vylabel+' (degrees)')           # set y-labels
        #ax.set_title('Quad QTAIM '+vlabel+'angles ($\phi,\psi$)')  # set plot title
        # Plot all datasets
        
        if not scalar=='none':  # if we are colouring points by QT scalars
            # find min and max of QT scalar values for colour bar
            allqtscal =  [ point[5] for point in pointlist]
            cbarmin = min(allqtscal)
            cbarmax = max(allqtscal)
            markercycle = cycle(['o','s','v','^','*','d','p','h','8','<','>'])  # set rotating marker sequence
            if (scalar == 'rho_ellip'):
                barlabel = 'Ellipticity'
            elif (scalar == 'rho_stiff'):
                barlabel = 'Stiffness'
            elif (scalar == 'stress_ellip'):
                barlabel = 'Stress tensor ellipticity'
            elif (scalar == 'stress_stiff'):
                barlabel = 'Stress tensor stiffness'
            
        for mytype in mytypesnames:
           # clear the lists of data points
           x1 = []
           y1 = []
           x2 = []
           y2 = []
           c2 = []
           if not scalar == 'none':   # prepare lists for the QT values
               c1 = []
               c2 = []
           names = mytype.split("-")
           # make two lists of points, one for 'strong' interactions (x1,y1) and one for 'weak' interactions (x2,y2)
           # then plot them separately on our graph
           for point in pointlist:
               if point[0] == mytype and point[1] == 'strong':
                   x1.append(point[3])
                   y1.append(point[4])
                   if not scalar == 'none':  # QT variable
                       c1.append(point[5])
               elif point[0] == mytype and point[1] == 'weak':
                   x2.append(point[3])
                   y2.append(point[4])
                   if not scalar == 'none':  # QT variable
                       c2.append(point[5])
           print('Type: {0}: {1} strong and {2} weak'.format(mytype,len(x1),len(x2)))
           if not scalar == 'none':  # colour scatter plots by QT variable, use different markers, change 's' to change marker size
               if len(x1) > 0:
                   sc = ax.scatter(x1,y1,c=c1,cmap=color_map,vmin=cbarmin, vmax=cbarmax,
                                   label=names[0]+'--'+names[-1],s=50,marker=next(markercycle))
               if len(x2) > 0:
                   sc = ax.scatter(x2,y2,c=c2,cmap=color_map,vmin=cbarmin, vmax=cbarmax,
                                   label=names[0]+'---'+names[-1],s=50,marker=next(markercycle))
           else:                    # colour scatter plot by bond type, different markers for 'weak'/'strong'
               if len(x1) > 0:
                   ax.scatter(x1,y1,marker='o',label=names[0]+'--'+names[-1],s=50,alpha=0.2)
               if len(x2) > 0:
                   ax.scatter(x2,y2,marker='s',label=names[0]+'---'+names[-1],s=50,alpha=0.2)
    # plot the colourbar if needed
        if not scalar == 'none':
            cbar=plt.colorbar(sc)
            cbar.set_label('{0}'.format(barlabel))
        ann2=[]
        af2 =  AnnoteFinder(x2,y2, ann2, ax=ax)  # annotation handler
        fig.canvas.mpl_connect('button_press_event', af2)
        plt.legend(loc=0,scatterpoints=1) # place legend automatically, loc=0 best, loc=1,2,3,4,5,6,7,8,9 or 10 fixed positions
        plt.show()        # draw graph
       
            
    # -----------------
    # BACKBONE ANALYSIS
    # -----------------
    elif (mode == 'backbone'): 
        # set C=O and backbone C-N cutoff distances (bohr)
        max_co = 2.50  # bohr
        max_cn = 2.7   # bohr
        # make the C-X and N-X BCP lists
        # list comprehensions - all Carbon and Nitrogen BCPs
        all_bcplist = [cp for cp in t.cplist if cp.type == "BCP" ]                        # all BCPs
        cs_bcplist = [cp for cp in all_bcplist if cp.DelSqRho < 0.0]                      # shared-shell BCPs
        allc_bcplist = [cp for cp in all_bcplist if cp.connected.find('C') > -1 ]         # All bonds to carbon
        c_bcplist = [cp for cp in cs_bcplist if cp.connected.find('C') > -1 ]             # shared-shell bonds to carbon
        n_bcplist = [cp for cp in cs_bcplist if cp.connected.find('N') > -1 ]             # shared-shell bonds to nitrogen
        cc_bcplist = [cp for cp in cs_bcplist if cp.connected.count('C') == 2 ]           # shared-shell C-C bonds
        allco_bcplist = [cp for cp in allc_bcplist if cp.connected.find('O') > -1 ]       # All C-O bonds 
        allshortco_bcplist = [cp for cp in allco_bcplist if cp.BPL < max_co ]             # All short (< 2.5 bohr) C-O bonds
        co_bcplist = [cp for cp in c_bcplist if cp.connected.find('O') > -1 ]             # shared-shell C-O bonds
        cn_bcplist = [cp for cp in c_bcplist if cp.connected.find('N') > -1 ]             # shared-shell C-N bonds
        
        # Get unique names of all carbon atoms in C-C bonds
        temp_cc_names = []
        for cp in cc_bcplist:
            names = cp.connected.split('-')
            temp_cc_names.append(names[0])
            temp_cc_names.append(names[1])
        cc_c_names = list(set(temp_cc_names))  # eliminate duplicates
        
        # Print counts of detected BCP types
        print('{0} BCPs'.format(len(all_bcplist)))
        print('{0} shared-shell BCPs'.format(len(cs_bcplist)))
        print('{0} shared-shell BCPs C-X'.format(len(c_bcplist)))
        print('{0} shared-shell BCPs N-X'.format(len(n_bcplist)))
        print('{0} shared-shell BCPs C-C'.format(len(cc_bcplist)))
        print('{0} shared-shell BCPs C-N'.format(len(cn_bcplist)))
        print('{0} BCPs C-O'.format(len(allco_bcplist)))
        print('{0} BCPs C-O (BPL < {1} bohr)'.format(len(allshortco_bcplist),max_co))
        print('{0} shared-shell BCPs C-O'.format(len(co_bcplist)))
        
        # unique names of all carbons involved in just 1 C-O bond that isn't too long
        #temp_co_c_names = [cp.connected.split('-')[0] for cp in co_bcplist]   # this assumes C=O all shared shell
        temp_co_c_names = [cp.connected.split('-')[0] for cp in allshortco_bcplist] # this makes no C=O assumptions except length
        co_c_names = [name for name in temp_co_c_names if temp_co_c_names.count(name) == 1]
                     
        # unique names of all carbons involved in just 1 C-N bond
        temp_cn_c_names = [cp.connected.split('-')[0] for cp in cn_bcplist]
        cn_c_names = [name for name in temp_cn_c_names if temp_cn_c_names.count(name) == 1]
        
        # print numbers of (CO) carbon atoms
        print('Found {0} unique C atoms involved in one C-O bond'.format(len(co_c_names)))
        
        # Filter 1: (CO)N
        con_c_names = [cname for cname in co_c_names if cname in cn_c_names]
        print('of which {0} are also bonded to an N atom'.format(len(con_c_names)))
        
        # Filter 2: C(CO)N
        conc_c_names = [cname for cname in con_c_names if cname in cc_c_names]
        print('of which {0} are also bonded to another C atom'.format(len(conc_c_names)))
        
        # check we have least one CO carbon that passes Filter 2
        if len(conc_c_names) == 0:  # no linkages found
            print('No peptide linkages found! Please check your input file')
            sys.exit()
        
        # Now build a list of peptide linkages
        peplinklist = []
        
        # Loop over qualifying (CO) carbons
        for conc_atom in conc_c_names:   # conc_atom is the (CO) carbon
            # Find the attached alpha carbon
            c_alpha = ""
            for cc_bcp in cc_bcplist:
                names = cc_bcp.connected.split("-")
                if (conc_atom == names[0]): 
                    c_alpha = names[1]
                    break
                elif (conc_atom == names[1]):
                    c_alpha = names[0]
                    break
            # Find the N in the peptide bond
            peptide_n = ""
            for cn_bcp in cn_bcplist:
                names = cn_bcp.connected.split("-")
                if names[0] == conc_atom:
                    peptide_n = names[1]
                    break
            link=[c_alpha,conc_atom,peptide_n]
            # now append the peptide linkage to a list        
            peplinklist.append(link)
        
        # show the detected linkages
        print('\nDiscovered {0} candidate peptide linkages'.format(len(peplinklist)))
        for link in peplinklist:
            print("-".join(link))
        
        # screen all linkages
        print('Screening all candidate linkages based on bond lengths')
        print('Max C-O bond path length (bohr) = {0}'.format(max_co))
        print('Max C-N bond path length (bohr) = {0}'.format(max_cn))
        screened_linklist = []
        for link in peplinklist:
            c_alpha = link[0]
            conc_atom = link[1]
            peptide_n = link[2]
            cn_list = [cp for cp in cn_bcplist if (cp.connected == conc_atom+'-'+peptide_n and cp.BPL < max_cn) ]
            co_list = [cp for cp in allco_bcplist if (cp.connected.startswith(conc_atom+'-') and cp.BPL < max_co) ]
            if len(co_list) > 1:
                print('Found a candidate backbone C-O carbon with > 2 bonds to O with BPL < {0}!'.format(max_co)) 
                for cp in co_list:
                    print('{0} BPL={1} bohr'.format(cp.connected,cp.BPL))
                print('Exiting')
                sys.exit()
            if len(cn_list) > 1:
                print('Found a candidate backbone C-N carbon with > 2 bonds to N with BPL < {0}!'.format(max_cn)) 
                for cp in cn_list:
                    print('{0} BPL={1} bohr'.format(cp.connected,cp.BPL))
                print('Exiting')
                sys.exit()    
            # test C-O and (CO)N length
            if ((co_list[0].BPL < max_co) and (cn_list[0].BPL < max_cn)):  # bond are short enough -> a real link
                screened_linklist.append(link)
                
        peplinklist = screened_linklist  # REPLACE original peplinklist with the screened version
        print('\n{0} candidate peptide linkages satisfy bond length criteria'.format(len(peplinklist)))
        for link in peplinklist:
            print("-".join(link))
        
        # If there is no C-N bond from the Calpha of a link to the N of any other link,
        # the link must be at the start of a chain - add it to a list of chains
        chainlist = []
        cn_connected = [cp.connected for cp in cn_bcplist]    # the names of every C-N  BCP
        terminal_n_list = [link[-1] for link in peplinklist]  # the end N atom of every link
        for link in peplinklist:   # Scan through links
            findlink_ca = link[0]      # get the alpha carbon name
            found_cn = False                # Set flag: Is there a C-N BCP joining this link and another link?
            for term_n in terminal_n_list:  # If Calpha of this link connects to N of another link, set flag
                if (findlink_ca+"-"+term_n in cn_connected):
                    #print('Found a connection {0}-{1}'.format(findlink_ca,term_n)) 
                    found_cn = True
                    break
            if not (found_cn):  # if flag is not set, this looks like the start of a chain
                print('Found a candidate start of a chain: {0}'.format('-'.join(link)))
                chainlist.append(link)       
        
        # Discover chains       
        newchainlist = []
        print('')
        for chain in chainlist:  # loop over available candidate chains
            print('Examining chain starting at link {0}'.format('-'.join(chain)))
            newchain = chain
            endchain = False
            num_passes = 0
            #
            chain_n = newchain[-1]  # end of the first chain link
            print('link terminal N = {0}'.format(chain_n))        
            while not endchain:
                endchain = True
                for link in peplinklist: 
                    # Can we find a link_ca - chain_n bond?
                    calpha = link[0]
                    if (calpha+"-"+chain_n in cn_connected):
                        print('Found {0}-{1}'.format(calpha,chain_n))
                        newchain[:] = newchain + link
                        chain_n = newchain[-1]
                        #print(newchain)
                        endchain = False
                        break
        
                print('Endchain is now {0}'.format(endchain))
                num_passes +=1
                print('Pass {0} complete'.format(num_passes))        
            newchainlist.append(newchain)
        
        # show and check detected chains
        for chain in newchainlist:
            print('{0}-link chain at {1}'.format(len(chain)//3,chain))
            for i in range (1,len(chain)):
                bondname = '-'.join(sorted([chain[i-1],chain[i]]))
                bond_exist = False
                for bcp in cs_bcplist:
                    if (bcp.connected == bondname):
                        bond_exist = True
                        break
                if not (bond_exist):
                    print('Designated chain bond {0} does not exist!'.format(bondname))
                    sys.exit()
        print('Checked bonding network in chains')
        print(' ')
        print('--- checking for N-termini')
        
        # Prepend the N atom and one of its H-atoms if the first Ca is next to an N-terminus NH_2 group 
        for chain in newchainlist:
            begin_c = chain[0]
            for cn_bcp in cn_bcplist:
                names = cn_bcp.connected.split('-')
                if begin_c in names:
                    print('Found an N atom at the beginning of the chain in bond {0}'.format(names))
                    for test_n in names:
                        if test_n.startswith('N'):
                        # get connection list of this N atom
                            n_bonds_list = [bcp.connected for bcp in n_bcplist if bcp.connected.startswith(test_n+'-') or bcp.connected.endswith(test_n)] 
                            n_bonds_list.remove(begin_c+'-'+test_n)
                            found_h = False
                            for possible_h in n_bonds_list:
                                if possible_h.startswith('H'):
                                    selected_h = possible_h.split('-')[0]
                                    found_h = True
                                    break
                            if (found_h):  # we found a terminal NH2 group, so we add the H and the N to the start of the chain
                                chain[:] = [selected_h,test_n]+chain
                                print('Prepended chain: {0}'.format(chain))
                                break
                    break
                break
            
        print('--- checking for C-termini')
        # Append a carboxyl carbon and an oxygen atom if the end of the chain is a C-terminus
        for chain in newchainlist:
            end_n = chain[-1]
            end_c = chain[-2]   
            newc_bcpnames = [cp.connected for cp in cn_bcplist if cp.connected.endswith(end_n) and not cn_bcp.connected.startswith(end_c)]
            #print('newc_bcpnames = {0}'.format(newc_bcpnames))
            newc_bcpnames.remove(end_c+'-'+end_n)
            if (len(newc_bcpnames) > 1):
                print('Found more than one candidate for end alpha-carbon')
                print(newc_bcpnames)
                sys.exit()
            if len(newc_bcpnames) > 0:
                end_alpha = newc_bcpnames[0].split('-')[0]
                print('End c-alpha is {0}'.format(end_alpha))
                chain[:] = chain+[end_alpha]
                print('Appended chain: {0}'.format(chain))
                next_cc_bcpnames = [cp.connected for cp in cc_bcplist if (cp.connected.startswith(end_alpha+"-") or cp.connected.endswith(end_alpha))]
                print('end C-alpha has the following C-C bonds: {0}'.format(next_cc_bcpnames))
                found_final_co = False
                final_co = ''
                for cpname in next_cc_bcpnames:
                    for i in cpname.split("-"):
                        if (not i == end_alpha):
                            if (i in co_c_names):
                                final_co = i
                                found_final_co = True
                if (found_final_co):
                    print('found a final C=O: {0}'.format(final_co))
                    print(final_co in co_c_names)
                    
        
        print('Finished checking for termini\n')
        
        # now work through the chains generating Ramachandran dihedral angles
        # phi = dihedral (C=O,N,Calpha,C=O), or dihedral (H,N,Calpha,C=O) at N-terminus
        # psi = dihedral (N,Calpha,C=O,N)
        rama_data = []
        print('== Generating Ramachandran angles')
        for chain in newchainlist:
            length = len(chain)
            print('Chain length = {0}'.format(length))
            if length < 5:
                print('Chain too short: skipping')
                break
            i = 0
            phi = []
            psi = []
            omega = []
            ann = []    
            while (i+4 < length):
                atomlist = chain[i:i+4]
                anglecode = atomlist[0][0]+atomlist[1][0]+atomlist[2][0]+atomlist[3][0]
                anglestring = '-'.join(atomlist)
                quartet = []
                for atomname in atomlist:
                    s = t.atom_label.index(atomname)
                    quartet.append([t.atom_x[s],t.atom_y[s],t.atom_z[s]])
                angle = bu.dihedral(quartet[0],quartet[1],quartet[2],quartet[3])*180.0/math.pi
                #print(angle)
                point_ann = ''
                if (anglecode[1:] == 'NCC'):  # this is a phi dihedral
                    phi.append(angle)
                elif (anglecode == 'NCCN'):   # this is a psi dihedral
                    psi.append(angle)    
                    if (plabels =='psiatoms'):
                        pass
                    ann.append(anglestring)
                elif (anglecode == 'CCNC'):   # this is an omega dihedral
                    omega.append(angle)
                else:                         # found unexpected atom pattern
                    print('Unrecognised atom pattern found: {0}'.format(anglecode))
                    print('found in atom sequence {0}'.format(anglestring))
                    sys.exit()
                i += 1
            # check on data points
            lenphi = len(phi)
            lenpsi = len(psi)
            lenomega = len(omega)
            print('Computed {0} phi values, {1} psi values, {2} omega values'.format(lenphi,lenpsi,lenomega))
            if (lenphi > lenpsi):
                phi[:] = phi[:lenpsi]
            elif (lenpsi > lenphi):
                psi[:] = psi[:lenphi]
            lenphi = len(phi)
            lenpsi = len(psi)
            #
            # print table of Ramachandran angles
            print('== Ramachandran angles ==')
            print('phi, psi, angle string')
            for i in range(0,lenphi):
                print('{0} {1} {2}'.format(phi[i],psi[i],ann[i]))
            print('=========================')            
            rama_data.append([phi,psi,ann])
        
        print('== Generating QTAIM angles')
        # now construct QTAIM quantities
        # suggestion: new phi = angle(normal to C=O,N,Calpha, vector at Calpha-C=O BCP)
        #             new psi = angle(normal to N,Calpha,C=O, vector at C=O,N BCP
        qtrama_data = []
        csvdata = []
        for chain in newchainlist:
            length = len(chain)
            print('Chain length = {0}'.format(length))
            if length < 5:
                print('Chain too short: skipping')
                break
            i = 0
            qtphi = []
            qtpsi = []
            qtomega = []
            qtscalar = []
            qtann = ann    
            while (i+4 < length):
                atomlist = chain[i:i+4]
                anglecode = atomlist[0][0]+atomlist[1][0]+atomlist[2][0]+atomlist[3][0]
                qtanglestring = '-'.join(atomlist[:3])+':'+atomlist[-1]
                bcpstring = '-'.join(sorted(atomlist[2:]))
                selected_bcp = [cp for cp in cs_bcplist if cp.connected == bcpstring][0]
                triplet = []
                for atomname in atomlist[:3]:
                    s = t.atom_label.index(atomname)
                    triplet.append([t.atom_x[s],t.atom_y[s],t.atom_z[s]])
                #get angle
                # first get plane normal
                p1 = [triplet[0][0], triplet[0][1], triplet[0][2]]
                p2 = [triplet[1][0], triplet[1][1], triplet[1][2]]
                p3 = [triplet[2][0], triplet[2][1], triplet[2][2]]
                r1 = [p2[0]-p1[0], p2[1]-p1[1], p2[2]-p1[2]]
                r2 = [p3[0]-p2[0], p3[1]-p2[1], p3[2]-p2[2]]
                modr2 = math.sqrt(bu.dotprod(r2,r2))
                u3 = [r2[0]/modr2, r2[1]/modr2, r2[2]/modr2]
                normvec = bu.vectorproduct(r1,r2)
                modnormvec = math.sqrt(bu.dotprod(normvec,normvec))
                n1 = [normvec[0]/modnormvec,normvec[1]/modnormvec,normvec[2]/modnormvec]        
                #   get QT vector from appropriate BCP
                if (projvec == 'e2'):     # e2 of the Hessian of Rho
                    qtvec = selected_bcp.HessRho_EigVec2
                elif (projvec == 'e1'):   # e1 of the Hessian of Rho
                    qtvec = selected_bcp.HessRho_EigVec1
                elif (projvec == 'e2s'):  # e2 of the Stress Tensor
                    qtvec = selected_bcp.Stress_EigVec2
                elif (projvec == 'e1s'):  # e1 of the Stress Tensor
                    qtvec = selected_bcp.Stress_EigVec1
                elif (projvec == 'ef'):  # minus divergence of the Stress Tensor
                    qtvec = selected_bcp.MinusDivStress
                else:
                    print('Unrecognised QT projection vector given on command line: {0}'.format(projvec))
                    sys.exit()
                # get QT scalar from appropriate BCP
                qtcolval = 1.0
                
                if (scalar == 'rho_ellip'):
                    qtcolval = selected_bcp.Ellipticity
                elif (scalar == 'rho_stiff'):     # lambda2/lambda3
                    qtcolval = math.fabs(selected_bcp.HessRho_EigVals[1]/selected_bcp.HessRho_EigVals[2])
                elif (scalar == 'stress_stiff'):  # lambda1/lambda3
                     qtcolval = math.fabs(selected_bcp.Stress_EigVals[0]/selected_bcp.Stress_EigVals[2])
                elif (scalar == 'stress_ellip'):  # lambda1/lambda2 - 1
                     qtcolval = math.fabs(selected_bcp.Stress_EigVals[0]/selected_bcp.Stress_EigVals[1]) - 1.0          
                modqtvec = math.sqrt(bu.dotprod(qtvec,qtvec))
                u1 = [qtvec[0]/modqtvec,qtvec[1]/modqtvec,qtvec[2]/modqtvec]
                u2 = bu.vectorproduct(u3,u1)
                # standard definition of angle as used in dihedral calculation
                #angle = -1.0*math.atan2(bu.dotprod(n1,u2),bu.dotprod(n1,u1))*180.0/math.pi
                #   compute angle according to earlier beta-angle definition
                angle = math.acos(bu.dotprod(n1,u1))*180.0/math.pi
                #if angle < -90:
                #    angle = angle + 180.0
                if angle >= 90:
                    angle = angle - 180.0
                #print(angle)
                if (anglecode[1:] == 'NCC'):  # this is a QT phi dihedral
                    qtphi.append(angle)
                    if (scalarcp == '1'):
                        qtscalar.append(qtcolval)
                elif (anglecode == 'NCCN'):  # this is a QT psi dihedral
                    qtpsi.append(angle)
                    ann.append(anglestring)
                    if (scalarcp == '2'):
                        qtscalar.append(qtcolval)
                elif (anglecode == 'CCNC'):  # QT this is an omega dihedral
                    qtomega.append(angle)
                else:
                    print('Unrecognised atom pattern in chain')
                    sys.exit()
                i += 1
            # check on data points
            lenqtphi = len(qtphi)
            lenqtpsi = len(qtpsi)
            lenqtomega = len(qtomega)
            print('Computed {0} QT phi values, {1} QT psi values, {2} QT omega values'.format(lenphi,lenpsi,lenomega))
            if (lenqtphi > lenqtpsi):
                qtphi[:] = qtphi[:lenqtpsi]
            elif (lenqtpsi > lenqtphi):
                qtpsi[:] = qtpsi[:lenqtphi]
            lenqtphi = len(qtphi)
            lenqtpsi = len(qtpsi)   
            qtrama_data.append([qtphi,qtpsi,ann])
            # add data to list for csv dump if selected
            if (dumpcsv):
                for i in range(0,lenqtphi):
                    csvdata.append([qtphi[i],qtpsi[i],ann[i],qtscalar[i]])        
        print(' ')
    
            
        # dump full csvdata list to csv file if needed
        if (dumpcsv):
            csvdump(csvfile,
                    ['From qtrama3.py','Mode = '+mode,'QT scalar = '+scalar,'QT vector = '+projvec,'QT scalar CP = '+scalarcp,infile,'angle1 angle2 label '+scalar],
                    csvdata)
                    
        print('Generating plots using QTAIM scalar values from CP {0}..'.format(scalarcp))
        print('Ramachandran regions from Lovell et al. 2003 DOI: http://dx.doi.org/10.1002/prot.10286')
           
        overlay_list = ['allowed_1','allowed_2','allowed_3','allowed_4',
                         'allowed_5','allowed_6','favoured_1','favoured_2',
                         'favoured_3']
        # Ramachandran plot regions
        # Regions from 'Structure validation by Cα geometry: ϕ,ψ and Cβ deviation', Lovell et al. 2003
        # DOI: http://dx.doi.org/10.1002/prot.10286
        # allowed region 1
        region_favoured_1 = [(-177.5, -180.0),(-177.5, -177.5),(-172.5, -177.5),(-172.5, -172.5),(-167.5, -172.5),
                            (-167.5, -167.5),(-127.5, -167.5),(-127.5, -172.5),(-97.5, -172.5),(-97.5, -167.5),
                            (-77.5, -167.5),(-77.5, -172.5),(-72.5, -172.5),(-72.5, -177.5),(-67.5, -177.5),
                            (-67.5, -180.0),(-177.5, -180.0)]
        region_favoured_2 = [(57.5, 67.5),(57.5, 62.5),(62.5, 62.5),(62.5, 57.5),(67.5, 57.5),
                            (67.5, 47.5),(72.5, 47.5),(77.5, 32.5),(77.5, 2.5),(62.5, 2.5),
                            (62.5, 7.5),(57.5, 7.5),(57.5, 12.5),(52.5, 12.5),(52.5, 22.5),
                            (47.5, 22.5),(47.5, 27.5),(42.5, 27.5),(42.5, 37.5),(37.5, 37.5),
                            (37.5, 62.5),(42.5, 62.5),(42.5, 67.5),(57.5, 67.5)]
        region_favoured_3 = [(-62.5, 180.0),(-62.5, 172.5),(-57.5, 172.5),(-57.5, 167.5),(-52.5, 167.5),
                             (-52.5, 157.5),(-47.5, 157.5),(-47.5, 147.5),(-42.5, 147.5),(-42.5, 137.5),
                             (-37.5, 137.5),(-37.5, 122.5),(-42.5, 122.5),(-42.5, 117.5),(-47.5, 117.5),
                             (-47.5, 112.5),(-57.5, 112.5),(-57.5, 107.5),(-62.5, 107.5),(-62.5, 102.5),
                             (-67.5, 102.5),(-67.5, 97.5),(-72.5, 97.5),(-72.5, 62.5),(-77.5, 62.5),
                             (-77.5, 52.5),(-87.5, 52.5),(-87.5, 47.5),(-92.5, 47.5),(-92.5, 52.5),
                             (-97.5, 52.5),(-97.5, 67.5),(-102.5, 67.5),(-102.5, 77.5),(-107.5, 77.5),
                             (-107.5, 82.5),(-112.5, 82.5),(-112.5, 72.5),(-117.5, 72.5),(-117.5, 62.5),
                             (-122.5, 62.5),(-122.5, 52.5),(-127.5, 52.5),(-127.5, 47.5),(-112.5, 47.5),
                             (-112.5, 42.5),(-102.5, 42.5),(-102.5, 37.5),(-92.5, 37.5),(-92.5, 32.5),
                             (-87.5, 32.5),(-87.5, 22.5),(-82.5, 22.5),(-82.5, 17.5),(-77.5, 17.5),
                             (-77.5, 12.5),(-67.5, 12.5),(-67.5, 7.5),(-62.5, 7.5),(-62.5, 2.5),
                             (-57.5, 2.5),(-57.5, -7.5),(-52.5, -7.5),(-52.5, -12.5),(-47.5, -12.5),
                             (-47.5, -22.5),(-42.5, -22.5),(-42.5, -32.5),(-37.5, -32.5),(-37.5, -62.5),
                             (-42.5, -62.5),(-42.5, -67.5),(-77.5, -67.5),(-77.5, -62.5),(-117.5, -62.5),
                             (-117.5, -57.5),(-122.5, -57.5),(-122.5, -47.5),(-127.5, -47.5),(-127.5, -37.5),
                             (-132.5, -37.5),(-132.5, -17.5),(-137.5, -17.5),(-137.5, 2.5),(-142.5, 2.5),
                             (-142.5, 32.5),(-137.5, 32.5),(-137.5, 52.5),(-142.5, 52.5),(-142.5, 57.5),
                             (-147.5, 57.5),(-147.5, 67.5),(-152.5, 67.5),(-152.5, 77.5),(-147.5, 77.5),
                             (-147.5, 87.5),(-152.5, 87.5),(-152.5, 97.5),(-157.5, 97.5),(-157.5, 112.5),
                             (-162.5, 112.5),(-162.5, 122.5),(-167.5, 122.5),(-167.5, 132.5),(-172.5, 132.5),
                             (-172.5, 142.5),(-180.0, 142.5),(-180.0, 180.0)]
        region_allowed_1 = [(-180.0, -147.5),(-177.5, -147.5),(-167.5, -147.5),(-167.5, -142.5),(-157.5, -142.5),
                            (-157.5, -137.5),(-147.5, -137.5),(-147.5, -132.5),(-142.5, -132.5),(-142.5, -127.5),
                            (-147.5, -127.5),(-147.5, -97.5 ),(-152.5, -97.5 ),(-152.5, -92.5 ),(-157.5, -92.5 ),
                            (-157.5, -82.5 ),(-162.5, -82.5 ),(-162.5, -52.5 ),(-157.5, -52.5 ),(-157.5, -37.5 ),
                            (-162.5, -37.5 ),(-162.5, -7.5  ),(-167.5, -7.5  ),(-167.5, 32.5  ),(-172.5, 32.5  ),
                            (-172.5, 52.5  ),(-177.5, 52.5  ),(-177.5, 77.5  ),(-180.0, 77.5  ),(-180.0, 180.0 ),
                            (-42.5, 180.0 ),(-42.5, 172.5 ),(-42.5, 172.5 ),(-37.5, 172.5 ),(-37.5, 167.5 ),
                            (-32.5, 167.5 ),(-32.5, 157.5 ),(-27.5, 157.5 ),(-27.5, 147.5 ),(-22.5, 147.5 ),
                            (-22.5, 127.5 ),(-17.5, 127.5 ),(-17.5, 112.5 ),(-22.5, 112.5 ),(-22.5, 107.5 ),
                            (-27.5, 107.5 ),(-27.5, 102.5 ),(-32.5, 102.5 ),(-32.5, 97.5  ),(-47.5, 97.5  ),
                            (-47.5, 92.5  ),(-52.5, 92.5  ),(-52.5, 72.5  ),(-57.5, 72.5  ),(-57.5, 42.5  ),
                            (-62.5, 42.5  ),(-62.5, 27.5  ),(-57.5, 27.5  ),(-57.5, 22.5  ),(-52.5, 22.5  ),
                            (-52.5, 12.5  ),(-47.5, 12.5  ),(-47.5, 7.5   ),(-42.5, 7.5   ),(-42.5, 2.5   ),
                            (-37.5, 2.5   ),(-37.5, -7.5  ),(-32.5, -7.5  ),(-32.5, -12.5 ),(-27.5, -12.5 ),
                            (-27.5, -27.5 ),(-22.5, -27.5 ),(-22.5, -47.5 ),(-17.5, -47.5 ),(-17.5, -67.5 ),
                            (-22.5, -67.5 ),(-22.5, -77.5 ),(-27.5, -77.5 ),(-27.5, -82.5 ),(-47.5, -82.5 ),
                            (-47.5, -87.5 ),(-77.5, -87.5 ),(-77.5, -92.5 ),(-87.5, -92.5 ),(-87.5, -112.5),
                            (-92.5, -112.5),(-92.5, -122.5),(-97.5, -122.5),(-97.5, -137.5),(-92.5, -137.5),
                            (-92.5, -142.5),(-82.5, -142.5),(-82.5, -147.5),(-72.5, -147.5),(-72.5, -152.5),
                            (-67.5, -152.5),(-67.5, -157.5),(-62.5, -157.5),(-62.5, -162.5),(-57.5, -162.5),
                            (-57.5, -167.5),(-52.5, -167.5),(-52.5, -172.5),(-47.5, -172.5),(-47.5, -177.5),
                            (-42.5, -177.5),(-42.5, -180.0),(-180.0, -180.0),(-180.0,-145.0)]
        region_allowed_2 = [(82.5, 57.5 ),(87.5, 57.5 ),(87.5, 42.5 ),(92.5, 42.5 ),(92.5, 22.5 ),
                            (97.5, 22.5 ),(97.5, -17.5),(92.5, -17.5),(92.5, -22.5),(87.5, -22.5),
                            (87.5, -27.5),(82.5, -27.5),(82.5, -37.5),(87.5, -37.5),(87.5, -47.5),
                            (92.5, -47.5),(92.5, -57.5),(87.5, -57.5),(87.5, -67.5),(82.5, -67.5),
                            (82.5, -72.5),(77.5, -72.5),(77.5, -77.5),(62.5, -77.5),(62.5, -72.5),
                            (57.5, -72.5),(57.5, -67.5),(52.5, -67.5),(52.5, -37.5),(57.5, -37.5),
                            (57.5, -27.5),(62.5, -27.5),(62.5, -22.5),(57.5, -22.5),(57.5, -12.5),
                            (52.5, -12.5),(52.5, -7.5 ),(47.5, -7.5 ),(47.5, -2.5 ),(42.5, -2.5 ),
                            (42.5, 2.5  ),(37.5, 2.5  ),(37.5, 12.5 ),(32.5, 12.5 ),(32.5, 22.5 ),
                            (27.5, 22.5 ),(27.5, 32.5 ),(22.5, 32.5 ),(22.5, 47.5 ),(17.5, 47.5 ),
                            (17.5, 67.5 ),(22.5, 67.5 ),(22.5, 77.5 ),(27.5, 77.5 ),(27.5, 82.5 ),
                            (32.5, 82.5 ),(32.5, 87.5 ),(47.5, 87.5 ),(47.5, 92.5 ),(67.5, 92.5 ),
                            (67.5, 87.5 ),(72.5, 87.5 ),(72.5, 82.5 ),(77.5, 82.5 ),(77.5, 77.5 ),
                            (82.5, 77.5 ),(82.5, 57.5 )]
        region_allowed_3 = [(72.5, -102.5),(72.5, -112.5),(77.5, -112.5),(77.5, -157.5),(72.5, -157.5),
                            (72.5, -180.0),(57.5, -180.0),(57.5, -167.5),(52.5, -167.5),(52.5, -162.5),
                            (47.5, -162.5),(47.5, -157.5),(42.5, -157.5),(42.5, -152.5),(37.5, -152.5),
                            (37.5, -142.5),(32.5, -142.5),(32.5, -107.5),(37.5, -107.5),(37.5, -102.5),
                            (42.5, -102.5),(42.5, -97.5 ),(52.5, -97.5 ),(52.5, -92.5 ),(62.5, -92.5 ),
                            (62.5, -97.5 ),(67.5, -97.5 ),(67.5, -102.5),(72.5, -102.5)]
        region_allowed_4 = [(77.5, 180.0),(77.5, 162.5),(82.5, 162.5),(82.5, 147.5),(72.5, 147.5),
                            (72.5, 157.5),(67.5, 157.5),(67.5, 167.5),(62.5, 167.5),(62.5, 180.0)]
        region_allowed_5 = [(162.5, 180.0),(162.5, 147.5),(167.5, 147.5),(167.5, 132.5),(172.5, 132.5),
                            (172.5, 117.5),(177.5, 117.5),(177.5, 77.5 ),(180.0, 77.5 ),(180.0, 180.0)]
        region_allowed_6 = [(162.5, -180.0),(162.5, -177.5),(167.5, -177.5),(167.5, -167.5),(172.5, -167.5),
                            (172.5, -157.5),(177.5, -157.5),(177.5, -147.5),(180.0, -147.5),(180.0, -180.0) ]
        
        # 
        fig = plt.figure(tight_layout=True)
        ax = fig.gca()
        ax.set_xlim(-180.0,180.0)
        ax.set_ylim(-180.0,180.0)
        ax.set_aspect('equal')
        ax.set_xticks([-180.0,-120.0,-60.0,0.0,60.0,120.0,180.0])
        ax.set_yticks([-180.0,-120.0,-60.0,0.0,60.0,120.0,180.0])
        ax.grid(which='major',axis='both')
        ax.set_xlabel("$\phi$ (degrees)")
        ax.set_ylabel("$\psi$ (degrees)")
        ax.set_title('Dihedral angles ($\phi,\psi$)')
        x = phi
        y = psi
        #ann = dslist[0][2]
        #
        if len(overlay_list) > 0:  # draw the overlays first, in the order they were passed
            for ol in overlay_list:
                #print('Drawing an overlay called {0}'.format(ol))
                if ol == 'favoured_1':
                    Path = mpath.Path
                    #
                    path_data = [(Path.MOVETO,region_favoured_1[0])]
                    for i in range(1,len(region_favoured_1)):
                         path_data.append((Path.LINETO,region_favoured_1[i]))
                    path_data.append((Path.CLOSEPOLY,region_favoured_1[-1]))
                    #                
                    codes, verts = zip(*path_data)
                    path = mpath.Path(verts, codes)
                    patch_1 = mpatches.PathPatch(path, facecolor='r', alpha=0.2)
                    ax.add_patch(patch_1)
                if ol == 'favoured_2':
                    Path = mpath.Path
                    #
                    path_data = [(Path.MOVETO,region_favoured_2[0])]
                    for i in range(1,len(region_favoured_2)):
                         path_data.append((Path.LINETO,region_favoured_2[i]))
                    path_data.append((Path.CLOSEPOLY,region_favoured_2[-1]))
                    #                
                    codes, verts = zip(*path_data)
                    path = mpath.Path(verts, codes)
                    patch_2 = mpatches.PathPatch(path, facecolor='r', alpha=0.2)
                    ax.add_patch(patch_2)
                if ol == 'favoured_3':
                    Path = mpath.Path
                    #
                    path_data = [(Path.MOVETO,region_favoured_3[0])]
                    for i in range(1,len(region_favoured_3)):
                         path_data.append((Path.LINETO,region_favoured_3[i]))
                    path_data.append((Path.CLOSEPOLY,region_favoured_3[-1]))
                    #                
                    codes, verts = zip(*path_data)
                    path = mpath.Path(verts, codes)
                    patch_3 = mpatches.PathPatch(path, facecolor='r', alpha=0.2)
                    ax.add_patch(patch_3)
                if ol == 'allowed_1':
                    Path = mpath.Path
                    #
                    path_data = [(Path.MOVETO,region_allowed_1[0])]
                    for i in range(1,len(region_allowed_1)):
                         path_data.append((Path.LINETO,region_allowed_1[i]))
                    path_data.append((Path.CLOSEPOLY,region_allowed_1[-1]))
                    #                
                    codes, verts = zip(*path_data)
                    path = mpath.Path(verts, codes)
                    patch_4 = mpatches.PathPatch(path, facecolor='b', alpha=0.2)
                    ax.add_patch(patch_4) 
                if ol == 'allowed_2':
                    Path = mpath.Path
                    #
                    path_data = [(Path.MOVETO,region_allowed_2[0])]
                    for i in range(1,len(region_allowed_2)):
                         path_data.append((Path.LINETO,region_allowed_2[i]))
                    path_data.append((Path.CLOSEPOLY,region_allowed_2[-1]))
                    #                
                    codes, verts = zip(*path_data)
                    path = mpath.Path(verts, codes)
                    patch_5 = mpatches.PathPatch(path, facecolor='b', alpha=0.2)
                    ax.add_patch(patch_5)
                if ol == 'allowed_3':
                    Path = mpath.Path
                    #
                    path_data = [(Path.MOVETO,region_allowed_3[0])]
                    for i in range(1,len(region_allowed_3)):
                         path_data.append((Path.LINETO,region_allowed_3[i]))
                    path_data.append((Path.CLOSEPOLY,region_allowed_3[-1]))
                    #                
                    codes, verts = zip(*path_data)
                    path = mpath.Path(verts, codes)
                    patch_6 = mpatches.PathPatch(path, facecolor='b', alpha=0.2)
                    ax.add_patch(patch_6) 
                if ol == 'allowed_4':
                    Path = mpath.Path
                    #
                    path_data = [(Path.MOVETO,region_allowed_4[0])]
                    for i in range(1,len(region_allowed_4)):
                         path_data.append((Path.LINETO,region_allowed_4[i]))
                    path_data.append((Path.CLOSEPOLY,region_allowed_4[-1]))
                    #                
                    codes, verts = zip(*path_data)
                    path = mpath.Path(verts, codes)
                    patch_7 = mpatches.PathPatch(path, facecolor='b', alpha=0.2)
                    ax.add_patch(patch_7)  
                if ol == 'allowed_5':
                    Path = mpath.Path
                    #
                    path_data = [(Path.MOVETO,region_allowed_5[0])]
                    for i in range(1,len(region_allowed_5)):
                         path_data.append((Path.LINETO,region_allowed_5[i]))
                    path_data.append((Path.CLOSEPOLY,region_allowed_5[-1]))
                    #                
                    codes, verts = zip(*path_data)
                    path = mpath.Path(verts, codes)
                    patch_8 = mpatches.PathPatch(path, facecolor='b', alpha=0.2)
                    ax.add_patch(patch_8)
                if ol == 'allowed_6':
                    Path = mpath.Path
                    #
                    path_data = [(Path.MOVETO,region_allowed_6[0])]
                    for i in range(1,len(region_allowed_6)):
                         path_data.append((Path.LINETO,region_allowed_6[i]))
                    path_data.append((Path.CLOSEPOLY,region_allowed_6[-1]))
                    #                
                    codes, verts = zip(*path_data)
                    path = mpath.Path(verts, codes)
                    patch_9 = mpatches.PathPatch(path, facecolor='b', alpha=0.2)
                    ax.add_patch(patch_9)                
        
        # now plot the calculated points
        ax.plot(x,y)
    
        # annotation handler
        af1 =  AnnoteFinder(x,y, ann, ax=ax)
        fig.canvas.mpl_connect('button_press_event', af1)
        # can link annotation finders via linkAnnotationFinders
        
        # QTAIM plot
        fig2 = plt.figure(tight_layout=True)
        ax2 = fig2.gca()
        ax2.set_xlim(-90.0,90.0)
        ax2.set_ylim(-90.0,90.0)
        ax2.set_aspect('equal')
        ax2.set_xticks([-90.0,-60.0,-30.0,0.0,30.0,60.0,90.0])
        ax2.set_yticks([-90.0,-60.0,-30.0,0.0,30.0,60.0,90.0])
        ax2.grid(which='major',axis='both')
        ax2.set_xlabel("$\phi_{{QT}}(${0}$)$ (degrees)".format(projvec))
        ax2.set_ylabel("$\psi_{{QT}}(${0}$)$ (degrees)".format(projvec))
        ax2.set_title('QT(${0}$) angles ($\phi_{{QT}},\psi_{{QT}}$)'.format(projvec))
        #
        color_map = plt.get_cmap(scal_cmap)
        x2 = qtphi
        y2 = qtpsi
        ann2 = ann
        # draw QTAIM scatter plot
        if not scalar == 'none':  # draw a scatter plot with colourbar if CP properties mapped to colours
            sc = ax2.scatter(x2,y2,c=qtscalar,cmap=color_map,vmin=min(qtscalar), vmax=max(qtscalar))
            cbar = plt.colorbar(sc)
            if (scalar == 'rho_ellip'):
                barlabel = 'Ellipticity'
            elif (scalar == 'rho_stiff'):
                barlabel = 'Stiffness'
            elif (scalar == 'stress_ellip'):
                barlabel = 'Stress tensor ellipticity'
            elif (scalar == 'stress_stiff'):
                barlabel = 'Stress tensor stiffness'
            cbar.set_label('CP{0} {1}'.format(scalarcp,barlabel))
        else:                     # draw a standard scatter plot
            sc = ax2.scatter(x2,y2)
        
        af2 =  AnnoteFinder(x2,y2, ann2, ax=ax2)  # annotation handler
        fig2.canvas.mpl_connect('button_press_event', af2)
        # can link annotation finders via linkAnnotationFinders
        
        if (mixed == 'yes'):
        # Hybrid Ramachandran phi- QTAIM psi plot
            fig3 = plt.figure(tight_layout=True)
            ax3 = fig3.gca()
            ax3.set_xlim(-180.0,180.0)
            ax3.set_ylim(-90.0,90.0)
            ax3.set_aspect('equal')
            ax3.set_xticks([-180.0,-120.0,-60.0,0.0,60.0,120.0,180.0])
            ax3.set_yticks([-90.0,-60.0,-30.0,0.0,30.0,60.0,90.0])
            ax3.grid(which='major',axis='both')
            ax3.set_xlabel("$\phi$ (degrees)")
            ax3.set_ylabel("$\psi_{{QT}}$(${0}$) (degrees)".format(projvec))
            ax3.set_title('Hybrid dihedral - QT(${0}$) angles ($\phi,\psi_{{QT}}$)'.format(projvec))
        #
            x3 = phi
            y3 = qtpsi
            ann3 = ann
            ax3.scatter(x3,y3)
            plt.tight_layout()
            af3 =  AnnoteFinder(x3,y3, ann3, ax=ax3)  # annotation handler
            fig3.canvas.mpl_connect('button_press_event', af3)
        # can link annotation finders via linkAnnotationFinders
        
        # Hybrid QTAIM phi-Ramachandran psi plot
            fig4 = plt.figure(tight_layout=True)
            ax4 = fig4.gca()
            ax4.set_xlim(-90.0,90.0)
            ax4.set_ylim(-180.0,180.0)
            ax4.set_aspect('equal')
            ax4.set_xticks([-90.0,-60.0,-30.0,0.0,30.0,60.0,90.0])
            ax4.set_yticks([-180.0,-120.0,-60.0,0.0,60.0,120.0,180.0])
            ax4.grid(which='major',axis='both')
            ax4.set_xlabel("$\phi_{{QT}}(${0}$)$ (degrees)".format(projvec))
            ax4.set_ylabel("$\psi$ (degrees)")
            ax4.set_title('Hybrid QT(${0}$) - dihedral angles ($\phi_{{QT}},\psi$)'.format(projvec))
        #
            x4 = qtphi
            y4 = psi
            ann4 = ann
            ax4.scatter(x4,y4)
            plt.tight_layout(pad=0.2)
            af4 =  AnnoteFinder(x4,y4, ann4, ax=ax4)  # annotation handler
            fig4.canvas.mpl_connect('button_press_event', af4)
        # can link annotation finders via linkAnnotationFinders
            linkAnnotationFinders([af1,af2,af3,af4])
        else:  # not the mixed plots
            linkAnnotationFinders([af1,af2])
        plt.tight_layout()
        plt.show()
          
    else:  # unrecognised mode
        print('Unrecognised mode given on command line')
        
    sys.exit()  

if __name__ == '__main__':
    main()    


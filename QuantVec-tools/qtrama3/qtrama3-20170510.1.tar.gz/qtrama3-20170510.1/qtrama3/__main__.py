# -*- coding: utf-8 -*-


"""qtrama3.__main__: executed when qtrama3 directory is called as script."""


from .qtrama3 import main
main()
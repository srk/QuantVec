# -*- coding: utf-8 -*-


"""critic2sumviz.__main__: executed when critic2sumviz directory is called as script."""


from .critic2sumviz import main
main()
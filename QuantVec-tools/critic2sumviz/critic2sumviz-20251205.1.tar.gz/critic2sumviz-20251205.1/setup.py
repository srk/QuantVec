# -*- coding: utf-8 -*-
"""setup.py: setuptools control."""

import re
from setuptools import setup

version = re.search(
    '^__version__\s*=\s*"(.*)"',
    open('critic2sumviz/critic2sumviz.py').read(),
    re.M
    ).group(1)

setup(
    name = "critic2sumviz",
    packages = ["critic2sumviz"],
    entry_points = {
        "console_scripts": ['critic2sumviz=critic2sumviz.critic2sumviz:main',]
        },
    version = version,
    author='Prof. Steven R. Kirk',
    author_email='stevenrkirk@gmail.com',
    description = "critic2sumviz",
    url = 'https://www.beaconresearch.org',
    install_requires=['numpy','matplotlib'],
    )

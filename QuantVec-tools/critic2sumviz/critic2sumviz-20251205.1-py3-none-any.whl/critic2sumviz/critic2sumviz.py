#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
critic2sumviz
========
Convert CRITIC2 output files to sumviz format for visualization
"""

__version__ = "20251205.0001"

from builtins import input
import sys,os,math,copy,argparse,pathlib
import numpy as np

import beacon_utils as bu
import molgraph as mg

def lookfor( f, pattern):
    try:
        while True:
            line = f.readline()
            if (line.find(pattern) >= 0):
                break
            else:
                line = ''
    except IOError as e:
        print("Input file error({0}): {1}".format(e.errno, e.strerror))
        line = ''
    return line
    
def eigen(a):
    """
    Wrapper to calculate eigenvalues and eigenvectors of symmetric (array/matrix) a
    evals : ndarray() : eigenvalues in increasing order
    evecs :  Column evecs[:, i] is the normalized eigenvector corresponding to the eigenvalue evals[i]
    """
    try:
       evals, evecs = np.linalg.eigh(a)
    except np.linalg.LinAlgError as e:
       print('Linear algebra error thrown by np.linalg.eigh()')
       sys.exit()       
    return evals, evecs

def eig_deflip(patheigvs,thresh):
    """
    Modify eigenvectors of spatial-derivative matrices to remove arbitrary 'flips' associated
    with changes of sign. As eigenvectors are defined to within an arbitrary sign, the first
    eigenvector in the list is regarded as the reference: for subsequent eigenvectors, in a progressive manner,
    their signs are flipped if (current_evec).(previous_evec) < thresh ( e.g. -0.1). 
    """
    oldev = patheigvs[0]
    for i in range(1,len(patheigvs)):
        ev = patheigvs[i]
        if bu.dotprod(ev,oldev) < thresh: # flip detected
           patheigvs[i] = [ -1.0*d for d in ev ]
           ev = patheigvs[i]
        oldev = ev           
        
    
            
def main():
    print(__doc__)
    print(__version__)
    print('Molgraph module version: {0}'.format(mg.__version__))
    print('beacon_utils module version: {0}'.format(bu.__version__))
    parser = argparse.ArgumentParser(description="critic2sumviz")
    parser.add_argument("infile", help="CRITIC2 output file to convert")
    parser.add_argument("--scaling", help="Optional scaling to apply to bondvectors ['ellipticity','none']")
    parser.add_argument("--celllabels", help="Generate cell index labels on the atoms",action='store_true')
    args = parser.parse_args()
    fname = args.infile
    scaling = args.scaling
    clabels = args.celllabels

    # main program starts here
    for line in bu.repheader():
        print(line)
    print("VERSION "+__version__)
    print("")
    #dummy = input()

    # test eigenroutine
    #a = np.array([[1.384129877E-01, 1.531911641E-01, 1.531918105E-01],  
    #              [1.531911641E-01, 1.382977244E-01, 1.531871927E-01],  
    #              [1.531918105E-01, 1.531871927E-01, 1.383646905E-01]] )
    #eval,evec = eigen(a)
    #for i in range(0,3):
    #   print('Eigenvalue {0}, eigenvector {1} {2} {3}'.format(eval[i],evec[0,i],evec[1,i],evec[2,i]))
    #sys.exit()

    
    print('Opening CRITIC2 file: {0}'.format(fname))
    t = mg.Molgraph() # create new mg object
    t.read(fname,debug=True)
    t.model = ''
    foutname = pathlib.Path(fname).stem+'.sumviz'
    t.wf_name = os.uname().nodename+':'+str(pathlib.Path(fname))
    # fix GBL for BCPs between nuclei
    t.calculate_gbl()
    # write the sumviz file
    with open(foutname,'w') as f:
        t.write_aimall(f,'sumviz')        
    
    #
    print("Input file name = {0}".format(t.filename))
    print("Input file type = {0}".format(t.filetype))
    #print("Code version = {0}".format(t.codeversion))
    print("Wavefunction file = {0}".format(t.wf_file))
    print("Title = {0}".format(t.title))
    print("Model = {0}".format(t.model))
    print("Atom data")
    print("Atom      Charge                 x                 y                 z       ")
    for i in range (0,len(t.atom_label)):
        print("{0:5s} {1:17.10E} {2:17.10E} {3:17.10E} {4:17.10E}".format(t.atom_label[i],t.atom_charge[i],
              t.atom_x[i],t.atom_y[i],t.atom_z[i]))
    #print("Molecular charge: {0} Molecular Energy: {1}".format(t.mol_charge,t.mol_energy))
    #print("Molecular virial ratio: {0}".format(t.mol_virial_ratio))
    print("")
    print("==== Critical points")
    print("Type  Label                 x                y                   z      ")
    for cp in t.cplist:
        print ("{0:5s} {1:12s} {2:17.10E} {3:17.10E} {4:17.10E}".format(cp.type,cp.connected,cp.pos_x,cp.pos_y,cp.pos_z))
        #print ("Rho = {0:17.10E}\nGradRho = {1:17.10E} {2:17.10E} {3:17.10E}".format(
        #        cp.Rho,cp.GradRho[0],cp.GradRho[1],cp.GradRho[2]))
        if cp.type == "BCP":
            print("BPL     = {0:17.10E}".format(cp.BPL))
        #    print("GBL_I   = {0:17.10E}".format(cp.GBL_I))
        #    print("GBL_II  = {0:17.10E}".format(cp.GBL_II))
        #    print("GBL_III = {0:17.10E}".format(cp.GBL_III))
        #    print("GBL_IV  = {0:17.10E}".format(cp.GBL_IV))            
            print("This BCP has {0} associated paths with lengths: {1}".format(len(cp.pathlist),' '.join([ str(len(tt.path_x)) for tt in cp.pathlist ] )))
            #for thispath in cp.pathlist:
            #    print(len(thispath.path_x)) 
            
    print("Critical point counts: {0} {1} {2} {3} {4}".format(
                            t.num_ncp,t.num_nna,t.num_bcp,t.num_rcp,t.num_ccp))


    # Now generate path files
    print('Making path files')
    for cp in t.cplist:
        if cp.type == 'BCP':
            cpname = '-'.join(cp.connected.split())
            bondpaths = cp.pathlist[0:2] # force use of 
            for thispath in bondpaths:
                lenpath = len(thispath.path_x)
                #print('{0} path description = {1}'.format(cpname,thispath.description))            
                tokens = thispath.description.split()
                endpoint = tokens[-1]
                foutname = pathlib.Path(fname).stem + '_{0}_{1}.path'.format(cpname,endpoint)
                with open(foutname,'w') as fout:
                    fout.write('Path data created by critic2sumviz version {0}\n'.format(__version__))
                    fout.write('Input file: {0}\n'.format(str(pathlib.Path(fname).resolve())))
                    fout.write('Description: {0} sample points along path from BCP to atom {1}\n'.format(lenpath, endpoint))
                    fout.write('Start: {0}\n'.format(cpname))
                    fout.write('End: {0}\n'.format(endpoint))
                    fout.write('Scaling: {0}\n'.format(scaling))
                    fout.write('Path eigenvector data: path coordinates, scaled e1, scaled e2\n')
                    fout.write('Scaled eigenvectors for hess : {0} path points\n'.format(lenpath))
                    e1 = []
                    e2 = []
                    scal = []
                    for i in range(0,lenpath):
                        mtrx = thispath.path_matfieldvar[i]  # numpy array 3x3
                        # get eigenproperties
                        evals, evecs = eigen(mtrx)
                        if scaling == 'ellipticity':    # Path eigenvectors are scaled by ellipticity
                            s = abs(evals[0]/evals[1])-1.0
                        else:                           # none (default)
                            s = 1.0
                        scal.append(s)
                        e1.append(evecs[:,0].tolist())
                        e2.append(evecs[:,1].tolist())
                    # now deflip the eigenvectors
                    eig_deflip(e1,-0.1)
                    eig_deflip(e2,-0.1)
                    # CRITIC2 eigenvectors go strange at the nuclei, fix to eigenvectors of previous step
                    #e1[-1] = [ e1[-2][j] for j in range(0,3)]
                    #e2[-1] = [ e2[-2][j] for j in range(0,3)]
                    # ellipticity not used at attractors
                    if scaling == 'ellipticity':
                        scal[-1] = 0.0
                    
                    # output
                    formatstring = '{0:17.9E}{1:17.9E}{2:17.9E}{3:17.9E}{4:17.9E}{5:17.9E}{6:17.9E}{7:17.9E}{8:17.9E}\n'
                    for i in range(0,lenpath):
                        fout.write(formatstring.format( thispath.path_x[i],thispath.path_y[i],thispath.path_z[i],
                                                        scal[i]*e1[i][0],scal[i]*e1[i][1],scal[i]*e1[i][2],
                                                        scal[i]*e2[i][0],scal[i]*e2[i][1],scal[i]*e2[i][2]))
    
    #
    print('Program exiting')

if __name__ == "__main__":
    main()

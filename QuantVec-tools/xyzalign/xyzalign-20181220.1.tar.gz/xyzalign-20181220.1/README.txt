xyzalign: Version 20181220.0001
usage: xyzalign [-h] [--alignby ALIGNBY]
                xyzfilein xyzfileout atom1name atom2name atom3name

xyzalign

positional arguments:
  xyzfilein          XYZ file to be aligned
  xyzfileout         Output XYZ file
  atom1name          Name/number of atom to place at origin
  atom2name          Name/number of atom to place on x-axis
  atom3name          Name/number of atom to define x-y plane

optional arguments:
  -h, --help         show this help message and exit
  --alignby ALIGNBY  Frame number in input, 'all' or single-frame XYZ
                     filename, to use as alignment reference (default: all)

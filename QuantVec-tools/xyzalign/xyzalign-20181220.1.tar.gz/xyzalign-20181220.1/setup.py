# -*- coding: utf-8 -*-
"""setup.py: setuptools control."""

import re
from setuptools import setup

version = re.search(
    '^__version__\s*=\s*"(.*)"',
    open('xyzalign/xyzalign.py').read(),
    re.M
    ).group(1)

setup(
    name = "xyzalign",
    packages = ["xyzalign"],
    entry_points = {
        "console_scripts": ['xyzalign=xyzalign.xyzalign:main',]
        },
    version = version,
    author='Prof. Steven R. Kirk',
    author_email='stevenrkirk@gmail.com',
    description = "xyzalign",
    url = 'https://www.beaconresearch.org',
    install_requires=['numpy','matplotlib'],
    )

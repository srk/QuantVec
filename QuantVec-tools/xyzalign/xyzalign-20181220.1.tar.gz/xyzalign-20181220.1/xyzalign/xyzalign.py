# -*- coding: utf-8 -*-
"""
xyzalign
=======

Usage: python xyzalign 

Written in Python 3.6
"""
from __future__ import print_function

__version__ = "20181220.0001"
import sys, math, os, copy, argparse, csv, os.path
import numpy as np
import beacon_utils as bu

def getaxes(origin,xatom,xyatom):
    """
    Given the 3-D location of an origin atom, an atom location marking a new x-axis and an
    atom location lying in a new x-y plane, return unit x,y,z vectors as lists for the
    new coordinate system.
    """
    newx = [0.0,0.0,0.0]
    tmpy = [0.0,0.0,0.0]
    newx = [ xatom[i] - origin[i] for i in range(0,3) ]
    tmpy = [ xyatom[i] - origin[i] for i in range(0,3) ]
    modx = math.sqrt(bu.dotprod(newx,newx))         # x normalization factor
    unitx = [ newx[i]/modx for i in range(0,3) ]    # new unit x vector
    mody_x = bu.dotprod(unitx,tmpy)
    y_x = [ mody_x*unitx[i] for i in range(0,3) ]   # component of tmpy vector along unitx
    newy = [ tmpy[i] - y_x[i] for i in range(0,3) ] # subtract unitx projection component to get new y axis
    mody = math.sqrt(bu.dotprod(newy,newy))         # y normalization factor
    unity = [ newy[i]/mody for i in range(0,3) ]    # new unit y vector
    unitz = bu.vectorproduct(unitx,unity)           # Compute unit z vector as a vector cross product
    return unitx,unity,unitz
    
class XYZFrame():
    """
    Class to hold a frame of XYZ format data
    """
    def __init__ (self):
        self.natoms= 0
        self.comment =''
        self.atoms = []
    
    def readframe(self,f):
        """
        Fill a new XYZFrame object with atom data read from file object f
        Individual atom data lines stored in list 'self.atoms' as lists of strings
        """
        line = f.readline().strip()
        self.natoms = int(line)
        line = f.readline().strip()
        self.comment = line
        for i in range(0, self.natoms):
            line = f.readline().strip()
            linelist = line.split()
            self.atoms.append(linelist)  
        
    def show(self):
        """
        Dump frame data to screen
        """
        print('{0}'.format(self.natoms))
        print('{0}'.format(self.comment))
        for i in range (0,self.natoms):
            print('{0}'.format(' '.join( [str(k) for k in self.atoms[i] ])))  
            
    def write(self,f):
        """
        Write frame data to file object f
        """
        f.write('{0}\n'.format(self.natoms))
        f.write('{0}\n'.format(self.comment))
        for atom in self.atoms:
            outputline = '{0} {1: .10f} {2: .10f} {3: .10f} '.format(atom[0],float(atom[1]),float(atom[2]),float(atom[3]))
            if len(atom) > 4:  # extra atom data beyond column 4 if present
                outputline = outputline + ' '.join(atom[4:])
            f.write('{0}\n'.format(outputline))

def getrefatoms(thisframe,names,atom1name,atom2name,atom3name):
    """
    For a given frame, return the 3-D positions of the chosen origin, x-axis and x-yplane atoms
    """
    if (names):  # if atom names are used
        i = 1
        for atom in thisframe.atoms:
            if atom[0].strip() == atom1name:
                atom1num = i
            elif atom[0].strip() == atom2name:
                atom2num = i
            elif atom[0].strip() == atom3name:
                atom3num = i
            i = i+1
         # now we have atom numbers, proceed   
    else:       # atom numbers given directly
        atom1num = int(atom1name)
        atom2num = int(atom2name)
        atom3num = int(atom3name)
    # generate the positions    
    atom = thisframe.atoms[atom1num-1]
    origin =  [ float(atom[1]), float(atom[2]), float(atom[3]) ]
    atom = thisframe.atoms[atom2num-1]
    xatom = [ float(atom[1]), float(atom[2]), float(atom[3]) ]
    atom = thisframe.atoms[atom3num-1]
    xyatom = [ float(atom[1]), float(atom[2]), float(atom[3]) ]
    return origin,xatom,xyatom


# main program starts here
# argument parser
def main():
    print('xyzalign: Version {0}'.format(__version__))
    parser = argparse.ArgumentParser(description="xyzalign")
    parser.add_argument("xyzfilein", help="XYZ file to be aligned")
    parser.add_argument("xyzfileout", help="Output XYZ file")
    parser.add_argument("atom1name", help="Name/number of atom to place at origin")
    parser.add_argument("atom2name", help="Name/number of atom to place on x-axis")
    parser.add_argument("atom3name", help="Name/number of atom to define x-y plane")
    parser.add_argument("--alignby", help="Frame number in input, 'all' or single-frame XYZ filename, to use as alignment reference (default: all)",
                                    default='all')
                             
    args = parser.parse_args()
    xyzfilein = args.xyzfilein
    xyzfileout = args.xyzfileout
    atom1name = args.atom1name
    atom2name = args.atom2name
    atom3name = args.atom3name
    alignby = args.alignby
    alignref = 'all'  # 'all', frame number, external file name 
    
    header=bu.repheader()
    print('\n'.join(header))
    print(__doc__)
    print("")
    
    framelist= []

    # check if numbers are used to specify the alignment atoms
    if atom1name.isnumeric():  # only atom *numbers* in the command line
        names = False
        print('Finding atoms by number (numerical order specified in frames)')
    else:
        names = True
        print('Finding atoms by names (specified on command line)')
          
    # read input XYZ file
    with open(xyzfilein,'r') as f:  # read input file into list of XYZFrame objects
        while True:
            newframe = XYZFrame()
            try:
                newframe.readframe(f)
            except:
                break
            else:
                framelist.append(newframe)
        
    nframes = len(framelist)
    print('Read {0} frames from input file'.format(nframes))

    # Test if user specified a frame number, 'all', or a file for alignment reference
    if alignby == 'all':  # default, constrain all frames (removes all molecular translation and rotation for all frames)
        alignref = 'all'

    elif alignby.isnumeric():  # frame number
        fnumber = int(alignby)-1
        if (fnumber < 0 or fnumber > nframes-1):  # check specified frame number is in range
            print('Cannot find frame number {0} in range 1-{1}'.format(alignby,nframes))
            sys.exit()
        print('Reference frame is {0} of {1}'.format(fnumber+1,nframes))
        alignref = 'Frame {0}'.format(alignby)
        ref_frame = framelist[fnumber]

    else:  # separate frame file = 
        print('Reference frame is from file: {0}'.format(alignby))
        if not os.path.exists(alignby):
            print('Reference frame file {0} not found'.format(alignby))
            sys.exit()
        with open(alignby,'r') as rf:
            ref_frame = XYZFrame()
            ref_frame.readframe(rf)
        alignref = 'File: {0}'.format(alignby)

    # get coordinates of the alignment atoms from reference frame
    origin = [0.0,0.0,0.0]
    xatom = [0.0,0.0,0.0]
    xyatom = [0.0,0.0,0.0]
    newx = [0.0,0.0,0.0]
    tmpy = [0.0,0.0,0.0]
    if (alignby != 'all'):  # align by single frame in original xyz file or reference xyz file
        origin,xatom,xyatom = getrefatoms(ref_frame,names,atom1name,atom2name,atom3name)
        unitx, unity, unitz = getaxes(origin,xatom,xyatom)
            
#  Loop over all frames, adjusting to the new reference frame
    for frame in framelist:
        if (alignby == 'all'):  # if we are aligning every frame, recompute origin/unitx/unity/unitz
            origin,xatom,xyatom = getrefatoms(frame,names,atom1name,atom2name,atom3name)
            unitx,unity,unitz = getaxes(origin,xatom,xyatom)
        for atom in frame.atoms:
            numfields = len(atom)
            r = [ float(atom[1]), float(atom[2]), float(atom[3]) ]
            r2 = [ r[0]-origin[0], r[1]-origin[1], r[2]-origin[2] ]
            newr = [ bu.dotprod(r2,unitx), bu.dotprod(r2,unity), bu.dotprod(r2,unitz) ]
            atom[1] = '{0}'.format(newr[0])
            atom[2] = '{0}'.format(newr[1])
            atom[3] = '{0}'.format(newr[2])
            # optionally, if the atom has a vector attached, adjust that into the new frame too
            # columns 1-4 (name,x,y,z) are assumed present; if 7 columns or more, assume vector components in columns 5,6,7
            if (numfields > 6):
                vec = [ float(atom[4]), float(atom[5]), float(atom[6]) ]
                newvec = [ bu.dotprod(vec,unitx), bu.dotprod(vec,unity), bu.dotprod(vec,unitz) ]
                atom[4] = '{0}'.format(newvec[0])
                atom[5] = '{0}'.format(newvec[1])
                atom[6] = '{0}'.format(newvec[2])                             

# Loop over all frames and output the aligned frame data
    with open(xyzfileout,'w') as fout:
        for frame in framelist:
            frame.write(fout)


if __name__ == '__main__':
    main()

 
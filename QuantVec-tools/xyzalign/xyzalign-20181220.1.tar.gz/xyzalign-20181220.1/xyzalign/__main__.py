# -*- coding: utf-8 -*-


"""xyzalign.__main__: executed when xyzalign directory is called as script."""


from .xyzalign import main
main()
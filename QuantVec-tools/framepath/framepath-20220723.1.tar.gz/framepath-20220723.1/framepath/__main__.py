# -*- coding: utf-8 -*-


"""framepath.__main__: executed when framepath directory is called as script."""


from .framepath import main
main()
# -*- coding: utf-8 -*-
"""
@author: steve

framepath
========
Calculate the evolution of vector quantities along a bond path, with additional quantities
evaluated for the bond path as a whole.

"""
from __future__ import print_function
import math,argparse,configparser,os,sys,math
import numpy as np
import beacon_utils as bu
import molgraph as mg

__version__ = "20220723.0001"

def checkconfig(configfile):  # check if a config file exists, build a template in current directory if needed
    """
    Check that a config file exists.
    If not, build an example 'framepath.cfg', direct the user to customise that, then exit
    """
    if (os.path.isfile(configfile)):
        print('Found a framepath configuration file: {0}'.format(configfile))
    else:
        with open('framepath.cfg','w') as f:
            f.write('[DEFAULT]\n')
            f.write('# aimpath is the full filesystem path to the AIM executable - you must customize this\n')
            f.write('# On Windows, double slashes must be used in the path\n')
            f.write('# On Linux, use a wrapper shell script that does NOT launch a new terminal\n')
            f.write('# Edit the line below in a text editor\n')
            f.write('aimpath = /opt/CCCE/aimall/AIMAll/aimext.sh\n')
        print('ERROR: No framepath.cfg file was found in this directory!')
        print('       An example framepath.cfg file has been created for you.')
        print('       Edit this and customize it before running framepath again')
        sys.exit()
        
def numbercheck(num): # catch cases of overwritten/missing E marker in .extout files, correct
    """
    Re-insert missing E marker in floating point numbers if needed
    """
    marker = num[-4]
    if (marker == '+') or (marker == '-'):
        newnum = num[:-4] + "E" + num[-4:]
    else:
        newnum = num
    return(newnum)        
                
def patheval(pointlist,exename,wfname):  # return properties at specified points from external program as long string
    """
    Given a list of 3D (x,y,z) coordinates, calculate and return a list of
    properties evaluated at these points using the specified wavefunction 
    file 'wfname' using analysis method 'analysistype'
    """
    results=[]
    inplist=[]
    lexename=exename.lower()
    if lexename.find('aimext') > -1:  # running aimext 
        print('Calling AIMExt') 
        analysistype = 'aimext'
    elif (exename == 'cmd' and wfname == 'test'):  # simple shell for debug purposes on Windows
        analysistype = 'cmdtest'
    else:
        analysistype = ''
        
    if analysistype == 'aimext':  # run AIMext and extract point properties
        # first build input list
        print('Command line = [{0} {1}]'.format(exename,wfname))
        inplist.append('Created by framepath')  # title
        inplist.append('1')  # Select rho as primary variable
        inplist.append('7')
        inplist.append('2')
        inplist.append('1')
        inplist.append('0')  # change AIMExt settings for more verbose output
        for i in range(0,len(pointlist)):
            inplist.append('5')  # select a point
            inplist.append('{0:.9E} {1:.9E} {2:.9E}'.format(pointlist[i][0],pointlist[i][1],pointlist[i][2]))
        inplist.append('99')  # exit
        inplist.append('0')
    elif analysistype == 'cmdtest':  # test
        inplist.append('dir')            
    else:
        print('Unknown analysis type!')
    
    #run the external program
    error = False
    args = [exename,wfname]
    #print(args)
    #print(inplist)
    results = bu.progfeed(args,inplist,error)
    return (results)
def parse_aimext(lines, pointlist,verbose):  # parse data from captured external program output, return pointlist
    """
    Given a set of captured AIMExt output lines, build a list of CriticalPoint objects holding
    the point-by-point properties.
    """
    if (verbose):
        print('INFO: parsing AIMExt output')
        print('Position, normalized HessRho e1, normalized HessRho e2')
    count = 0
    lineiter = iter(lines)  # make an iterator from input lines
    for line in lineiter:
        if 'Coordinates for local property evaluation:' in line:  # found the point
            # create a new point object and initialize position coordinates
            thiscp = mg.CriticalPoint()
            line = lineiter.__next__()
            thiscp.pos_x, thiscp.pos_y, thiscp.pos_z = [float(numbercheck(i)) for i in line.split() ]
        elif 'The Hessian:' in line:  
            # get Rho Hessian
            line = lineiter.__next__()
            thiscp.HessRho.append( [float(numbercheck(i)) for i in line.split() ] )
            line = lineiter.__next__()
            thiscp.HessRho.append( [float(numbercheck(i)) for i in line.split() ] )
            line = lineiter.__next__()
            thiscp.HessRho.append( [float(numbercheck(i)) for i in line.split() ] )
            # get HessRho eigenvalues
            for i in range(0,3):
                line = lineiter.__next__()
            thiscp.HessRho_EigVals = [float(numbercheck(i)) for i in line.split() ]

            # special case - ellipticity is not captured for NCP locations at the end of paths, so calculate it instead
            thiscp.Ellipticity = math.fabs(thiscp.HessRho_EigVals[0]/thiscp.HessRho_EigVals[1])-1.0
            while (not line.strip().startswith('Eigenvectors')):  # skip past the listed Ellipticity
                line = lineiter.__next__()
            
            # Get HessRho eigenvectors NB columnn format!
            line = lineiter.__next__()
            row1 = [float(numbercheck(i)) for i in line.split() ]
            line = lineiter.__next__()
            row2 = [float(numbercheck(i)) for i in line.split() ]
            line = lineiter.__next__()
            row3 = [float(numbercheck(i)) for i in line.split() ]
            thiscp.HessRho_EigVec1 = bu.unitvec([ row1[0], row2[0],row3[0] ])
            thiscp.HessRho_EigVec2 = bu.unitvec([ row1[1], row2[1],row3[1] ])
            thiscp.HessRho_EigVec3 = bu.unitvec([ row1[2], row2[2],row3[2] ])
            if (verbose):
                formatstring = '{0:>16.9E} {1:>16.9E} {2:>16.9E} {3:>16.9E} {4:>16.9E} {5:>16.9E} {6:>16.9E} {7:>16.9E} {8:>16.9E}'
                lineout = formatstring.format(thiscp.pos_x,thiscp.pos_y,thiscp.pos_z,
                                              thiscp.HessRho_EigVec1[0],thiscp.HessRho_EigVec1[1],thiscp.HessRho_EigVec1[2],
                                              thiscp.HessRho_EigVec2[0],thiscp.HessRho_EigVec2[1],thiscp.HessRho_EigVec2[2])
                print(lineout)
                
            # get Stress Tensor
            for i in range(0,3):
                line = lineiter.__next__()
            thiscp.Stress.append( [float(numbercheck(i)) for i in line.split() ] )
            line = lineiter.__next__()
            thiscp.Stress.append( [float(numbercheck(i)) for i in line.split() ] )
            line = lineiter.__next__()
            thiscp.Stress.append( [float(numbercheck(i)) for i in line.split() ] )
            
            # get Stress Tensor eigenvalues
            for i in range(0,3):
                line = lineiter.__next__()
            thiscp.Stress_EigVals = [float(numbercheck(i)) for i in line.split() ]
            
            # Get Stress Tensor eigenvectors NB column format!
            for i in range(0,3):
                line = lineiter.__next__()
            row1 = [float(numbercheck(i)) for i in line.split() ]
            line = lineiter.__next__()
            row2 = [float(numbercheck(i)) for i in line.split() ]
            line = lineiter.__next__()
            row3 = [float(numbercheck(i)) for i in line.split() ]
            thiscp.Stress_EigVec1 = bu.unitvec([ row1[0], row2[0],row3[0] ])
            thiscp.Stress_EigVec2 = bu.unitvec([ row1[1], row2[1],row3[1] ])
            thiscp.Stress_EigVec3 = bu.unitvec([ row1[2], row2[2],row3[2] ])
            
            # get Minus DivStress
            for i in range(0,3):
                line = lineiter.__next__()
            thiscp.MinusDivStress = [float(numbercheck(i)) for i in line.split() ]
            
            # Get scalars
            for i in range(0,3):
                line = lineiter.__next__()
            thiscp.Rho  =  float(line.split()[-1])
            line = lineiter.__next__() # skip modulus of Grad Rho
            line = lineiter.__next__() # get GradRho
            gradrho_x = float(line.split()[-1])
            line = lineiter.__next__()
            gradrho_y = float(line.split()[-1])
            line = lineiter.__next__()
            gradrho_z = float(line.split()[-1])
            thiscp.GradRho = [gradrho_x, gradrho_y, gradrho_z]
            line = lineiter.__next__()
            thiscp.DelSqRho  =  float(line.split()[-1])
            line = lineiter.__next__()
            thiscp.G  =  float(line.split()[-1])
            line = lineiter.__next__()
            thiscp.K  =  float(line.split()[-1])
            line = lineiter.__next__()
            thiscp.L  =  float(line.split()[-1])
            line = lineiter.__next__()
            thiscp.Vnuc  =  float(line.split()[-1])
            line = lineiter.__next__()
            thiscp.V  =  float(line.split()[-1])
            line = lineiter.__next__()
            thiscp.Ven  =  float(line.split()[-1])
            line = lineiter.__next__()
            thiscp.Vrep  =  float(line.split()[-1])
            line = lineiter.__next__()
            thiscp.DelSqV  =  float(line.split()[-1])
            line = lineiter.__next__()
            thiscp.DelSqVen  =  float(line.split()[-1])
            line = lineiter.__next__()
            thiscp.DelSqVrep  =  float(line.split()[-1])
            line = lineiter.__next__()
            thiscp.DelSqG  =  float(line.split()[-1])
            line = lineiter.__next__()
            thiscp.DelSqK  =  float(line.split()[-1])
            
            # finally, add this new point to the pointlist
            pointlist.append(thiscp)
            
def frameangles(pointlist,vtype1,vtype2,vtype3):  # calculate lists of frame angles for input path: reference frame = first point
    """
    Given a list of points (as molgraph CriticalPoint objects), calculate and return a list of Frenet-Serret style 
    angles using the frame from the first point as reference. The 'vtype' parameters determine which vectors are used
    for frame construction, e.g. HessRho eigenvectors, Stress eigenvectors, etc.
    In the standard Frenet-Serret formalism, the main vectors are:
    t : the tangent to the curve (== e3 for QTAIM)
    n : the normal to the curve, usually determined by curvature, can use any QTAIM vector to replace this (e.g. e1)
    b : the binormal t x n  (== e2)
    then if Frame F1=(t1,n1,b1) transforms to Frame F2=(t2,n2,b2), then the transformation matrix T=F2*(F1)^-1 is
    T = [ r11 r12 r13 ]    where    yaw = atan2(r21,r11)
        [ r21 r22 r23 ]           pitch = atan2(-r31, sqrt((r32)^2 + (r33)^2)
        [ r31 r32 r33 ]            roll = atan2(r32,r33)
        
    ALTERNATIVE FORMULATION
    'forward' unit vector f = t = e3, reference unit vectors u1,u2,u3 = e3, e1, -e2
    Pitch = asin( -1.0 * (f.u2)) = asin (-1.0 * (f.e1))
    Yaw = atan2( (f.e3), (-f.e2))
    Roll = 
    """
    output = []
    refpoint = pointlist[0]
    ref_dict = getpointdict(refpoint)  # a dictionary of QTAIM/stress tensor reference vectors
    ref_t = ref_dict[vtype1]  # named 3-component vector for reference frame
    ref_n = ref_dict[vtype2]  # named 3-component vector for reference frame
    ref_b = ref_dict[vtype3]  # named 3-component vector for reference frame
    
    for i in range(0,len(pointlist)):  # calculate pitch, roll, yaw angles for points on pointlist, append to output
        pathpoint = pointlist[i]
        pointdict = getpointdict(pathpoint)
        v1 = pointdict[vtype1]
        v2 = pointdict[vtype2]
        v3 = pointdict[vtype3]    
        #
        # assemble angles for this point
        pointangles = angles(ref_t,ref_n,ref_b,v1,v2,v3)
        output.append(pointangles)
    return(output)
    
    
def angles(ref_t,ref_n,ref_b,v1,v2,v3):
    """
    Calculate pitch, roll and yaw angle between frames defined by (ref_t,ref_n,ref_b) and (v1,v2,v3)
    """
    f1 = np.asarray([ref_t,ref_n,ref_b])
    f1inv = np.linalg.inv(f1)
    #
    # construct transformation matrix r
    r = np.zeros((3,3))        
    f2 = np.asarray([v1,v2,v3])
    r = np.matmul(f2,f1inv)
    #
    # construct pitch, roll, yaw angles
    pitch = np.arctan2(-1.0*r[2,0],math.sqrt((r[2,1]*r[2,1])+(r[2,2]*r[2,2])))
    roll = np.arctan2(r[2,1],r[2,2])
    yaw = np.arctan2(r[1,0],r[0,0])
    return [pitch, roll, yaw]
       
    
def getpointdict(point):
    """
    For an input instance of CriticalPoint, return a dictionary of its vector quantities.
    """
    pdict = {'HessRho_EigVec1': point.HessRho_EigVec1,
             'HessRho_EigVec2': point.HessRho_EigVec2,
             'HessRho_EigVec3': point.HessRho_EigVec3,
             'Stress_EigVec1': point.Stress_EigVec1,
             'Stress_EigVec2': point.Stress_EigVec2,
             'Stress_EigVec3': point.Stress_EigVec3,
             '' : 0.0 }
    return(pdict)
    
    
def getvectors(point,v1name,v2name,v3name):
    """
    Given a molgraph CriticalPoint object, return the named triplet of vectors as a tuple
    """ 
    
def sortlabel(instring):
    """
    Generate a CP label with the atom order sorted alphabetically, separated by '-'
    """
    tokens=instring.split("-")
    tokens.sort()
    return("-".join(tokens))    
def buildxyzframe(framelines,labels,r,vectors=[]): 
    """
    Appends lines containing point labels, coordinates as [x,y,z] triples in r and optionally per-point vectors, 
    in XYZ file format, to the list of strings 'framelines'.
    """
    au2ang = 0.529177
    natoms = len(labels)
    if (natoms != len(r)):
        print('len(labels)={0}'.format(len(labels)))
        print('len(r)={0}'.format(len(r)))
        sys.exit()
    if (len(vectors) == 0):  # only coordinates supplied
        for i in range (0,natoms):
            ri = r[i]
            framelines.append('{0} {1: .10f} {2: .10f} {3: .10f}'.format(
                              labels[i], ri[0]*au2ang, ri[1]*au2ang, ri[2]*au2ang))
    else:  # coordinates and per-atom vectors supplied
        for i in range (0,natoms):
            ri = r[i]
            vi = vectors[i]
            framelines.append('{0} {1: .10f} {2: .10f} {3: .10f} {4: .10f} {5: .10f} {6: .10f}'.format(
                              labels[i], ri[0]*au2ang, ri[1]*au2ang, ri[2]*au2ang, vi[0], vi[1], vi[2]))
def frametoxyz(f, framelines, comment): 
    """
    Sends framelines constructed by buildxyzframe, to the file descriptor f.
    Use 'comment' as the frame comment.
    """
    n = len(framelines)    
    f.write('{0}\n'.format(n))
    f.write('{0}\n'.format(comment))
    for line in framelines:
        f.write('{0}\n'.format(line))
        
        
def pathlength(r):
    """
    Returns the cumulative length list of a path r (provided as a list of [x,y,z] triples)
    """
    length = 0.0
    c_length = []
    oldp = r[0]
    for p in r:  # accumulate path length over position list
        dx = p[0] - oldp[0]
        dy = p[1] - oldp[1]
        dz = p[2] - oldp[2]
        length = length + math.sqrt((dx*dx)+(dy*dy)+(dz*dz))
        c_length.append(length)
        oldp = p
    return(c_length)  # returns array of cumulative lengths for input path r
def interp3d(x,y,z,n):
    '''
    Return 3 lists of interpolated x,y,z values with n-1 extra points 
    between the original points
    
    '''
    if n < 2:
        return x, y, z
    oldn = len(x)
    newx, newy, newz = [],[],[]
    frac = 1.0/float(n)
    for i in range(0,oldn-1):
        delta_x = x[i+1]-x[i]
        delta_y = y[i+1]-y[i]
        delta_z = z[i+1]-z[i]
        for j in range(0,n):
            newx.append(x[i]+(float(j)*frac*delta_x))
            newy.append(y[i]+(float(j)*frac*delta_y))
            newz.append(z[i]+(float(j)*frac*delta_z))
    newx.append(x[-1])
    newy.append(y[-1])
    newz.append(z[-1])
    return newx, newy, newz

def main():
    print('---------')
    print('framepath')
    print('---------')
    print('framepath version = {0}'.format(__version__))
    print('molgraph version = {0}'.format(mg.__version__))
    print('beacon_utils version = {0}'.format(bu.__version__))
    print(' ')    
    for line in bu.repheader():  # write run environment data
        print('{0}'.format(line))
    # testing code
    todeg = 180.0/math.pi
    ref_t = [1.0, 0.0, 0.0]
    ref_n = [0.0, 1.0, 0.0]
    ref_b = [0.0, 0.0, 1.0]
    # 30 degree pitch
    p1 = [0.8660254, 0.5, 0.0]
    p2 = [-0.5, 0.8660254, 0.0]
    p3 = [0.0, 0.0, 1.0]
    # 30 degree roll
    r1 = [0.0, 0.0, 1.0]
    r2 = [0.0, 0.8660254,0.5]
    r3 = [0.0,-0.5,0.8660254]
    # 30 degree yaw
    y1 = [0.8660254, 0.0, 0.5]
    y2 = [0.0, 1.0, 0.0]
    y3 = [-0.5, 0.0 ,0.8660254]
    
#    print('Check angles')
#    angles1 = angles(ref_t,ref_n,ref_b,p1,p2,p3)
#    print('{0} {1} {2}'.format(angles1[0]*todeg,angles1[1]*todeg,angles1[2]*todeg))
#    angles2 = angles(ref_t,ref_n,ref_b,r1,r2,r3)
#    print('{0} {1} {2}'.format(angles2[0]*todeg,angles2[1]*todeg,angles2[2]*todeg))
#    angles3 = angles(ref_t,ref_n,ref_b,y1,y2,y3)
#    print('{0} {1} {2}'.format(angles1[0]*todeg,angles1[1]*todeg,angles1[2]*todeg))
    
    #parser
    parser = argparse.ArgumentParser(description='Calculate helicity and bond path frame rotation angle profiles')
    parser.add_argument("infile", help="Name of input file, or file containing list of input filenames")
    parser.add_argument("atom_1_name", help="First atom name specifying BCP of interest")
    parser.add_argument("atom_2_name", help="Second atom name specifying BCP of interest")
    parser.add_argument("--configfile",help="File containing configuration data",default="framepath.cfg")
    parser.add_argument("--csvfile", help="Filename for CSV-format results if required",default='none')
    parser.add_argument("--matrix", help="Matrix to use for eigenproperties(hessrho, stress: default=hessrho)",default="hessrho")
    parser.add_argument("--scaling",help="Scale the path point eigenvectors by factor \n"+
                                         "Options: ellipticity, st_ellip_hessrho, st_ellip_stress, difflambda, none")
    parser.add_argument("--flipthresh",help="Eigenvector flipping threshold dot product value [default=-0.1]",default="-0.1")
    parser.add_argument("--interp",help="Path interpolation factor [integer,default =1 =no interpolation]",default="1")
    parser.add_argument("--verbose",help="Show more verbose screen output",action='store_true')
    #parser.add_argument("--directed",help="Construct the path as the full bond path in the order NCP1 - BCP - NCP2",choices=['yes','no'],default=['no'])
    #parser.add_argument("--frame", help="Names of vectors to use as frame angles in the order: tangent, normal, binormal ",
    #                              nargs="3", 
    #                              choices=['HessRho_EigVec1','HessRho_EigVec2','HessRho_EigVec3',
    #                                       'Stress_EigVec1','Stress_EigVec2','Stress_EigVec3',
    #                                       'auto'],
    #                              default=['HessRho_EigVec3','HessRho_EigVec1','HessRho_EigVec2'])                               
    args = parser.parse_args()
    infile = os.path.abspath(args.infile)
    atom1 = args.atom_1_name
    atom2 = args.atom_2_name
    matrix = args.matrix
    csvfile = args.csvfile
    configfile = os.path.abspath(args.configfile)
    checkconfig(configfile)
    flipthresh=float(args.flipthresh)
    scaling = args.scaling
    verbose = args.verbose
    interp = int(args.interp)

    if scaling == 'none':  # set scaling flag
        scalevec = False
        print('No eigenvector scaling performed - unit eigenvectors used')
    else:
        scalevec = True
        print('Eigenvector scaling active: mode is >{0}<'.format(scaling))
    
    # Build input file list
    filelist = []
    # determine if the specified input file is a single file or a filelist itself   
    if infile.endswith('.txt'):  # this is a file list
        with open(infile,'r') as listfile:
            for line in listfile:
                if not (line.startswith('#') or len(line.strip()) == 0 ):
                    filelist.append(line.strip())
    else:                        # This is a single file
        filelist.append(infile)
    # if CSV has been requested, prepare a list of strings for output    
    if (not csvfile == 'none'):
        csvresults = []        
    
    
    # fetch and check the path to the QTAIM executable
    iswindows=False
    if sys.platform.startswith('win'):   # double up directory slashes if running on Windows
        iswindows=True
        aimcode = aimcode.replace('\\','\\\\')
    # check that various files exist
    if (not os.path.isfile(configfile)):
        print('Config file {0} does not exist!'.format(configfile))
        sys.exit()
    else:
        print('Config file: {0}'.format(configfile))                    
    # parse config file
    config = configparser.ConfigParser()
    config.read(configfile)
    aimcode = os.path.normpath(config['DEFAULT']['aimpath'])
    if (not os.path.isfile(aimcode)):
        print('AIMAll executable {0} does not exist!'.format(aimcode))
        sys.exit()
    else:
        print('AIM executable: {0}'.format(aimcode))
    if iswindows:   # double up directory slashes if running on Windows
        aimcode = aimcode.replace('\\','\\\\')
        
        
    # get named BCP
    bcplabel=sortlabel(atom1+'-'+atom2)
    
    
    # LOOP OVER INPUT FILES ============================================================

    framenum = 0
    print('==========')    
    for fname in filelist:  # files in input list
        framenum = framenum + 1
        if iswindows:   # double up directory slashes if running on Windows
            fname = fname.replace('\\','\\\\')
        if (not os.path.isfile(fname)):  # check that input file exists
            print('Input file {0} does not exist!'.format(fname))
            sys.exit()
        else:
            print('Input file: {0}'.format(fname))   
        # replace .sumviz file extension on fname to get name of .wfx file
        wfname = fname.replace('.sumviz','.wfx')
        if (not os.path.isfile(wfname)): # test if wavefunction file exists
            print('Wavefunction file {0} does not exist'.format(wfname))
            sys.exit()
        else:
            print('Wavefunction file: {0}'.format(wfname))       
        if iswindows:   # double up directory slashes if running on Windows
            wfname = wfname.replace('\\','\\\\')
        
        # get directory path, file name and file name stem
        fnamepath, localfname = os.path.split(fname)
        fnameroot, fnamext = os.path.splitext(localfname)
        
        # Fetch molecular graph from file
        thismg = mg.Molgraph()
        thismg.read(fname)
        total_e = thismg.mol_energy  # get total energy
        for cp in thismg.cplist:  # sort the CP labels
            cp.connected = sortlabel(cp.connected)
        print('Loaded molecular graph from {0}'.format(fname))
    
    
        # find the BCP of interest   
        thiscp = None
        for cp in thismg.cplist:  # find the named BCP  
            if (cp.type == 'BCP' and bcplabel == cp.connected):  # found the BCP of interest
                thiscp = cp
                break
        if thiscp == None:   # if we didn't find the named CP, exit
            print('BCP named {0} was not found - try reversing the order of the atom names'.format(bcplabel))
            sys.exit()    
        if len(thiscp.pathlist) == 0:  # if no path information on this BCP, exit
            print('Cannot find path information for BCP {0}'.format(bcplabel))
            sys.exit()
        
        # Extract useful scalars from bondpath
        nucnucdist = thiscp.GBL_II
        ncpncpdist = thiscp.GBL_I
        bpl = thiscp.BPL
        
        # print path names and get lists of path points back
        print('For BCP {0}, found the paths:'.format(bcplabel))
        thispath1 = thiscp.pathlist[0]
        thispath2 = thiscp.pathlist[1]
        endatom1 = thispath1.description.split()[-1]
        endatom2 = thispath2.description.split()[-1]
    
        # calculate straight line distances and initialize calculated path lengths to zero
        bcpnucdist1 = 0.0   # BCP - NCP 1 distance
        bcpnucdist2 = 0.0   # BCP - NCP 2 distance
        path1dist = 0.0     # BPL (BCP -> NCP 1)
        path2dist = 0.0     # BPL (BCP -> NCP 2)        

        # Assemble paths and calculate cumulative distances
        # BCP-NCP1 distances assumed positive
        # BCP-NCP2 distances assumed negative
        print('{0}'.format(thispath1.description))
        patharray1 = []
        p1x = thispath1.path_x
        p1y = thispath1.path_y
        p1z = thispath1.path_z
        if interp > 1:
            p1x, p1y, p1z = interp3d(p1x,p1y,p1z,interp)
            print('Interpolated path factor {0}'.format(interp))
        for i in range(0,len(p1x)):
            patharray1.append( [p1x[i], p1y[i], p1z[i]] )
        patharray1dist = pathlength(patharray1)
        path1dist = patharray1dist[-1]  # This path's contribution to BPL
        
        print('{0}'.format(thispath2.description))
        patharray2 = []
        p2x = thispath2.path_x
        p2y = thispath2.path_y
        p2z = thispath2.path_z
        if interp > 1:
            p2x, p2y, p2z = interp3d(p2x,p2y,p2z,interp)
            print('Interpolated path factor {0}'.format(interp))
        for i in range(0,len(p2x)):
            patharray2.append( [p2x[i], p2y[i], p2z[i]] )
        patharray2dist = pathlength(patharray2)
        path2dist = patharray2dist[-1]  # This path's contribution to BPL
        patharray2dist = [-1.0*dist for dist in patharray2dist]  # make cumulative distances negative
        
            
        # Call external code to evaluate QTAIM quantities along paths
        results1 = patheval(patharray1,aimcode,wfname)
        with open('aimext1_out.log','w') as fdump:
            fdump.write(results1)
        framelist1 = []
        parse_aimext(results1.splitlines(), framelist1,verbose)  # send results to parse as list of line strings
                                                         # return list of CriticalPoint objects as framelist1
        results2 = patheval(patharray2,aimcode,wfname)
        with open('aimext2_out.log','w') as fdump:  # dump output log
            fdump.write(results2)
        framelist2 = []
        parse_aimext(results2.splitlines(), framelist2,verbose)  # send results to parse as list of line strings
                                                         # return list of CriticalPoint objects as framelist2
                     
            
        # Calculate frame angles for all frames
        #frameangles1 = frameangles(framelist1,'HessRho_EigVec3','HessRho_EigVec1','HessRho_EigVec2')
        #frameangles2 = frameangles(framelist2,'HessRho_EigVec3','HessRho_EigVec1','HessRho_EigVec2')
               
        # initialize output arrays for .xyz file
        xyzlines = []
        nuclabels = []
        nuc_coords = []
        
        
        # Start building .xyz frame using atoms and specified BCP
        start_x = thiscp.pos_x   # x-coordinate of BCP
        start_y = thiscp.pos_y   # y-coordinate of BCP
        start_z = thiscp.pos_z   # z-coordinate of BCP
        natoms = len(thismg.atom_x)
        for i in range (0,natoms):  # add atom symbols and coordinates, remove trailing digits from symbols
            nuclabels.append(thismg.atom_label[i].strip('0123456789'))
            nuc_coords.append([thismg.atom_x[i], thismg.atom_y[i], thismg.atom_z[i]])        
        buildxyzframe(xyzlines, nuclabels, nuc_coords)                   # add nuclear coordinates
        buildxyzframe(xyzlines, ['Au'], [[start_x, start_y, start_z]])   # add BCP of selected bond 
        
        
        # get eigenvector and eigenvalue lists for paths 1 and 2
        
        if matrix == 'hessrho':  # HessRho eigenvectors
            # get and normalize unit vectors
            path1e1 = [bu.unitvec(cp.HessRho_EigVec1) for cp in framelist1 ]   
            path1e2 = [bu.unitvec(cp.HessRho_EigVec2) for cp in framelist1 ]
            path2e1 = [bu.unitvec(cp.HessRho_EigVec1) for cp in framelist2 ]  
            path2e2 = [bu.unitvec(cp.HessRho_EigVec2) for cp in framelist2 ]
            if (scaling == 'ellipticity' or scaling =='difflambda' or scaling =='none'):  # Hessian eigvals (conventional)
                path1lambda1 = [cp.HessRho_EigVals[0] for cp in framelist1 ]
                path1lambda2 = [cp.HessRho_EigVals[1] for cp in framelist1 ]
                path1lambda3 = [cp.HessRho_EigVals[2] for cp in framelist1 ]
                path2lambda1 = [cp.HessRho_EigVals[0] for cp in framelist2 ]
                path2lambda2 = [cp.HessRho_EigVals[1] for cp in framelist2 ]
                path2lambda3 = [cp.HessRho_EigVals[2] for cp in framelist2 ]
            else:
                print(scaling)
                print('The combination: --matrix={0}, --scaling={1} is not allowed'.format(matrix,scaling))
                sys.exit()
                
        else:                    # Stress Tensor eigenvectors
            # get and normalize unit vectors
            path1e1 = [bu.unitvec(cp.Stress_EigVec1) for cp in framelist1 ]  
            path1e2 = [bu.unitvec(cp.Stress_EigVec2) for cp in framelist1 ]
            path2e1 = [bu.unitvec(cp.Stress_EigVec1) for cp in framelist2 ]  
            path2e2 = [bu.unitvec(cp.Stress_EigVec2) for cp in framelist2 ]
            if (scaling == 'st_ellip_hessrho' or scaling =='st_ellip_stress' or scaling =='none'):  # Stress Tensor eigenvals
                path1lambda1 = [cp.Stress_EigVals[0] for cp in framelist1 ]
                path1lambda2 = [cp.Stress_EigVals[1] for cp in framelist1 ]
                path1lambda3 = [cp.Stress_EigVals[2] for cp in framelist1 ]
                path2lambda1 = [cp.Stress_EigVals[0] for cp in framelist2 ]
                path2lambda2 = [cp.Stress_EigVals[1] for cp in framelist2 ]
                path2lambda3 = [cp.Stress_EigVals[2] for cp in framelist2 ]
            else:
                print('The combination: --matrix={0}, --scaling={1} is not allowed'.format(matrix,scaling))
                sys.exit()                
    
        # Filter e1 and e2 eigenvectors for pi-radian flips
        # Scan over e1 eigenvectors and e2 eigenvectors separately
        # default flipthresh = -0.1
        
        # For path 1
        refe1 = path1e1[0]  # at the BCP
        refe2 = path1e2[0]
        for i in range(1,len(path1e1)):
            thise1 = path1e1[i]
            thise2 = path1e2[i]
            compare_dp = bu.dotprod(thise1,refe1)  # CHECKING e1
            if (compare_dp < flipthresh):  # check if there was a flip, reverse eigenvectors if there was
                newe1 = [-1.0*thise1[0], -1.0*thise1[1], -1.0*thise1[2]]
                path1e1[i] = newe1
                thise1 = newe1
            compare_dp = bu.dotprod(thise2,refe2)  # CHECKING e2
            if (compare_dp < flipthresh):  # check if there was a flip, reverse eigenvectors if there was
                newe2 = [-1.0*thise2[0], -1.0*thise2[1], -1.0*thise2[2]]
                path1e2[i] = newe2
                thise2 = newe2
            refe1 = thise1  # keep the current eigenvector as the reference for the next step
            refe2 = thise2 
        # For path 2
        refe1 = path2e1[0]  # at the BCP
        refe2 = path2e2[0]
        for i in range(1,len(path2e1)):
            thise1 = path2e1[i]
            thise2 = path2e2[i]
            compare_dp = bu.dotprod(thise1,refe1)  # CHECKING e1
            if (compare_dp < flipthresh):  # check if there was a flip, reverse eigenvectors if there was
                newe1 = [-1.0*thise1[0], -1.0*thise1[1], -1.0*thise1[2]]
                path2e1[i] = newe1
                thise1 = newe1
            compare_dp = bu.dotprod(thise2,refe2)  # CHECKING e2
            if (compare_dp < flipthresh):  # check if there was a flip, reverse eigenvectors if there was
                newe2 = [-1.0*thise2[0], -1.0*thise2[1], -1.0*thise2[2]]
                path2e2[i] = newe2
                thise2 = newe2
            refe1 = thise1  # keep the current eigenvector as the reference for the next step
            refe2 = thise2
        # filtering done
            
        path1dplist1 = [ bu.dotprod(path1e1[i],path1e1[i-1]) for i in range(1,len(path1e1)) ]
        path1dplist2 = [ bu.dotprod(path1e2[i],path1e2[i-1]) for i in range(1,len(path1e2)) ]
        path2dplist1 = [ bu.dotprod(path2e1[i],path2e1[i-1]) for i in range(1,len(path2e1)) ]
        path2dplist2 = [ bu.dotprod(path2e2[i],path2e2[i-1]) for i in range(1,len(path2e2)) ]
        p1dp1 = [ (i,path1dplist1[i]) for i in range (0,len(path1dplist1)) if path1dplist1[i] < flipthresh ]
        p1dp2 = [ (i,path1dplist2[i]) for i in range (0,len(path1dplist2)) if path1dplist2[i] < flipthresh ]
        p2dp1 = [ (i,path2dplist1[i]) for i in range (0,len(path2dplist1)) if path2dplist1[i] < flipthresh ]
        p2dp2 = [ (i,path2dplist2[i]) for i in range (0,len(path2dplist2)) if path2dplist2[i] < flipthresh ]
        if len(p1dp1)+len(p1dp2)+len(p2dp1)+len(p2dp2) > 0:
            print('Negative Path 1 e1 dotproducts')
            print(p1dp1)
            print('Negative Path 1 e2 dotproducts')
            print(p1dp2)
            print('Negative Path 2 e1 dotproducts')
            print(p2dp1)
            print('Negative Path 2 e2 dotproducts')
            print(p2dp2)
             
        # prepare path point labels for .xyz file
        pathlabel = 'He'    
        vecpath1 = []  # vectors associated with path points vecpath[i] for e1 
        tippath1 = []  # coordinates of tip path p(i)+current_vec(i)    for e1
        vecpath2 = []  # vectors associated with path points vecpath[i] for e2 
        tippath2 = []  # coordinates of tip path p(i)+current_vec(i)    for e2
        vecpath1m = []  # vectors associated with path points vecpath[i] for -e1 
        tippath1m = []  # coordinates of tip path p(i)+current_vec(i)    for -e1
        vecpath2m = []  # vectors associated with path points vecpath[i] for -e2 
        tippath2m = []  # coordinates of tip path p(i)+current_vec(i)    for -e2        
        path1factorlist = []  # list of vector scaling factors
        count = 0
        if interp > 1:
            interp_msg = ',interpolation factor {0}'.format(interp)
        else:
            interp_msg = ''
        
        ###########################################
        # BUILD PATHS AND CALCULATE THEIR LENGTHS #
        ###########################################
        
        #  ===== PATH 1
        start = patharray1[0]
        end = patharray1[-1]
        dx = start[0]-end[0]
        dy = start[1]-end[1]
        dz = start[2]-end[2]
        bcpnucdist1 = math.sqrt((dx*dx)+(dy*dy)+(dz*dz))  # BCP-NCP1 straight-line distance
        
        # build the filename to hold the path data using fnameroot
        pathfilename1 = fnameroot+'_'+bcplabel+'_'+endatom1+'.path'
        with open(pathfilename1,'w') as pathfile:  ### write path data to the screen and a file
            # FILE HEADER
            if (verbose):
                print('====')
            pathfile.write('Path data created by framepath version '+__version__+interp_msg+'\n')
            line = 'Input file: {0}'.format(fname)
            if (verbose):
                print(line)
            pathfile.write(line+'\n')
            line = 'Description: {0}'.format(thispath1.description)
            if (verbose):
                print(line)
            pathfile.write(line+'\n')            
            line = 'Start: {0}'.format(bcplabel)
            if (verbose):
                print(line)
            pathfile.write(line+'\n')
            line = 'End: {0}'.format(endatom1)
            if (verbose):
                print(line)
            pathfile.write(line+'\n')
            line = 'Scaling: {0}'.format(scaling)
            if (verbose):
                print(line)
            pathfile.write(line+'\n')
            line = 'Path eigenvector data: path coordinates, scaled e1, scaled e2'
            if (verbose):
                print(line)
            pathfile.write(line+'\n')
            line = 'Scaled eigenvectors for {0} : {1} path points'.format(matrix,len(patharray1))
            if (verbose):
                print(line)
            pathfile.write(line+'\n')
            # END OF FILE HEADER
            for i in range (0,len(patharray1)):  # construct and measure tip paths for segment 1
                p = patharray1[i]
                count = count + 1 
                e1 = path1e1[i]
                e2 = path1e2[i]
                #
                lambda1 = path1lambda1[i]
                lambda2 = path1lambda2[i]
                lambda3 = path1lambda3[i]            
                # ensure normalization of eigenvectors
                #modulus1 = bu.modvec(e1)
                #modulus2 = bu.modvec(e2)
                vec1 = bu.unitvec(e1)
                vec2 = bu.unitvec(e2)
                    
                # scale if requested
                if (scaling == 'ellipticity' or scaling == 'st_ellip_hessrho'):  # scale the vectors by ellipticity
                    factor = (lambda1 / lambda2) - 1.0  # standard ellipticity
                elif (scaling == 'st_ellip_stress'):
                    factor = (lambda2 / lambda1) - 1.0  # alternative stress tensor ellipticity
                elif (scaling == 'difflambda'):  # lambda2 - lambda1
                    factor = (lambda2 - lambda1)  # lambda2 - lambda1
                elif (scaling == 'none'):
                    factor = 1.0
                else:
                    print('Select a valid scaling factor with --scaling')
                    sys.exit()
                path1factorlist.append(factor)
                tempvec1 = [factor*vec1[0], factor*vec1[1], factor*vec1[2] ]
                tempvec2 = [factor*vec2[0], factor*vec2[1], factor*vec2[2] ]
                vec1m = [-1.0*factor*vec1[0], -1.0*factor*vec1[1], -1.0*factor*vec1[2] ]
                vec2m = [-1.0*factor*vec2[0], -1.0*factor*vec2[1], -1.0*factor*vec2[2] ]
                vec1 = tempvec1
                vec2 = tempvec2
                
                formatstring = '{0:>16.9E} {1:>16.9E} {2:>16.9E} {3:>16.9E} {4:>16.9E} {5:>16.9E} {6:>16.9E} {7:>16.9E} {8:>16.9E}'
                line = formatstring.format(p[0],p[1],p[2],vec1[0],vec1[1],vec1[2],vec2[0],vec2[1],vec2[2])
                if (verbose):
                    print(line)
                pathfile.write(line+'\n')
                # construct positions of vector tip points
                tippath1.append([p[0]+vec1[0], p[1]+vec1[1], p[2]+vec1[2]])
                tippath2.append([p[0]+vec2[0], p[1]+vec2[1], p[2]+vec2[2]])
                vecpath1.append(vec1)  # save scaled e1 vector
                vecpath2.append(vec2)  # save scaled e2 vector
                tippath1m.append([p[0]+vec1m[0], p[1]+vec1m[1], p[2]+vec1m[2]])
                tippath2m.append([p[0]+vec2m[0], p[1]+vec2m[1], p[2]+vec2m[2]])
                vecpath1m.append(vec1m)  # save scaled -e1 vector
                vecpath2m.append(vec2m)  # save scaled -e2 vector
                
                #print('{0:>16.9E} {1:>16.9E} {2:>16.9E} {3:>16.9E} {4:>16.9E} {5:>16.9E} {6:>16.9E} {7:>16.9E} {8:>16.9E}'.format(
                #        p[0],      p[1],      p[2],      vec1[0],   vec1[1],   vec1[2],   vec2[0],   vec2[1],   vec2[2])         )               
                ## construct positions of vector tip points
                #tippath1.append([p[0]+vec1[0], p[1]+vec1[1], p[2]+vec1[2]])
                #tippath2.append([p[0]+vec2[0], p[1]+vec2[1], p[2]+vec2[2]])
                #vecpath1.append(vec1)  # save scaled e1 vector
                #vecpath2.append(vec2)  # save scaled e2 vector
                   
    
        # Calculate vector tip path lengths for both path segments
        # = distance travelled by tip of selected unit length eigenvector swept out along path
        path1vec1length = pathlength(tippath1)[-1]
        path1vec2length = pathlength(tippath2)[-1]
        path1vec1minuslength = pathlength(tippath1m)[-1]
        path1vec2minuslength = pathlength(tippath2m)[-1]
        
        # optionally, output the dependendence of scaling factor on distance along bondpath from BCP
        if (verbose):
            print('--------')
            print('Scaling factor profile for BCP {0} - NCP {1} '.format(bcplabel,endatom1))
            print('Columns: Distance along bond path from BCP, vector scale factor (e.g. ellipticity)')
            for i in range(0,len(patharray1dist)):
                print('{0:>16.9E} {1:>16.9E}'.format(patharray1dist[i],path1factorlist[i]))
            print('--------')
        
        # write set of frames
        print('Adding {0} points for BCP-NCP path 1'.format(len(patharray1)))    
        buildxyzframe(xyzlines, ['He']*len(patharray1), patharray1, vecpath1)
        buildxyzframe(xyzlines, ['N ']*len(patharray1), patharray1, vecpath2)            
    
        # ===== PATH 2  
        vecpath1 = []  # vectors associated with path points vecpath[i] for e1 
        tippath1 = []  # coordinates of tip path p(i)+current_vec(i)    for e1
        vecpath2 = []  # vectors associated with path points vecpath[i] for e2 
        tippath2 = []  # coordinates of tip path p(i)+current_vec(i)    for e2
        vecpath1m = []  # vectors associated with path points vecpath[i] for -e1 
        tippath1m = []  # coordinates of tip path p(i)+current_vec(i)    for -e1
        vecpath2m = []  # vectors associated with path points vecpath[i] for -e2 
        tippath2m = []  # coordinates of tip path p(i)+current_vec(i)    for -e2        
        path2factorlist = []  # list of scaling factors
       
        count = 0
        start = patharray2[0]
        end = patharray2[-1]
        dx = start[0]-end[0]
        dy = start[1]-end[1]
        dz = start[2]-end[2]
        bcpnucdist2 = math.sqrt((dx*dx)+(dy*dy)+(dz*dz))  # BCP-NCP2 straight-line distance
        # build the filename to hold the path data using fnameroot
        pathfilename2 = fnameroot+'_'+bcplabel+'_'+endatom2+'.path'
        with open(pathfilename2,'w') as pathfile:  ### write path data to the screen and a file
            # FILE HEADER
            if (verbose):
                print('====')
            pathfile.write('Path data created by framepath version '+__version__+interp_msg+'\n')
            line = 'Input file: {0}'.format(fname)
            if (verbose):
                print(line)
            pathfile.write(line+'\n')
            line = 'Description: {0}'.format(thispath2.description)
            if (verbose):
                print(line)
            pathfile.write(line+'\n')    
            line = 'Start: {0}'.format(bcplabel)
            if (verbose):
                print(line)
            pathfile.write(line+'\n')
            line = 'End: {0}'.format(endatom2)
            if (verbose):
                print(line)
            pathfile.write(line+'\n')
            line = 'Scaling: {0}'.format(scaling)
            if (verbose):
                print(line)
            pathfile.write(line+'\n')
            line = 'Path eigenvector data: path coordinates, scaled e1, scaled e2'
            if (verbose):
                print(line)
            pathfile.write(line+'\n')
            line = 'Scaled eigenvectors for {0} : {1} path points'.format(matrix,len(patharray2))
            if (verbose):
                print(line)
            pathfile.write(line+'\n')        
            # END OF FILE HEADER
            for i in range (0,len(patharray2)):  # construct and measure tip paths for segment 2
                p = patharray2[i]
                count = count + 1 
                e1 = path2e1[i]
                e2 = path2e2[i]
                #e3 = cp.HessRho_EigVec3
                lambda1 = path2lambda1[i]
                lambda2 = path2lambda2[i]
                lambda3 = path2lambda3[i]            
                # ensure normalization of eigenvectors
                #modulus1 = bu.modvec(e1)
                #modulus2 = bu.modvec(e2)
                vec1 = bu.unitvec(e1)
                vec2 = bu.unitvec(e2)
                    
                # scale if requested
                if (scaling == 'ellipticity' or scaling == 'st_ellip_hessrho'):  # scale the vectors by ellipticity
                    factor = (lambda1 / lambda2) - 1.0  # standard ellipticity
                elif (scaling == 'st_ellip_stress'):
                    factor = (lambda2 / lambda1) - 1.0  # alternative stress tensor ellipticity
                elif (scaling == 'difflambda'):  # lambda2 - lambda1
                    factor = (lambda2 - lambda1)        # lambda2 - lambda1
                elif (scaling == 'none'):
                    factor = 1.0
                else:
                    print('Select a valid scaling factor with --scaling')
                    sys.exit()
                path2factorlist.append(factor)
                tempvec1 = [factor*vec1[0], factor*vec1[1], factor*vec1[2] ]
                tempvec2 = [factor*vec2[0], factor*vec2[1], factor*vec2[2] ]
                vec1m = [-1.0*factor*vec1[0], -1.0*factor*vec1[1], -1.0*factor*vec1[2] ]
                vec2m = [-1.0*factor*vec2[0], -1.0*factor*vec2[1], -1.0*factor*vec2[2] ]
                vec1 = tempvec1
                vec2 = tempvec2
                formatstring = '{0:>16.9E} {1:>16.9E} {2:>16.9E} {3:>16.9E} {4:>16.9E} {5:>16.9E} {6:>16.9E} {7:>16.9E} {8:>16.9E}'
                line = formatstring.format(p[0],p[1],p[2],vec1[0],vec1[1],vec1[2],vec2[0],vec2[1],vec2[2])
                if (verbose):
                    print(line)
                pathfile.write(line+'\n')
    
                # construct positions of vector tip points
                tippath1.append([p[0]+vec1[0], p[1]+vec1[1], p[2]+vec1[2]])
                tippath2.append([p[0]+vec2[0], p[1]+vec2[1], p[2]+vec2[2]])
                vecpath1.append(vec1)  # save scaled e1 vector
                vecpath2.append(vec2)  # save scaled e2 vector
                tippath1m.append([p[0]+vec1m[0], p[1]+vec1m[1], p[2]+vec1m[2]])
                tippath2m.append([p[0]+vec2m[0], p[1]+vec2m[1], p[2]+vec2m[2]])
                vecpath1m.append(vec1m)  # save scaled e1 vector
                vecpath2m.append(vec2m)  # save scaled e2 vector
                   
            
        # Calculate vector tip path lengths for both path segments
        # = distance travelled by tip of selected unit length eigenvector swept out along path
        path2vec1length = pathlength(tippath1)[-1]
        path2vec2length = pathlength(tippath2)[-1]
        path2vec1minuslength = pathlength(tippath1m)[-1]
        path2vec2minuslength = pathlength(tippath2m)[-1]
        
        # optionally, output the dependendence of scaling factor on distance along bondpath from BCP
        if (verbose):
            print('--------')
            print('Scaling factor profile for BCP {0} - NCP {1} '.format(bcplabel,endatom2))
            print('Columns: Distance along bond path from BCP, vector scale factor (e.g. ellipticity)')
            for i in range(0,len(patharray2dist)):
                print('{0:>16.9E} {1:>16.9E}'.format(patharray2dist[i],path2factorlist[i]))
            print('--------')
        
        # write set of frames
        print('Adding {0} points for BCP-NCP path 2'.format(len(patharray2)))    
        buildxyzframe(xyzlines, ['He']*len(patharray2), patharray2, vecpath1)
        buildxyzframe(xyzlines, ['N ']*len(patharray2), patharray2, vecpath2)  
        
        # Write all points (nuclei, BCP, path points+vectors) to .xyz file
        pathxyzname = atom1+'-'+atom2+'_path_'+'{0:04d}'.format(framenum)+'.xyz'
        with open(pathxyzname,'w') as testf:
            frametoxyz(testf, xyzlines, '{0} {1}'.format(fname,bcplabel))
       
        # print path angles
        #print('Length  Pitch  Roll  Yaw')
        #for i in range(0,len(patharray1dist)):
        #    print('{0:.9E} {1:.9E} {2:.9E} {3:.9E}'.format(patharray1dist[i],frameangles1[i][0]*todeg,
        #                                                                     frameangles1[i][1]*todeg,
        #                                                                     frameangles1[i][2]*todeg))
        #
        #pitch = 0.0
        #roll = 0.0
        #yaw = 0.0
        
        # 
        #print('PathArray1Distances {0}'.format(len(patharray1dist)))
        #print(patharray1dist) 
        #print('PathArray2Distances {0}'.format(len(patharray2dist)))
        #print(patharray2dist)
        #print('Path1lambda1 {0}'.format(len(path1lambda1list)))
        #print(path1lambda1list) 
        #print('Path2lambda1 {0}'.format(len(path2lambda1list)))
        #print(path2lambda1list)
        #cpath1 = list(zip(patharray1dist, path1lambda1, path1lambda2, path1factorlist))
        #cpath2 = list(zip(patharray2dist, path2lambda1, path2lambda2, path2factorlist))
        #cpath2.reverse()
        #print('=======')
        #print('Bond path scale factor profile along selected bond')
        #print('Distance           Lambda_1           Lambda_2          ScaleFactor')
        #for tup in cpath2:
        #    print('{0}  {1}  {2}  {3}'.format(tup[0],tup[1],tup[2],tup[3]))
        #print(cpath1)
        #for tup in cpath1:
        #    print('{0}  {1}  {2}  {3}'.format(tup[0],tup[1],tup[2],tup[3]))
        #print(path1factorlist)
        #print(path2factorlist)
        
        print(' ')
        print('Path distances summary')
        print('======================')
        print('Path 1 BCP {0}-{1} -> NCP {2} : {3} points'.format(endatom1,endatom2,endatom1,len(framelist1)))
        print('{0:>18} {1:>18} {2:>18} {3:>18} {4:>18} {5:>18}'.format('Geometric distance','Bond-path length',
                                                                       'Vector 1 TPL','Vector TPL',
                                                                       'Vector 1` TPL','Vector 2` TPL'))
        print('{0:>18.9E} {1:>18.9E} {2:>18.9E} {3:>18.9E}  {4:>18.9E} {5:>18.9E}'.format(bcpnucdist1,path1dist,
                                                                   path1vec1length,path1vec2length,
                                                                   path1vec1minuslength,path1vec2minuslength))
        #      
        print('Path 2 BCP {0}-{1} -> NCP {2} : {3} points'.format(endatom1,endatom2,endatom2,len(framelist2)))
        print('{0:>18} {1:>18} {2:>18} {3:>18} {4:>18} {5:>18}'.format('Geometric distance','Bond-path length',
                                                                       'Vector 1 TPL','Vector 2 TPL',
                                                                       'Vector 1` TPL','Vector 2` TPL'))
        print('{0:>18.9E} {1:>18.9E} {2:>18.9E} {3:>18.9E}  {4:>18.9E} {5:>18.9E}'.format(bcpnucdist2,path2dist,
                                                                   path2vec1length,path2vec2length,
                                                                   path2vec1minuslength,path2vec2minuslength))
        #
        curvature = (bpl - ncpncpdist)/ncpncpdist
        pathvec1sum = path1vec1length+path2vec1length
        pathvec2sum = path1vec2length+path2vec2length
        pathvec1_minus_sum = path1vec1minuslength+path2vec1minuslength
        pathvec2_minus_sum = path1vec2minuslength+path2vec2minuslength
        print('Complete bondpath {0}-{1}'.format(endatom1,endatom2))
        print('{0:>18} {1:>18} {2:>20} {3:>20} {4:>20} {5:>20}'.format('Geometric distance GBL_II','Bond-path length',
                                                       'e1 HelicityLength','e2 HelicityLength',
                                                       'e1` HelicityLength','e2` HelicityLength'))
        print('{0:>18.9E} {1:>18.9E} {2:>20.9E} {3:>20.9E} {4:>20.9E} {5:>20.9E}'.format(nucnucdist,bpl,
                                                                                         pathvec1sum,pathvec2sum,
                                                                                         pathvec1_minus_sum,pathvec2_minus_sum))
        print('Curvature (BPL-GBL_I)/GBL_I = {0}'.format(curvature))
        #print('DEBUG: file BPL - calculated BPL = {0}'.format(bpl-path1dist-path2dist))
        if (not csvfile =='none'):
            csvresults.append([fname, total_e, atom1, atom2, nucnucdist, bpl, curvature,
                               pathvec1sum, pathvec2sum,(pathvec1sum-bpl)/bpl, (pathvec2sum-bpl)/bpl,
                               pathvec1_minus_sum, pathvec2_minus_sum,(pathvec1_minus_sum-bpl)/bpl, (pathvec2_minus_sum-bpl)/bpl])
        print
         
    # END OF LOOP OVER INPUT FILES ===============================================================
    
    # Close output files and print results summary
    testf.close()     
    if (not csvfile == 'none'):
        print('Sending results to {0}'.format(csvfile))
        header = ['Generated by framepath version '+__version__,infile,atom1+'-'+atom2,'Eigenvectors from '+matrix+' Scale='+scaling,
                  'Filename, TotalEnergy, atom1, atom2, GBL_II, BPL, curvature=(BPL-GBL_I)/GBL_I, '+
                                                                  'H_length_e1(*), H_length_e2, Hf(*), Hf, '+
                                                                  'H_length_e1`(*), H_length_e2`, Hf`(*), Hf`'] 
        bu.csvdump(csvfile,header,csvresults)
    
if __name__ == '__main__':
    main()
    
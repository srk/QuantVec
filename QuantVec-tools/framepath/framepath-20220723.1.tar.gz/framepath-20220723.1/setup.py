# -*- coding: utf-8 -*-
"""setup.py: setuptools control."""

import re
from setuptools import setup

version = re.search(
    '^__version__\s*=\s*"(.*)"',
    open('framepath/framepath.py').read(),
    re.M
    ).group(1)

setup(
    name = "framepath",
    packages = ["framepath"],
    entry_points = {
        "console_scripts": ['framepath=framepath.framepath:main',]
        },
    version = version,
    author='Prof. Steven R. Kirk',
    author_email='stevenrkirk@gmail.com',
    description = "framepath",
    url = 'https://www.beaconresearch.org',
    )

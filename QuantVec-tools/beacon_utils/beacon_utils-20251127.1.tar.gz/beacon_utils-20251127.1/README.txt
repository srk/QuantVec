README for beacon_utils
=======================
Several utility functions

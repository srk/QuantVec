# -*- coding: utf-8 -*-
"""setup.py: setuptools control."""

import re
from setuptools import setup,find_packages

version = re.search(
    '^__version__\s*=\s*"(.*)"',
    open('wfx_to_xyz/wfx_to_xyz.py').read(),
    re.M
    ).group(1)

setup(
    name = "wfx_to_xyz",
    py_modules=['wfx_to_xyz'],
    packages=find_packages(),
    version = version,
    entry_points = {
        "console_scripts": [' wfx_to_xyz = wfx_to_xyz.wfx_to_xyz:main',]
        },    
    author='Prof. Steven R. Kirk',
    author_email='stevenrkirk@gmail.com',
    description = "wfx_to_xyz",
    url = 'https://www.beaconresearch.org',
    )

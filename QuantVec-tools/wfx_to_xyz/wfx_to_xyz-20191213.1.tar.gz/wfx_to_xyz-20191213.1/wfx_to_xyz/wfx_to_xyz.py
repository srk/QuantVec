# -*- coding: utf-8 -*-
"""
wfx_to_xyz
---------------------------------
Loops over all .wfx (atomic units) files in the current directory and recreates 
a multi-step.xyz file (Angstrom units)

Usage: wfx_to_xyz <inputfile/filelist> <output XYZ file name>


"""
from __future__ import print_function
import argparse, glob, sys

__version__ = "20191213.0001"

def getsection(f,tag1,tag2):
    """
    Return a list of strings from a section in the inputfile f, delimited by tag1 (start) and tag2 (end)
    """
    selected=[]
    foundit = False
    while True:
        line = f.readline()
        if tag1 in line:                     # found the starting tag, start line captures
           foundit = True
        elif ((foundit) and (tag2 in line)): # was in the delineated section, found the ending tag
            foundit = False
            break
        elif (foundit):                      # in the delineated section, capture the line
            selected.append(line)
    return(selected)
 

def main():
    parser = argparse.ArgumentParser(description="Extract atomic coordinates from .wfx files to simple XYZ format\n"+
                                                 "===============================================================")
    parser.add_argument("inputfile",help="Input file or filelist(.txt)")
    parser.add_argument("outputfile", help="XYZ file name for output")
    parser.add_argument("--verbose",help="Show more verbose screen output",action='store_true')
    args = parser.parse_args()
                    
    arglist = []
    verbose = args.verbose
    inputfile = args.inputfile
    countmode = False
    autoang = 0.52917721067 
    
    print("wfx_to_xyz")
    print("==========")
    print("Version {0}".format(__version__))
    if not inputfile.endswith(".wfx"):  # filelist case
        with open(inputfile,'r') as f:
            for line in f.readlines():
                if not (line.startswith('#') or line.strip() == ''):
                    arglist.append(line)
    else:
        arglist.append(inputfile)

    xyzfilename = args.outputfile
    with open(xyzfilename,'w') as xyzfile:
        for filename in arglist:
# open the specified file
            fin = filename.strip()
            print('Reading file: {0}'.format(fin))
            with open(fin,'r') as inpfile:
                title = getsection(inpfile,'<Title>','</Title>')[0]
                natoms = getsection(inpfile,'<Number of Nuclei>','</Number of Nuclei>')[0]
                atomnames = [s.strip().strip('0123456789') for s in getsection(inpfile,'<Nuclear Names>','</Nuclear Names>') ]
                coordstrings = [ s for s in  getsection(inpfile,'<Nuclear Cartesian Coordinates>','</Nuclear Cartesian Coordinates>') ]
                coords = []
                for s in coordstrings:
                    tokens = s.split()
                    x = float(tokens[0])*autoang
                    y = float(tokens[1])*autoang
                    z = float(tokens[2])*autoang
                    coords.append('{0: .10f} {1: .10f} {2: .10f}'.format(x,y,z))
                energy = getsection(inpfile,'<Energy ','</Energy ')[0]
                # write the frame
                xyzfile.write('{0}'.format(natoms))
                xyzfile.write('{0} E={1}\n'.format(title.strip(), energy.strip()))
                for i in range(0, int(natoms)):
                    xyzfile.write('{0: <3} {1}\n'.format(atomnames[i].strip(),coords[i].strip()))
# finished looping over files

if __name__ == '__main__':
    main()



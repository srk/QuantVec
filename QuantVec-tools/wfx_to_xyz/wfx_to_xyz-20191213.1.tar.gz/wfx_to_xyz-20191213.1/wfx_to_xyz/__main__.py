# -*- coding: utf-8 -*-


"""wfx_to_xyz .__main__: executed when wfx_to_xyz  directory is called as script."""


from .wfx_to_xyz  import main
main()

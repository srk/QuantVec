# -*- coding: utf-8 -*-


"""topviz.__main__: executed when topviz directory is called as script."""


from .topviz import main
main()
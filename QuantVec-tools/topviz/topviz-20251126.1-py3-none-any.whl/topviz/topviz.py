# -*- coding: utf-8 -*-
"""
topviz
@author: Steven R. Kirk and Samantha Jenkins, BEACON Research Group, College of Chemistry and Chemical Engineering, Hunan Normal University
"""
# imports for previous compatibility with Python 2.7 removed here as Python 2.x is EOL

# standard imports
import sys, argparse, os, os.path, re, mayavi, gzip, pngmeta

# Gooey builds
#from gooey import Gooey

# Mayavi imports
from traits.api import (List, Str, HasTraits, File, Instance, Bool, Float, Int, Range, RGBColor, on_trait_change, observe, Button,
                       Callable, Dict, Property, Trait )
from traitsui.api import (View, Item, Spring, Label, Heading, HGroup, HSplit, VGroup, Group, Tabbed, StatusItem, TitleEditor,
                          RGBColorEditor, ValueEditor, TreeEditor, TreeNode, TreeNodeObject, TableEditor, NullEditor, InstanceEditor,
                          ArrayEditor, UItem,
                          CheckListEditor, RangeEditor, ObjectColumn, ToolBar, NumericColumn, TextEditor, ValueEditor, VFold )
from traitsui.menu import Action, Menu, MenuBar, Separator
from traitsui.file_dialog import open_file
from pyface.api import FileDialog, OK
from traitsui.table_filter import MenuFilterTemplate, MenuTableFilter
from mayavi import mlab
from mayavi.core.api import PipelineBase
from mayavi.core.ui.api import MayaviScene, SceneEditor, MlabSceneModel
from objprint import objprint


# custom imports
import numpy as np
import molgraph as mg

#sys.settrace()
__version__ = "20251126.0001"

# Element data methods
def get_element_data(datafile):
    '''
    From 'datafile', return element properties as list of lists
    '''
    eldata = []
    with open(datafile) as f:
        lines = f.readlines()
        for line in lines:
            if not(line.startswith('#') or line.strip() == ''):  # for all except comment lines and blank lines
                tokens = line.split()
                elnum = int(tokens[0])                     # Element atomic number
                elsym = tokens[1].strip()                  # Element symbol
                elcovrad = float(tokens[2])                # Element covalent radius
                elatmrad = float(tokens[3])                # Element atomic radius
                elvdwrad = float(tokens[4])                # Element VDW radius
                irgb = tokens[5].strip('[]').split(',')    # Element colour RGB contributions 0-255 [R,G,B]
                elfrgb = [float(i)/255.0 for i in irgb]    # Element colour RGB contributions 0.0-1.0 [R,G,B]
                # add this element's data to the list
                eldata.append([elnum, elsym, elcovrad, elatmrad, elvdwrad, elfrgb])
    # sanity check
    if len(eldata) < 109:
        print('WARNING: found only {0} sets of element data in {1} - expected 109 or more'.format(len(eldata), datafile))
    return eldata

def get_element_property_dict(eldata, field):
    '''
    Given 'eldata', a list of lists of element properties, return a dict of specific properties, selected by 'field', keyed by element symbol
    '''
    elcols = {}
    for element in eldata:
        elnum = element[0]
        elsym = element[1]
        elcovrad = element[2]
        elatmrad = element[3]
        elvdwrad = element[4]
        elfrgb = element[5]
        if field == 'color':
            elcols[elsym] = elfrgb
        elif field == 'covrad':
            elcols[elsym] = elcovrad
        elif field == 'atmrad':
            elcols[elsym] = elatmrad
        elif field == 'vdwrad':
            elcols[elsym] = elvdwrad
    return elcols

# helper functions
def setplotobjvisibility(obj, status):
    '''
    Set the visibility flags on a specific Mayavi plot object
    '''
    obj.visible = status
    obj.actor.visible=status
    obj.actor.actor.visibility=status

def getplotobjvisibility(obj):
    '''
    Get the visibility flags on a specific Mayavi plot object
    '''    
    return(obj.actor.actor.visibility)

def readuntil(f, endpattern):
    """
    Read subsequent lines from file attached to descriptor 'f' and return them as a list, excluding
    a matching 'end' pattern
    """
    lines = []
    for line in f:
        if not line:
            print('Possible premature end of file')
            sys.exit()
        if endpattern in line:
            break
        else:
            lines.append(line.split('#')[0]) # strip everything after a '#' character, add it to the lines list
    return(lines)


# CLASSES

class ViewControl(HasTraits):
    '''
    Encapsulates the camera view 
    '''
#    azimuth = Float()
#    elevation = Float()
#    distance = Float()

#    def __init__(self, label='Camera',**traits):
#        HasTraits.__init__(self, **traits)
#        self._get_azimuth()
#        self._get_elevation()
#        self._get_distance()

#    @property
#    def _get_azimuth(self):
#        print('azimuth')
#        tuple = mlab.view()
#        print('tuple')
#        print(tuple)
#        az = Float(mlab.view()[0])
#        return az
    
#    @azimuth.setter
#    def _set_azimuth(self,azangle):
#        if azangle < 0.0:
#            azangle = 0.0
#        elif azangle > 360.0:
#            azangle = 360.0
#        mlab.view(azimuth=azangle)

#    @property
#    def _get_elevation(self):
#        print('elevation')
#        print(mlab.view())
#        #return(mlab.view()[1])
    
#    @elevation.setter
#    def _set_elevation(self,elangle):
#        if elangle < 0.0:
#            elangle = 0.0
#        elif elangle > 360:
#            elangle = 360.0
#        mlab.view(elevation=elangle)

#    @property
#    def _get_distance(self):
#        print('distance')
#        print(mlab.view())
#        #return(mlab.view()[2])
    
#    @distance.setter
#    def _set_distance(self,dist):
#        if dist < 0.0:
#            dist = 0.0
#        mlab.view(distance=dist)


class NamedFieldPath(mg.FieldPath):
   '''
   Derived class from molgraph FieldPath

   Parent class has fields
        self.description = ""
        self.path_x = []
        self.path_y = []
        self.path_z = []
        self.path_fieldvar = []
   '''
   pathtype = ''

   def __init__(self, px, py, pz, description, pathtype, matrix, path_fieldvar):
       super()
       self.path_x = px
       self.path_y = py
       self.path_z = pz
       self.description = description
       self.pathtype = pathtype
       self.matrix = matrix
       self.path_fieldvar = path_fieldvar


class FramePathList():
    '''
    Class to hold list of NamedFramePath objects, and associated molecular graph file name
    '''
    pathlist = []
    framepathname = ''

    def __init__(self,pathlist,framepathname):
        self.pathlist = pathlist
        self.framepathname = framepathname


class MGFileDialog(HasTraits):
    '''
    Molecular graph data file dialog
    '''
    # The name of the selected file:
    fname = File()
    file_name=None

    #-- Traits View Definitions ----------------------------------------------
    #view = View(HGroup(Item('fname', style='simple', springy=True, label='Input file'), is_save_file=False))

    def __init__(self):
        """
        Open a file dialog
        """
        #file_name = open_file(extensions=LineCountInfo(), id=demo_id)
        fname = open_file(default_directory=os.getcwd(),is_save_file=False)
        if fname != '':
            self.file_name = '{0}'.format(fname)


class SeqFileDialog(HasTraits):
    """
    Sequence file dialog
    """
    fname = File()
    file_name=None

    def __init__(self):
        """
        Open a file dialog
        """
        # fname = open_file(default_directory=os.getcwd(),is_save_file=False)
        dialog = FileDialog(action='open', default_path=os.getcwd())
        if dialog.open() == OK:
            fname = dialog.path
            print('Opened a file {0}'.format(fname))
            self.file_name = '{0}'.format(fname)           


class TFrameNode(HasTraits):
    '''
    Dummy base class for TFrame nodes in Tree view
    '''
    pass


class TMG(TFrameNode):
    name = Str('Molecular Graph')
    mg = None
    
    def __init__(self):
       self.name = 'Default MG Name'

    def loadmg(self,mgfile):
        self.mg = mg.Molgraph()
        self.mg.title = ''
        self.mg.read(mgfile)
        self.mg.title = mgfile


class TPath(TFrameNode):
    name = Str('Path')
    path = None
    plength = 0.0
    
    def __init__(self):
        self.name='New path'


class TFieldGrid(HasTraits):
    name = Str()
    itemtype=Str('Generic Field Item')
    grid = None
    gridmin = 0.0
    gridmax = 0.0
    
    def __init__(self):
        self.name='Default Gridded Field'


class TraitedCP(HasTraits):
    '''
    This is as minimal a Traited wrapper as possible around a molecular graph critical point
    '''
    def __init__(self,cp):
        #self.pathlist = []
        self.X = cp.pos_x
        self.Y = cp.pos_y
        self.Z = cp.pos_z
        self.field = cp.field
        self.filetype = cp.filetype
        self.Type = cp.type
        self.Number = 0
        self.Name = cp.connected
        self.Rho = cp.Rho
        #self.RhoNuc = Float()
        #self.GradRho = List( Float(0.0),Float(0.0),Float(0.0))
        #self.HessRho = []
        #self.HessRho_EigVals = List( Float(0.0),Float(0.0),Float(0.0) )
        #self.HessRho_EigVec1 = List( Float(0.0),Float(0.0),Float(0.0) )
        #self.HessRho_EigVec2 = List( Float(0.0),Float(0.0),Float(0.0) )
        #self.HessRho_EigVec3 = List( Float(0.0),Float(0.0),Float(0.0) )
        self.DelSqRho = cp.DelSqRho
        self.Ellipticity = cp.Ellipticity
        if self.Type == 'BCP':
            self.Metallicity = self.Rho/self.DelSqRho
            self.BPL = cp.BPL
            self.GBL_I = cp.GBL_I
            self.GBL_II = cp.GBL_II
            self.GBL_III = cp.GBL_III
            self.GBL_IV = cp.GBL_IV
        else:
            self.Metallicity = 0.0
            self.BPL = 0.0
            self.GBL_I = 0.0
            self.GBL_II = 0.0
            self.GBL_III = 0.0
            self.GBL_IV = 0.0
        self.V = cp.V
        self.G = cp.G
        self.K = cp.K
        self.L = cp.L
        #self.Vnuc = Float(0.0)
        #self.Ven = Float(0.0)
        #self.Vrep = Float(0.0)
        #self.DelSqV = Float(0.0)
        #self.DelSqVen = Float(0.0)
        #self.DelSqVrep = Float(0.0)
        #self.DelSqG = Float(0.0)
        #self.DelSqK = Float(0.0)
        #self.Stress = []
        #self.Stress_EigVals = List( Float(0.0),Float(0.0),Float(0.0))
        #self.Stress_EigVec1 = List( Float(0.0),Float(0.0),Float(0.0))
        #self.Stress_EigVec2 = List( Float(0.0),Float(0.0),Float(0.0))
        #self.Stress_EigVec3 = List( Float(0.0),Float(0.0),Float(0.0))
        #self.MinusDivStress = List( Float(0.0),Float(0.0),Float(0.0))
        #self.ESP = Float()
        #self.ESPNuc = Float()
        #self.ESPe = Float()
        #self.ESPeNuc = Float()
        #self.ESPn = Float()
        #self.ESPnNuc = Float()
        self.GBL_I = cp.GBL_I
        self.GBL_III = cp.GBL_III
        self.GBL_IV = cp.GBL_IV


class TraitedFrame(HasTraits):
    '''
    Traited frame
    '''
    framename = Str()
    title = Str()
    name = Str()
    framemg = TMG()
    sequencevar = Float()
    framedesc = List(Str)
    framevars = Dict()
    mgs = List(TMG)
    paths = List(TPath)
    scalargrids = List(TFieldGrid)
    vectorgrids = List(TFieldGrid)
    #MGList = List(TraitedCP)    

    def addmg(self, framemg):
       '''
       Add a molecular graph to a TraitedFrame as a Tree Node object
       '''
       self.framename = framemg.filename
       self.name = self.framename
       self.framemg = framemg  


class Sequence(HasTraits):
    '''
    Defines a top-level Sequence
    '''
    name = Str() 
    framelist = List(TraitedFrame) # TraitedFramelist()  # The list of TraitedFrame objects in this Sequence
    comment = List(Str(''))  # List of comment strings, initialized to empty strings

    def __init__(self):  # Initialize the Sequence object
        #print("\nSequence.__init__ : Initializing a new Sequence object")
        self.name = 'Default sequence name'
        self.metadata = {}
        self.comment = ['']
        self.framelist = [] # TraitedFramelist()
        #print('self.framelist has type {0}'.format(type(self.framelist)))
        #print("... after initialization")
        #print("\nSequence vars")
        #print(vars(self))
        #print("\nSequence.framelist vars")
        #print(vars(self.framelist))

    def listframes(self):  # list info on frames in this sequence
        '''
        List details of the frames currently in the sequence 
        '''
        print('Sequence title = {0}'.format(self.metadata['Title']))
        print('Sequence metadata dictionary:')
        print(self.metadata)
        print('Sequence contains {0} frames'.format(len(self.framelist)))
        for iframes in self.framelist:
            objprint(iframes.framemg, depth=2)
        print(' ==== Summary of loaded frames from seqviz ====')
        count = 0
        for frame in self.framelist:
            count = count + 1
            print('----- Frame {0} -----'.format(count))
            #objprint(frame.framemg, depth=3)
            print('Filename = {0}'.format(frame.framemg.mg.filename))
            print('Title = {0}'.format(frame.framemg.mg.title))
            frame.framemg.mg.title = frame.framemg.mg.filename
            print('Vars = {0}'.format(frame.framevars))
        print('This sequence has {0} frames'.format(len(self.framelist)))
        print('===============================================')
        #objprint(self,depth=3)

    def load_mgs_from_list(self, mgfilelist):  # Read a list of sumviz files into this sequence object as frames
        '''
        '''
        framecount = 0
        currentframe = None
        for thisfile in mgfilelist:
            # create a new frame
            newframe = TraitedFrame()
            newmg = TMG()
            newmg.loadmg(thisfile)
            # load MG into new frame
            newframe.framemg = newmg
            # add new frame to framelist
            self.framelist.append(newframe)

    def load_paths_from_list(self, pathlist):  # Read a list of path files, one by one, into frames in this sequence
        '''
        '''
        # TODO
        pass  

    def read_seqviz(self,filename,err,log_destination): # Read a seqviz file into this Sequence object
        '''
        Read a seqviz file into the Sequence object instance
        '''
        framecount = 0
        currentframe = None
        currenttag = 'none'
        print('Request to read sequence file {0}'.format(filename))
        # TODO check if file exists 
        with open(filename,'r') as f:
            # set current sequence to None
            # set current frame to None
            while True:
                try:
                    line = f.readline()
                except:
                    break
                line = line.partition('#')[0]
                #tagmatch = re.search(r'</?\w+>',line)
                tagmatch = re.search(r'<.+>',line)
                if tagmatch != None:  # change reading mode based on currently active tag
                    tagname = tagmatch.group(0)
                    #print('TAG: {0}'.format(tagname))
                    if tagname == '<Sequence>':     # sequence started
                        print('Found a new <Sequence>')
                        currenttag = 'sequence'
                    elif tagname == '</Sequence>':  # sequence ended
                        print('End of <Sequence>')
                        currenttag = 'end'
                        break                     
                    elif tagname == '<Frame>' and currenttag == 'sequence': # found a frame while in a sequence
                        currenttag = 'frame'
                        framecount = framecount + 1
                        print('    Found a new frame: {0}'.format(framecount))
                        # Initialize current frame as a new frame with number 'framecount', add frame to current sequence
                        newframe = TraitedFrame()
                        currentframe = newframe
                    elif tagname == '</Frame>':   # frame ended
                        print('Finished creating this frame, appending to framelist')
                        self.framelist.append(currentframe)
                        currenttag = 'sequence'
                    elif tagname == '<Frame Description>' and currenttag == 'frame':
                        framedesclines = readuntil(f,'</Frame Description>')
                        currentframe.framedesc = framedesclines
                        for fdl in framedesclines:
                            tokens = fdl.split('=')
                            if len(tokens) == 2:
                                currentframe.framevars[tokens[0].strip()]  = tokens[1].replace('"','').strip()
                    elif tagname == '<Molecular Graph>' and currenttag == 'frame':  # found an MG file while in a Frame  
                        print('ADDING AN MG')
                        currenttag = 'mg'
                        newmg = TMG()
                        mgfile = f.readline().split()[-1]
                        print('mgfile name is {0}'.format(mgfile))
                        #
                        # TODO Check if file exists
                        print('Parsed a filename: {0}'.format(mgfile))
                        newmg.loadmg(mgfile)
                        currentframe.framemg = newmg
                    elif tagname == '</Molecular Graph>': # mg ended
                        print('Finished adding the MG to the current frame')
                        currenttag = 'frame' 
                    elif tagname == '<Description>' and currenttag == 'sequence': # found a description while in a sequence
                        desclines = readuntil(f,'</Description>')
                        print('Parsed Description lines:')
                        for line in desclines:
                            #print(line)
                            tokens = line.split('=')
                            self.metadata[tokens[0].strip()]  = tokens[1].replace('"','').strip()
                            #print(self.metadata)
                        print('End of parsed Description lines')
                        #self.comment = list(':'.join(self.metadata.items()))
                        #print(self.comment)
                        # get description dictionary of current sequence
                else:
                    pass

            print(' ')
            print(' ---> Finished reading sequence file')
            self.name = self.metadata['Title']
            self.listframes()
            print('frames listed, now what')
            #sys.exit()            

    def write_seqviz(self,filename): # Write this Sequence object into a .seqviz file
        '''
        Write a seqviz file from the current sequence object
        '''
        # TODO
        pass
     
      
class SequenceList(HasTraits):
    name = Str('<unknown>')
    sequence = Instance(Sequence)
    traits_view = View(
        Item(name='sequence', editor=TreeEditor(), show_label=False),
        title='Sequence',
        resizable=True,
    )     
    
class AboutDialog(HasTraits):
    '''
    'About' information modal dialog
    '''
    message = Str("All about TopViz")
    ok_button = Button("OK")

    def _ok_button_fired(self):
        self.ui.dispose()

# =========== MODEL definition =======
class MyModel(HasTraits):
    '''
    Model object
    '''
    # 
    currentseq = None        # The currently active Sequence object in this MyModel object
    graph_file_list = []     # list of molecular graph files
    path_file_list = []      # list of path files
    atom_radius_dict = None  # dict of atomsymbol:atom radii
    atom_colour_dist = None  # dict of atomsymbol:atom rendering colour
    framenames = []          # list of frames (input filenames holding molecular graphs)
    frames = []              # list of frames (molecular graphs)
    pathframes = []          # list of frame paths
    numframes = 0            # number of frames
    currentframe = 0
    cell = None              # flag for cell boundary
    verbose = None           # verbose output flag
    crystal = None           # flag for periodic crystal
    CPTable = None
    logfilename = None       # for logging/debugging
    mgloaded = False
    seqnum_low = 1
    seqnum_high = 1
    seqrange = Range(low=seqnum_low,high=seqnum_high) # The sequence index GUI variable range
    seqnum = 1

    # per frame
    thismg = None
    atomx, atomy, atomz =            None, None, None
    atomsize, atomcols, atomlabels = None, None, None
    cpx, cpy, cpz, cptype, cplabel = None, None, None, None, None
    bondpaths, iaspaths, paths, pathtypes, ScalarField, VectorField = [], [], [], [], [], []
    thisnatoms, thisnumcps = 0, 0
    filename = None

    # CURRENT FRAME PLOT OBJECTS
    atomplot = None          # list of plot objects for atoms
    atomlabelsplot = None    # list of plot objects for atom labels
    dynamictextplot = None   # plot object for dynamic text
    cpplot = None            # Single plot object for all CPs
    bondplot = None          # Lists of plot objects for bond paths
    iaspathplot = None       # Lists of plot objects for IAS paths
    pathplot = None          # Lists of plot objects for other paths
    patharrowplot = None     # Lists of plot object for arrows
    boundaryplot = None      # Boundary plot object
    scalarfieldplot = None   # Scalar Field Plot object
    vectorfieldplot = None   # Vector Field Plot object 
    numbondplot, numiasplot, numpathplot = 0,0,0
    gridused = False
    pointsperglyph = 0
    picker = None

    # Initialize MAYAVI and declare Traits for Scene object
    scene = Instance(MlabSceneModel, ())
    viewcontrol = ViewControl()
    #scene2 = Instance(MlabSceneModel,())
    
    # Configure GUI sizes and colours
    # GUI Floats (Traits) - sizes
    Atoms, CPs, Paths, Arrows, Text, Interval = Float(0.3), Float(0.25), Float(0.03), Float(1.0), Float(12.0), Int(1)
    #DynamicText = Float(12.0)
    #
    # GUI visibility toggles
    show_atoms, show_labels = Bool(True), Bool(True)                                             # atoms and labels visibility
    #show_dynamic_text = Bool(True)                                                               # per-frame dynamic annotation
    show_cps = Bool(True)                                                                        # CPs visibility
    show_ncps = Bool(True)                                                                       # NCPs
    show_bcps = Bool(True)                                                                       # BCPs
    show_rcps = Bool(True)                                                                       # RCPs
    show_ccps = Bool(True)                                                                       # CCPs
    show_bps, show_pps, show_qps = Bool(True), Bool(False), Bool(False)                          # p,q,r paths
    show_ppps, show_qpps = Bool(False), Bool(False)                                              # p`,q` primed paths
    show_parrows, show_qarrows = Bool(False), Bool(False)                                        # Arrows
    show_iasev1s, show_iasev2s = Bool(False), Bool(False)                                        # IAS EV1, EV2 paths
    show_extra_pps, show_extra_qps = Bool(False), Bool(False)                                    # Extra p,q paths
    show_extra_ppps, show_extra_qpps = Bool(False), Bool(False)                                  # Extra p',q' paths
    show_scalarfield = Bool(False)                                                               # ScalarField
    show_vectorfield = Bool(False)                                                               # VectorField
    show_atoms_more = Button(label='..')
    #show_dynamic_text_more = Button(label='..')
    show_labels_more = Button(label='..')
    show_cps_more = Button(label='..')
    show_bps_more = Button(label='..')
    show_pps_more = Button(label='..')
    show_qps_more = Button(label='..')
    show_ppps_more = Button(label='..')
    show_qpps_more = Button(label='..')
    # Boundary
    show_boundary = Bool(False)
    boundary_linepattern=Str('Continuous') 
    # View style
    viewstyle = Str('Parallel')
    # GUI colour settings
    modelcolors =  {'NCP':         (0.0,1.0,1.0),
                    'BCP':         (0.0,1.0,0.0),
                    'RCP':         (1.0,0.0,0.0),
                    'CCP':         (0.0,0.0,1.0),
                    'bondpath':    (0.0,0.0,0.0),
                    'iaspath':     (0.75,0.75,0.75),
                    'p-path':      (0.0,1.0,1.0),
                    'q-path':      (1.0,0.5,1.0),
                    'p`-path':     (0.0,1.0,1.0),
                    'q`-path':     (1.0,0.5,1.0),
                    'extra p-path':(0.0,0.0,1.0),
                    'extra q-path':(1.0,0.0,0.0),
                    'extra p`-path':(0.0,0.0,1.0),
                    'extra q`-path':(1.0,0.0,0.0),
                    'background':  (1.0,1.0,1.0),
                    'labelcolor':  (0.0,0.0,0.0),
                    'boundary':    (0.5,0.5,0.5)
                    }
    # initialize editable color pickers
    show_bps_col = RGBColor(modelcolors['bondpath'])                                             # bond path color
    show_pps_col = RGBColor(modelcolors['p-path'])                                               # p-path color
    show_qps_col = RGBColor(modelcolors['q-path'])                                               # q-path color
    show_ppps_col = RGBColor(modelcolors['p`-path'])                                             # p`-path color
    show_qpps_col = RGBColor(modelcolors['q`-path'])                                             # q`-path color
    show_extra_pps_col = RGBColor(modelcolors['extra p-path'])                                   # Extra p-path color
    show_extra_qps_col = RGBColor(modelcolors['extra q-path'])                                   # Extra q-path color
    show_extra_ppps_col = RGBColor(modelcolors['extra p`-path'])                                 # Extra p`-path color
    show_extra_qpps_col = RGBColor(modelcolors['extra q`-path'])                                 # Extra q`-path color
    show_iaspath_col = RGBColor(modelcolors['iaspath'])                                          # IAS path
    show_boundary_col = RGBColor(modelcolors['boundary'])                                        # boundary color
    PQscale = Float(1.0)                                                                         # p,q vector scaling factor
    # Things for status line
    framelistname = Str('No file loaded')
    statuslinelist = [StatusItem(name='framelistname'),StatusItem(name='viewstyle')]
                         

    def picker_callback(self,picker):
        """ 
        Picker callback: this gets called on pick events.
        Currently picks: BCPs and bondpaths
        """
        #print('Picked an object')
        print('-------------')
        # detect a picked CP
        cpcounter = -1
        for cpi in self.cpplot:
            cpcounter = cpcounter+1
            if picker.actor in cpi.actor.actors:
                #print('Length of cpi.actor.actors list is {0}'.format(len(cpi.actor.actors)))
                print('Picked CP object found: {0}, index={1}'.format(cpi.name,cpcounter))
                cpi.actor.actors[0].object_name = cpi.name   # transfer picked name of CP to actor object
                cpi.actor.actors[0].edit_traits(view=self.pickerview)  # Show according to 'pickerview'
                #cpi.edit_traits()
                return
        # No CP close enough, detect a bond path
        bpcounter = -1
        for bpi in self.bondplot:
            bpcounter = bpcounter+1
            if picker.actor in bpi.actor.actors:
                picked_bpi_name = bpi.parent.parent.parent.parent.name
                print('Picked bond path object found: {0}, index={1}'.format(picked_bpi_name, bpcounter))
                bpi.actor.actors[0].object_name = picked_bpi_name
                bpi.actor.actors[0].edit_traits(view=self.pickerview)
                #bpi.edit_traits()
                return
        


    # =================
    # MODEL OBJECT INIT
    # =================
    def __init__(self, graphlist, atom_radius_dict, atom_colour_dict,
                 bvsetlist, bvcolors, extrasetlist, extrasetcolors,
                 vectorscale, verboseflag, swap_pq):
        '''
        Initialize the Model object
        '''
        # Call the parent class (HasTraits) __init__
        HasTraits.__init__(self)
        print('Initializing model')
        # Initialize the Sequence object of this MyModel
        self.currentseq = Sequence()
        print("Model: Created an empty Sequence object")
        #print(vars(self.currentseq))
        print("====")
        self.seqnum = len(self.currentseq.framelist)  # Active frame number in the sequence                
        # frame list
        if (len(graphlist) == 0): # No .seqviz file loaded, no MG list imported
            self.framelistname = 'Load input files using the File menu'
        else: # the graphlist contains information from the command line
            if graphlist[0].endswith('.seqviz'): # graphlist contains a .seqviz filename, pass it on to Sequence.read_seqviz()
                print("Model object will read sequence from {0}".format(graphlist[0]))
                seq_load_error = 0
                self.currentseq.read_seqviz(graphlist[0],seq_load_error,self.logfilename)
                print('Model: loaded sequence data into the Sequence object called self.currentseq' )
                #objprint(self.currentseq,level=3)
                #sys.exit()
                if seq_load_error != 0:
                    print('Error occurred while loading sequence - exiting')
                    sys.exit()
            else: # graphlist contains a list of MG files for import into TFrame objects
                print('Importing MGs into the current sequence')
                self.framelistname = graphlist[0]
        self.graph_file_list = graphlist       
        self.atom_radius_dict = atom_radius_dict
        self.atom_colour_dict = atom_colour_dict
        self.pathr = []
        self.pathp = None
        self.pathq = None
        self.pathx = []
        self.bvsetlabels = None
        self.bvsetlist = bvsetlist
        self.bvcolors = bvcolors
        self.extrasetlist = extrasetlist
        self.extrasetcolors = extrasetcolors
        self.verbose = verboseflag
        self.swap_pq = swap_pq
        #self.vectorscale = vectorscale
        self.PQscale = vectorscale
        # set default background colour
        self.scene.scene.background=self.modelcolors['background']
        # set parallel projection by default
        self.scene.scene.parallel_projection = True
        # selected CPS from CP Table
        self.selectedcps=List([])
        # Add a view for picked objects
        self.pickerview=View(Item('object_name',editor=TitleEditor()),
                             Item('visibility'),
                             Item('force_translucent'),
                             )
        # Add a view for About dialog
        self.aboutdialog=View(VGroup(Item('message',style='readonly'),
                                     Item('ok_button'),
                                    ),
                                    title = 'About TopViz',
                                    kind = 'modal',
                                    resizable = False),
        #self.vislistview=View(Item('visibility_list',editor=CheckListEditor()))
        # Add a picked item outline
        #pickedoutline = mlab.outline(line_width=2)
        #pickedoutline.outline_mode = 'cornered'
        #pickedoutline.bounds = (-0.1,0.1,-0.1,0.1,-0.1,0.1)

        if not (len(graphlist) == 0):
            self.read(verboseflag)   # read data into model
            # trigger frame load
            self.mgloaded=True
            self.loadframe()         # load frame data into scene


    
    # MENU Functions
    def menu_get_mg(self):
        """
        Menu function to select input MGs (individual or as a list from a .txt file)
        """
        filelist=[]
        getmg = SeqFileDialog()
        infile=getmg.file_name
        if infile == None:
            print('No input molecular graph or sequence defined')
            return
        if infile.endswith('.txt'):                            # multiple input MG files specified in a list file
            print('Reading a .txt (list) file ..')
            with open(infile,'r') as listfile:
                rawlines = listfile.readlines()
            # filter comment lines and blank lines
            lines = [i.strip() for i in rawlines if not (i.startswith('#') or len(i.strip()) == 0) ]
            for line in lines:
                tokens = line.split()
                filelist.append(tokens[0])
        elif infile.endswith('.seqviz'):  # A sequence file
            self.currentseq.read_seqviz(infile,'err','logfile')
            self.framelistname = infile
        else:                             # assume just a single MG
            filelist.append(infile)
        if not infile.endswith('.seqviz'):
            # Check that all input files in the input molecular graph file list exist
            for i in filelist:
                if not (os.path.isfile(i)):
                    print('Input file {0} not found!'.format(i))
                    sys.exit()
                    
            # all files exist, add them to the graph_file_list
            self.graph_file_list = filelist
            print('Selected file {0}, No. of MGs={1}'.format(infile,len(filelist)))
            self.read(self.verbose)
            self.loadframe()
            
        self.statuslinelist[0] = Str(infile) 
        #print('Setting status line = {0}'.format(self.statuslinelist[0]))
        self.mgloaded=True
        
    def menu_close(self):
        """
        Delete current frames, MGs, paths and reset to initial state
        """
        print('Close function not yet implemented')

    def menu_import(self):
        """
        Import a list of MGs into a Sequence
        """
        print('Import function not yet implemented')    
        
    def menu_export(self):
        """
        Configure
        """
        print('Export function not yet implemented!')

    def menu_exit(self):
        """
        Exit the program
        """
        sys.exit()

#def menu_about(self):
#    """
#    Display About information
#    """
#    dialog = AboutDialog()
#    dialog.message = "Live updated message"
#    #dialog.edit_traits(view=self.aboutdialog,kind='modal')

    def report_selected(self,selectedcps):
        """
        """
        for i in selectedcps:
            print('Selected {0}'.format(i.Name))
        #return self.selectedcps

    def stringtotuple(self, s):
       '''
       convert string to tuple of floats
       '''
       temp = s.strip('()')
       tokens = temp.split(',')
       return (float(tokens[0]), float(tokens[1]), float(tokens[2]))

    def read_paths(self,t,verbose):
        '''
        Read in paths into the model object t 
        '''
        pass
        
    # Loading functions
    def read(self, verbose):
        '''
        Read molecular graphs, CPs, paths etc. into the model object
        '''
        print('==== Reading molecular graphs')
        for i in self.graph_file_list:  # Read all molecular graphs into self.frames
            t = mg.Molgraph()           # make a new Molgraph object called 't'
            t.title = ''
            t.read(i,debug=False)                   # fill our new object 't' with data from the input file
            if verbose:
                print('Read molecular graph from {0}'.format(i))
            # check if molecular graph file has crystal or grid parameters, if so build box corners arrays 
            #print(t.title)
            if 'BOUNDARY' in t.title or 'CRYSTAL' in t.title:
                self.gridused = True
                self.cell = []
                self.corner_x=[]
                self.corner_y=[]
                self.corner_z=[]
                self.show_boundary = True
                tokens = t.title.split()
                self.box_o = np.fromstring(tokens[-4].strip('{}'),sep=',')
                self.box_a = np.fromstring(tokens[-3].strip('{}'),sep=',')
                self.box_b = np.fromstring(tokens[-2].strip('{}'),sep=',')
                self.box_c = np.fromstring(tokens[-1].strip('{}'),sep=',')
                print(' === Boundary box data: origin and box vectors ====')
                print('Origin: {0} {1} {2}'.format(self.box_o[0],self.box_o[1],self.box_o[2]))
                print('     a: {0} {1} {2}'.format(self.box_a[0],self.box_a[1],self.box_a[2]))
                print('     b: {0} {1} {2}'.format(self.box_b[0],self.box_b[1],self.box_b[2]))
                print('     c: {0} {1} {2}'.format(self.box_c[0],self.box_c[1],self.box_c[2]))
                self.cell.append(self.box_o)
                self.cell.append(self.box_o+self.box_a)
                self.cell.append(self.box_o+self.box_b)
                self.cell.append(self.box_o+self.box_c)
                self.cell.append(self.box_o+self.box_a+self.box_b)
                self.cell.append(self.box_o+self.box_b+self.box_c)
                self.cell.append(self.box_o+self.box_c+self.box_a)
                self.cell.append(self.box_o+self.box_a+self.box_b+self.box_c)
                for i in range(0,len(self.cell)):
                    self.corner_x.append(self.cell[i][0])
                    self.corner_y.append(self.cell[i][1])
                    self.corner_z.append(self.cell[i][2])
            if 'CRYSTAL' in t.title:
                self.crystal = True
            else:
                self.crystal = False                    
            print('Read cplist')
            #for cp in t.cplist:
            #    print('{0}|{1}|{2}|'.format(cp.id,cp.type,cp.connected))            
                
            self.frames.append(t)
            # now build a TraitedFrame and add the MG to that
            tf = TraitedFrame()
            tf.addmg(t)
            # Add the TraitedFrame to the current sequence framelist
            self.currentseq.framelist.append(tf)
            # update the number of frames in the current sequence
            self.seqnum = len(self.currentseq.framelist)

                
        self.numframes = len(self.currentseq.framelist)
        print('==== Done: read {0} molecular graphs'.format(self.numframes))

        # Bond path data and p,q,p`,q` paths from bvsetlist
        bvsetcount = 0
        self.bvsetlabels = []
        print('==== Reading bond path vector data ====')
        print('Using {0} files with bond path vector data'.format(len(self.bvsetlist)))
        for bvset in self.bvsetlist:
            with open(bvset,'r') as bvsetfile:  # reading the next bond vectors file
                line = bvsetfile.readline()     # read first line of file
                while (line):
                    # First line of vector set currently contains no useful information, just echo
                    if (verbose):
                        print('==== New set of path vector information ====')
                        print(line.strip())
                    # Second line contains the input data file name 'Input file:'
                    line = bvsetfile.readline()
                    #print(line.strip())
                    if not line.startswith('Input file:'):
                        print('Expected an Input file: line in {0}'.format(bvset))
                        print('Instead, found [{0}] - exiting'.format(line))
                        sys.exit()
                    originmgfile = line[len('Input file: '):].strip()
                    # Third line contains a description
                    line = bvsetfile.readline()
                    if not line.startswith('Description:'):
                        print('Expected a Description: line in {0}'.format(bvset))
                        print('Instead, found [{0}] - exiting'.format(line))
                        sys.exit()
                    description = line[len('Description:'):].strip()
                    if (verbose):
                        print('Description line:{0}'.format(description))
                    numpathpoints = int(description.split()[0])
                    if (verbose):
                        print('Description line specifies {0} path points'.format(numpathpoints))
                        
                    if 'from BCP to' in description:  # this is a bond path, create and store a NamedFieldPath object
                        bcpname = bvsetfile.readline().split()[-1]      # Start
                        pathendname = bvsetfile.readline().split()[-1]  # End
                        if (verbose):
                           print('Bond path segment: {0} -> {1}'.format(bcpname,pathendname))
                        # save the next line for descriptive use
                        line = bvsetfile.readline()
                        if not line.startswith('Scal'):  # trap
                            print('Expected a line starting with Scal ..')
                            print('Instead, found [{0}] - exiting'.format(line))
                            sys.exit()
                        description2 = line
                        if (verbose):
                            print('{0}'.format(description2))
                        # 20190428: Force swap_pq to True if 'ellip_stress' scaling used
                        if 'ellip_stress' in description2:
                            print('Stress tensor ellipticity scaling detected! AUTOMATICALLY swapping p and q!')
                            self.swap_pq = True
                        # now skip to the last line before the numbers
                        thismatrix = 'unknown'
                        while True:
                            line = bvsetfile.readline()
                            if line.startswith('Scaled'):  # next line should be the start of the numbers
                                tokens = line.split()
                                # capture the matrix used
                                thismatrix = tokens[3]
                                if (verbose):
                                    print('Verifying: about to read {0} number lines'.format(tokens[-3]))
                                break
                            else:
                                if (verbose):
                                    print('Ignoring the line: {0}'.format(line.strip()))
                        if (verbose):
                            print('Last header line before numbers: {0}'.format(line.strip()))
                        # now retrieve the path
                        temp_px,temp_py,temp_pz,v1x,v1y,v1z,v2x,v2y,v2z = [],[],[],[],[],[],[],[],[]
                        for i in range(0,numpathpoints):  # read the specified number of lines
                            line = bvsetfile.readline()
                            if (verbose):
                                print('Line {0}:{1}'.format(i+1, line.strip()))
                            if (not (line.startswith((" ","-","0","1","2","3","4","5","6","7","8","9")) )):  # something's wrong, stop
                                print('Expected the first line of numbers, got {0} instead'.format(line))
                                print('Previous line was supposed to start with Scaled, instead was: {0}'.format(line))
                                print('Check your data file - exiting')
                                sys.exit()
                            tokens = line.split()
                            if (not len(tokens) == 9):
                                print('Expected 9 columns of numbers here, got: {0}'.format(line))
                                print('Check your path data file - exiting')
                                sys.exit()
                            temp_px.append(float(tokens[0]))
                            temp_py.append(float(tokens[1]))
                            temp_pz.append(float(tokens[2]))
                            if (self.swap_pq):
                                v1x.append(float(tokens[6])*self.PQscale)
                                v1y.append(float(tokens[7])*self.PQscale)
                                v1z.append(float(tokens[8])*self.PQscale)
                                v2x.append(float(tokens[3])*self.PQscale)
                                v2y.append(float(tokens[4])*self.PQscale)
                                v2z.append(float(tokens[5])*self.PQscale)
                            else:
                                v1x.append(float(tokens[3])*self.PQscale)
                                v1y.append(float(tokens[4])*self.PQscale)
                                v1z.append(float(tokens[5])*self.PQscale)
                                v2x.append(float(tokens[6])*self.PQscale)
                                v2y.append(float(tokens[7])*self.PQscale)
                                v2z.append(float(tokens[8])*self.PQscale)

                        if (verbose):
                            print('Read {0} path points from file: {1}'.format(numpathpoints,bvset))
                            print('==== v1 =====, {0} {1} {2}'.format(len(v1x),len(v1y),len(v1z)))
                            for i in range(0,len(v1x)):
                                print(v1x[i],v1y[i],v1z[i])
                            print('==== v2 =====, {0} {1} {2}'.format(len(v2x),len(v2y),len(v2z)))
                            for i in range(0,len(v2x)):
                                print(v2x[i],v2y[i],v2z[i])
                        # init: px,py,pz,description,pathtype,path_fieldvar
                        bvsetcount = bvsetcount + 1
                        partialdesc = ' '.join(description.split()[3:])
                        # create a new NamedFieldPath
                        nfp = NamedFieldPath(temp_px,temp_py,temp_pz,
                                             'Bondpath '+originmgfile+' '+bcpname+' -> '+pathendname+' '+partialdesc+' with '+description2,
                                             '0.0 0.0 0.0',
                                             thismatrix,
                                             [ v1x, v1y, v1z, v2x, v2y, v2z ])
                        nfp.type = 'Bondpath with vectors'
                        self.pathr.append(nfp)
                    # done with number columns, read for another header block in the bond path data
                    line = bvsetfile.readline()
        print('Number of read bond paths = {0}'.format(bvsetcount))
        print('==== Finished reading bond path vector data ====')

        # EXTRA PATHS
        extrasetcount = 0
        print('Using {0} files with extra path vector data'.format(len(self.extrasetlist)))
        for extraset in self.extrasetlist:
            with open(extraset,'r') as extrasetfile:  # reading the next bond vectors file
                line = extrasetfile.readline()        # read first line of file
                while (line):
                    # First line of vector set currently contains no useful information
                    if (verbose):
                        print('==== New set of path vector information ====')
                        print(line.strip())
                    # Second line contains the input data file name 'Input file:'
                    line = extrasetfile.readline()
                    #print(line.strip())
                    if not line.startswith('Input file:'):
                        print('Expected an Input file: line in {0}'.format(extraset))
                        print('Instead, found [{0}] - exiting'.format(line))
                        sys.exit()
                    originmgfile = line[len('Input file: '):].strip()
                    # Third line contains a description
                    line = extrasetfile.readline()
                    if not line.startswith('Description:'):
                        print('Expected a Description: line in {0}'.format(extraset))
                        print('Instead, found [{0}] - exiting'.format(line))
                        sys.exit()
                    description = line[len('Description:'):].strip()
                    if (verbose):
                        print('Description line:{0}'.format(description))
                    numpathpoints = int(description.split()[0])
                    if (verbose):
                        print('Description line specifies {0} path points'.format(numpathpoints))
                    if 'from BCP to' in description:  # this is a bond path, create and store a NamedFieldPath object
                        bcpname = extrasetfile.readline().split()[-1]      # Start
                        pathendname = extrasetfile.readline().split()[-1]  # End
                        # skip 2 next lines
                        #line = extrasetfile.readline()
                        #if (verbose):
                        #    print('Found [{0}] - skipping'.format(line))
                        #line = extrasetfile.readline()
                        #if (verbose):
                        #    print('Found [{0}] - skipping'.format(line))
                        # save the next line for descriptive use
                        line = extrasetfile.readline()
                        if not line.startswith('Scaling'):  # trap
                            print('Expected a line starting with Scaling ..')
                            print('Instead, found [{0}] - exiting'.format(line))
                            sys.exit()
                        #print ('Found a line starting with Scaling: {0}'.format(line))
                        description2 = line
                        if (verbose):
                            print('{0}'.format(description2))
                        # 20190428: Force swap_pq to True if 'ellip_stress' scaling used
                        if 'ellip_stress' in description2:
                            print('Stress tensor ellipticity scaling detected! AUTOMATICALLY swapping p and q!')
                            self.swap_pq = True
                        # now skip to the last line before the numbers
                        thismatrix = 'unknown'
                        while True:
                            line = extrasetfile.readline()
                            if line.startswith('Scaled'):  # next line should be the start of the numbers
                                tokens = line.split()
                                thismatrix = tokens[3]
                                if (verbose):
                                    print('Verifying: about to read {0} number lines'.format(tokens[-3]))
                                break
                            else:
                                if (verbose):
                                    print('Ignoring the line: {0}'.format(line.strip()))
                        if (verbose):
                            print('Last header line before numbers: {0}'.format(line.strip()))
                        # now retrieve the path
                        temp_px,temp_py,temp_pz,v1x,v1y,v1z,v2x,v2y,v2z = [],[],[],[],[],[],[],[],[]
                        for i in range(0,numpathpoints):
                            line = extrasetfile.readline()
                            if (verbose):
                                print('Line {0}:{1}'.format(i+1, line.strip()))
                            if (not (line.startswith(" ") or line.startswith("-")) ):  # something's wrong, stop
                                print('Expected the first line of numbers, got {0} instead'.format(line))
                                print('Previous line was supposed to start with Scaled, instead was: {0}'.format(line))
                                print('Check your data file - exiting')
                                sys.exit()
                            tokens = line.split()
                            if (not len(tokens) == 9):
                                print('Expected 9 columns of numbers here, got: {0}'.format(line))
                                print('Check your data file - exiting')
                                sys.exit()
                            ft = [ float(t) for t in tokens ]  # saves using float(tokens multiple times below
                            temp_px.append(ft[0])
                            temp_py.append(ft[1])
                            temp_pz.append(ft[2])
                            if (self.swap_pq):
                                v1x.append(ft[6]*self.PQscale)
                                v1y.append(ft[7]*self.PQscale)
                                v1z.append(ft[8]*self.PQscale)
                                v2x.append(ft[3]*self.PQscale)
                                v2y.append(ft[4]*self.PQscale)
                                v2z.append(ft[5]*self.PQscale)
                            else:
                                v1x.append(ft[3]*self.PQscale)
                                v1y.append(ft[4]*self.PQscale)
                                v1z.append(ft[5]*self.PQscale)
                                v2x.append(ft[6]*self.PQscale)
                                v2y.append(ft[7]*self.PQscale)
                                v2z.append(ft[8]*self.PQscale)
                        # create a new NamedFieldPath
                        if (verbose):
                            print('Read {0} path points from file: {1}'.format(numpathpoints,extraset))
                        # init: px,py,pz,description,pathtype,path_fieldvar
                        extrasetcount = extrasetcount + 1
                        partialdesc = ' '.join(description.split()[3:])
                        nfp = NamedFieldPath(temp_px,temp_py,temp_pz,
                                             'Bondpath '+originmgfile+' '+bcpname+' -> '+pathendname+' '+partialdesc+' with '+description2,
                                             '0.0 0.0 0.0',
                                             thismatrix,
                                             [ v1x, v1y, v1z, v2x, v2y, v2z ])
                        nfp.pathtype = 'Extra bondpath with vectors'
                        self.pathx.append(nfp)
                    line = extrasetfile.readline()

    def loadframe(self):
        '''
        Load the current molecular graph and set number of atoms
        '''
        # Load this frame's MG
        #self.thismg = self.frames[self.currentframe]  # got the frame molecular graph, now extract its contents
        self.thismg = self.currentseq.framelist[self.currentframe].framemg  # got the frame molecular graph, now extract its contents
        self.thisnatoms = len(self.thismg.atom_x)
        #print('self.currentframe = {0}, self.thisnatoms={1}'.format(self.currentframe,self.thisnatoms))
        self.atomx = self.thismg.atom_x
        self.atomy = self.thismg.atom_y
        self.atomz = self.thismg.atom_z
        self.atomlabels = [s.partition('_')[0] for s in self.thismg.atom_label ]
        self.atomsymbols = [ ''.join(re.findall(r'\A[a-zA-Z]+', i)) for i in self.atomlabels ]        
        #self.atomsymbols = [ i.strip('0123456789') for i in self.atomlabels ]
        self.atomsize = [self.atom_radius_dict[i] for i in self.atomsymbols ]
        self.atomcols = [self.atom_colour_dict[i] for i in self.atomsymbols ]

        # Store CPs for current frame
        self.thiscplist = self.thismg.cplist
        self.thisnumcps = len(self.thismg.cplist)
        # add this frame's CPs to the CPTable
        tcpl = []
        for i in range(0,self.thisnumcps):
            tcpl.append(TraitedCP(self.thiscplist[i]))
        for i in range(0,self.thisnumcps):
            tcpl[i].Number = i+1
        self.CPTable = tcpl
        self.cpx, self.cpy, self.cpz, self.cptype, self.cplabel = [], [], [], [], []   # clear the CP arrays
        for cp in self.thiscplist:  # loop over this frame's CPs, store position, type, connectivity and BCP paths
            #print('CP Type={0}, location {1},{2},{3}'.format(cp.type,cp.pos_x,cp.pos_y,cp.pos_z))
            self.cpx.append(cp.pos_x)
            self.cpy.append(cp.pos_y)
            self.cpz.append(cp.pos_z)
            self.cptype.append(cp.type)
            self.cplabel.append(cp.connected)
            # If CP is a BCP, capture the path and IAS path information
            # IAS paths look like this
            # 492 sample points along IAS +EV1 path from BCP
            # 487 sample points along IAS -EV1 path from BCP
            # 463 sample points along IAS +EV2 path from BCP
            # 463 sample points along IAS -EV2 path from BCP
            if cp.type == 'BCP':
                thiscplabel = cp.connected
                if len(cp.pathlist) >0:  # has at least the bond path segments
                    # add BCP name to field path descriptions
                    cp.pathlist[0].description = thiscplabel + ' ' + cp.pathlist[0].description
                    cp.pathlist[1].description = thiscplabel + ' ' + cp.pathlist[1].description
                    self.bondpaths.append(cp.pathlist[0])  # as mg.FieldPath
                    self.bondpaths.append(cp.pathlist[1])  # as mg.FieldPath
                if len(cp.pathlist) >2:  # also has IAS paths
                    cp.pathlist[2].description = thiscplabel + ' ' + cp.pathlist[2].description
                    cp.pathlist[3].description = thiscplabel + ' ' + cp.pathlist[3].description
                    cp.pathlist[4].description = thiscplabel + ' ' + cp.pathlist[4].description
                    cp.pathlist[5].description = thiscplabel + ' ' + cp.pathlist[5].description
                    self.iaspaths.append(cp.pathlist[2])  # +IAS EV1
                    self.iaspaths.append(cp.pathlist[3])  # -IAS EV1
                    self.iaspaths.append(cp.pathlist[4])  # +IAS EV2
                    self.iaspaths.append(cp.pathlist[5])  # -IAS EV2

        # Add extra bond paths
        self.paths=[]
        for nfp in self.pathr:
            # build p,q,q',q' paths, add to pathplot
            px,py,pz,qx,qy,qz,ppx,ppy,ppz,qpx,qpy,qpz = [],[],[],[],[],[],[],[],[],[],[],[]
            rx = nfp.path_x
            ry = nfp.path_y
            rz = nfp.path_z
            description_tail = nfp.description[len('Bondpath '):]
            thismatrix = nfp.matrix
            v1x, v1y, v1z, v2x, v2y, v2z = nfp.path_fieldvar
            for i in range(0,len(rx)):
                px.append(rx[i] + v1x[i])    # p-path
                py.append(ry[i] + v1y[i])
                pz.append(rz[i] + v1z[i])
                ppx.append(rx[i] - v1x[i])   # p`-path
                ppy.append(ry[i] - v1y[i])
                ppz.append(rz[i] - v1z[i])
                qx.append(rx[i] + v2x[i])    # q-path
                qy.append(ry[i] + v2y[i])
                qz.append(rz[i] + v2z[i])
                qpx.append(rx[i] - v2x[i])   # q`-path
                qpy.append(ry[i] - v2y[i])
                qpz.append(rz[i] - v2z[i])

            originmgfile = ''
            newnfp1 = NamedFieldPath(px, py, pz,
                                    'p-path '+description_tail,
                                    '0.0 0.0 0.0',
                                    thismatrix,
                                    [ v1x, v1y, v1z, v2x, v2y, v2z ])
            newnfp1.pathtype = 'p-path with vectors'
            self.paths.append(newnfp1)
            newnfp2 = NamedFieldPath(ppx, ppy, ppz,
                                    'p`-path '+description_tail,
                                    '0.0 0.0 0.0',
                                    thismatrix,
                                    [ v1x, v1y, v1z, v2x, v2y, v2z ])
            newnfp2.pathtype = 'p`-path with vectors'
            self.paths.append(newnfp2)
            newnfp3 = NamedFieldPath(qx, qy, qz,
                                    'q-path '+description_tail,
                                    '0.0 0.0 0.0',
                                    thismatrix,
                                    [ v1x, v1y, v1z, v2x, v2y, v2z ])
            newnfp3.pathtype = 'q-path with vectors'
            self.paths.append(newnfp3)
            newnfp4 = NamedFieldPath(qpx, qpy, qpz,
                                    'q`-path '+description_tail,
                                    '0.0 0.0 0.0',
                                    thismatrix,
                                    [ v1x, v1y, v1z, v2x, v2y, v2z ])
            newnfp4.pathtype = 'q`-path with vectors'
            self.paths.append(newnfp4)

        # Now update the plot
        print('paths now contains {0} paths'.format(len(self.paths)))

        # ADD EXTRA PATHS
        for nfp in self.pathx:
            # build p,q,q',q' paths, add to pathplot
            px,py,pz,qx,qy,qz,ppx,ppy,ppz,qpx,qpy,qpz = [],[],[],[],[],[],[],[],[],[],[],[]
            rx = nfp.path_x
            ry = nfp.path_y
            rz = nfp.path_z
            description_tail = nfp.description[len('Bondpath '):]
            v1x, v1y, v1z, v2x, v2y, v2z = nfp.path_fieldvar
            for i in range(0,len(rx)):
                px.append(rx[i] + v1x[i])    # p-path
                py.append(ry[i] + v1y[i])
                pz.append(rz[i] + v1z[i])
                ppx.append(rx[i] - v1x[i])   # p`-path
                ppy.append(ry[i] - v1y[i])
                ppz.append(rz[i] - v1z[i])
                qx.append(rx[i] + v2x[i])    # q-path
                qy.append(ry[i] + v2y[i])
                qz.append(rz[i] + v2z[i])
                qpx.append(rx[i] - v2x[i])   # q`-path
                qpy.append(ry[i] - v2y[i])
                qpz.append(rz[i] - v2z[i])

            originmgfile = ''
            newnfp1 = NamedFieldPath(px, py, pz,
                                    'p-path Extra '+description_tail,
                                    '0.0 0.0 0.0',
                                    [ v1x, v1y, v1z, v2x, v2y, v2z ])
            newnfp1.pathtype = 'p-path Extra with vectors'
            self.paths.append(newnfp1)
            newnfp2 = NamedFieldPath(ppx, ppy, ppz,
                                    'p`-path Extra '+description_tail,
                                    '0.0 0.0 0.0',
                                    [ v1x, v1y, v1z, v2x, v2y, v2z ])
            newnfp2.pathtype = 'p`-path Extra with vectors'
            self.paths.append(newnfp2)
            newnfp3 = NamedFieldPath(qx, qy, qz,
                                    'q-path Extra '+description_tail,
                                    '0.0 0.0 0.0',
                                    [ v1x, v1y, v1z, v2x, v2y, v2z ])
            newnfp3.pathtype = 'q-path Extra with vectors'
            self.paths.append(newnfp3)
            newnfp4 = NamedFieldPath(qpx, qpy, qpz,
                                    'q`-path Extra'+description_tail,
                                    '0.0 0.0 0.0',
                                    [ v1x, v1y, v1z, v2x, v2y, v2z ])
            newnfp4.pathtype = 'q`-path Extra with vectors'
            self.paths.append(newnfp4)

        print('Added all extra paths - Total for this frame is {0} paths'.format(len(self.paths)))
        print('====\n')
        # Diagnostic before triggering UI
        print("Current sequence name is {0}".format(self.currentseq.name))
        print("with metadata")
        print(self.currentseq.metadata)
        print('and comments')
        #for s in self.currentseq.comments:
        #    print(s)
        print('There are {0} TraitedFrame objects in the framelist'.format(len(self.currentseq.framelist)))
        framecount = 0
        for thisTraitedFrame in self.currentseq.framelist:
            print(vars(thisTraitedFrame))
            objprint(thisTraitedFrame.framemg,depth=2)
            print("\n")
        #
        print('Check completed\n\n')
        #objprint(self.atomlabels)
        #objprint(self.atomlabelsplot)
        
        # -------------------------------------------------------------------
        # Trigger creation of plotted items
        self.update_plot_atoms()
        self.update_plot_cps()
        self.update_plot_paths()
        if not self.cell == None:
            self.show_boundary=True
            self.update_boundary()


    # INTERACTIVE RESPONSES
    # When the scene is activated, or when the parameters are changed, we
    # update the plot using 'update_plot_*' methods below.
    
    @on_trait_change('scene.activated')
    def initializePicker(self):
        picker = self.scene.mayavi_scene.on_mouse_pick(self.picker_callback)
        picker.tolerance = 0.01
        #self.pointsperglyph = self.cpplot[0].glyph.glyph_source.glyph_source.output.points.to_array().shape[0]
        #self.glyph_pointslist = []
        #lencplist = len(self.cpplot)
        #for i in self.cpplot:
        #    thisarray = i.glyph.glyph_source.glyph_source.output.points.to_array()
        #    self.glyph_pointslist.append(thisarray)        
        #self.glyph_points = np.concatenate(self.glyph_pointslist)
        #print(self.glyph_points)
        #print(type(self.glyph_points))
        #print('points per glyph = {0}'.format(self.pointsperglyph))
    
    @on_trait_change('currentseq.frames')
    def update_frame_slider(self):
        '''
        Update the frame slider
        '''
        numframes = len(self.currentseq.framelist)
        print('number of frames is now {0}'.format(numframes)) 
        self.seqnum.high = numframes

    @on_trait_change('seqrange')
    def update_current_frame(self):
        '''
        set the 
        
        :param self: Description
        '''  
        pass

    @on_trait_change('scene.scene.parallel_projection,scene.activated,self.framelistname')
    def update_status_bar(self):
        '''
        Update the status bar
        '''
        if self.scene.scene.parallel_projection:
            self.viewstyle = 'Parallel'
        else:
            self.viewstyle = 'Perspective'
        print('number of frames is now {0}'.format(len(self.currentseq.framelist)))
        #self.scene.picker(self.picker_callback())
        #print(mlab.view())  

    @on_trait_change('scene.activated')
    def update_view_params(self):
        print(mlab.view())
        #print('Current Azimuth: {0}'.format(self.viewcontrol.azimuth))
        #print('Current Elevation: {0}'.format(self.viewcontrol.elevation))
        #print('Current Distance: {0}'.format(self.viewcontrol.distance))
        #self.viewcontrol.edit_traits(view=View(),kind='live')

    @on_trait_change('show_boundary,show_boundary_col,scene.activated')
    def update_boundary(self):
        """
        update the boundary object
        """
        if (not self.mgloaded) or (self.gridused == False):
            return
        if  self.boundaryplot is None:
            # DRAW THE BOUNDARY
            self.boundaryplot = []
            firstdraw = True
            self.boundaryplot.append(self.scene.mlab.plot3d([self.corner_x[0],self.corner_x[1]],
                                                            [self.corner_y[0],self.corner_y[1]],
                                                            [self.corner_z[0],self.corner_z[1]],
                                                            reset_zoom=False,tube_radius=None,color=self.show_boundary_col))
            self.boundaryplot.append(self.scene.mlab.plot3d([self.corner_x[1],self.corner_x[4]],
                                                            [self.corner_y[1],self.corner_y[4]],
                                                            [self.corner_z[1],self.corner_z[4]],
                                                            reset_zoom=False,tube_radius=None,color=self.show_boundary_col))
            self.boundaryplot.append(self.scene.mlab.plot3d([self.corner_x[1],self.corner_x[6]],
                                                            [self.corner_y[1],self.corner_y[6]],
                                                            [self.corner_z[1],self.corner_z[6]],
                                                            reset_zoom=False,tube_radius=None,color=self.show_boundary_col))                                                            
            self.boundaryplot.append(self.scene.mlab.plot3d([self.corner_x[0],self.corner_x[2]],
                                                            [self.corner_y[0],self.corner_y[2]],
                                                            [self.corner_z[0],self.corner_z[2]],
                                                            reset_zoom=False,tube_radius=None,color=self.show_boundary_col))
            self.boundaryplot.append(self.scene.mlab.plot3d([self.corner_x[2],self.corner_x[4]],
                                                            [self.corner_y[2],self.corner_y[4]],
                                                            [self.corner_z[2],self.corner_z[4]],
                                                            reset_zoom=False,tube_radius=None,color=self.show_boundary_col))
            self.boundaryplot.append(self.scene.mlab.plot3d([self.corner_x[2],self.corner_x[5]],
                                                            [self.corner_y[2],self.corner_y[5]],
                                                            [self.corner_z[2],self.corner_z[5]],
                                                            reset_zoom=False,tube_radius=None,color=self.show_boundary_col))                                                            
            self.boundaryplot.append(self.scene.mlab.plot3d([self.corner_x[0],self.corner_x[3]],
                                                            [self.corner_y[0],self.corner_y[3]],
                                                            [self.corner_z[0],self.corner_z[3]],
                                                            reset_zoom=False,tube_radius=None,color=self.show_boundary_col))
            self.boundaryplot.append(self.scene.mlab.plot3d([self.corner_x[3],self.corner_x[5]],
                                                            [self.corner_y[3],self.corner_y[5]],
                                                            [self.corner_z[3],self.corner_z[5]],
                                                            reset_zoom=False,tube_radius=None,color=self.show_boundary_col))
            self.boundaryplot.append(self.scene.mlab.plot3d([self.corner_x[3],self.corner_x[6]],
                                                            [self.corner_y[3],self.corner_y[6]],
                                                            [self.corner_z[3],self.corner_z[6]],
                                                            reset_zoom=False,tube_radius=None,color=self.show_boundary_col)) 
            self.boundaryplot.append(self.scene.mlab.plot3d([self.corner_x[4],self.corner_x[7]],
                                                            [self.corner_y[4],self.corner_y[7]],
                                                            [self.corner_z[4],self.corner_z[7]],
                                                            reset_zoom=False,tube_radius=None,color=self.show_boundary_col))
            self.boundaryplot.append(self.scene.mlab.plot3d([self.corner_x[5],self.corner_x[7]],
                                                            [self.corner_y[5],self.corner_y[7]],
                                                            [self.corner_z[5],self.corner_z[7]],
                                                            reset_zoom=False,tube_radius=None,color=self.show_boundary_col))
            self.boundaryplot.append(self.scene.mlab.plot3d([self.corner_x[6],self.corner_x[7]],
                                                            [self.corner_y[6],self.corner_y[7]],
                                                            [self.corner_z[6],self.corner_z[7]],
                                                            reset_zoom=False,tube_radius=None,color=self.show_boundary_col))
        # set boundary visible/invisible
        for p in self.boundaryplot:
            setplotobjvisibility(p,self.show_boundary)
                                                          
#    @on_trait_change('DynamicText,show_dynamic_text,scene.activated')
#    def update_dynamic_text(self):
#        '''
#        Draw dynamic annotation based on a format string and optionally a dynamic sequence variable
#        '''
#        if not self.mgloaded:
#            return
#        if self.dynamictextplot is None:  # Initial draw
#            if self.show_dynamic_text:
#                self.dynamictextplot = []
#                dyntextobj = self.scene.mlab.text(0.05,0.05,'dynamic text',color=self.modelcolors['labelcolor'],width=self.DynamicText*0.004)
#                dyntextobj.property.bold = True
#                dyntextobj.actor.text_scale_mode = 'viewport'
#                dyntextobj.property.justification = 'left'
#                dyntextobj.property.vertical_justification = 'centered'
#                self.dynamictextplot.append(dyntextobj)
#        else:                      # triggered on redraw
#            for i in range(0,len(self.dynamictextplot)):
#                self.dynamictextplot[0].width=self.DynamicText*0.004
#                self.dynamictextplot[0].property.justification = 'left'
#                self.dynamictextplot[0].property.vertical_justification = 'centered'
#                # set dynamic text visibility       
#        for i in range(0,len(self.dynamictextplot)):
#            self.dynamictextplot[i].visible = self.show_dynamic_text
                    

    @on_trait_change('Atoms,Text,show_atoms,show_labels,scene.activated')
    def update_plot_atoms(self):  # atom plotter method
        '''
        Draw atom spheres with radius and colour chosen by element name, optionally with text atom labels
        '''
        if not self.mgloaded:
            return
        if self.atomplot is None:  # Initial draw
            self.atomplot = []
            self.atomlabelsplot = []
            firstdraw = True
            for i in range(0,self.thisnatoms):  # DRAW ATOMS
                px = self.atomx[i]
                py = self.atomy[i]
                pz = self.atomz[i]
                plabel = self.atomlabels[i]
                ps = self.atomsize[i]*self.Atoms
                pcol = self.atomcols[i]
                thisatom = self.scene.mlab.points3d(px,py,pz,ps,
                                                    name='Atom '+plabel, resolution=32, color=tuple(pcol),
                                                    scale_mode='scalar',scale_factor=1.0,transparent=False)
                #objprint(thisatom,depth=2)
                self.atomplot.append(thisatom)
                if self.show_labels:
                    textobj = self.scene.mlab.text(px,py,plabel, z=pz, name='Label '+plabel,
                                                                    color=self.modelcolors['labelcolor'],width=self.Text*0.004)
                    textobj.property.bold = True
                    textobj.actor.text_scale_mode = 'viewport'
                    textobj.property.justification = 'centered'
                    textobj.property.vertical_justification = 'centered'
                    self.atomlabelsplot.append(textobj)
            print('There are now {0} atoms in self.atomplot'.format(len(self.atomplot)))

        else:                      # triggered on redraw
            for i in range(0,self.thisnatoms):  # redraw atoms
                #print('Redrawing atom {0} of {1} ({2})'.format(i,self.thisnatoms,len(self.atomplot)))
                self.atomplot[i].mlab_source.set(x=self.atomx[i],y=self.atomy[i],z=self.atomz[i],scalars=self.atomsize[i]*self.Atoms)
                if self.crystal:
                    pass

            for i in range(0,len(self.atomlabelsplot)):  # redraw text
                self.atomlabelsplot[i].width=self.Text*0.004
                self.atomlabelsplot[i].property.justification = 'centered'
                self.atomlabelsplot[i].property.vertical_justification = 'centered'
        # set atom and label visibility       
        for i in range(0,self.thisnatoms):
            self.atomplot[i].visible = self.show_atoms
            self.atomlabelsplot[i].visible = self.show_labels

    @on_trait_change('CPs,show_ncps,show_bcps,show_rcps,show_ccps,scene.activated')
    def update_plot_cps(self):  # CP plotter method
        '''
        Draw critical points
        '''
        if not self.mgloaded:
            return
        if self.cpplot is None:  # first draw
            self.cpplot = []
            thisnumcps = self.thisnumcps
            for j in range(0,thisnumcps):  # DRAW CPS
                px = self.cpx[j]
                py = self.cpy[j]
                pz = self.cpz[j]
                ps = [self.CPs]
                ptype = self.cptype[j]
                thiscplabel = self.cplabel[j]

                if ptype == 'BCP':   # BCPs are green
                    self.cpplot.append(self.scene.mlab.points3d(px,py,pz,ps,name='BCP '+thiscplabel,resolution=16,color=self.modelcolors['BCP'],
                                                                scale_mode='scalar',scale_factor=1.0) )
                elif (ptype == 'NCP' or ptype == 'NNACP' or ptype == 'NACP'):   # NCPs are cyan
                    self.cpplot.append(self.scene.mlab.points3d(px,py,pz,ps,name='NCP '+thiscplabel, resolution=16,color=self.modelcolors['NCP'],
                                                                scale_mode='scalar',scale_factor=1.0) )
                elif ptype == 'RCP':  # RCPs are red
                    self.cpplot.append(self.scene.mlab.points3d(px,py,pz,ps,name='RCP '+thiscplabel, resolution=16,color=self.modelcolors['RCP'],
                                                                scale_mode='scalar',scale_factor=1.0) )
                elif ptype == 'CCP':  # CCPs are blue
                    self.cpplot.append(self.scene.mlab.points3d(px,py,pz,ps,name='CCP '+thiscplabel, resolution=16,color=self.modelcolors['CCP'],
                                                                scale_mode='scalar',scale_factor=1.0) )
        else:   # triggered on redraw
            for i in range(0,len(self.cpplot)):  # redraw CPs
                self.cpplot[i].mlab_source.set(x=self.cpx[i],y=self.cpy[i],z=self.cpz[i],scalars=self.CPs)

        # loop over CP plot objects, set CP visibility
        for p in self.cpplot:
            if p.name.startswith('N'):
                setplotobjvisibility(p, self.show_ncps)
            elif p.name.startswith('B'):
                setplotobjvisibility(p, self.show_bcps)
            elif p.name.startswith('R'):
                setplotobjvisibility(p, self.show_rcps)
            elif p.name.startswith('C'):
                setplotobjvisibility(p, self.show_ccps)                
                    

    @on_trait_change('scene.activated,Paths,'\
                     'show_bps,show_bps_col,show_pps,show_pps_col,show_ppps,show_ppps_col,'\
                     'show_qps,show_qps_col,show_qps,show_qpps,show_qpps_col,show_qps_col,'\
                     'show_iasev1s,show_iasev2s,show_iaspath_col,'\
                     'show_extra_pps,show_extra_pps_col,show_extra_qps,show_extra_qps_col,'\
                     'show_extra_ppps,show_extra_ppps_col,show_extra_qpps,show_extra_qpps_col')
    def update_plot_paths(self):  # path plotter method
        '''
        Draw paths
        '''
        if not self.mgloaded:
            return
        ############
        # BOND PATHS
        ############
        if self.bondplot is None:  # first draw
            self.bondplot = []
            for thispath in self.bondpaths:  # create plot3d objects for bondpaths from thispath.{path_x,path_y,path_z} lists
                pathx = thispath.path_x
                pathy = thispath.path_y
                pathz = thispath.path_z
                dummypathscalars = [1.0]*len(pathx)
                #print('Description = {0}'.format(thispath.description))
                # append this path from self.bondpaths as a mlab.plot3d object to self.bondplot
                newobject = self.scene.mlab.plot3d(pathx, pathy, pathz, dummypathscalars,
                                                   color=self.modelcolors['bondpath'], name=thispath.description,
                                                   tube_radius=self.Paths, tube_sides=16)  # black
                newobject.actor.actors[0].object_name = thispath.description
                self.bondplot.append(newobject)
            print('Object tree of first bondplot object:')
            objprint(self.bondplot[0],depth=1)
        else:                      # triggered on redraw
            newcol = self.stringtotuple('{0}'.format(self.show_bps_col))
            for plotobject in self.scene.mayavi_scene.children:
                if ("from BCP to" in plotobject.name):
                    surface = plotobject.children[0].children[0].children[0].children[0]
                    surface.parent.parent.filter.radius=self.Paths
                    surface.actor.property.color = newcol
                    surface.actor.property.ambient_color = newcol
                    surface.actor.property.diffuse_color = newcol
                    surface.actor.property.specular_color = newcol

        if self.show_bps:  # toggle bondpath visibility
            for bondplotobj in self.bondplot:  # loop over bondplot path objects, make visible
                bondplotobj.visible = True
            allvis = [ i.visible for i in self.bondplot ]
        else:
            for bondplotobj in self.bondplot:  # loop over bondplot path object, make invisible
                bondplotobj.visible = False

        ###########
        # IAS PATHS
        ###########
        if self.iaspathplot is None:  # first draw
            self.iaspathplot = []
            for thispath in self.iaspaths:  # DRAW IAS PATHS
                pathx = thispath.path_x
                pathy = thispath.path_y
                pathz = thispath.path_z
                #print(thispath.description)
                dummypathscalars = [1.0]*len(pathx)
                self.iaspathplot.append(self.scene.mlab.plot3d(pathx, pathy, pathz, dummypathscalars,
                                                               color=self.modelcolors['iaspath'], name=thispath.description,
                                                               tube_radius=self.Paths, tube_sides=16))  # grey
        else:                        # triggered on redraw
            for iasplotobj in self.iaspathplot:  # redraw bond paths with new radius
                iasplotobj.parent.parent.filter.radius=self.Paths

        # toggle IAS path visibility                  
        for iasplotobj in self.iaspathplot:            
            if 'EV1' in iasplotobj.parent.parent.parent.parent.name:
                iasplotobj.visible = self.show_iasev1s
            elif 'EV2' in iasplotobj.parent.parent.parent.parent.name:
                iasplotobj.visible = self.show_iasev2s

                
        ###########################
        # p,p`,q,q` and EXTRA PATHS
        ###########################
        if self.pathplot is None:  # first draw
            if (self.verbose):
                print('*** ADDING PATHS ***')
            self.pathplot = []
            for thispath in self.paths:  # DRAW PATHS (these should have 'pathtype' field)
                pathx = thispath.path_x
                pathy = thispath.path_y
                pathz = thispath.path_z
                pathtype = thispath.pathtype
                if (self.verbose):  # print path (x,y,z) triples
                    print('Adding path: {0}'.format(pathtype))
                    print('Current path description: {0}'.format(thispath.description))
                    for i in range(0,len(pathx)):
                        print(pathx[i],pathy[i],pathz[i])
                dummypathscalars = [1.0]*len(pathx)
                # construct and store path objects
                #
                if not 'xtra' in pathtype:  # ======== build and add BASIC path-types
                    if pathtype.startswith('p-path'):   # build and add p-paths
                        newobject = self.scene.mlab.plot3d(pathx, pathy, pathz, dummypathscalars,
                                                           color=self.modelcolors['p-path'], name=thispath.description,
                                                           tube_radius=self.Paths, tube_sides=16)  # cyan
                        self.pathplot.append(newobject)
                        newobject.actor.actors[0].object_name = thispath.description
                    elif pathtype.startswith('p`-path'):  # build and add p`-paths
                        self.pathplot.append(self.scene.mlab.plot3d(pathx, pathy, pathz, dummypathscalars,
                                                                    color=self.modelcolors['p`-path'], name=thispath.description,
                                                                    tube_radius=self.Paths, tube_sides=16))  # cyan
                    elif pathtype.startswith('q-path'):   # build and add q-paths
                        self.pathplot.append(self.scene.mlab.plot3d(pathx, pathy, pathz, dummypathscalars,
                                                                    color=self.modelcolors['q-path'], name=thispath.description,
                                                                    tube_radius=self.Paths, tube_sides=16))  # magenta
                    elif pathtype.startswith('q`-path'):  # build and add q`-paths
                        self.pathplot.append(self.scene.mlab.plot3d(pathx, pathy, pathz, dummypathscalars,
                                                                    color=self.modelcolors['q`-path'], name=thispath.description,
                                                                    tube_radius=self.Paths, tube_sides=16))  # magenta
                else:                      # ======== build and add EXTRA path-types,
                    if pathtype.startswith('p-path'):   # build and add EXTRA p-paths
                        self.pathplot.append(self.scene.mlab.plot3d(pathx, pathy, pathz, dummypathscalars,
                                                                    color=self.modelcolors['extra p-path'], name=thispath.description,
                                                                    tube_radius=self.Paths, tube_sides=16))  # cyan
                    elif pathtype.startswith('p`-path'):  # build and add EXTRA p`-paths
                        self.pathplot.append(self.scene.mlab.plot3d(pathx, pathy, pathz, dummypathscalars,
                                                                    color=self.modelcolors['extra p`-path'], name=thispath.description,
                                                                    tube_radius=self.Paths, tube_sides=16))  # cyan
                    elif pathtype.startswith('q-path'):   # build and add EXTRA q-paths
                        self.pathplot.append(self.scene.mlab.plot3d(pathx, pathy, pathz, dummypathscalars,
                                                                    color=self.modelcolors['extra q-path'], name=thispath.description,
                                                                    tube_radius=self.Paths, tube_sides=16))  # magenta
                    elif pathtype.startswith('q`-path'):  # build and add EXTRA q`-paths
                        self.pathplot.append(self.scene.mlab.plot3d(pathx, pathy, pathz, dummypathscalars,
                                                                    color=self.modelcolors['extra q`-path'], name=thispath.description,
                                                                    tube_radius=self.Paths, tube_sides=16))  # magenta

            if (self.verbose):
                print('*** FINISHED ADDING PATHS ***')
        else:                      # redraw
            # ==================== PATHPLOT OBJECT RADIUS AND COLORS  =========================
            newpcol = self.stringtotuple('{0}'.format(self.show_pps_col))
            newppcol = self.stringtotuple('{0}'.format(self.show_ppps_col))
            newqcol = self.stringtotuple('{0}'.format(self.show_qps_col))
            newqpcol = self.stringtotuple('{0}'.format(self.show_qpps_col))
            newxtrapcol = self.stringtotuple('{0}'.format(self.show_extra_pps_col))
            newxtraqcol = self.stringtotuple('{0}'.format(self.show_extra_qps_col))
            newxtrappcol = self.stringtotuple('{0}'.format(self.show_extra_ppps_col))
            newxtraqpcol = self.stringtotuple('{0}'.format(self.show_extra_qpps_col))
            for plotobject in self.scene.mayavi_scene.children:
                if (not 'xtra' in plotobject.name):     # ordinary p,q,p',q'
                    if ("p-path" in plotobject.name):
                        isvisible = plotobject.visible
                        surface = plotobject.children[0].children[0].children[0].children[0]
                        surface.parent.parent.filter.radius=self.Paths
                        surface.actor.property.color = newpcol
                        surface.actor.property.ambient_color = newpcol
                        surface.actor.property.diffuse_color = newpcol
                        surface.actor.property.specular_color = newpcol
                        plotobject.visible = False
                        plotobject.visible = isvisible
                    elif ("q-path" in plotobject.name):
                        isvisible = plotobject.visible
                        surface = plotobject.children[0].children[0].children[0].children[0]
                        surface.parent.parent.filter.radius=self.Paths
                        surface.actor.property.color = newqcol
                        surface.actor.property.ambient_color = newqcol
                        surface.actor.property.diffuse_color = newqcol
                        surface.actor.property.specular_color = newqcol
                        plotobject.visible = False
                        plotobject.visible = isvisible
                    elif ("p`-path" in plotobject.name):
                        isvisible = plotobject.visible
                        surface = plotobject.children[0].children[0].children[0].children[0]
                        surface.parent.parent.filter.radius=self.Paths
                        surface.actor.property.color = newppcol
                        surface.actor.property.ambient_color = newppcol
                        surface.actor.property.diffuse_color = newppcol
                        surface.actor.property.specular_color = newppcol
                        plotobject.visible = False
                        plotobject.visible = isvisible
                    elif ("q`-path" in plotobject.name):
                        isvisible = plotobject.visible
                        surface = plotobject.children[0].children[0].children[0].children[0]
                        surface.parent.parent.filter.radius=self.Paths
                        surface.actor.property.color = newqpcol
                        surface.actor.property.ambient_color = newqpcol
                        surface.actor.property.diffuse_color = newqpcol
                        surface.actor.property.specular_color = newqpcol
                        plotobject.visible = False
                        plotobject.visible = isvisible
                else:                                   # extra p,q,p',q'
                    if ("p-path" in plotobject.name):
                        isvisible = plotobject.visible
                        surface = plotobject.children[0].children[0].children[0].children[0]
                        surface.parent.parent.filter.radius=self.Paths
                        surface.actor.property.color = newxtrapcol
                        surface.actor.property.ambient_color = newxtrapcol
                        surface.actor.property.diffuse_color = newxtrapcol
                        surface.actor.property.specular_color = newxtrapcol
                        plotobject.visible = False
                        plotobject.visible = isvisible
                    elif ("q-path" in plotobject.name):
                        isvisible = plotobject.visible
                        surface = plotobject.children[0].children[0].children[0].children[0]
                        surface.parent.parent.filter.radius=self.Paths
                        surface.actor.property.color = newxtraqcol
                        surface.actor.property.ambient_color = newxtraqcol
                        surface.actor.property.diffuse_color = newxtraqcol
                        surface.actor.property.specular_color = newxtraqcol
                        plotobject.visible = False
                        plotobject.visible = isvisible
                    elif ("p`-path" in plotobject.name):
                        isvisible = plotobject.visible
                        surface = plotobject.children[0].children[0].children[0].children[0]
                        surface.parent.parent.filter.radius=self.Paths
                        surface.actor.property.color = newxtrapcol
                        surface.actor.property.ambient_color = newxtrappcol
                        surface.actor.property.diffuse_color = newxtrappcol
                        surface.actor.property.specular_color = newxtrappcol
                        plotobject.visible = False
                        plotobject.visible = isvisible
                    elif ("q`-path" in plotobject.name):
                        isvisible = plotobject.visible
                        surface = plotobject.children[0].children[0].children[0].children[0]
                        surface.parent.parent.filter.radius=self.Paths
                        surface.actor.property.color = newxtraqcol
                        surface.actor.property.ambient_color = newxtraqpcol
                        surface.actor.property.diffuse_color = newxtraqpcol
                        surface.actor.property.specular_color = newxtraqpcol
                        plotobject.visible = False
                        plotobject.visible = isvisible
        #  ==================== PATHPLOT OBJECT VISIBILITY =========================
        for bondplotobj in self.pathplot:        # Loop over pathplot objects, set visibility
            bondplotobjname = bondplotobj.parent.parent.parent.parent.name
            if not 'xtra' in bondplotobjname:    #    ORDINARY PATH
                if 'p-path' in bondplotobjname:  # P-path
                    setplotobjvisibility(bondplotobj,self.show_pps)
                elif 'q-path' in bondplotobjname:  # Q-path
                    setplotobjvisibility(bondplotobj,self.show_qps)
                elif 'p`-path' in bondplotobjname: # P`-path
                    setplotobjvisibility(bondplotobj,self.show_ppps)
                elif 'q`-path' in bondplotobjname: # Q`-path
                    setplotobjvisibility(bondplotobj,self.show_qpps)
            else:                                #     EXTRA PATH
                if 'p-path' in bondplotobjname:  # EXTRA P-path
                    setplotobjvisibility(bondplotobj,self.show_extra_pps)
                elif 'q-path' in bondplotobjname:  # EXTRA Q-path
                    setplotobjvisibility(bondplotobj,self.show_extra_qps)
                elif 'p`-path' in bondplotobjname: # EXTRA P`-path
                    setplotobjvisibility(bondplotobj,self.show_extra_ppps)
                elif 'q`-path' in bondplotobjname: # EXTRA Q`-path
                    setplotobjvisibility(bondplotobj,self.show_extra_qpps)


        #### Stuff for arrows
        #        if self.show_parrows:  # draw the two sets of q-arrows
        #            self.scene.mlab.quiver3d(r1x,r1y,r1z,self.Arrows*v12x,self.Arrows*v12y,self.Arrows*v12z,
        #                                     color=self.modelcolors['q-path'],mode='arrow',scale_factor=self.Arrows,
        #                                     mask_points=self.Interval,resolution=16,line_width=0.5)  # q-path color
        #            self.scene.mlab.quiver3d(r2x,r2y,r2z,self.Arrows*v22x,self.Arrows*v22y,self.Arrows*v22z,
        #                                     color=self.modelcolors['q-path'],mode='arrow',scale_factor=self.Arrows,
        #                                     mask_points=self.Interval,resolution=16,line_width=0.5) # q-path color

    @on_trait_change('scene.activated,show_scalarfield')
    def update_plot_scalarfield(self):
        '''
        Draw the currently selected scalar field
        '''
        if self.scalarfieldplot is None:  # first draw
            pass
        else:  # redraw
            pass
        
    @on_trait_change('scene.activated,show_vectorfield')
    def update_plot_vectorfield(self):
        '''
        Draw the currently selected vector field
        '''        
        if self.vectorfieldplot is None:  # first draw
            pass
        else:  # redraw
            pass 

    @on_trait_change('show_atoms_more')
    def atom_visibility(self):
        print('Atoms visibility button was pressed')
        stateslist = List([(obj.visible,"label") for obj in self.atomplot])
        objprint(stateslist)
        viswin = VisibilityListWindow(stateslist,self.atomlabels)
        viswin.edit_traits(view=self.vislistview,kind='live')
        
        atom_visibility_view=View(Item('stateobject',editor=CheckListEditor()),kind='live')
        viswin.edit_traits(view='atom_visibility_view')
        


##################################################################################
##################################################################################
# GUI LAYOUT
# Sections defined below
#
    # Side panel for main view tab    
    sidepanel1 = VGroup(HGroup(Item('show_atoms',label='Atoms'),
                               Item('Atoms',label='Size'),
                               Item('show_atoms_more',show_label=False),
                               Spring()
                               ),
                        HGroup(Item('show_labels',label='Labels'),
                               Item('Text',label='Size'),
                               Item('show_labels_more',show_label=False),
                               Spring()
                               ),
                        VGroup(HGroup(Item('show_ncps',label=' '),
                                        Item('CPs',label='Size'),Spring(),label='NCP',
                                    ),
                                HGroup(Item('show_bcps',label=' '),
                                        Item('CPs',label='Size'),Spring(),label='BCP',
                                    ),
                                HGroup(Item('show_rcps',label=' '),
                                        Item('CPs',label='Size'),Spring(),label='RCP',
                                    ),
                                HGroup(Item('show_ccps',label=' '),
                                        Item('CPs',label='Size'),Spring(),label='CCP',
                                    ),
                                label='CP style',
                                ),
                        Item(name='_'),
                        HGroup(Item('Paths'),
                               Spring()
                              ),
                        HGroup(Item('PQscale',label='Path vector scale'),
                               Spring()
                              ),
                        #Item(name='_'),
                        VGroup(HGroup(
                                   Item('show_bps',label='Bond paths'),
                                   Item('show_bps_col', editor=RGBColorEditor(),style='simple',show_label=False),
                                   Item('show_bps_more',show_label=False),
                                   Spring()
                                  ),
                            HGroup(
                                   Item('show_pps',label='P-paths'),
                                   Item('show_pps_col', editor=RGBColorEditor(),style='simple',show_label=False),
                                   Item('show_pps_more',show_label=False),
                                   Spring()
                                  ),
                            HGroup(
                                   Item('show_qps',label='Q-paths'),
                                   Item('show_qps_col', editor=RGBColorEditor(),style='simple',show_label=False),
                                   Item('show_qps_more',show_label=False),
                                   Spring()
                                  ),
                            HGroup(
                                   Item('show_ppps',label='P`-paths'),
                                   Item('show_ppps_col', editor=RGBColorEditor(),style='simple',show_label=False),
                                   Item('show_ppps_more',show_label=False),
                                   Spring()
                                  ),
                            HGroup(
                                   Item('show_qpps',label='Q`-paths'),
                                   Item('show_qpps_col', editor=RGBColorEditor(),style='simple',show_label=False),
                                   Item('show_qpps_more',show_label=False),
                                   Spring()
                                  ),
                            Item(name='_'),
                            Item(name=' '),
                            HGroup(
                                   Item('show_extra_pps',label='Extra p-paths'),
                                   Item('show_extra_pps_col', editor=RGBColorEditor(),style='simple',show_label=False),
                                   Spring()
                                  ),
                            HGroup(
                                   Item('show_extra_qps',label='Extra q-paths'),
                                   Item('show_extra_qps_col', editor=RGBColorEditor(),style='simple',show_label=False),
                                   Spring()
                                  ),
                            HGroup(
                                   Item('show_extra_ppps',label='Extra p`-paths'),
                                   Item('show_extra_ppps_col', editor=RGBColorEditor(),style='simple',show_label=False),
                                   Spring()
                                  ),
                            HGroup(
                                   Item('show_extra_qpps',label='Extra q`-paths'),
                                   Item('show_extra_qpps_col', editor=RGBColorEditor(),style='simple',show_label=False),
                                   Spring()
                                  ),
                            Item(name='_'),
                            Item(name=' '),
                            HGroup(
                                   Item('show_iasev1s',label='IAS EV1 paths'),
                                   Item('show_iaspath_col', editor=RGBColorEditor(),style='simple',show_label=False),
                                   Spring()
                                  ),
                            HGroup(
                                   Item('show_iasev2s',label='IAS EV2 paths'),
                                   Item('show_iaspath_col', editor=RGBColorEditor(),style='simple',show_label=False),
                                   Spring()
                                  ),
                            label='Path style'
                        ),
                        Item(name='_'),
                        Item(name=' '),
                        Item('show_parrows',label='P-arrows',enabled_when='False'),
                        Item('show_qarrows',label='Q-arrows',enabled_when='False'),
                        HGroup(Item('Interval',enabled_when='False'),
                               Spring()
                               ),
                        Item(name='_'),
                        Item(name=' '),
                        Item('show_boundary',label='Boundary'),
                        Item('show_scalarfield',label='Scalar field',enabled_when='False'),
                        Item('show_vectorfield',label='Vector field',enabled_when='False'),
                        label='Visibility',

                       )

    # Critical point table tab
    cptable_editor = TableEditor(editable=False,
                                 sortable=True,
                                 selection_mode='rows',
                                 columns=[
                                          NumericColumn(name='Number',label='CP#'),
                                          ObjectColumn(name='Type'),
                                          ObjectColumn(name='Name'),
                                          NumericColumn(name='X'),
                                          NumericColumn(name='Y'),
                                          NumericColumn(name='Z'),
                                          NumericColumn(name='Rho'),
                                          NumericColumn(name='DelSqRho',label='Lap'),
                                          NumericColumn(name='Ellipticity',label='Ellipticity'),
                                          NumericColumn(name='Metallicity',label='Metallicity'),
                                          NumericColumn(name='BPL'),
                                          NumericColumn(name='GBL_II'),
                                          NumericColumn(name='K'),
                                         ],
                                 other_columns=[
                                                NumericColumn(name='V'),
                                                NumericColumn(name='G'),
                                                NumericColumn(name='L'),
                                                NumericColumn(name='GBL_I'),
                                                NumericColumn(name='GBL_III'),
                                                NumericColumn(name='GBL_IV'),
                                               ],
                                 sort_model=False,
                                 auto_size=True,
                                 filters=[MenuFilterTemplate],
                                 orientation='vertical',
                                 configurable=True,
                                 selected_indices='selectedcps',
                                 show_toolbar=True,
                                 search=MenuTableFilter(),
                                 cell_font='bold',
                                 menu=None,
                                 #on_select=report_selected(selectedcps),
                                )

    # frame list tab
    framelist_editor = TreeEditor(nodes=[
#    # The first node specified is the top level one
        TreeNode(
            node_for=[Sequence],
            auto_open=True,
            children='',
            label='name',  # label with Sequence name
            view=View(  VGroup(Item(name='name',
                                  tooltip=u"Sequence name",
                                  editor=TextEditor(),
                                  show_label=True,
                                  label='Sequence Name',
                                  resizable=False,
                                  ),
                             Item(name='comment',
                                  tooltip=u"Comment field for this sequence",
                                  editor=TextEditor(),
                                  show_label=True,
                                  label='Comments',
                                  resizable=True,
                                  height=150,
                                  ),
                                 label="Sequence information") 
                            ),
                        
        ),
        # Node for Sequence
        TreeNode(
            node_for=[Sequence],
            auto_open=True,
            children='framelist',
            label='=Frames',  # constant label
#            view=View(Label('Number of frames = {0}'.format(len(self.currentseq.frames))),
#                     ),
            view=View(Label('=Frames'),
                     ),                     
            add=[TraitedFrame]
        ),
        #Node for Frame
        TreeNode(
            name = 'Frame',   # Menu label New->Frame
            node_for=[TraitedFrame],
            auto_open=True,
            children='',
            label='name',  # label with Frame name
            # View for frame data
            view=View(Label('Frame Data'),
                      Item(name='name',
                           editor=TextEditor(),
                           label='Name',
                           show_label=True,
                           resizable=False ),
                      Item(name='sequencevar',
                           editor=TextEditor(),
                           show_label=True,
                           label='Sequence variable',
                           resizable=False ),   
                      ),
        ),
        #Node for MGs
        TreeNode(
            node_for=[TraitedFrame],
            auto_open=True,
            children='mgs',
            label='=Molecular graph',  # label with Frame name
            view=View(),
            add=[TMG],
        ),
        # Node for Paths
        TreeNode(
            node_for=[TraitedFrame],
            auto_open=True,
            children='paths',
            label='=Paths',  # label with Frame name
            view=View(),
            add=[TPath],
        ),
        # Node for scalar grids
        TreeNode(
            node_for=[TraitedFrame],
            auto_open=True,
            children='scalargrids',
            label='=Scalar Fields',  # label with Frame name
            view=View(),
            add=[TFieldGrid],
        ),
        # Node for vector grids
        TreeNode(
            node_for=[TraitedFrame],
            auto_open=True,
            children='vectorgrids',
            label='=Vector Fields',  # label with Frame name
            view=View(),
            add=[TFieldGrid],
        ),
        # Node for molecular graphs        
        TreeNode(
            name='Molecular graph',  # menu label New->Molecular graph
            node_for=[TMG],
            auto_open=True,
            children='',
            label='name',  # label with MG name
            view=View(Label('Molecular graph data'),
                      Item(name='name',
                           editor=TextEditor(),
                           show_label=True),
                           title='Name',
                           resizable=False,
                      ),
        ),
        # Node for Path
        TreeNode(
            name = 'Path',    # menu label New->Path
            node_for=[TPath],
            auto_open=True,
            children='',
            label='name',  # label with Path name
            view=View(Label('Path data'),
                      Item(name='name',
                           editor=TextEditor(),
                           show_label=True),
                           title='Name',
                           resizable=False,
                      ),
        ),
        #Node for Field Grid
        TreeNode(
            name='Field Grid',  # Menu label New->Field Grid
            node_for=[TFieldGrid],
            auto_open=True,
            children='',
            label='name',  # label with Frame name
            view=View(Label('Grid data'),
                      Item(name='name',
                           editor=TextEditor(),
                           show_label=True),
                           title='Name',
                           resizable=False,
                      ),
                ),     
        ],
        editable=True
    )

    scalarfield_editor = NullEditor()

    vectorfield_editor = NullEditor()

    # MAIN VIEW TAB
    view = View(Tabbed(
                       HSplit(VGroup(Item('scene', editor=SceneEditor(scene_class=MayaviScene),
                                          height=700, width=700, show_label=False),
                                     Item('seqrange', 
                                          editor=RangeEditor(low_name='seqnum_low',high_name='seqnum_high',mode='slider',is_float=False) ,
                                          height=50,label='Frame' )), 
                              sidepanel1,
                              label='View'
                              ),
                       HSplit(Item('currentseq',editor=framelist_editor,
                                   show_label=False,label='Frames'),
                              label='Frames',
                              enabled_when='True'
                              ),
                       HSplit(Item('paths',editor=NullEditor(),
                                   show_label=False),
                              label='Paths',
                              enabled_when='False'
                              ),
                       HSplit(Item('CPTable',editor=cptable_editor,
                                          show_label=False),
                              label='CPs'
                             ),
                        HSplit(Item('ScalarField',editor=NullEditor(),
                                   show_label=False),
                              label='ScalarField',
                              enabled_when='False'
                              ),
                       HSplit(Item('VectorField',editor=NullEditor(),
                                   show_label=False),
                              label='VectorField',
                              enabled_when='False'
                              ),
                       ),
                resizable=True,
                toolbar=ToolBar(),
                title='TopViz alpha version '+__version__ ,
                statusbar=statuslinelist,
                menubar=MenuBar(Menu(Action(name="New ..",action='menu_new_mg'),      # action='new'
                                     Action(name="Load",action='menu_get_mg'),        # action="load"
                                     Action(name="Close",action='menu_close'),        # action="close"
                                     Action(name="Export",action='menu_export'),      # action="export"
                                     Action(name="Exit",action='menu_exit'),          # action="exit"
                                     name="File"
                                    ),
                                Menu(Action(name='About ..'),
                                     Separator(),
                                     Action(name="Display Help"),
                                     name="Help"
                                    )
                                )
               )
    #cameraview = View(Item('self.scene.camera',editor=InstanceEditor()))
    

#################################################################################
def main():
    '''
    Main
    '''
    # main code
    # Print information header
    print("==================================================")
    print('Version {0}'.format(__version__))
    print("Using molgraph version {0}".format(mg.__version__))
    print("====== System versions =======")
    print("Mayavi version: {0}".format(mayavi.__version__))
    #print("   VTK version: {0}".format(tvtk.version()._vtk_obj.GetVTKVersion()))
    print("====== ENVIRONMENT =======")
    try:
        qtapi = os.environ['QT_API']
    except KeyError:
        qtapi = 'Not set'
    etstoolkit = os.getenv('ETS_TOOLKIT','Not set')
    if etstoolkit == 'Not set':
        os.environ['ETS_TOOLKIT'] = 'qt'
        print('Environment variable ETS_TOOLKIT undefined: set to qt')
    print("QT_API = {0}".format(qtapi))
    print("ETS_TOOLKIT = {0}".format(etstoolkit))
    print("==========================")
    
    # argument parser
    parser = argparse.ArgumentParser(description="Visualize molecular graph files using Mayavi2\n"+
                                                 "=============================================")
    parser.add_argument("--input", help=".sumviz file or list file [default: none]",default='none')
    parser.add_argument("--atomradius", help="Atom radius to use for atom spheres: covrad, atmrad, vdwrad [default: atmrad]",
                                        default='atmrad')
    parser.add_argument("--bondvectors", help="Optional input file containing bond vectors [default: none]",
                                         default='none')
    parser.add_argument("--extravectors", help="Optional input file containing extra vectors [default: none]",
                                         default='none')
    parser.add_argument("--align", help="Optional sequence of 3 alignment atom names: ORIGIN_ATOM XAXIS_ATOM XYPLANE_ATOM [default: none]",nargs=3,
                                         default=['','',''])
    parser.add_argument("--verbose", help="Print more verbose output",action='store_true')
    parser.add_argument("--elementdata", help="Provide an explicit path to file containing element radius data  [default:use built-in data]",default='none')
    parser.add_argument("--vectorscale", help="Optional scaling to apply to bondvectors and extravectors [default: 1.0]", default=1.0)
    parser.add_argument("--swap_pq", help="Swap the p- and q-path data (e.g. for stress tensor paths)",action='store_true')
    
    # parse the arguments
    args = parser.parse_args()
    infile=args.input
    verbose=args.verbose
    swap_pq = args.swap_pq
    elementdata=args.elementdata
    atomradius = args.atomradius
    bondvectors = args.bondvectors
    extravectors = args.extravectors
    vectorscale = float(args.vectorscale)
    alignatoms = args.align

    # ELEMENT DATA
    # make sure element data file exists, read in element property dictionaries
    if elementdata == 'none':  # use default element data location
        elementdatafile=os.path.join(os.path.abspath(os.path.dirname(__file__)), "jmol_element_colors.txt")
    else:                      # another data location is specified
        elementdatafile = elementdata
    print('Found element radii and JMol colours from {0}'.format(elementdatafile))
    eldata = get_element_data(elementdatafile)
    # Prepare a dictionary of element colour RGB triples
    atom_color_dict = get_element_property_dict(eldata,  'color')
    print('{0} element data items read'.format(len(atom_color_dict)))
    # prepare a dictionary of element radii
    if atomradius == 'covrad':
        print('Using covalent atom radii')
        atom_radius_dict = get_element_property_dict(eldata, 'covrad')
    elif atomradius == 'atmrad':
        print('Using atomic radii (default)')
        atom_radius_dict = get_element_property_dict(eldata, 'atmrad')
    elif atomradius == 'vdwrad':
        print('Using atomic VDW radii')
        atom_radius_dict = get_element_property_dict(eldata, 'vdwrad')
    print('  == Finished reading element data\n')
    # add entry to atom dictionaries for NNAs
    atom_radius_dict['NNA'] = 1.0
    atom_color_dict['NNA'] = [0.5, 0.5, 0.5]

    # INPUT DATA - check if command line parameters have been specified
    if (infile=='none'):
        print('No command line data found')
        cmdlinedata = False
    else:
        cmdlinedata = True
        print('Parsing command line data parameters')
    # 'align' option ?
    if not alignatoms[0] == '':
        print('Specified alignment atoms {0},{1},{2}'.format(alignatoms[0],alignatoms[1],alignatoms[2]))
        print('This option does not work yet - please rerun without the --align option')
        sys.exit()
    # check existence of command line input files, if specified
    if (cmdlinedata):
        if not (os.path.isfile(infile)):
            print('Input file {0} not found!'.format(infile))
            sys.exit()
        if not bondvectors == 'none':
            if not (os.path.isfile(bondvectors)):
                print('Bond vectors input file {0} not found!'.format(bondvectors))
                sys.exit()
        if not extravectors == 'none':
            if not (os.path.isfile(extravectors)):
                print('Extra bond vectors input file {0} not found!'.format(extravectors))
                sys.exit()


    # get lists of files to process
    # MOLECULAR GRAPHS
    filelist = []
    if (cmdlinedata):
        if not infile.endswith('.txt'):  # this is not a file list, must be .seqviz, .sumviz
            filelist.append(infile)
        else:                        # multiple input files specified in a list file
            with open(infile,'r') as listfile:
                rawlines = listfile.readlines()
            # filter comment lines and blank lines
            lines = [i.strip() for i in rawlines if not (i.startswith('#') or len(i.strip()) == 0) ]
            for line in lines:
                tokens = line.split()
                filelist.append(tokens[0])
        # Check that all input files in the input molecular graph file list exist
        for i in filelist:
            if not (os.path.isfile(i)):
                print('Input file {0} not found!'.format(i))
                sys.exit()
            else:
                print('Found the input file: {0}'.format(i))

    # BOND VECTORS
    bvsetlist = []
    bvcolors = []
    if (cmdlinedata):
        if not bondvectors == 'none':
            if not bondvectors.endswith('.txt'):  # this is not a file list
                bvsetlist.append(bondvectors)
            else:                        # multiple input files specified in a list file
                with open(bondvectors,'r') as listfile:
                    rawlines = listfile.readlines()
                # filter comment lines and blank lines
                lines = [i.strip() for i in rawlines if not (i.startswith('#') or len(i.strip()) == 0) ]
                for line in lines:
                    tokens = line.split()
                    numtokens = len(tokens)
                    bvsetlist.append(tokens[0])
                    if numtokens > 1:
                        bvcolors.append(' '.join(tokens[1:]))
                    else:
                        bvcolors.append('')
            # Check that all input files in the input bondvector file list exist
            for i in bvsetlist:
                if not (os.path.isfile(i)):
                    print('Bond vector file {0} not found!'.format(i))
                    sys.exit()

    # EXTRA VECTORS
    extrasetlist = []
    extracolors = []
    if (cmdlinedata):
        if not extravectors == 'none':
            if not extravectors.endswith('.txt'):  # this is not a file list
                extrasetlist.append(extravectors)
            else:                        # multiple input files specified in a list file
                with open(extravectors,'r') as listfile:
                    rawlines = listfile.readlines()
                # filter comment lines and blank lines
                lines = [i.strip() for i in rawlines if not (i.startswith('#') or len(i.strip()) == 0) ]
                for line in lines:
                    tokens = line.split()
                    numtokens = len(tokens)
                    extrasetlist.append(tokens[0])
                    if numtokens > 1:
                        extracolors.append(' '.join(tokens[1:]))
                    else:
                        extracolors.append('')

            # Check that all input files in the input bondvector file list exist
            for i in extrasetlist:
                if not (os.path.isfile(i)):
                    print('Extra vector file {0} not found!'.format(i))
                    sys.exit()

    # Create a Model object and send all the data for visualization
    # modified - now send in list of molecular graph filenames instead of coordinate arrays
    print('\nCreating model\n')
    my_model = MyModel( filelist,
                        atom_radius_dict, atom_color_dict,
                        bvsetlist, bvcolors,
                        extrasetlist, extracolors, vectorscale,
                        verbose, swap_pq)
    # Configure all Traits on the MyModel 
    my_model.configure_traits()

if __name__ == '__main__':
    main()

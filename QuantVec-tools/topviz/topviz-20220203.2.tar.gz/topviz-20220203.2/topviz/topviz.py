# -*- coding: utf-8 -*-
"""
topviz
@author: Steven R. Kirk and Samantha Jenkins, BEACON Research Group, College of Chemistry and Chemical Engineering, Hunan Normal University
"""
# imports for previous compatibility with Python 2.7 removed here as Python 2.x is EOL

# standard imports
import sys, argparse, os, os.path, mayavi

# Gooey builds
#from gooey import Gooey

# Mayavi imports
from traits.api import List, Str, HasTraits, File, Instance, Bool, Float, Int, RGBColor, on_trait_change
from traitsui.api import View, Item, Spring, HGroup, HSplit, VGroup, Tabbed, StatusItem, RGBColorEditor, TreeEditor, TreeNode, TreeNodeObject, TableEditor,NullEditor, ObjectColumn, ToolBar, NumericColumn
from traitsui.menu import Action, Menu, MenuBar, Separator
from traitsui.file_dialog import open_file
from traitsui.table_filter import MenuFilterTemplate, MenuTableFilter
from mayavi import mlab
from mayavi.core.api import PipelineBase
from mayavi.core.ui.api import MayaviScene, SceneEditor, MlabSceneModel

# custom imports
#import numpy as np
import molgraph as mg

__version__ = "20220203.0002"


def get_element_data(datafile):
    '''
    From 'datafile', return element properties as list of lists
    '''
    eldata = []
    with open(datafile) as f:
        lines = f.readlines()
        for line in lines:
            if not(line.startswith('#') or line.strip() == ''):  # for all except comment lines and blank lines
                tokens = line.split()
                elnum = int(tokens[0])                     # Element atomic number
                elsym = tokens[1].strip()                  # Element symbol
                elcovrad = float(tokens[2])                # Element covalent radius
                elatmrad = float(tokens[3])                # Element atomic radius
                elvdwrad = float(tokens[4])                # Element VDW radius
                irgb = tokens[5].strip('[]').split(',')    # Element colour RGB contributions 0-255 [R,G,B]
                elfrgb = [float(i)/255.0 for i in irgb]    # Element colour RGB contributions 0.0-1.0 [R,G,B]
                # add this element's data to the list
                eldata.append([elnum, elsym, elcovrad, elatmrad, elvdwrad, elfrgb])
    # sanity check
    if len(eldata) < 109:
        print('WARNING: found only {0} sets of element data in {1} - expected 109 or more'.format(len(eldata), datafile))
    return eldata


def setplotobjvisibility(obj, status):
    '''
    Set the visibility flags on a specific Mayavi plot object
    '''
    obj.visible = status
    obj.actor.visible=status
    obj.actor.actor.visibility=status

def get_element_property_dict(eldata, field):
    '''
    Given 'eldata', a list of lists of element properties, return a dict of specific properties, selected by 'field', keyed by element symbol
    '''
    elcols = {}
    for element in eldata:
        elnum = element[0]
        elsym = element[1]
        elcovrad = element[2]
        elatmrad = element[3]
        elvdwrad = element[4]
        elfrgb = element[5]
        if field == 'color':
            elcols[elsym] = elfrgb
        elif field == 'covrad':
            elcols[elsym] = elcovrad
        elif field == 'atmrad':
            elcols[elsym] = elatmrad
        elif field == 'vdwrad':
            elcols[elsym] = elvdwrad
    return elcols

class NamedFieldPath(mg.FieldPath):
   '''
   Derived class from molgraph FieldPath

   Parent class has fields
        self.description = ""
        self.path_x = []
        self.path_y = []
        self.path_z = []
        self.path_fieldvar = []
   '''
   pathtype = ''

   def __init__(self, px, py, pz, description, pathtype, path_fieldvar):
       super()
       self.path_x = px
       self.path_y = py
       self.path_z = pz
       self.description = description
       self.pathtype = pathtype
       self.path_fieldvar = path_fieldvar

class FramePathList():
    '''
    Class to hold list of NamedFramePath objects, and associated molecular graph file name
    '''
    pathlist = []
    framepathname = ''

    def __init__(self,pathlist,framepathname):
        self.pathlist = pathlist
        self.framepathname = framepathname

class MGFileDialog(HasTraits):
    '''
    Molecular graph data file dialog
    '''
    # The name of the selected file:
    fname = File()
    file_name=None

    #-- Traits View Definitions ----------------------------------------------
    #view = View(HGroup(Item('fname', style='simple', springy=True, label='Input file'), is_save_file=False))

    def __init__(self):
        """
        Open a file dialog
        """
        #file_name = open_file(extensions=LineCountInfo(), id=demo_id)
        fname = open_file(is_save_file=False)
        if fname != '':
            self.file_name = '{0}'.format(fname)

class TraitedCP(HasTraits):
    '''
    This is as minimal a Traited wrapper as possible around a molecular graph critical point
    '''
    def __init__(self,cp):
        #self.pathlist = []
        self.X = cp.pos_x
        self.Y = cp.pos_y
        self.Z = cp.pos_z
        self.field = cp.field
        self.filetype = cp.filetype
        self.Type = cp.type
        self.Number = 0
        self.Name = cp.connected
        self.Rho = cp.Rho
        #self.RhoNuc = Float()
        #self.GradRho = List( Float(0.0),Float(0.0),Float(0.0))
        #self.HessRho = []
        #self.HessRho_EigVals = List( Float(0.0),Float(0.0),Float(0.0) )
        #self.HessRho_EigVec1 = List( Float(0.0),Float(0.0),Float(0.0) )
        #self.HessRho_EigVec2 = List( Float(0.0),Float(0.0),Float(0.0) )
        #self.HessRho_EigVec3 = List( Float(0.0),Float(0.0),Float(0.0) )
        self.DelSqRho = cp.DelSqRho
        self.Ellipticity = cp.Ellipticity
        self.V = cp.V
        self.G = cp.G
        self.K = cp.K
        self.L = cp.L
        #self.Vnuc = Float(0.0)
        #self.Ven = Float(0.0)
        #self.Vrep = Float(0.0)
        #self.DelSqV = Float(0.0)
        #self.DelSqVen = Float(0.0)
        #self.DelSqVrep = Float(0.0)
        #self.DelSqG = Float(0.0)
        #self.DelSqK = Float(0.0)
        #self.Stress = []
        #self.Stress_EigVals = List( Float(0.0),Float(0.0),Float(0.0))
        #self.Stress_EigVec1 = List( Float(0.0),Float(0.0),Float(0.0))
        #self.Stress_EigVec2 = List( Float(0.0),Float(0.0),Float(0.0))
        #self.Stress_EigVec3 = List( Float(0.0),Float(0.0),Float(0.0))
        #self.MinusDivStress = List( Float(0.0),Float(0.0),Float(0.0))
        #self.ESP = Float()
        #self.ESPNuc = Float()
        #self.ESPe = Float()
        #self.ESPeNuc = Float()
        #self.ESPn = Float()
        #self.ESPnNuc = Float()
        self.BPL = cp.BPL
        self.GBL_I = cp.GBL_I
        self.GBL_II = cp.GBL_II
        self.GBL_III = cp.GBL_III
        self.GBL_IV = cp.GBL_IV


class TraitedFrame(TreeNodeObject):
    '''
    Traited frame
    '''
    def __init__(self):
        pass
        #MGList = List(TraitedCP)
        #HasTraits.add_trait(MGList,List(TraitedCP))
        #MGList = List(TraitedCP)
    #    self.PathList = None
    #    self.PathList = List(FramePathList)
    #    self.ScalarFieldList = List()
    #    self.VectorFieldList = List()

    def addmg(self, mg):
       '''
       Add a molecular graph to a TraitedFrame as a Tree Node object
       '''
       #self.MGList.append(TreeNode(node_for=[TraitedFrame],
       #                            auto_open=False,
       #                            label='='+mg.filename))
       pass


class TraitedFramelist(HasTraits):
    '''
    Traited Frame List
    '''
    framelist = List(TraitedFrame)

    def addframe(self,newframe):
        self.framelist.append(newframe)



class MyModel(HasTraits):
    '''
    Model object
    '''
    # per sequence of frames
    graph_file_list = []     # list of molecular graph files
    path_file_list = []      # list of path files
    atom_radius_dict = None  # dict of atomsymbol:atom radii
    atom_colour_dist = None  # dict of atomsymbol:atom rendering colour
    framenames = []          # list of frames (input filenames holding molecular graphs)
    frames = []              # list of frames (molecular graphs)
    pathframes = []          # list of frame paths
    numframes = 0            # number of frames
    currentframe = 0
    verbose = None

    # per frame
    thismg = None
    mgloaded = False
    #firstdraw = True
    atomx, atomy, atomz =            None, None, None
    atomsize, atomcols, atomlabels = None, None, None
    cpx, cpy, cpz, cptype, cplabel = None, None, None, None, None
    bondpaths, iaspaths, paths, pathtypes, ScalarField, VectorField = [], [], [], [], [], []
    thisnatoms, thisnumcps = 0, 0
    filename = None

    # PER_FRAME PLOT OBJECTS
    atomplot = None          # list of plot objects for atoms
    atomlabelsplot = []      # list of plot objects for atom labels
    cpplot = None            # Single plot object for all CPs
    bondplot = None          # Lists of plot objects for bond paths
    iaspathplot = None       # Lists of plot objects for IAS paths
    pathplot = None          # Lists of plot objects for other paths
    numbondplot, numiasplot, numpathplot = 0,0,0

    # Initialize MAYAVI and declare Traits
    scene = Instance(MlabSceneModel, ())
    # Configure GUI sizes and colours
    # GUI Floats (Traits) - sizes
    Atoms, CPs, Paths, Arrows, Text, Interval = Float(0.3), Float(0.25), Float(0.03), Float(1.0), Float(12.0), Int(1)
    # GUI visibility toggles
    show_atoms, show_labels = Bool(True), Bool(True)                                             # atoms and labels
    show_cps = Bool(True)                                                                        # CPs
    show_bps, show_pps, show_qps = Bool(True), Bool(False), Bool(False)                          # p,q,r paths
    show_ppps, show_qpps = Bool(False), Bool(False)                                              # p`,q` primed paths
    show_parrows, show_qarrows = Bool(False), Bool(False)                                        # Arrows
    show_iasev1s, show_iasev2s = Bool(False), Bool(False)                                        # IAS EV1, EV2 paths
    show_extra_pps, show_extra_qps = Bool(False), Bool(False)                                    # Extra p,q paths
    show_extra_ppps, show_extra_qpps = Bool(False), Bool(False)                                  # Extra p',q' paths
    show_scalarfield = Bool(False)                                                               # ScalarField
    show_vectorfield = Bool(False)                                                               # VectorField
    # View style
    viewstyle = Str('Parallel')
    # GUI colour settings
    modelcolors =  {'NCP':         (0.0,1.0,1.0),
                    'BCP':         (0.0,1.0,0.0),
                    'RCP':         (1.0,0.0,0.0),
                    'CCP':         (0.0,0.0,1.0),
                    'bondpath':    (0.0,0.0,0.0),
                    'iaspath':     (0.75,0.75,0.75),
                    'p-path':      (0.0,1.0,1.0),
                    'q-path':      (1.0,0.5,1.0),
                    'p`-path':     (0.0,1.0,1.0),
                    'q`-path':     (1.0,0.5,1.0),
                    'extra p-path':(0.0,0.0,1.0),
                    'extra q-path':(1.0,0.0,0.0),
                    'extra p`-path':(0.0,0.0,1.0),
                    'extra q`-path':(1.0,0.0,0.0),
                    'background':  (1.0,1.0,1.0),
                    'labelcolor':  (0.0,0.0,0.0)
                    }
    # initialize editable color pickers
    show_bps_col = RGBColor(modelcolors['bondpath'])                                             # bond path color
    show_pps_col = RGBColor(modelcolors['p-path'])                                               # p-path color
    show_qps_col = RGBColor(modelcolors['q-path'])                                               # q-path color
    show_ppps_col = RGBColor(modelcolors['p`-path'])                                             # p`-path color
    show_qpps_col = RGBColor(modelcolors['q`-path'])                                             # q`-path color
    show_extra_pps_col = RGBColor(modelcolors['extra p-path'])                                   # Extra p-path color
    show_extra_qps_col = RGBColor(modelcolors['extra q-path'])                                   # Extra q-path color
    show_extra_ppps_col = RGBColor(modelcolors['extra p`-path'])                                 # Extra p`-path color
    show_extra_qpps_col = RGBColor(modelcolors['extra q`-path'])                                 # Extra q`-path color
    show_iaspath_col = RGBColor(modelcolors['iaspath'])                                          # IAS path
    #

    framelistname = Str('No file loaded')
    statuslinelist = [StatusItem(name='framelistname'),StatusItem(name='viewstyle')]
    FrameList = TraitedFramelist()

    FrameListNode = TreeNode(
                         children=''
                         )
    CPTable = List(TraitedCP)


    def __init__(self, graphlist, atom_radius_dict, atom_colour_dict,
                 bvsetlist, bvcolors, extrasetlist, extrasetcolors,
                 vectorscale, verboseflag, swap_pq):
        '''
        Initialize the Model object
        '''
        # Call the parent class __init__
        HasTraits.__init__(self)
        # Initialize object fields
        # frame list
        if (len(graphlist) == 0):
            self.framelistname = 'Load input files using the File menu'
        else:
            self.framelistname = graphlist[0]
        self.graph_file_list = graphlist
        for gfile in self.graph_file_list:
            newframe = TraitedFrame()
            newframe.addmg(gfile)
            self.FrameList.addframe(newframe)
        #
        self.atom_radius_dict = atom_radius_dict
        self.atom_colour_dict = atom_colour_dict
        self.pathr = []
        self.pathp = None
        self.pathq = None
        self.pathx = []
        self.bvsetlabels = None
        self.bvsetlist = bvsetlist
        self.bvcolors = bvcolors
        self.extrasetlist = extrasetlist
        self.extrasetcolors = extrasetcolors
        self.verbose = verboseflag
        self.swap_pq = swap_pq
        self.vectorscale = vectorscale
        # set default background colour
        self.scene.scene.background=self.modelcolors['background']
        # set parallel projection by default
        self.scene.scene.parallel_projection = True
        # now read the graphs, if they have been specified
        if not (len(graphlist) == 0):
            self.read(verboseflag)
            # trigger frame load
            self.mgloaded=True
            self.loadframe()


    def get_mg(self):
        """
        Menu function to select input MGs
        """
        filelist=[]
        getmg = MGFileDialog()
        #getmg.configure_traits()
        infile=getmg.file_name
        if infile == None:
            return
        if not infile.endswith('.txt'):  # this is not a file list
            filelist.append(infile)
        else:                            # multiple input files specified in a list file
            with open(infile,'r') as listfile:
                rawlines = listfile.readlines()
            # filter comment lines and blank lines
            lines = [i.strip() for i in rawlines if not (i.startswith('#') or len(i.strip()) == 0) ]
            for line in lines:
                tokens = line.split()
                filelist.append(tokens[0])
        # Check that all input files in the input molecular graph file list exist
        for i in filelist:
            if not (os.path.isfile(i)):
                print('Input file {0} not found!'.format(i))
                sys.exit()
        # all files exist, add them to the graph_file_list
        self.graph_file_list = filelist
        print('Selected file {0}, No. of MGs={1}'.format(infile,len(filelist)))
        self.read(self.verbose)
        self.statuslinelist = [ Str(infile) ]
        self.mgloaded=True
        self.loadframe()

    def exit(self):
        """
        Exit the program
        """
        sys.exit()

    def stringtotuple(self, s):
       '''
       convert string to tuple of floats
       '''
       temp = s.strip('()')
       tokens = temp.split(',')
       return (float(tokens[0]), float(tokens[1]), float(tokens[2]))

    def read(self, verbose):
        '''
        Read molecular graphs, CPs, paths etc. into the model object
        '''
        print('==== Reading molecular graphs')
        for i in self.graph_file_list:  # Read all molecular graphs into self.frames
            t = mg.Molgraph()           # make a new Molgraph object called 't'
            t.read(i)                   # fill our new object 't' with data from the input file
            if verbose:
                print('Read molecular graph from {0}'.format(i))
            self.frames.append(t)
        self.numframes = len(self.frames)
        print('==== Done: read {0} molecular graphs'.format(self.numframes))

        # Bond path data and p,q,p`,q` paths from bvsetlist
        bvsetcount = 0
        self.bvsetlabels = []

        print('Using {0} files with bond path vector data'.format(len(self.bvsetlist)))
        for bvset in self.bvsetlist:
            with open(bvset,'r') as bvsetfile:  # reading the next bond vectors file
                line = bvsetfile.readline()     # read first line of file
                while (line):
                    # First line of vector set currently contains no useful information, just echo
                    if (verbose):
                        print('==== New set of path vector information ====')
                        print(line.strip())
                    # Second line contains the input data file name 'Input file:'
                    line = bvsetfile.readline()
                    #print(line.strip())
                    if not line.startswith('Input file:'):
                        print('Expected an Input file: line in {0}'.format(bvset))
                        print('Instead, found [{0}] - exiting'.format(line))
                        sys.exit()
                    originmgfile = line[len('Input file: '):].strip()
                    # Third line contains a description
                    line = bvsetfile.readline()
                    if not line.startswith('Description:'):
                        print('Expected a Description: line in {0}'.format(bvset))
                        print('Instead, found [{0}] - exiting'.format(line))
                        sys.exit()
                    description = line[len('Description:'):].strip()
                    if (verbose):
                        print('Description line:{0}'.format(description))
                    numpathpoints = int(description.split()[0])
                    if (verbose):
                        print('Description line specifies {0} path points'.format(numpathpoints))
                    if 'from BCP to' in description:  # this is a bond path, create and store a NamedFieldPath object
                        bcpname = bvsetfile.readline().split()[-1]      # Start
                        pathendname = bvsetfile.readline().split()[-1]  # End
                        if (verbose):
                           print('Bond path segment: {0} -> {1}'.format(bcpname,pathendname))
                        # save the next line for descriptive use
                        line = bvsetfile.readline()
                        if not line.startswith('Scal'):  # trap
                            print('Expected a line starting with Scal ..')
                            print('Instead, found [{0}] - exiting'.format(line))
                            sys.exit()
                        description2 = line
                        if (verbose):
                            print('{0}'.format(description2))
                        # 20190428: Force swap_pq to True if 'ellip_stress' scaling used
                        if 'ellip_stress' in description2:
                            print('Stress tensor ellipticity scaling detected! AUTOMATICALLY swapping p and q!')
                            self.swap_pq = True
                        # now skip to the last line before the numbers
                        while True:
                            line = bvsetfile.readline()
                            if line.startswith('Scaled'):  # next line should be the start of the numbers
                                tokens = line.split()
                                if (verbose):
                                    print('Verifying: about to read {0} number lines'.format(tokens[-3]))
                                break
                            else:
                                if (verbose):
                                    print('Ignoring the line: {0}'.format(line.strip()))
                        if (verbose):
                            print('Last header line before numbers: {0}'.format(line.strip()))
                        # now retrieve the path
                        temp_px,temp_py,temp_pz,v1x,v1y,v1z,v2x,v2y,v2z = [],[],[],[],[],[],[],[],[]
                        for i in range(0,numpathpoints):  # read the specified number of lines
                            line = bvsetfile.readline()
                            if (verbose):
                                print('Line {0}:{1}'.format(i+1, line.strip()))
                            if (not (line.startswith((" ","-","0","1","2","3","4","5","6","7","8","9")) )):  # something's wrong, stop
                                print('Expected the first line of numbers, got {0} instead'.format(line))
                                print('Previous line was supposed to start with Scaled, instead was: {0}'.format(line))
                                print('Check your data file - exiting')
                                sys.exit()
                            tokens = line.split()
                            if (not len(tokens) == 9):
                                print('Expected 9 columns of numbers here, got: {0}'.format(line))
                                print('Check your data file - exiting')
                                sys.exit()
                            temp_px.append(float(tokens[0]))
                            temp_py.append(float(tokens[1]))
                            temp_pz.append(float(tokens[2]))
                            if (self.swap_pq):
                                v1x.append(float(tokens[6])*self.vectorscale)
                                v1y.append(float(tokens[7])*self.vectorscale)
                                v1z.append(float(tokens[8])*self.vectorscale)
                                v2x.append(float(tokens[3])*self.vectorscale)
                                v2y.append(float(tokens[4])*self.vectorscale)
                                v2z.append(float(tokens[5])*self.vectorscale)
                            else:
                                v1x.append(float(tokens[3])*self.vectorscale)
                                v1y.append(float(tokens[4])*self.vectorscale)
                                v1z.append(float(tokens[5])*self.vectorscale)
                                v2x.append(float(tokens[6])*self.vectorscale)
                                v2y.append(float(tokens[7])*self.vectorscale)
                                v2z.append(float(tokens[8])*self.vectorscale)

                        if (verbose):
                            print('Read {0} path points from file: {1}'.format(numpathpoints,bvset))
                            print('==== v1 =====, {0} {1} {2}'.format(len(v1x),len(v1y),len(v1z)))
                            for i in range(0,len(v1x)):
                                print(v1x[i],v1y[i],v1z[i])
                            print('==== v2 =====, {0} {1} {2}'.format(len(v2x),len(v2y),len(v2z)))
                            for i in range(0,len(v2x)):
                                print(v2x[i],v2y[i],v2z[i])
                        # init: px,py,pz,description,pathtype,path_fieldvar
                        bvsetcount = bvsetcount + 1
                        partialdesc = ' '.join(description.split()[3:])
                        # create a new NamedFieldPath
                        nfp = NamedFieldPath(temp_px,temp_py,temp_pz,
                                             'Bondpath '+originmgfile+' '+bcpname+' -> '+pathendname+' '+partialdesc+' with '+description2,
                                             '0.0 0.0 0.0',
                                             [ v1x, v1y, v1z, v2x, v2y, v2z ])
                        nfp.type = 'Bondpath with vectors'
                        self.pathr.append(nfp)
                    # done with number columns, read for another header block
                    line = bvsetfile.readline()
        print('Number of read bond paths = {0}'.format(bvsetcount))

        # EXTRA PATHS
        extrasetcount = 0
        print('Using {0} files with extra path vector data'.format(len(self.extrasetlist)))
        for extraset in self.extrasetlist:
            with open(extraset,'r') as extrasetfile:  # reading the next bond vectors file
                line = extrasetfile.readline()        # read first line of file
                while (line):
                    # First line of vector set currently contains no useful information
                    if (verbose):
                        print('==== New set of path vector information ====')
                        print(line.strip())
                    # Second line contains the input data file name 'Input file:'
                    line = extrasetfile.readline()
                    #print(line.strip())
                    if not line.startswith('Input file:'):
                        print('Expected an Input file: line in {0}'.format(extraset))
                        print('Instead, found [{0}] - exiting'.format(line))
                        sys.exit()
                    originmgfile = line[len('Input file: '):].strip()
                    # Third line contains a description
                    line = extrasetfile.readline()
                    if not line.startswith('Description:'):
                        print('Expected a Description: line in {0}'.format(extraset))
                        print('Instead, found [{0}] - exiting'.format(line))
                        sys.exit()
                    description = line[len('Description:'):].strip()
                    if (verbose):
                        print('Description line:{0}'.format(description))
                    numpathpoints = int(description.split()[0])
                    if (verbose):
                        print('Description line specifies {0} path points'.format(numpathpoints))
                    if 'from BCP to' in description:  # this is a bond path, create and store a NamedFieldPath object
                        bcpname = extrasetfile.readline().split()[-1]      # Start
                        pathendname = extrasetfile.readline().split()[-1]  # End
                        # skip 2 next lines
                        #line = extrasetfile.readline()
                        #if (verbose):
                        #    print('Found [{0}] - skipping'.format(line))
                        #line = extrasetfile.readline()
                        #if (verbose):
                        #    print('Found [{0}] - skipping'.format(line))
                        # save the next line for descriptive use
                        line = extrasetfile.readline()
                        if not line.startswith('Scaling'):  # trap
                            print('Expected a line starting with Scaling ..')
                            print('Instead, found [{0}] - exiting'.format(line))
                            sys.exit()
                        #print ('Found a line starting with Scaling: {0}'.format(line))
                        description2 = line
                        if (verbose):
                            print('{0}'.format(description2))
                        # 20190428: Force swap_pq to True if 'ellip_stress' scaling used
                        if 'ellip_stress' in description2:
                            print('Stress tensor ellipticity scaling detected! AUTOMATICALLY swapping p and q!')
                            self.swap_pq = True
                        # now skip to the last line before the numbers
                        while True:
                            line = extrasetfile.readline()
                            if line.startswith('Scaled'):  # next line should be the start of the numbers
                                tokens = line.split()
                                if (verbose):
                                    print('Verifying: about to read {0} number lines'.format(tokens[-3]))
                                break
                            else:
                                if (verbose):
                                    print('Ignoring the line: {0}'.format(line.strip()))
                        if (verbose):
                            print('Last header line before numbers: {0}'.format(line.strip()))
                        # now retrieve the path
                        temp_px,temp_py,temp_pz,v1x,v1y,v1z,v2x,v2y,v2z = [],[],[],[],[],[],[],[],[]
                        for i in range(0,numpathpoints):
                            line = extrasetfile.readline()
                            if (verbose):
                                print('Line {0}:{1}'.format(i+1, line.strip()))
                            if (not (line.startswith(" ") or line.startswith("-")) ):  # something's wrong, stop
                                print('Expected the first line of numbers, got {0} instead'.format(line))
                                print('Previous line was supposed to start with Scaled, instead was: {0}'.format(line))
                                print('Check your data file - exiting')
                                sys.exit()
                            tokens = line.split()
                            if (not len(tokens) == 9):
                                print('Expected 9 columns of numbers here, got: {0}'.format(line))
                                print('Check your data file - exiting')
                                sys.exit()
                            ft = [ float(t) for t in tokens ]  # saves using float(tokens multiple times below
                            temp_px.append(ft[0])
                            temp_py.append(ft[1])
                            temp_pz.append(ft[2])
                            if (self.swap_pq):
                                v1x.append(ft[6]*self.vectorscale)
                                v1y.append(ft[7]*self.vectorscale)
                                v1z.append(ft[8]*self.vectorscale)
                                v2x.append(ft[3]*self.vectorscale)
                                v2y.append(ft[4]*self.vectorscale)
                                v2z.append(ft[5]*self.vectorscale)
                            else:
                                v1x.append(ft[3]*self.vectorscale)
                                v1y.append(ft[4]*self.vectorscale)
                                v1z.append(ft[5]*self.vectorscale)
                                v2x.append(ft[6]*self.vectorscale)
                                v2y.append(ft[7]*self.vectorscale)
                                v2z.append(ft[8]*self.vectorscale)
                        # create a new NamedFieldPath
                        if (verbose):
                            print('Read {0} path points from file: {1}'.format(numpathpoints,extraset))
                        # init: px,py,pz,description,pathtype,path_fieldvar
                        extrasetcount = extrasetcount + 1
                        partialdesc = ' '.join(description.split()[3:])
                        nfp = NamedFieldPath(temp_px,temp_py,temp_pz,
                                             'Bondpath '+originmgfile+' '+bcpname+' -> '+pathendname+' '+partialdesc+' with '+description2,
                                             '0.0 0.0 0.0',
                                             [ v1x, v1y, v1z, v2x, v2y, v2z ])
                        nfp.pathtype = 'Extra bondpath with vectors'
                        self.pathx.append(nfp)
                    line = extrasetfile.readline()


    def loadframe(self):
        '''
        Load the current molecular graph and set number of atoms
        '''
        self.thismg = self.frames[self.currentframe]  # got the frame molecular graph, now extract its contents
        self.thisnatoms = len(self.thismg.atom_x)
        #print('self.currentframe = {0}, self.thisnatoms={1}'.format(self.currentframe,self.thisnatoms))
        self.atomx = self.thismg.atom_x
        self.atomy = self.thismg.atom_y
        self.atomz = self.thismg.atom_z
        self.atomlabels = self.thismg.atom_label
        self.atomsymbols = [ i.strip('0123456789') for i in self.atomlabels ]
        self.atomsize = [self.atom_radius_dict[i] for i in self.atomsymbols ]
        self.atomcols = [self.atom_colour_dict[i] for i in self.atomsymbols ]

        # Store CPs for current frame
        self.thiscplist = self.thismg.cplist
        self.thisnumcps = len(self.thismg.cplist)
        # add this frame's CPs to the CPTable
        tcpl = []
        for i in range(0,self.thisnumcps):
            tcpl.append(TraitedCP(self.thiscplist[i]))
        for i in range(0,self.thisnumcps):
            tcpl[i].Number = i+1
        self.CPTable = tcpl
        self.cpx, self.cpy, self.cpz, self.cptype, self.cplabel = [], [], [], [], []   # clear the CP arrays
        for cp in self.thiscplist:  # loop over this frame's CPs, store position, type, connectivity and BCP paths
            self.cpx.append(cp.pos_x)
            self.cpy.append(cp.pos_y)
            self.cpz.append(cp.pos_z)
            self.cptype.append(cp.type)
            self.cplabel.append(cp.connected)
            # If CP is a BCP, capture the path and IAS path information
            # IAS paths look like this
            # 492 sample points along IAS +EV1 path from BCP
            # 487 sample points along IAS -EV1 path from BCP
            # 463 sample points along IAS +EV2 path from BCP
            # 463 sample points along IAS -EV2 path from BCP
            if cp.type == 'BCP':
                thiscplabel = cp.connected
                if len(cp.pathlist) >0:  # has at least the bond path segments
                    # add BCP name to field path descriptions
                    cp.pathlist[0].description = thiscplabel + ' ' + cp.pathlist[0].description
                    cp.pathlist[1].description = thiscplabel + ' ' + cp.pathlist[1].description
                    self.bondpaths.append(cp.pathlist[0])  # as mg.FieldPath
                    self.bondpaths.append(cp.pathlist[1])  # as mg.FieldPath
                if len(cp.pathlist) >2:  # also has IAS paths
                    cp.pathlist[2].description = thiscplabel + ' ' + cp.pathlist[2].description
                    cp.pathlist[3].description = thiscplabel + ' ' + cp.pathlist[3].description
                    cp.pathlist[4].description = thiscplabel + ' ' + cp.pathlist[4].description
                    cp.pathlist[5].description = thiscplabel + ' ' + cp.pathlist[5].description
                    self.iaspaths.append(cp.pathlist[2])  # +IAS EV1
                    self.iaspaths.append(cp.pathlist[3])  # -IAS EV1
                    self.iaspaths.append(cp.pathlist[4])  # +IAS EV2
                    self.iaspaths.append(cp.pathlist[5])  # -IAS EV2

        # Add extra bond paths
        self.paths=[]
        for nfp in self.pathr:
            # build p,q,q',q' paths, add to pathplot
            px,py,pz,qx,qy,qz,ppx,ppy,ppz,qpx,qpy,qpz = [],[],[],[],[],[],[],[],[],[],[],[]
            rx = nfp.path_x
            ry = nfp.path_y
            rz = nfp.path_z
            description_tail = nfp.description[len('Bondpath '):]
            v1x, v1y, v1z, v2x, v2y, v2z = nfp.path_fieldvar
            for i in range(0,len(rx)):
                px.append(rx[i] + v1x[i])    # p-path
                py.append(ry[i] + v1y[i])
                pz.append(rz[i] + v1z[i])
                ppx.append(rx[i] - v1x[i])   # p`-path
                ppy.append(ry[i] - v1y[i])
                ppz.append(rz[i] - v1z[i])
                qx.append(rx[i] + v2x[i])    # q-path
                qy.append(ry[i] + v2y[i])
                qz.append(rz[i] + v2z[i])
                qpx.append(rx[i] - v2x[i])   # q`-path
                qpy.append(ry[i] - v2y[i])
                qpz.append(rz[i] - v2z[i])

            originmgfile = ''
            newnfp1 = NamedFieldPath(px, py, pz,
                                    'p-path '+description_tail,
                                    '0.0 0.0 0.0',
                                    [ v1x, v1y, v1z, v2x, v2y, v2z ])
            newnfp1.pathtype = 'p-path with vectors'
            self.paths.append(newnfp1)
            newnfp2 = NamedFieldPath(ppx, ppy, ppz,
                                    'p`-path '+description_tail,
                                    '0.0 0.0 0.0',
                                    [ v1x, v1y, v1z, v2x, v2y, v2z ])
            newnfp2.pathtype = 'p`-path with vectors'
            self.paths.append(newnfp2)
            newnfp3 = NamedFieldPath(qx, qy, qz,
                                    'q-path '+description_tail,
                                    '0.0 0.0 0.0',
                                    [ v1x, v1y, v1z, v2x, v2y, v2z ])
            newnfp3.pathtype = 'q-path with vectors'
            self.paths.append(newnfp3)
            newnfp4 = NamedFieldPath(qpx, qpy, qpz,
                                    'q`-path '+description_tail,
                                    '0.0 0.0 0.0',
                                    [ v1x, v1y, v1z, v2x, v2y, v2z ])
            newnfp4.pathtype = 'q`-path with vectors'
            self.paths.append(newnfp4)

        # Now update the plot
        print('paths now contains {0} paths'.format(len(self.paths)))

        # ADD EXTRA PATHS
        for nfp in self.pathx:
            # build p,q,q',q' paths, add to pathplot
            px,py,pz,qx,qy,qz,ppx,ppy,ppz,qpx,qpy,qpz = [],[],[],[],[],[],[],[],[],[],[],[]
            rx = nfp.path_x
            ry = nfp.path_y
            rz = nfp.path_z
            description_tail = nfp.description[len('Bondpath '):]
            v1x, v1y, v1z, v2x, v2y, v2z = nfp.path_fieldvar
            for i in range(0,len(rx)):
                px.append(rx[i] + v1x[i])    # p-path
                py.append(ry[i] + v1y[i])
                pz.append(rz[i] + v1z[i])
                ppx.append(rx[i] - v1x[i])   # p`-path
                ppy.append(ry[i] - v1y[i])
                ppz.append(rz[i] - v1z[i])
                qx.append(rx[i] + v2x[i])    # q-path
                qy.append(ry[i] + v2y[i])
                qz.append(rz[i] + v2z[i])
                qpx.append(rx[i] - v2x[i])   # q`-path
                qpy.append(ry[i] - v2y[i])
                qpz.append(rz[i] - v2z[i])

            originmgfile = ''
            newnfp1 = NamedFieldPath(px, py, pz,
                                    'p-path Extra '+description_tail,
                                    '0.0 0.0 0.0',
                                    [ v1x, v1y, v1z, v2x, v2y, v2z ])
            newnfp1.pathtype = 'p-path Extra with vectors'
            self.paths.append(newnfp1)
            newnfp2 = NamedFieldPath(ppx, ppy, ppz,
                                    'p`-path Extra '+description_tail,
                                    '0.0 0.0 0.0',
                                    [ v1x, v1y, v1z, v2x, v2y, v2z ])
            newnfp2.pathtype = 'p`-path Extra with vectors'
            self.paths.append(newnfp2)
            newnfp3 = NamedFieldPath(qx, qy, qz,
                                    'q-path Extra '+description_tail,
                                    '0.0 0.0 0.0',
                                    [ v1x, v1y, v1z, v2x, v2y, v2z ])
            newnfp3.pathtype = 'q-path Extra with vectors'
            self.paths.append(newnfp3)
            newnfp4 = NamedFieldPath(qpx, qpy, qpz,
                                    'q`-path Extra'+description_tail,
                                    '0.0 0.0 0.0',
                                    [ v1x, v1y, v1z, v2x, v2y, v2z ])
            newnfp4.pathtype = 'q`-path Extra with vectors'
            self.paths.append(newnfp4)

        print('Added all extra paths - Total for this frame is {0} paths'.format(len(self.paths)))
        print('====')
        # Trigger creation of plotted items
        self.update_plot_atoms()
        self.update_plot_cps()
        self.update_plot_paths()

    # INTERACTIVE RESPONSES
    # When the scene is activated, or when the parameters are changed, we
    # update the plot using 'update_plot_*' methods below.
    @on_trait_change('scene.scene.parallel_projection,scene.activated')
    def update_status_bar(self):
        '''
        Update the status bar
        '''
        if self.scene.scene.parallel_projection:
            self.viewstyle = 'Parallel'
        else:
            self.viewstyle = 'Perspective'

    @on_trait_change('Atoms,Text,show_atoms,show_labels,scene.activated')
    def update_plot_atoms(self):  # atom plotter method
        '''
        Draw atom spheres with radius and colour chosen by element name, optionally with text atom labels
        '''
        if not self.mgloaded:
            return
        if self.atomplot is None:  # Initial draw
            self.atomplot = []
            self.atomslabelplot = []
            firstdraw = True
            for i in range(0,self.thisnatoms):  # DRAW ATOMS
                px = self.atomx[i]
                py = self.atomy[i]
                pz = self.atomz[i]
                plabel = self.atomlabels[i]
                ps = self.atomsize[i]*self.Atoms
                pcol = self.atomcols[i]
                thisatom = self.scene.mlab.points3d(px,py,pz,ps,
                                                    name='Atom '+plabel, resolution=32, color=tuple(pcol),
                                                    scale_mode='scalar',scale_factor=1.0,transparent=False)
                self.atomplot.append(thisatom)
                if self.show_labels:
                    textobj = self.scene.mlab.text(px,py,plabel, z=pz, name='Label '+plabel,
                                                                    color=self.modelcolors['labelcolor'],width=self.Text*0.004)
                    textobj.property.bold = True
                    textobj.actor.text_scale_mode = 'viewport'
                    textobj.property.justification = 'centered'
                    textobj.property.vertical_justification = 'centered'
                    self.atomlabelsplot.append(textobj)

        else:                      # triggered on redraw
            for i in range(0,self.thisnatoms):  # redraw atoms
                self.atomplot[i].mlab_source.set(x=self.atomx[i],y=self.atomy[i],z=self.atomz[i],scalars=self.atomsize[i]*self.Atoms)

            for i in range(0,len(self.atomlabelsplot)):  # redraw text
                self.atomlabelsplot[i].width=self.Text*0.004
                self.atomlabelsplot[i].property.justification = 'centered'
                self.atomlabelsplot[i].property.vertical_justification = 'centered'

        if self.show_atoms:  # set atoms visible/invisible
            for i in range (0,self.thisnatoms):
                self.atomplot[i].visible = True
        else:
            for i in range (0,self.thisnatoms):
                self.atomplot[i].visible = False

        if self.show_labels:  # set labels visible/invisible
            for i in range (0,self.thisnatoms):
                self.atomlabelsplot[i].visible = True
        else:
            for i in range (0,self.thisnatoms):
                self.atomlabelsplot[i].visible = False

    @on_trait_change('CPs,show_cps,scene.activated')
    def update_plot_cps(self):  # CP plotter method
        '''
        Draw critical points
        '''
        if not self.mgloaded:
            return
        if self.cpplot is None:  # first draw
            self.cpplot = []
            thisnumcps = self.thisnumcps
            for j in range(0,thisnumcps):  # DRAW CPS
                px = self.cpx[j]
                py = self.cpy[j]
                pz = self.cpz[j]
                ps = [self.CPs]
                ptype = self.cptype[j]
                thiscplabel = self.cplabel[j]

                if ptype == 'BCP':   # BCPs are green
                    self.cpplot.append(self.scene.mlab.points3d(px,py,pz,ps,name='BCP '+thiscplabel,resolution=16,color=self.modelcolors['BCP'],
                                                                scale_mode='scalar',scale_factor=1.0) )
                elif (ptype == 'NCP' or ptype == 'NNACP' or ptype == 'NACP'):   # NCPs are cyan
                    self.cpplot.append(self.scene.mlab.points3d(px,py,pz,ps,name='NCP '+thiscplabel, resolution=16,color=self.modelcolors['NCP'],
                                                                scale_mode='scalar',scale_factor=1.0) )
                elif ptype == 'RCP':  # RCPs are red
                    self.cpplot.append(self.scene.mlab.points3d(px,py,pz,ps,name='RCP '+thiscplabel, resolution=16,color=self.modelcolors['RCP'],
                                                                scale_mode='scalar',scale_factor=1.0) )
                elif ptype == 'CCP':  # CCPs are blue
                    self.cpplot.append(self.scene.mlab.points3d(px,py,pz,ps,name='CCP '+thiscplabel, resolution=16,color=self.modelcolors['CCP'],
                                                                scale_mode='scalar',scale_factor=1.0) )
        else:                        # triggered on redraw
            for i in range(0,len(self.cpplot)):  # redraw CPs
                self.cpplot[i].mlab_source.set(x=self.cpx[i],y=self.cpy[i],z=self.cpz[i],scalars=self.CPs)

        if self.show_cps:  # toggle CP visibility
            for i in range (0,self.thisnumcps):
                self.cpplot[i].visible = True
        else:
            for i in range (0,self.thisnumcps):
                self.cpplot[i].visible = False

    @on_trait_change('showscene.activated,Paths,'\
                     'show_bps,show_bps_col,show_pps,show_pps_col,show_ppps,show_ppps_col,'\
                     'show_qps,show_qps_col,show_qps,show_qpps,show_qpps_col,show_qps_col,'\
                     'show_iasev1s,show_iasev2s,show_iaspath_col,'\
                     'show_extra_pps,show_extra_pps_col,show_extra_qps,show_extra_qps_col,'\
                     'show_extra_ppps,show_extra_ppps_col,show_extra_qpps,show_extra_qpps_col')
    def update_plot_paths(self):  # path plotter method
        '''
        Draw paths
        '''
        if not self.mgloaded:
            return
        ############
        # BOND PATHS
        if self.bondplot is None:  # first draw
            self.bondplot = []
            for thispath in self.bondpaths:  # DRAW BOND PATHS
                pathx = thispath.path_x
                pathy = thispath.path_y
                pathz = thispath.path_z
                dummypathscalars = [1.0]*len(pathx)
                self.bondplot.append(self.scene.mlab.plot3d(pathx, pathy, pathz, dummypathscalars,
                                                            color=self.modelcolors['bondpath'], name=thispath.description,
                                                            tube_radius=self.Paths, tube_sides=16))  # black
        else:                      # triggered on redraw
            newcol = self.stringtotuple('{0}'.format(self.show_bps_col))
            for plotobject in self.scene.mayavi_scene.children:
                if ("from BCP to" in plotobject.name):
                    surface = plotobject.children[0].children[0].children[0].children[0]
                    surface.parent.parent.filter.radius=self.Paths
                    surface.actor.property.color = newcol
                    surface.actor.property.ambient_color = newcol
                    surface.actor.property.diffuse_color = newcol
                    surface.actor.property.specular_color = newcol

        if self.show_bps:  # toggle bondpath visibility
            for bondplotobj in self.bondplot:  # loop over bondplot objects, make visible
                bondplotobj.visible = True
        else:
            for bondplotobj in self.bondplot:  # loop over bondplot object, make invisible
                bondplotobj.visible = False

        ###########
        # IAS PATHS
        if self.iaspathplot is None:  # first draw
            self.iaspathplot = []
            for thispath in self.iaspaths:  # DRAW IAS PATHS
                pathx = thispath.path_x
                pathy = thispath.path_y
                pathz = thispath.path_z
                #print(thispath.description)
                dummypathscalars = [1.0]*len(pathx)
                self.iaspathplot.append(self.scene.mlab.plot3d(pathx, pathy, pathz, dummypathscalars,
                                                               color=self.modelcolors['iaspath'], name=thispath.description,
                                                               tube_radius=self.Paths, tube_sides=16))  # grey
        else:                        # triggered on redraw
            for iasplotobj in self.iaspathplot:  # redraw bond paths with new radius
                iasplotobj.parent.parent.filter.radius=self.Paths

        # toggle IAS path visibility
        if self.show_iasev1s:  # toggle IAS EV1 visibility
            for iasplotobj in self.iaspathplot:  # loop over iasplot objects, make visible
                if 'EV1' in iasplotobj.parent.parent.parent.parent.name:
                    iasplotobj.visible = True
        else:
            for iasplotobj in self.iaspathplot:  # loop over iasplot object, make invisible
                if 'EV1' in iasplotobj.parent.parent.parent.parent.name:
                    iasplotobj.visible = False
        if self.show_iasev2s:  # toggle IAS EV2 visibility
            for iasplotobj in self.iaspathplot:  # loop over iasplot objects, make visible
                if 'EV2' in iasplotobj.parent.parent.parent.parent.name:
                    iasplotobj.visible = True
        else:
            for iasplotobj in self.iaspathplot:  # loop over iasplot object, make invisible
                if 'EV2' in iasplotobj.parent.parent.parent.parent.name:
                    iasplotobj.visible = False

        #################
        # p,p`,q,q` PATHS
        if self.pathplot is None:  # first draw
            if (self.verbose):
                print('*** ADDING PATHS ***')
            self.pathplot = []
            for thispath in self.paths:  # DRAW PATHS (these should have 'pathtype' field)
                pathx = thispath.path_x
                pathy = thispath.path_y
                pathz = thispath.path_z
                pathtype = thispath.pathtype
                if (self.verbose):  # print path (x,y,z) triples
                    print('Adding path: {0}'.format(pathtype))
                    print('Current path description: {0}'.format(thispath.description))
                    for i in range(0,len(pathx)):
                        print(pathx[i],pathy[i],pathz[i])
                dummypathscalars = [1.0]*len(pathx)
                # construct and store path objects
                #
                if not 'xtra' in pathtype:  # ======== build and add BASIC path-types
                    if pathtype.startswith('p-path'):   # build and add p-paths
                        self.pathplot.append(self.scene.mlab.plot3d(pathx, pathy, pathz, dummypathscalars,
                                                                    color=self.modelcolors['p-path'], name=thispath.description,
                                                                    tube_radius=self.Paths, tube_sides=16))  # cyan
                    elif pathtype.startswith('p`-path'):  # build and add p`-paths
                        self.pathplot.append(self.scene.mlab.plot3d(pathx, pathy, pathz, dummypathscalars,
                                                                    color=self.modelcolors['p`-path'], name=thispath.description,
                                                                    tube_radius=self.Paths, tube_sides=16))  # cyan
                    elif pathtype.startswith('q-path'):   # build and add q-paths
                        self.pathplot.append(self.scene.mlab.plot3d(pathx, pathy, pathz, dummypathscalars,
                                                                    color=self.modelcolors['q-path'], name=thispath.description,
                                                                    tube_radius=self.Paths, tube_sides=16))  # magenta
                    elif pathtype.startswith('q`-path'):  # build and add q`-paths
                        self.pathplot.append(self.scene.mlab.plot3d(pathx, pathy, pathz, dummypathscalars,
                                                                    color=self.modelcolors['q`-path'], name=thispath.description,
                                                                    tube_radius=self.Paths, tube_sides=16))  # magenta
                else:                      # ======== build and add EXTRA path-types,
                    if pathtype.startswith('p-path'):   # build and add EXTRA p-paths
                        self.pathplot.append(self.scene.mlab.plot3d(pathx, pathy, pathz, dummypathscalars,
                                                                    color=self.modelcolors['extra p-path'], name=thispath.description,
                                                                    tube_radius=self.Paths, tube_sides=16))  # cyan
                    elif pathtype.startswith('p`-path'):  # build and add EXTRA p`-paths
                        self.pathplot.append(self.scene.mlab.plot3d(pathx, pathy, pathz, dummypathscalars,
                                                                    color=self.modelcolors['extra p`-path'], name=thispath.description,
                                                                    tube_radius=self.Paths, tube_sides=16))  # cyan
                    elif pathtype.startswith('q-path'):   # build and add EXTRA q-paths
                        self.pathplot.append(self.scene.mlab.plot3d(pathx, pathy, pathz, dummypathscalars,
                                                                    color=self.modelcolors['extra q-path'], name=thispath.description,
                                                                    tube_radius=self.Paths, tube_sides=16))  # magenta
                    elif pathtype.startswith('q`-path'):  # build and add EXTRA q`-paths
                        self.pathplot.append(self.scene.mlab.plot3d(pathx, pathy, pathz, dummypathscalars,
                                                                    color=self.modelcolors['extra q`-path'], name=thispath.description,
                                                                    tube_radius=self.Paths, tube_sides=16))  # magenta

            if (self.verbose):
                print('*** FINISHED ADDING PATHS ***')
        else:                      # redraw
            # ==================== PATHPLOT OBJECT RADIUS AND COLORS  =========================
            newpcol = self.stringtotuple('{0}'.format(self.show_pps_col))
            newppcol = self.stringtotuple('{0}'.format(self.show_ppps_col))
            newqcol = self.stringtotuple('{0}'.format(self.show_qps_col))
            newqpcol = self.stringtotuple('{0}'.format(self.show_qpps_col))
            newxtrapcol = self.stringtotuple('{0}'.format(self.show_extra_pps_col))
            newxtraqcol = self.stringtotuple('{0}'.format(self.show_extra_qps_col))
            newxtrappcol = self.stringtotuple('{0}'.format(self.show_extra_ppps_col))
            newxtraqpcol = self.stringtotuple('{0}'.format(self.show_extra_qpps_col))
            for plotobject in self.scene.mayavi_scene.children:
                if (not 'xtra' in plotobject.name):     # ordinary p,q,p',q'
                    if ("p-path" in plotobject.name):
                        isvisible = plotobject.visible
                        surface = plotobject.children[0].children[0].children[0].children[0]
                        surface.parent.parent.filter.radius=self.Paths
                        surface.actor.property.color = newpcol
                        surface.actor.property.ambient_color = newpcol
                        surface.actor.property.diffuse_color = newpcol
                        surface.actor.property.specular_color = newpcol
                        plotobject.visible = False
                        plotobject.visible = isvisible
                    elif ("q-path" in plotobject.name):
                        isvisible = plotobject.visible
                        surface = plotobject.children[0].children[0].children[0].children[0]
                        surface.parent.parent.filter.radius=self.Paths
                        surface.actor.property.color = newqcol
                        surface.actor.property.ambient_color = newqcol
                        surface.actor.property.diffuse_color = newqcol
                        surface.actor.property.specular_color = newqcol
                        plotobject.visible = False
                        plotobject.visible = isvisible
                    elif ("p`-path" in plotobject.name):
                        isvisible = plotobject.visible
                        surface = plotobject.children[0].children[0].children[0].children[0]
                        surface.parent.parent.filter.radius=self.Paths
                        surface.actor.property.color = newppcol
                        surface.actor.property.ambient_color = newppcol
                        surface.actor.property.diffuse_color = newppcol
                        surface.actor.property.specular_color = newppcol
                        plotobject.visible = False
                        plotobject.visible = isvisible
                    elif ("q`-path" in plotobject.name):
                        isvisible = plotobject.visible
                        surface = plotobject.children[0].children[0].children[0].children[0]
                        surface.parent.parent.filter.radius=self.Paths
                        surface.actor.property.color = newqpcol
                        surface.actor.property.ambient_color = newqpcol
                        surface.actor.property.diffuse_color = newqpcol
                        surface.actor.property.specular_color = newqpcol
                        plotobject.visible = False
                        plotobject.visible = isvisible
                else:                                   # extra p,q,p',q'
                    if ("p-path" in plotobject.name):
                        isvisible = plotobject.visible
                        surface = plotobject.children[0].children[0].children[0].children[0]
                        surface.parent.parent.filter.radius=self.Paths
                        surface.actor.property.color = newxtrapcol
                        surface.actor.property.ambient_color = newxtrapcol
                        surface.actor.property.diffuse_color = newxtrapcol
                        surface.actor.property.specular_color = newxtrapcol
                        plotobject.visible = False
                        plotobject.visible = isvisible
                    elif ("q-path" in plotobject.name):
                        isvisible = plotobject.visible
                        surface = plotobject.children[0].children[0].children[0].children[0]
                        surface.parent.parent.filter.radius=self.Paths
                        surface.actor.property.color = newxtraqcol
                        surface.actor.property.ambient_color = newxtraqcol
                        surface.actor.property.diffuse_color = newxtraqcol
                        surface.actor.property.specular_color = newxtraqcol
                        plotobject.visible = False
                        plotobject.visible = isvisible
                    elif ("p`-path" in plotobject.name):
                        isvisible = plotobject.visible
                        surface = plotobject.children[0].children[0].children[0].children[0]
                        surface.parent.parent.filter.radius=self.Paths
                        surface.actor.property.color = newxtrapcol
                        surface.actor.property.ambient_color = newxtrappcol
                        surface.actor.property.diffuse_color = newxtrappcol
                        surface.actor.property.specular_color = newxtrappcol
                        plotobject.visible = False
                        plotobject.visible = isvisible
                    elif ("q`-path" in plotobject.name):
                        isvisible = plotobject.visible
                        surface = plotobject.children[0].children[0].children[0].children[0]
                        surface.parent.parent.filter.radius=self.Paths
                        surface.actor.property.color = newxtraqcol
                        surface.actor.property.ambient_color = newxtraqpcol
                        surface.actor.property.diffuse_color = newxtraqpcol
                        surface.actor.property.specular_color = newxtraqpcol
                        plotobject.visible = False
                        plotobject.visible = isvisible


        #  ==================== PATHPLOT OBJECT VISIBILITY =========================
        for bondplotobj in self.pathplot:        # Loop over pathplot objects, set visibility
            bondplotobjname = bondplotobj.parent.parent.parent.parent.name
            if not 'xtra' in bondplotobjname:    #    ORDINARY PATH
                if 'p-path' in bondplotobjname:  # P-path
                    setplotobjvisibility(bondplotobj,self.show_pps)
                elif 'q-path' in bondplotobjname:  # Q-path
                    setplotobjvisibility(bondplotobj,self.show_qps)
                elif 'p`-path' in bondplotobjname: # P`-path
                    setplotobjvisibility(bondplotobj,self.show_ppps)
                elif 'q`-path' in bondplotobjname: # Q`-path
                    setplotobjvisibility(bondplotobj,self.show_qpps)
            else:                                #     EXTRA PATH
                if 'p-path' in bondplotobjname:  # EXTRA P-path
                    setplotobjvisibility(bondplotobj,self.show_extra_pps)
                elif 'q-path' in bondplotobjname:  # EXTRA Q-path
                    setplotobjvisibility(bondplotobj,self.show_extra_qps)
                elif 'p`-path' in bondplotobjname: # EXTRA P`-path
                    setplotobjvisibility(bondplotobj,self.show_extra_ppps)
                elif 'q`-path' in bondplotobjname: # EXTRA Q`-path
                    setplotobjvisibility(bondplotobj,self.show_extra_qpps)


        #### Stuff for arrows
        #        if self.show_parrows:  # draw the two sets of q-arrows
        #            self.scene.mlab.quiver3d(r1x,r1y,r1z,self.Arrows*v12x,self.Arrows*v12y,self.Arrows*v12z,
        #                                     color=self.modelcolors['q-path'],mode='arrow',scale_factor=self.Arrows,
        #                                     mask_points=self.Interval,resolution=16,line_width=0.5)  # q-path color
        #            self.scene.mlab.quiver3d(r2x,r2y,r2z,self.Arrows*v22x,self.Arrows*v22y,self.Arrows*v22z,
        #                                     color=self.modelcolors['q-path'],mode='arrow',scale_factor=self.Arrows,
        #                                     mask_points=self.Interval,resolution=16,line_width=0.5) # q-path color



    ##################################################################################
    ##################################################################################
    # GUI LAYOUT
    # Sections defined below
    # Visibility toggles /Sizes/ Colors panel (right)
    sidepanel1 = VGroup(HGroup(Item('show_atoms',label='Atoms'),
                               Item('Atoms',label='Size'),
                               Spring()
                               ),
                        HGroup(Item('show_labels',label='Labels'),
                               Item('Text',label='Size'),
                               Spring()
                               ),
                        HGroup(Item('show_cps',label='  CPs'),
                               Item('CPs',label='Size'),
                               Spring()
                              ),
                        #Item(name='_'),
                        HGroup(Item('Paths'),
                               Spring()
                              ),
                        HGroup(Item('PQscale',label='Path vector scale'),
                               Spring()
                              ),
                        #Item(name='_'),
                        HGroup(
                               Item('show_bps',label='Bond paths'),
                               Item('show_bps_col', editor=RGBColorEditor(),style='simple',show_label=False),
                               Spring()
                              ),
                        HGroup(
                               Item('show_pps',label='P-paths'),
                               Item('show_pps_col', editor=RGBColorEditor(),style='simple',show_label=False),
                               Spring()
                              ),
                        HGroup(
                               Item('show_qps',label='Q-paths'),
                               Item('show_qps_col', editor=RGBColorEditor(),style='simple',show_label=False),
                               Spring()
                              ),
                        HGroup(
                               Item('show_ppps',label='P`-paths'),
                               Item('show_ppps_col', editor=RGBColorEditor(),style='simple',show_label=False),
                               Spring()
                              ),
                        HGroup(
                               Item('show_qpps',label='Q`-paths'),
                               Item('show_qpps_col', editor=RGBColorEditor(),style='simple',show_label=False),
                               Spring()
                              ),
                        Item(name='_'),
                        Item(name=' '),
                        HGroup(
                               Item('show_extra_pps',label='Extra p-paths'),
                               Item('show_extra_pps_col', editor=RGBColorEditor(),style='simple',show_label=False),
                               Spring()
                              ),
                        HGroup(
                               Item('show_extra_qps',label='Extra q-paths'),
                               Item('show_extra_qps_col', editor=RGBColorEditor(),style='simple',show_label=False),
                               Spring()
                              ),
                        HGroup(
                               Item('show_extra_ppps',label='Extra p`-paths'),
                               Item('show_extra_ppps_col', editor=RGBColorEditor(),style='simple',show_label=False),
                               Spring()
                              ),
                        HGroup(
                               Item('show_extra_qpps',label='Extra q`-paths'),
                               Item('show_extra_qpps_col', editor=RGBColorEditor(),style='simple',show_label=False),
                               Spring()
                              ),
                        Item(name='_'),
                        Item(name=' '),
                        HGroup(
                               Item('show_iasev1s',label='IAS EV1 paths'),
                               Item('show_iaspath_col', editor=RGBColorEditor(),style='simple',show_label=False),
                               Spring()
                              ),
                        HGroup(
                               Item('show_iasev2s',label='IAS EV2 paths'),
                               Item('show_iaspath_col', editor=RGBColorEditor(),style='simple',show_label=False),
                               Spring()
                              ),
                        Item(name='_'),
                        Item(name=' '),
                        Item('show_parrows',label='P-arrows',enabled_when='False'),
                        Item('show_qarrows',label='Q-arrows',enabled_when='False'),
                        HGroup(Item('Interval',enabled_when='False'),
                               Spring()
                               ),
                        Item(name='_'),
                        Item(name=' '),
                        Item('show_scalarfield',label='Scalar field',enabled_when='False'),
                        Item('show_vectorfield',label='Vector field',enabled_when='False'),
                        label='Visibility',
                       )

    # Critical point table tab
    cptable_editor = TableEditor(editable=False,
                                 sortable=True,
                                 columns=[
                                          NumericColumn(name='Number',label='CP#'),
                                          ObjectColumn(name='Type'),
                                          ObjectColumn(name='Name'),
                                          NumericColumn(name='X'),
                                          NumericColumn(name='Y'),
                                          NumericColumn(name='Z'),
                                          NumericColumn(name='Rho'),
                                          NumericColumn(name='DelSqRho',label='Lap'),
                                          NumericColumn(name='Ellipticity',label='Ellipticity'),
                                          NumericColumn(name='BPL'),
                                          NumericColumn(name='GBL_II'),
                                          NumericColumn(name='K'),
                                         ],
                                 other_columns=[
                                                NumericColumn(name='V'),
                                                NumericColumn(name='G'),
                                                NumericColumn(name='L'),
                                                NumericColumn(name='GBL_I'),
                                                NumericColumn(name='GBL_III'),
                                                NumericColumn(name='GBL_IV'),
                                               ],
                                 sort_model=False,
                                 auto_size=True,
                                 filters=[MenuFilterTemplate],
                                 orientation='vertical',
                                 configurable=True,
                                 show_toolbar=True,
                                 search=MenuTableFilter(),
                                 cell_font='bold'
                                )

    # frame list tab
    framelist_editor = TreeEditor(nodes=[None],
                                  editable=False
    )

    # OVERALL MAIN VIEW TAB
    view = View(Tabbed(
                       HSplit(Item('scene', editor=SceneEditor(scene_class=MayaviScene),
                                   height=700, width=700, show_label=False),
                              sidepanel1,
                              label='View'
                              ),
                       HSplit(Item('FrameList',editor=NullEditor(),
                                   show_label=False),
                              label='Frames',
                              enabled_when='False'
                              ),
                       HSplit(Item('paths',editor=NullEditor(),
                                   show_label=False),
                              label='Paths',
                              enabled_when='False'
                              ),
                       HSplit(Item('CPTable',editor=cptable_editor,
                                          show_label=False),
                              label='CPs'
                             ),
                        HSplit(Item('ScalarField',editor=NullEditor(),
                                   show_label=False),
                              label='ScalarField',
                              enabled_when='False'
                              ),
                       HSplit(Item('VectorField',editor=NullEditor(),
                                   show_label=False),
                              label='VectorField',
                              enabled_when='False'
                              ),
                       ),
                resizable=True,
                #toolbar=ToolBar(),
                title='TopViz alpha version '+__version__ ,
                statusbar=statuslinelist,
                menubar=MenuBar(Menu(Action(name="Load ..",enabled_when="True",action='get_mg'),     # action="load"
                                     Action(name="Close",enabled_when="False"),                      # action="close"
                                     Action(name="Export",enabled_when="False"),                     # action="export"
                                     Action(name="Exit",enabled_when="True",action='exit'),          # action="exit"
                                     name="File"
                                    ),
                                Menu(Action(name='About ..',enabled_when="False"),
                                     Separator(),
                                     Action(name="Display Help"),
                                     name="Help"
                                    )
                                )
               )
    #################################################################################
    #################################################################################

def main():
    '''
    Main
    '''
    # main code
    # Print information header
    print("==================================================")
    print('Version {0}'.format(__version__))
    print("Using molgraph version {0}".format(mg.__version__))
    print("====== System versions =======")
    print("Mayavi version: {0}".format(mayavi.__version__))
    #print("   VTK version: {0}".format(tvtk.version()._vtk_obj.GetVTKVersion()))
    print("====== ENVIRONMENT =======")
    try:
        qtapi = os.environ['QT_API']
    except KeyError:
        qtapi = 'Not set'
    etstoolkit = os.getenv('ETS_TOOLKIT','Not set')

    print("QT_API = {0}".format(qtapi))
    print("ETS_TOOLKIT = {0}".format(etstoolkit))
    print("==========================")
    # argument parser
    parser = argparse.ArgumentParser(description="Visualize molecular graph files using Mayavi2\n"+
                                                 "=============================================")
    parser.add_argument("--input", help=".sumviz file or list file [default: none]",default='none')
    parser.add_argument("--atomradius", help="Atom radius to use for atom spheres: covrad, atmrad, vdwrad [default: atmrad]",
                                        default='atmrad')
    parser.add_argument("--bondvectors", help="Optional input file containing bond vectors [default: none]",
                                         default='none')
    parser.add_argument("--extravectors", help="Optional input file containing extra vectors [default: none]",
                                         default='none')
    parser.add_argument("--align", help="Optional sequence of 3 alignment atom names: ORIGIN_ATOM XAXIS_ATOM XYPLANE_ATOM [default: none]",nargs=3,
                                         default=['','',''])
    parser.add_argument("--verbose", help="Print more verbose output",action='store_true')
    parser.add_argument("--elementdata", help="Provide an explicit path to file containing element radius data  [default:use built-in data]",default='none')
    parser.add_argument("--vectorscale", help="Optional scaling to apply to bondvectors and extravectors [default: 1.0]",
                                         default=1.0)
    parser.add_argument("--swap_pq", help="Swap the p- and q-path data (e.g. for stress tensor paths)",action='store_true')
    # parse the arguments
    args = parser.parse_args()
    infile=args.input
    verbose=args.verbose
    swap_pq = args.swap_pq
    elementdata=args.elementdata
    atomradius = args.atomradius
    bondvectors = args.bondvectors
    extravectors = args.extravectors
    vectorscale = float(args.vectorscale)
    alignatoms = args.align


    # check if data files specified
    if (infile=='none'):
        cmdlinedata = False
    else:
        cmdlinedata = True
        print('Parsing command line data parameters')

    # 'align' option
    if not alignatoms[0] == '':
        print('Specified alignment atoms {0},{1},{2}'.format(alignatoms[0],alignatoms[1],alignatoms[2]))
        print('This option does not work yet - please rerun without the --align option')
        sys.exit()


    # check existence of command line specified input files
    if (cmdlinedata):
        if not (os.path.isfile(infile)):
            print('Input file {0} not found!'.format(infile))
            sys.exit()
        if not bondvectors == 'none':
            if not (os.path.isfile(bondvectors)):
                print('Bond vectors input file {0} not found!'.format(bondvectors))
                sys.exit()
        if not extravectors == 'none':
            if not (os.path.isfile(extravectors)):
                print('Extra bond vectors input file {0} not found!'.format(extravectors))
                sys.exit()


    # get lists of files to process
    # MOLECULAR GRAPHS
    filelist = []
    if (cmdlinedata):
        if not infile.endswith('.txt'):  # this is not a file list
            filelist.append(infile)
        else:                        # multiple input files specified in a list file
            with open(infile,'r') as listfile:
                rawlines = listfile.readlines()
            # filter comment lines and blank lines
            lines = [i.strip() for i in rawlines if not (i.startswith('#') or len(i.strip()) == 0) ]
            for line in lines:
                tokens = line.split()
                filelist.append(tokens[0])
        # Check that all input files in the input molecular graph file list exist
        for i in filelist:
            if not (os.path.isfile(i)):
                print('Input file {0} not found!'.format(i))
                sys.exit()

    # BOND VECTORS
    bvsetlist = []
    bvcolors = []
    if (cmdlinedata):
        if not bondvectors == 'none':
            if not bondvectors.endswith('.txt'):  # this is not a file list
                bvsetlist.append(bondvectors)
            else:                        # multiple input files specified in a list file
                with open(bondvectors,'r') as listfile:
                    rawlines = listfile.readlines()
                # filter comment lines and blank lines
                lines = [i.strip() for i in rawlines if not (i.startswith('#') or len(i.strip()) == 0) ]
                for line in lines:
                    tokens = line.split()
                    numtokens = len(tokens)
                    bvsetlist.append(tokens[0])
                    if numtokens > 1:
                        bvcolors.append(' '.join(tokens[1:]))
                    else:
                        bvcolors.append('')
            # Check that all input files in the input bondvector file list exist
            for i in bvsetlist:
                if not (os.path.isfile(i)):
                    print('Bond vector file {0} not found!'.format(i))
                    sys.exit()

    # EXTRA VECTORS
    extrasetlist = []
    extracolors = []
    if (cmdlinedata):
        if not extravectors == 'none':
            if not extravectors.endswith('.txt'):  # this is not a file list
                extrasetlist.append(extravectors)
            else:                        # multiple input files specified in a list file
                with open(extravectors,'r') as listfile:
                    rawlines = listfile.readlines()
                # filter comment lines and blank lines
                lines = [i.strip() for i in rawlines if not (i.startswith('#') or len(i.strip()) == 0) ]
                for line in lines:
                    tokens = line.split()
                    numtokens = len(tokens)
                    extrasetlist.append(tokens[0])
                    if numtokens > 1:
                        extracolors.append(' '.join(tokens[1:]))
                    else:
                        extracolors.append('')

            # Check that all input files in the input bondvector file list exist
            for i in extrasetlist:
                if not (os.path.isfile(i)):
                    print('Extra vector file {0} not found!'.format(i))
                    sys.exit()

    # ELEMENT DATA
    # make sure element data file exists, read in element property dictionaries
    if elementdata == 'none':  # use default element data location
        elementdatafile=os.path.join(os.path.abspath(os.path.dirname(__file__)), "jmol_element_colors.txt")
    else:                      # another data location is specified
        elementdatafile = elementdata
    print('Found element radii and JMol colours from {0}'.format(elementdatafile))
    eldata = get_element_data(elementdatafile)
    # Prepare a dictionary of element colour RGB triples
    atom_color_dict = get_element_property_dict(eldata, 'color')
    print('{0} element data items read'.format(len(atom_color_dict)))
    # prepare a dictionary of element radii
    if atomradius == 'covrad':
        print('Using covalent atom radii')
        atom_radius_dict = get_element_property_dict(eldata, 'covrad')
    elif atomradius == 'atmrad':
        print('Using atomic radii (default)')
        atom_radius_dict = get_element_property_dict(eldata, 'atmrad')
    elif atomradius == 'vdwrad':
        print('Using atomic VDW radii')
        atom_radius_dict = get_element_property_dict(eldata, 'vdwrad')
    print('  == Finished reading element data')
    # add entry to atom dictionaries for NNAs
    atom_radius_dict['NNA'] = 1.0
    atom_color_dict['NNA'] = [0.5, 0.5, 0.5]


    # now create a Model object and send all the data for visualization
    # modified - now send in list of molecular graph filenames instead of coordinate arrays
    my_model = MyModel(filelist,
                       atom_radius_dict, atom_color_dict,
                       bvsetlist, bvcolors,
                       extrasetlist, extracolors, vectorscale,
                       verbose, swap_pq)
    my_model.configure_traits()

if __name__ == '__main__':
    main()

# -*- coding: utf-8 -*-
"""setup.py: setuptools control."""

import re
from setuptools import setup

version = re.search(
    '^__version__\s*=\s*"(.*)"',
    open('topviz/topviz.py').read(),
    re.M
    ).group(1)

setup(
    name = "topviz",
    packages = ["topviz"],
    entry_points = {
        "console_scripts": ['topviz=topviz.topviz:main',]
        },
    version = version,
    include_package_data=True,
    author='Prof. Steven R. Kirk',
    author_email='stevenrkirk@gmail.com',
    description = "topviz",
    url = 'https://www.beaconresearch.org',
    install_requires=['numpy','molgraph','traits','traitsui','VTK','mayavi']
    )

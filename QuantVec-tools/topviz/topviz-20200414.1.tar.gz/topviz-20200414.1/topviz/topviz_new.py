# -*- coding: utf-8 -*-
"""
topviz
@author: steve
"""
# compatibility imports
from __future__ import print_function  # compatibility with Python 2.7
# standard imports
import sys, math, argparse
import os, os.path
# Traits imports
from traits.api import HasTraits, Range, Instance, Bool, Float, on_trait_change, Event
from traitsui.api import View, Item, Group, HGroup, VGroup
from traitsui.menu import Action, Menu, MenuBar, ToolBar
# Mayavi imports
from mayavi import mlab
from mayavi.core.api import PipelineBase
from mayavi.core.ui.api import MayaviScene, SceneEditor, MlabSceneModel
# custom imports
import numpy as np
import molgraph as mg  
                    
__version__ = "20180419.0001"     
                    
def get_element_data(datafile):
    '''
    From 'datafile', return element properties as list of lists
    '''
    eldata = []
    with open(datafile) as f:
        lines = f.readlines()
        for line in lines:
            if not(line.startswith('#') or line.strip() == ''):  # for all except comment lines and blank lines
                tokens = line.split()
                elnum = int(tokens[0])                     # Element atomic number
                elsym = tokens[1].strip()                  # Element symbol
                elcovrad = float(tokens[2])                # Element covalent radius
                elatmrad = float(tokens[3])                # Element atomic radius
                elvdwrad = float(tokens[4])                # Element VDW radius
                irgb = tokens[5].strip('[]').split(',')    # Element colour RGB contributions 0-255 [R,G,B]
                elfrgb = [ float(i)/255.0 for i in irgb]   # Element colour RGB contributions 0.0-1.0 [R,G,B]
                # add this element's data to the list
                eldata.append([elnum,elsym,elcovrad,elatmrad,elvdwrad,elfrgb])
    # sanity check
    if len(eldata) < 109:
        print('WARNING: found only {0} sets of element data in {1} - expected 109 or more'.format(len(eldata),datafile))    
    return eldata
    
def get_element_property_dict(eldata,field):
    '''
    Given 'eldata', a list of lists of element properties, return a dict of specific properties, selected by 'field', keyed by element symbol
    '''
    elcols = {}
    for element in eldata:
        elnum = element[0]
        elsym = element[1]
        elcovrad = element[2]
        elatmrad = element[3]
        elvdwrad = element[4]
        elfrgb = element[5]
        if field == 'color':
            elcols[elsym] = elfrgb
        elif field == 'covrad':
            elcols[elsym] = elcovrad
        elif field == 'atmrad':
            elcols[elsym] = elatmrad
        elif field == 'vdwrad':
            elcols[elsym] = elvdwrad
    return elcols
    
class NamedFieldPath(mg.FieldPath): 
   '''
   Derived class from molgraph FieldPath
   
   Parent class has fields
        self.description = ""
        self.path_x = []
        self.path_y = []
        self.path_z = []
        self.path_fieldvar = []
   '''
   pathtype = ''
   
   def __init__(self,px,py,pz,description,pathtype,path_fieldvar):
       super()
       self.path_x = px
       self.path_y = py
       self.path_z = pz
       self.description = description
       self.pathtype = pathtype
       self.path_fieldvar = path_fieldvar

class FramePathList():
    '''
    Class to hold list of NamedFramePath objects, and associated molecular graph file name
    '''
    pathlist = []
    framepathname = ''
    
    def __init__(self,pathlist,framepathname):
        self.pathlist = pathlist
        self.framepathname = framepathname
    
class MyModel(HasTraits):
    '''
    Model object
    '''
    # per sequence of frames
    graph_file_list = []     # list of molecular graph files
    path_file_list = []      # list of path files
    atom_radius_dict = None  # dict of atomsymbol:atom radii
    atom_colour_dist = None  # dict of atomsymbol:atom rendering colour
    framenames = []          # list of frames (input filenames holding molecular graphs)
    frames = []              # list of frames (molecular graphs)
    pathframes = []          # list of frame paths 
    numframes = 0            # number of frames
    currentframe = 0
    
    # per frame
    thismg = None
    #firstdraw = True
    atomx, atomy, atomz = None, None, None
    atomsize, atomcols, atomlabels = None, None, None
    cpx, cpy, cpz, cptype, cplabel = None, None, None, None, None
    bondpaths, iaspaths, paths, pathtypes = [], [], [], []
    thisnatoms, thisnumcps = 0, 0
    filename = None
    
    # PER_FRAME PLOT OBJECTS
    atomplot = None          # list of plot objects for atoms
    atomlabelsplot = []      # list of plot objects for atom labels
    cpplot = None            # Single plot object for all CPs
    bondplot = None          # Lists of plot objects for bond paths
    iaspathplot = None       # Lists of plot objects for IAS paths
    pathplot = None          # Lists of plot objects for other paths 
    numbondplot, numiasplot, numpathplot = 0,0,0
    
    # MAYAVI AND TRAITS 
    scene = Instance(MlabSceneModel, ())
    # GUI Floats (Traits) - sizes
    Atoms, CPs, Paths, Arrows, Text = Float(0.3), Float(0.15), Float(0.02), Float(1.0), Float(10.0) 
    # GUI toggles
    show_atoms, show_labels = Bool(True), Bool(True)                                             # atoms and labels
    show_cps = Bool(True)                                                                        # CPs
    show_bps, show_pps, show_qps = Bool(True), Bool(False), Bool(False)                          # p,q,r paths
    show_ppps, show_qpps = Bool(False), Bool(False)                                              # p`,q` primed paths
    show_iasev1s, show_iasev2s = Bool(False), Bool(False)                                        # IAS EV1, EV2 paths
    show_extraps = Bool(False)                                                                   # Extra paths
    show_parrows, show_qarrows = Bool(False), Bool(False)                                        # Arrows
    modelcolors =  {'NCP':(0.0,1.0,1.0),
                    'BCP':(0.0,1.0,0.0),
                    'RCP':(1.0,0.0,0.0),
                    'CCP':(0.0,0.0,1.0),
                    'bondpath':(0.0,0.0,0.0),
                    'iaspath': (0.75,0.75,0.75),
                    'p-path':(0.0,1.0,1.0),
                    'q-path':(1.0,0.5,1.0),
                    'p`-path':(0.0,1.0,1.0),
                    'q`-path':(1.0,0.5,1.0),
                    'extra p-path':(0.0,0.0,1.0),
                    'extra q-path':(1.0,0.0,0.0),                   
                    'background':(1.0,1.0,1.0),
                    'labelcolor':(0.0,0.0,0.0)
                    }                    
                    
    #atomplot = Instance(PipelineBase)
    stuff_action = Action(name='Flip', action='do_stuff')
    
    def do_stuff(self):
        print('flip')
        pass

    def __init__(self,graphlist,atom_radius_dict,atom_colour_dict,
                 bvsetlist, bvcolors, extrasetlist, extrasetcolors,
                 verboseflag):
        '''
        Initialize the Model object
        '''
        # Call the parent class __init__
        HasTraits.__init__(self)
        # Initialize object fields
        self.graph_file_list = graphlist
        self.atom_radius_dict = atom_radius_dict
        self.atom_colour_dict = atom_colour_dict
        self.pathr = []
        self.pathp = None
        self.pathq = None
        self.pathx = []
        self.bvsetlabels = None
        self.bvsetlist = bvsetlist
        self.bvcolors = bvcolors
        self.extrasetlist = extrasetlist
        self.extrasetcolors = extrasetcolors
        # set default background colour
        self.scene.scene.background=self.modelcolors['background']
        # now read the graphs
        self.read(verboseflag)        
        # trigger frame load
        self.loadframe()

    def read(self,verbose):
        '''
        Read molecular graphs, CPs, paths etc. into the model object
        '''
        verbose = True
        for i in self.graph_file_list:  # Read all molecular graphs into self.frames
            t = mg.Molgraph()           # make a new Molgraph object called 't'
            t.read(i)                   # fill our new object 't' with data from the input file
            if verbose:
                print('Read molecular graph from {0}'.format(i))
            self.frames.append(t)
        self.numframes = len(self.frames)
        
        # Bond path data and p,q,p`,q` paths
        bvsetcount = 0
        self.bvsetlabels = []

        print('Using {0} files with bond path vector data'.format(len(self.bvsetlist)))
        for bvset in self.bvsetlist:
            with open(bvset,'r') as bvsetfile:  # reading the next bond vectors file
                line = bvsetfile.readline()     # read first line of file
                while (line):
                    # First line of vector set currently contains no useful information
                    # Second line contains the input data file name 'Input file:'
                    line = bvsetfile.readline()
                    originmgfile = line[len('Input file: '):].strip()
                    # Third line contains a description
                    line = bvsetfile.readline()
                    if not line.startswith('Description:'):
                        print('Expected a Description: line in {0}'.format(bvset))
                        sys.exit()
                    description = line[len('Description:'):].strip()
                    numpathpoints = int(description.split()[0])
                    
                    if 'from BCP to' in description:  # this is a bond path, create and store a NamedFieldPath object
                        bcpname = bvsetfile.readline().split()[-1]
                        pathendname = bvsetfile.readline().split()[-1]
                        # skip 2 next lines
                        line = bvsetfile.readline()
                        line = bvsetfile.readline()
                        # save the next line for descriptive use
                        line = bvsetfile.readline()
                        if not line.startswith('Scaled'):  # trap
                            print('Expected a line starting with Scaled ..')
                            sys.exit()
                        description2 = line
                        # now retrieve the path
                        temp_px,temp_py,temp_pz,v1x,v1y,v1z,v2x,v2y,v2z = [],[],[],[],[],[],[],[],[]
                        for i in range(0,numpathpoints):
                            tokens = bvsetfile.readline().split()
                            temp_px.append(float(tokens[0]))
                            temp_py.append(float(tokens[1]))
                            temp_pz.append(float(tokens[2]))
                            v1x.append(float(tokens[3]))
                            v1y.append(float(tokens[4]))
                            v1z.append(float(tokens[5]))
                            v2x.append(float(tokens[6]))
                            v2y.append(float(tokens[7]))
                            v2z.append(float(tokens[8]))

                        if (verbose):
                            print('Read {0} path points from file: {1}'.format(numpathpoints,bvset))
                        # init: px,py,pz,description,pathtype,path_fieldvar
                        bvsetcount = bvsetcount + 1
                        partialdesc = ' '.join(description.split()[3:])
                        # create a new NamedFieldPath
                        nfp = NamedFieldPath(temp_px,temp_py,temp_pz,
                                             'Bondpath '+originmgfile+' '+bcpname+' -> '+pathendname+' '+partialdesc+' with '+description2,
                                             '0.0 0.0 0.0',
                                             [ v1x, v1y, v1z, v2x, v2y, v2z ])
                        nfp.type = 'Bondpath with vectors'
                        self.pathr.append(nfp)
                    line = bvsetfile.readline()
        
        print('Number of read bond paths = {0}'.format(bvsetcount))

        # EXTRA PATHS
        extrasetcount = 0
        print('Using {0} files with extra path vector data'.format(len(self.extrasetlist)))
        for extraset in self.extrasetlist:
            with open(extraset,'r') as extrasetfile:  # reading the next bond vectors file
                line = extrasetfile.readline()        # read first line of file
                while (line):
                    # First line of vector set currently contains no useful information
                    # Second line contains the input data file name 'Input file:'
                    line = extrasetfile.readline()
                    originmgfile = line[len('Input file: '):].strip()
                    # Third line contains a description
                    line = extrasetfile.readline()
                    if not line.startswith('Description:'):
                        print('Expected a Description: line in {0}'.format(extraset))
                        sys.exit()
                    description = line[len('Description:'):].strip()
                    numpathpoints = int(description.split()[0])
                    
                    if 'from BCP to' in description:  # this is a bond path, create and store a NamedFieldPath object
                        bcpname = extrasetfile.readline().split()[-1]
                        pathendname = extrasetfile.readline().split()[-1]
                        # skip 2 next lines
                        line = extrasetfile.readline()
                        line = extrasetfile.readline()
                        # save the next line for descriptive use
                        line = extrasetfile.readline()
                        if not line.startswith('Scaled'):  # trap
                            print('Expected a line starting with Scaled ..')
                            sys.exit()
                        description2 = line
                        # now retrieve the path
                        temp_px,temp_py,temp_pz,v1x,v1y,v1z,v2x,v2y,v2z = [],[],[],[],[],[],[],[],[]
                        for i in range(0,numpathpoints):
                            tokens = extrasetfile.readline().split()
                            temp_px.append(float(tokens[0]))
                            temp_py.append(float(tokens[1]))
                            temp_pz.append(float(tokens[2]))
                            v1x.append(float(tokens[3]))
                            v1y.append(float(tokens[4]))
                            v1z.append(float(tokens[5]))
                            v2x.append(float(tokens[6]))
                            v2y.append(float(tokens[7]))
                            v2z.append(float(tokens[8]))
                        # create a new NamedFieldPath
                        if (verbose):
                            print('Read {0} path points from file: {1}'.format(numpathpoints,extraset))
                        # init: px,py,pz,description,pathtype,path_fieldvar
                        extrasetcount = extrasetcount + 1
                        partialdesc = ' '.join(description.split()[3:])
                        nfp = NamedFieldPath(temp_px,temp_py,temp_pz,
                                             'Bondpath '+originmgfile+' '+bcpname+' -> '+pathendname+' '+partialdesc+' with '+description2,
                                             '0.0 0.0 0.0',
                                             [ v1x, v1y, v1z, v2x, v2y, v2z ])
                        nfp.pathtype = 'Extra bondpath with vectors'
                        self.pathx.append(nfp)
                    line = extrasetfile.readline()
             
    
    def loadframe(self):
        '''
        Load the current molecular graph and set number of atoms
        
        '''
        self.thismg = self.frames[self.currentframe]  # got the frame molecular graph, now extract its contents
        self.thisnatoms = len(self.thismg.atom_x)
        self.atomx = self.thismg.atom_x
        self.atomy = self.thismg.atom_y
        self.atomz = self.thismg.atom_z
        self.atomlabels = self.thismg.atom_label
        self.atomsymbols = [ i.strip('0123456789') for i in self.atomlabels ]
        self.atomsize = [self.atom_radius_dict[i] for i in self.atomsymbols ]
        self.atomcols = [self.atom_colour_dict[i] for i in self.atomsymbols ]

        # Store CPs for current frame 
        self.thiscplist = self.thismg.cplist
        self.thisnumcps = len(self.thismg.cplist)
        self.cpx, self.cpy, self.cpz, self.cptype, self.cplabel = [], [], [], [], []   # clear the CP arrays
        for cp in self.thiscplist:  # loop over this frame's CPs, store position, type, connectivity and BCP paths
            self.cpx.append(cp.pos_x)
            self.cpy.append(cp.pos_y)
            self.cpz.append(cp.pos_z)
            self.cptype.append(cp.type)
            self.cplabel.append(cp.connected)
            # If CP is a BCP, capture the path and IAS path information
            # IAS paths look like this
            # 492 sample points along IAS +EV1 path from BCP
            # 487 sample points along IAS -EV1 path from BCP
            # 463 sample points along IAS +EV2 path from BCP
            # 463 sample points along IAS -EV2 path from BCP
            if cp.type == 'BCP':
                thiscplabel = cp.connected
                if len(cp.pathlist) >0:  # has at least the bond path segments
                    # add BCP name to field path descriptions
                    cp.pathlist[0].description = thiscplabel + ' ' + cp.pathlist[0].description
                    cp.pathlist[1].description = thiscplabel + ' ' + cp.pathlist[1].description
                    self.bondpaths.append(cp.pathlist[0])  # as mg.FieldPath
                    self.bondpaths.append(cp.pathlist[1])  # as mg.FieldPath
                if len(cp.pathlist) >2:  # also has IAS paths
                    cp.pathlist[2].description = thiscplabel + ' ' + cp.pathlist[2].description
                    cp.pathlist[3].description = thiscplabel + ' ' + cp.pathlist[3].description
                    cp.pathlist[4].description = thiscplabel + ' ' + cp.pathlist[4].description
                    cp.pathlist[5].description = thiscplabel + ' ' + cp.pathlist[5].description
                    self.iaspaths.append(cp.pathlist[2])  # +IAS EV1
                    self.iaspaths.append(cp.pathlist[3])  # -IAS EV1
                    self.iaspaths.append(cp.pathlist[4])  # +IAS EV2
                    self.iaspaths.append(cp.pathlist[5])  # -IAS EV2

        # Add extra bond paths
        self.paths=[]
        for nfp in self.pathr:
            # build p,q,q',q' paths, add to pathplot
            px,py,pz,qx,qy,qz,ppx,ppy,ppz,qpx,qpy,qpz = [],[],[],[],[],[],[],[],[],[],[],[] 
            rx = nfp.path_x
            ry = nfp.path_y
            rz = nfp.path_z
            description_tail = nfp.description[len('Bondpath '):]
            v1x, v1y, v1z, v2x, v2y, v2z = nfp.path_fieldvar
            for i in range(0,len(rx)):
                px.append(rx[i] + v1x[i])    # p-path
                py.append(ry[i] + v1y[i])
                pz.append(rz[i] + v1z[i])
                ppx.append(rx[i] - v1x[i])   # p`-path
                ppy.append(ry[i] - v1y[i])
                ppz.append(rz[i] - v1z[i])
                qx.append(rx[i] + v2x[i])    # q-path
                qy.append(ry[i] + v2y[i])
                qz.append(rz[i] + v2z[i])
                qpx.append(rx[i] - v2x[i])   # q`-path
                qpy.append(ry[i] - v2y[i])
                qpz.append(rz[i] - v2z[i])
            originmgfile = ''
            newnfp1 = NamedFieldPath(px, py, pz,
                                    'p-path '+description_tail,
                                    '0.0 0.0 0.0',
                                    [ v1x, v1y, v1z, v2x, v2y, v2z ])
            newnfp1.pathtype = 'p-path with vectors'
            self.paths.append(newnfp1)
            newnfp2 = NamedFieldPath(ppx, ppy, ppz,
                                    'p`-path '+description_tail,
                                    '0.0 0.0 0.0',
                                    [ v1x, v1y, v1z, v2x, v2y, v2z ])
            newnfp2.pathtype = 'p`-path with vectors'
            self.paths.append(newnfp2)
            newnfp3 = NamedFieldPath(qx, qy, qz,
                                    'q-path '+description_tail,
                                    '0.0 0.0 0.0',
                                    [ v1x, v1y, v1z, v2x, v2y, v2z ])
            newnfp3.pathtype = 'q-path with vectors'
            self.paths.append(newnfp3) 
            newnfp4 = NamedFieldPath(qpx, qpy, qpz,
                                    'q`-path '+description_tail,
                                    '0.0 0.0 0.0',
                                    [ v1x, v1y, v1z, v2x, v2y, v2z ])
            newnfp4.pathtype = 'q`-path with vectors'
            self.paths.append(newnfp4)
            
        #    self.bondpaths = nfp  ### FIX THIS! - assumes one 
        # Now update the plot 
        print('paths now contains {0} paths'.format(len(self.paths)))
        
        # ADD EXTRA PATHS
        for nfp in self.pathx:
            # build p,q,q',q' paths, add to pathplot
            px,py,pz,qx,qy,qz,ppx,ppy,ppz,qpx,qpy,qpz = [],[],[],[],[],[],[],[],[],[],[],[] 
            rx = nfp.path_x
            ry = nfp.path_y
            rz = nfp.path_z
            description_tail = nfp.description[len('Bondpath '):]
            v1x, v1y, v1z, v2x, v2y, v2z = nfp.path_fieldvar
            for i in range(0,len(rx)):
                px.append(rx[i] + v1x[i])    # p-path
                py.append(ry[i] + v1y[i])
                pz.append(rz[i] + v1z[i])
                ppx.append(rx[i] - v1x[i])   # p`-path
                ppy.append(ry[i] - v1y[i])
                ppz.append(rz[i] - v1z[i])
                qx.append(rx[i] + v2x[i])    # q-path
                qy.append(ry[i] + v2y[i])
                qz.append(rz[i] + v2z[i])
                qpx.append(rx[i] - v2x[i])   # q`-path
                qpy.append(ry[i] - v2y[i])
                qpz.append(rz[i] - v2z[i])
            originmgfile = ''
            newnfp1 = NamedFieldPath(px, py, pz,
                                    'p-path Extra '+description_tail,
                                    '0.0 0.0 0.0',
                                    [ v1x, v1y, v1z, v2x, v2y, v2z ])
            newnfp1.pathtype = 'p-path Extra with vectors'
            self.paths.append(newnfp1)
            newnfp2 = NamedFieldPath(ppx, ppy, ppz,
                                    'p`-path Extra '+description_tail,
                                    '0.0 0.0 0.0',
                                    [ v1x, v1y, v1z, v2x, v2y, v2z ])
            newnfp2.pathtype = 'p`-path Extra with vectors'
            self.paths.append(newnfp2)
            newnfp3 = NamedFieldPath(qx, qy, qz,
                                    'q-path Extra '+description_tail,
                                    '0.0 0.0 0.0',
                                    [ v1x, v1y, v1z, v2x, v2y, v2z ])
            newnfp3.pathtype = 'q-path Extra with vectors'
            self.paths.append(newnfp3) 
            newnfp4 = NamedFieldPath(qpx, qpy, qpz,
                                    'q`-path Extra'+description_tail,
                                    '0.0 0.0 0.0',
                                    [ v1x, v1y, v1z, v2x, v2y, v2z ])
            newnfp4.pathtype = 'q`-path Extra with vectors'
            self.paths.append(newnfp4)
        
        print('Added all extra paths - now paths contains {0} paths'.format(len(self.paths)))        
        # Trigger creation of plotted items
        self.update_plot_atoms()  
        self.update_plot_cps()
        self.update_plot_paths()
        
        
    # When the scene is activated, or when the parameters are changed, we
    # update the plot using 'update_plot_*' methods below.
    
    @on_trait_change('Atoms,Text,show_atoms,show_labels,scene.activated')
    def update_plot_atoms(self):  # atom plotter method
        '''
        Draw atom spheres with radius and colour chosen by element name, optionally with text atom labels
        '''   
        if self.atomplot is None:  # Initial draw
            self.atomplot = []
            self.atomslabelplot = []            
            firstdraw = True
            for i in range(0,self.thisnatoms):  # DRAW ATOMS
                px = self.atomx[i]
                py = self.atomy[i]
                pz = self.atomz[i]
                plabel = self.atomlabels[i]
                ps = self.atomsize[i]*self.Atoms
                pcol = self.atomcols[i]
                thisatom = self.scene.mlab.points3d(px,py,pz,ps,
                                                    name='Atom '+plabel, resolution=32, color=tuple(pcol),
                                                    scale_mode='scalar',scale_factor=1.0)
                self.atomplot.append(thisatom)                                        
                if self.show_labels:
                    textobj = self.scene.mlab.text(px,py,plabel, z=pz, name='Label '+plabel,
                                                                    color=self.modelcolors['labelcolor'],width=self.Text*0.004)
                    textobj.property.bold = True
                    #textobj.property.justification = 'centered'
                    #textobj.property.vertical_justification = 'centered'                    
                    self.atomlabelsplot.append(textobj)
        else:                      # triggered on redraw
            for i in range(0,self.thisnatoms):  # redraw atoms
                self.atomplot[i].mlab_source.set(x=self.atomx[i],y=self.atomy[i],z=self.atomz[i],scalars=self.atomsize[i]*self.Atoms)
            for i in range(0,len(self.atomlabelsplot)):  # redraw text
                self.atomlabelsplot[i].width=self.Text*0.004
                #self.atomlabelsplot[i].property.justification = 'centered'
                #self.atomlabelsplot[i].property.vertical_justification = 'centered'                

        if self.show_atoms:  # set atoms visible/invisible
            for i in range (0,self.thisnatoms):
                self.atomplot[i].visible = True
        else:
            for i in range (0,self.thisnatoms):
                self.atomplot[i].visible = False
        
        if self.show_labels:  # set labels visible/invisible
            for i in range (0,self.thisnatoms):
                self.atomlabelsplot[i].visible = True
        else:
            for i in range (0,self.thisnatoms):
                self.atomlabelsplot[i].visible = False
            
    @on_trait_change('CPs,show_cps,scene.activated')        
    def update_plot_cps(self):  # CP plotter method
        '''
        Draw critical points
        '''
        if self.cpplot is None:  # first draw
            self.cpplot = [] 
            thisnumcps = self.thisnumcps       
            for j in range(0,thisnumcps):  # DRAW CPS
                px = self.cpx[j]
                py = self.cpy[j]
                pz = self.cpz[j]
                ps = [self.CPs]
                ptype = self.cptype[j]
                thiscplabel = self.cplabel[j]
                if ptype == 'BCP':   # BCPs are green
                    self.cpplot.append(self.scene.mlab.points3d(px,py,pz,ps,name='BCP '+thiscplabel,resolution=16,color=self.modelcolors['BCP'],
                                                                scale_mode='scalar',scale_factor=1.0) )
                elif (ptype == 'NCP' or ptype == 'NNACP' or ptype == 'NACP'):   # NCPs are cyan
                    self.cpplot.append(self.scene.mlab.points3d(px,py,pz,ps,name='NCP '+thiscplabel, resolution=16,color=self.modelcolors['NCP'],
                                                                scale_mode='scalar',scale_factor=1.0) )
                elif ptype == 'RCP':  # RCPs are red
                    self.cpplot.append(self.scene.mlab.points3d(px,py,pz,ps,name='RCP '+thiscplabel, resolution=16,color=self.modelcolors['RCP'],
                                                                scale_mode='scalar',scale_factor=1.0) )
                elif ptype == 'CCP':  # CCPs are blue
                    self.cpplot.append(self.scene.mlab.points3d(px,py,pz,ps,name='CCP '+thiscplabel, resolution=16,color=self.modelcolors['CCP'],
                                                                scale_mode='scalar',scale_factor=1.0) )
        else:                        # triggered on redraw
            for i in range(0,len(self.cpplot)):  # redraw CPs
                self.cpplot[i].mlab_source.set(x=self.cpx[i],y=self.cpy[i],z=self.cpz[i],scalars=self.CPs)
                
        if self.show_cps:  # toggle CP visibility        
            for i in range (0,self.thisnumcps):
                self.cpplot[i].visible = True
        else:
            for i in range (0,self.thisnumcps):
                self.cpplot[i].visible = False
                
    @on_trait_change('Paths,show_bps,show_pps,show_qps,show_ppps,show_qpps,show_iasev1s,show_iasev2s,show_extraps,scene.activated')
    def update_plot_paths(self):  # path plotter method
        '''
        Draw paths
        '''
        ############        
        # BOND PATHS        
        if self.bondplot is None:  # first draw
            self.bondplot = []
            for thispath in self.bondpaths:  # DRAW BOND PATHS 
                pathx = thispath.path_x
                pathy = thispath.path_y
                pathz = thispath.path_z
                dummypathscalars = [1.0]*len(pathx)
                self.bondplot.append(self.scene.mlab.plot3d(pathx, pathy, pathz, dummypathscalars,
                                                            color=self.modelcolors['bondpath'], name=thispath.description,
                                                            tube_radius=self.Paths, tube_sides=16))  # black 
        else:                        # triggered on redraw
            for bondplotobj in self.bondplot:  # redraw bond paths with new radius
                bondplotobj.parent.parent.filter.radius=self.Paths
                
        if self.show_bps:  # toggle bondpath visibility        
            for bondplotobj in self.bondplot:  # loop over bondplot objects, make visible
                bondplotobj.visible = True
        else:
            for bondplotobj in self.bondplot:  # loop over bondplot object, make invisible
                bondplotobj.visible = False

        ###########        
        # IAS PATHS
        if self.iaspathplot is None:  # first draw
            self.iaspathplot = []
            for thispath in self.iaspaths:  # DRAW IAS PATHS 
                pathx = thispath.path_x
                pathy = thispath.path_y
                pathz = thispath.path_z
                #print(thispath.description)
                dummypathscalars = [1.0]*len(pathx)
                self.iaspathplot.append(self.scene.mlab.plot3d(pathx, pathy, pathz, dummypathscalars,
                                                               color=self.modelcolors['iaspath'], name=thispath.description,
                                                               tube_radius=self.Paths, tube_sides=16))  # grey 
        else:                        # triggered on redraw
            for iasplotobj in self.iaspathplot:  # redraw bond paths with new radius
                iasplotobj.parent.parent.filter.radius=self.Paths
                
        # toggle IAS path visibility        
        if self.show_iasev1s:  # toggle IAS EV1 visibility        
            for iasplotobj in self.iaspathplot:  # loop over iasplot objects, make visible
                if 'EV1' in iasplotobj.parent.parent.parent.parent.name:
                    iasplotobj.visible = True
        else:
            for iasplotobj in self.iaspathplot:  # loop over iasplot object, make invisible
                if 'EV1' in iasplotobj.parent.parent.parent.parent.name:
                    iasplotobj.visible = False 
        if self.show_iasev2s:  # toggle IAS EV2 visibility        
            for iasplotobj in self.iaspathplot:  # loop over iasplot objects, make visible
                if 'EV2' in iasplotobj.parent.parent.parent.parent.name:
                    iasplotobj.visible = True
        else:
            for iasplotobj in self.iaspathplot:  # loop over iasplot object, make invisible
                if 'EV2' in iasplotobj.parent.parent.parent.parent.name:
                    iasplotobj.visible = False                    
        
        #################
        # p,p`,q,q` PATHS
        if self.pathplot is None:  # first draw
            self.pathplot = []
            for thispath in self.paths:  # DRAW PATHS (these should have 'pathtype' field)
                pathx = thispath.path_x
                pathy = thispath.path_y
                pathz = thispath.path_z
                pathtype = thispath.pathtype
                #print('Adding path: {0}'.format(pathtype))
                dummypathscalars = [1.0]*len(pathx)
                # construct and store path objects
                #
                if pathtype.startswith('p-path') and not 'xtra' in pathtype:   # build and add p-paths                
                    self.pathplot.append(self.scene.mlab.plot3d(pathx, pathy, pathz, dummypathscalars,
                                                                color=self.modelcolors['p-path'], name=thispath.description,
                                                                tube_radius=self.Paths, tube_sides=16))  # cyan
                elif pathtype.startswith('p`-path') and not 'xtra' in pathtype:  # build and add p`-paths 
                    self.pathplot.append(self.scene.mlab.plot3d(pathx, pathy, pathz, dummypathscalars,
                                                                color=self.modelcolors['p`-path'], name=thispath.description,
                                                                tube_radius=self.Paths, tube_sides=16))  # cyan
                elif pathtype.startswith('q-path') and not 'xtra' in pathtype:   # build and add q-paths 
                    self.pathplot.append(self.scene.mlab.plot3d(pathx, pathy, pathz, dummypathscalars,
                                                                color=self.modelcolors['q-path'], name=thispath.description,
                                                                tube_radius=self.Paths, tube_sides=16))  # magenta
                elif pathtype.startswith('q`-path') and not 'xtra' in pathtype:  # build and add q`-paths 
                    self.pathplot.append(self.scene.mlab.plot3d(pathx, pathy, pathz, dummypathscalars,
                                                                color=self.modelcolors['q`-path'], name=thispath.description,
                                                                tube_radius=self.Paths, tube_sides=16))  # magenta
                else:                      # general (extra) path-type, make lighter version of original colours
                    #thispathcolor = tuple(thispath.description.split()[0:2])  # first 3 items of description field are colour info
                    #self.pathplot.append(self.scene.mlab.plot3d(pathx, pathy, pathz, dummypathscalars,
                    #                                            color=thispathcolor, name='Extra path: '+thispath.description,
                    #                                            tube_radius=self.Paths, tube_sides=16))  # custom colour
                    if 'p-path' in pathtype and 'xtra' in pathtype:   # build and add extra p-paths                
                        self.pathplot.append(self.scene.mlab.plot3d(pathx, pathy, pathz, dummypathscalars,
                                                                    color=self.modelcolors['extra p-path'], name=thispath.description,
                                                                    tube_radius=self.Paths, tube_sides=16))  # cyan
                    #elif 'p`-path' in pathtype and 'xtra' in pathtype:  # build and add extra p`-paths 
                    #    self.pathplot.append(self.scene.mlab.plot3d(pathx, pathy, pathz, dummypathscalars,
                    #                                                color=(0.5,1.0,1.0), name=thispath.description,
                    #                                                tube_radius=self.Paths, tube_sides=16))  # cyan
                    elif 'q-path' in pathtype and 'xtra' in pathtype:   # build and add q-paths 
                        self.pathplot.append(self.scene.mlab.plot3d(pathx, pathy, pathz, dummypathscalars,
                                                                    color=self.modelcolors['extra q-path'], name=thispath.description,
                                                                    tube_radius=self.Paths, tube_sides=16))  # magenta
                    #elif 'q`-path' in pathtype and 'xtra' in pathtype:  # build and add q`-paths 
                    #    self.pathplot.append(self.scene.mlab.plot3d(pathx, pathy, pathz, dummypathscalars,
                    #                                                color=(1.0,0.5,1.0), name=thispath.description,
                    #                                                tube_radius=self.Paths, tube_sides=16))  # magenta                    
        else:                        # triggered on redraw
            for pathplotobj in self.pathplot:  # redraw bond paths with new radius
                pathplotobj.parent.parent.filter.radius=self.Paths
        
        # VISIBILITY
        # STANDARD P,Q PATHS
        #print(self.show_pps,self.show_qps,self.show_ppps,self.show_qpps)
        if self.show_pps:  # toggle p-path visibility        
            for bondplotobj in self.pathplot:  # loop over pathplot objects, make visible
                if 'p-path' in bondplotobj.parent.parent.parent.parent.name:  # P-path
                    bondplotobj.visible = True
        else:
            for bondplotobj in self.pathplot:  # loop over pathplot objects, make invisible
                if 'p-path' in bondplotobj.parent.parent.parent.parent.name:  # P-path
                    bondplotobj.visible = False
        if self.show_qps:  # toggle q-path visibility        
            for bondplotobj in self.pathplot:  # loop over pathplot objects, make visible
                if 'q-path' in bondplotobj.parent.parent.parent.parent.name:  # Q-path
                    bondplotobj.visible = True
        else:
            for bondplotobj in self.pathplot:  # loop over pathplot objects, make invisible
                if 'q-path' in bondplotobj.parent.parent.parent.parent.name:  # Q-path
                    bondplotobj.visible = False
                    
        # PRIMED P,Q PATHS
        if self.show_ppps:  # toggle p`-path visibility        
            for bondplotobj in self.pathplot:  # loop over pathplot objects, make visible
                if 'p`-path' in bondplotobj.parent.parent.parent.parent.name:  # P`-path
                    bondplotobj.visible = True
        else:
            for bondplotobj in self.pathplot:  # loop over pathplot objects, make invisible
                if 'p`-path' in bondplotobj.parent.parent.parent.parent.name:  # P`-path
                    bondplotobj.visible = False
                    
        if self.show_qpps:  # toggle q`-path visibility        
            for bondplotobj in self.pathplot:  # loop over pathplot objects, make visible
                if 'q`-path' in bondplotobj.parent.parent.parent.parent.name:  # Q`-path
                    bondplotobj.visible = True
        else:
            for bondplotobj in self.pathplot:  # loop over pathplot objects, make invisible
                if 'q`-path' in bondplotobj.parent.parent.parent.parent.name:  # Q`-path
                    bondplotobj.visible = False
                    
        # Extra PATHS
        if self.show_extraps:  # toggle q`-path visibility        
            for bondplotobj in self.pathplot:  # loop over pathplot objects, make visible
                if 'xtra' in bondplotobj.parent.parent.parent.parent.name:  #  extra path
                    bondplotobj.visible = True
        else:
            for bondplotobj in self.pathplot:  # loop over pathplot objects, make invisible
                if 'xtra' in bondplotobj.parent.parent.parent.parent.name:  # extra path
                    bondplotobj.visible = False        
                    
        #### Stuff for arrows
        #        if self.show_parrows:  # draw the two sets of q-arrows 
        #            self.scene.mlab.quiver3d(r1x,r1y,r1z,self.Arrows*v12x,self.Arrows*v12y,self.Arrows*v12z,
        #                                     color=(0.0,1.0,1.0),mode='arrow',scale_factor=self.Arrows, resolution=16,line_width=0.5)  # cyan
        #            self.scene.mlab.quiver3d(r2x,r2y,r2z,self.Arrows*v22x,self.Arrows*v22y,self.Arrows*v22z, 
        #                                     color=(0.0,1.0,1.0),mode='arrow',scale_factor=self.Arrows, resolution=16,line_width=0.5) cyan
    
    
    # ##########
    # GUI LAYOUT
    sidepanel1 = VGroup(Item('Atoms',width=60),
                        Item('CPs',width=60),
                        Item('Paths',width=60),
                        Item('Text',width=60),
                        label='Scales')
    sidepanel2 = VGroup(Item('show_atoms',label='Atoms',width=60),
                        Item('show_labels',label='Labels',width=60),
                        Item('show_cps',label='CPs',width=60),
                        Item('show_bps',label='Bond paths',width=60),
                        Item('show_iasev1s',label='IAS EV1 paths',width=60),
                        Item('show_iasev2s',label='IAS EV2 paths',width=60),
                        Item('show_pps',label='P-paths',width=60),
                        Item('show_qps',label='Q-paths',width=60),
                        Item('show_ppps',label='P`-paths',width=60),
                        Item('show_qpps',label='Q`-paths',width=60),
                        Item('show_extraps',label='Extra paths',width=60),
                        label='Visibility')
    topmenubar = MenuBar(Menu(stuff_action, name='File'))
    view = View(HGroup(
                       Item('scene', editor=SceneEditor(scene_class=MayaviScene), height=700, width=1000, show_label=False),
                       VGroup(sidepanel1,sidepanel2),
                      ),
                menubar = topmenubar,
                resizable=True, title='TopViz alpha version '+__version__ ,
                )
    
def main():
    '''
    Main
    '''
    # main code
    # Print information header
    print("==================================================")
    print('Version {0}'.format(__version__))
    print("Using molgraph version {0}".format(mg.__version__))    
    # argument parser
    parser = argparse.ArgumentParser(description="Visualize molecular graph files using Mayavi2\n"+
                                                 "=============================================")
    parser.add_argument("inputfile", help=".sumviz file or list file")
    parser.add_argument("--atomradius", help="Atom radius to use for atom spheres: covrad, atmrad, vdwrad [default: atmrad]", 
                                        default='atmrad')
    parser.add_argument("--bondvectors", help="Optional input file containing bond vectors [default: none]", 
                                         default='none')
    parser.add_argument("--extravectors", help="Optional input file containing extra vectors [default: none]", 
                                         default='none')
    parser.add_argument("--verbose", help="Print more verbose output",action='store_true') 
    parser.add_argument("--elementdata", help="Provide an explicit path to file containing element radius data  [default:use built-in data]",default='none')    

    # parse the arguments                                
    args = parser.parse_args()
    infile=args.inputfile
    verbose=args.verbose
    elementdata=args.elementdata
    atomradius = args.atomradius
    bondvectors = args.bondvectors
    extravectors = args.extravectors
    # check existence of command line specified input files
    if not (os.path.isfile(infile)):
        print('Input file {0} not found!'.format(infile))
        sys.exit()
    if not bondvectors == 'none':
        if not (os.path.isfile(bondvectors)):
            print('Bond vectors input file {0} not found!'.format(bondvectors))
            sys.exit()
    if not extravectors == 'none':
        if not (os.path.isfile(extravectors)):
            print('Extra bond vectors input file {0} not found!'.format(extravectors))
            sys.exit()        
  
    # get lists of files to process
    # MOLECULAR GRAPHS
    filelist = []
    if not infile.endswith('.txt'):  # this is not a file list
        filelist.append(infile)
    else:                        # multiple input files specified in a list file
        with open(infile,'r') as listfile:
            rawlines = listfile.readlines()
        # filter comment lines and blank lines
        lines = [i.strip() for i in rawlines if not (i.startswith('#') or len(i.strip()) == 0) ]         
        for line in lines:
            tokens = line.split()
            filelist.append(tokens[0])
    # Check that all input files in the input molecular graph file list exist
    for i in filelist:
        if not (os.path.isfile(i)):
            print('Input file {0} not found!'.format(i))
            sys.exit()

    # BOND VECTORS
    bvsetlist = []
    bvcolors = []
    if not bondvectors == 'none':
        if not bondvectors.endswith('.txt'):  # this is not a file list
            bvsetlist.append(bondvectors)
        else:                        # multiple input files specified in a list file
            with open(bondvectors,'r') as listfile:
                rawlines = listfile.readlines()
            # filter comment lines and blank lines
            lines = [i.strip() for i in rawlines if not (i.startswith('#') or len(i.strip()) == 0) ]         
            for line in lines:
                tokens = line.split()
                numtokens = len(tokens)
                bvsetlist.append(tokens[0])
                if numtokens > 1:
                    bvcolors.append(' '.join(tokens[1:]))
                else:
                    bvcolors.append('')
        # Check that all input files in the input bondvector file list exist
        for i in bvsetlist:
            if not (os.path.isfile(i)):
                print('Bond vector file {0} not found!'.format(i))
                sys.exit()

    # EXTRA VECTORS
    extrasetlist = []
    extracolors = []
    if not extravectors == 'none':
        if not extravectors.endswith('.txt'):  # this is not a file list
            extrasetlist.append(extravectors)
        else:                        # multiple input files specified in a list file
            with open(extravectors,'r') as listfile:
                rawlines = listfile.readlines()
            # filter comment lines and blank lines
            lines = [i.strip() for i in rawlines if not (i.startswith('#') or len(i.strip()) == 0) ]         
            for line in lines:
                tokens = line.split()
                numtokens = len(tokens)
                extrasetlist.append(tokens[0])
                if numtokens > 1:
                    extracolors.append(' '.join(tokens[1:]))
                else:
                    extracolors.append('')
                    
        # Check that all input files in the input bondvector file list exist
        for i in extrasetlist:
            if not (os.path.isfile(i)):
                print('Extra vector file {0} not found!'.format(i))
                sys.exit()               
    
    # ELEMENT DATA
    # make sure element data file exists, read in element property dictionaries
    if elementdata == 'none':  # use default element data location
        elementdatafile=os.path.join(os.path.abspath(os.path.dirname(__file__)),"jmol_element_colors.txt")
    else:                      # another data location is specified
        elementdatafile = elementdata
    print('Found element radii and JMol colours from {0}'.format(elementdatafile))        
    eldata = get_element_data(elementdatafile)
    # Prepare a dictionary of element colour RGB triples
    atom_color_dict = get_element_property_dict(eldata,'color')
    print('{0} element data items read'.format(len(atom_color_dict)))
    # prepare a dictionary of element radii
    if atomradius == 'covrad':
        print('Using covalent atom radii')
        atom_radius_dict = get_element_property_dict(eldata,'covrad')
    elif atomradius == 'atmrad':
        print('Using atomic radii (default)')
        atom_radius_dict = get_element_property_dict(eldata,'atmrad')
    elif atomradius == 'vdwrad':
        print('Using atomic VDW radii')
        atom_radius_dict = get_element_property_dict(eldata,'vdwrad')
    print('  == Finished reading element data')         
        
    # now create a Model object and send all the data for visualization
    # modified - now send in list of molecular graph filenames instead of coordinate arrays        
    my_model = MyModel(filelist, atom_radius_dict, atom_color_dict, bvsetlist, bvcolors,
                                                                    extrasetlist, extracolors, verbose)
    my_model.configure_traits()
        
if __name__ == '__main__':
    main()    